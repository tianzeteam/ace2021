package com.yuejike.generator.dao;

import com.yuejike.generator.domain.GenTableColumn;

import java.util.List;

public interface GenTableColumnDaoCustom {

    List<GenTableColumn> findDbTableColumnsByName(String tableName);

}
