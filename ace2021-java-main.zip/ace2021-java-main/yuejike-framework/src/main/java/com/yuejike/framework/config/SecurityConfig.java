package com.yuejike.framework.config;

import com.yuejike.framework.handler.LoginAuthenticationProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.logout.LogoutFilter;
import org.springframework.web.filter.CorsFilter;
import com.yuejike.framework.security.filter.JwtAuthenticationTokenFilter;
import com.yuejike.framework.security.handle.AuthenticationEntryPointImpl;
import com.yuejike.framework.security.handle.LogoutSuccessHandlerImpl;

/**
 * spring security配置
 *
 * @author yuejike
 */
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {
    /**
     * 自定义用户认证逻辑
     */
    @Autowired
    @Qualifier("userDetailsByPassword")
    private UserDetailsService userDetailsService;

    @Autowired
    @Qualifier("userDetailsByOtherLogin")
    private UserDetailsService userDetailsByOtherLoginService;

    /**
     * 认证失败处理类
     */
    @Autowired
    private AuthenticationEntryPointImpl unauthorizedHandler;

    /**
     * 退出处理类
     */
    @Autowired
    private LogoutSuccessHandlerImpl logoutSuccessHandler;

    /**
     * token认证过滤器
     */
    @Autowired
    private JwtAuthenticationTokenFilter authenticationTokenFilter;

    /**
     * 跨域过滤器
     */
    @Autowired
    private CorsFilter corsFilter;

    /**
     * 解决 无法直接注入 AuthenticationManager
     *
     * @return
     * @throws Exception
     */
    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    /**
     * anyRequest          |   匹配所有请求路径
     * access              |   SpringEl表达式结果为true时可以访问
     * anonymous           |   匿名可以访问
     * denyAll             |   用户不能访问
     * fullyAuthenticated  |   用户完全认证可以访问（非remember-me下自动登录）
     * hasAnyAuthority     |   如果有参数，参数表示权限，则其中任何一个权限可以访问
     * hasAnyRole          |   如果有参数，参数表示角色，则其中任何一个角色可以访问
     * hasAuthority        |   如果有参数，参数表示权限，则其权限可以访问
     * hasIpAddress        |   如果有参数，参数表示IP地址，如果用户IP和参数匹配，则可以访问
     * hasRole             |   如果有参数，参数表示角色，则其角色可以访问
     * permitAll           |   用户可以任意访问
     * rememberMe          |   允许通过remember-me登录的用户访问
     * authenticated       |   用户登录后可访问
     */
    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        httpSecurity
                // CSRF禁用，因为不使用session
                .csrf().disable()
                // 认证失败处理类
                .exceptionHandling().authenticationEntryPoint(unauthorizedHandler).and()
                // 基于token，所以不需要session
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
                // 过滤请求
                .authorizeRequests()
                // 对于登录login 验证码captchaImage 允许匿名访问
                .antMatchers("/login*", "/captchaImage").permitAll()
                .antMatchers(
                        HttpMethod.GET,
                        "/*.html",
                        "/**/*.html",
                        "/**/*.css",
                        "/**/*.js"
                ).permitAll()
                .antMatchers("/oauth/**").permitAll()
                .antMatchers("/v2/oauth/**").permitAll()
                .antMatchers("/v3d/web/**").permitAll()
                .antMatchers("/dev-api/**").permitAll()
                .antMatchers("/favicon.ico").permitAll()
                .antMatchers("/register").permitAll()
                .antMatchers("/v2/register").anonymous()
                .antMatchers("/profile/**").permitAll()
                .antMatchers("/common/download**").permitAll()
                .antMatchers("/common/download/resource**").permitAll()
                .antMatchers("/swagger-ui.html").anonymous()
                .antMatchers("/doc.html").anonymous()
                .antMatchers("/swagger-resources/**").anonymous()
                .antMatchers("/webjars/**").anonymous()
                .antMatchers("/*/api-docs").anonymous()
                .antMatchers("/sendCode").permitAll()
                .antMatchers("/druid/**").permitAll()
                .antMatchers("/cms/category/**").permitAll()
                .antMatchers("/cms/content/**").permitAll()
                .antMatchers("/cms/banner/**").permitAll()
                .antMatchers("/cms/plan/**").permitAll()
                .antMatchers("/cms/classification/**").permitAll()
                .antMatchers("/cms/exhibitor/**").permitAll()
                .antMatchers("/cms/product/**").permitAll()
                .antMatchers("/cms/conference/**").permitAll()
                .antMatchers("/cms/enroll/**").permitAll()
                .antMatchers("/system/dict/**").permitAll()
                .antMatchers("/cms/label/**").permitAll()
                .antMatchers("/cms/live/getClassStatus").permitAll()
                .antMatchers("/cms/notice/list").permitAll()
                .antMatchers("/cms/inbox/ui/list").permitAll()
                .antMatchers("/cms/live/ui/list").permitAll()
                .antMatchers("/cms/live/appointment").permitAll()
                .antMatchers("/**/ui/list").permitAll()
                .antMatchers("/cms/exposition/list").permitAll()
                .antMatchers("/cms/live/*").permitAll()
                .antMatchers("/cms/statistical/*").permitAll()
                .antMatchers("/system/config/configKey/*").permitAll()
                .antMatchers("/system/user/profile/retrievePwd").permitAll()
                .antMatchers("/cms/productCategory/treeselect").permitAll()
                .antMatchers("/monitor/access/**").permitAll()
                .antMatchers("/fullText/search").permitAll()
                .antMatchers("/v3d/userInf/**").permitAll()
                .antMatchers("/cms/industry/**").permitAll()
                .antMatchers("/cms/qrcode/**").permitAll()
                // 除上面外的所有请求全部需要鉴权认证
                .anyRequest().authenticated()
                .and()
                .headers().frameOptions().disable();
        httpSecurity.logout().logoutUrl("/logout").logoutSuccessHandler(logoutSuccessHandler);
        // 添加JWT filter
        httpSecurity.addFilterBefore(authenticationTokenFilter, UsernamePasswordAuthenticationFilter.class);
        // 添加CORS filter
        httpSecurity.addFilterBefore(corsFilter, JwtAuthenticationTokenFilter.class);
        httpSecurity.addFilterBefore(corsFilter, LogoutFilter.class);
    }


    /**
     * 强散列哈希加密实现
     */
    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * 身份认证接口
     */
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        //其他登录方式的验证
        auth.authenticationProvider(new LoginAuthenticationProvider(userDetailsByOtherLoginService));
        //账号密码的验证
        auth.userDetailsService(userDetailsService).passwordEncoder(bCryptPasswordEncoder());
    }
}
