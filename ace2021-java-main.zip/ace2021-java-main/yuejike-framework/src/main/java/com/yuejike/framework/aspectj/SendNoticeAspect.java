package com.yuejike.framework.aspectj;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.yuejike.cms.domain.SysInbox;
import com.yuejike.cms.service.ISysInboxService;
import com.yuejike.common.annotation.Message;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.enums.NoticeType;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.common.utils.spring.SpringUtils;
import com.yuejike.framework.manager.AsyncManager;
import com.yuejike.framework.manager.factory.AsyncFactory;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.system.domain.SysNotice;
import com.yuejike.system.service.ISysNoticeService;
import com.yuejike.system.service.ISysUserService;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Aspect
@Order(10000)
@Component
public class SendNoticeAspect {
    private static final Logger log = LoggerFactory.getLogger(SendNoticeAspect.class);

    @Pointcut("@annotation(com.yuejike.common.annotation.Message)")
    public void SendNoticeCut(){

    }

    @AfterReturning(pointcut = "SendNoticeCut()", returning = "jsonResult")
    public void doAfterReturning(JoinPoint joinPoint, Object jsonResult)
    {
        sendNotice(joinPoint, null, jsonResult);
    }


    public void sendNotice(JoinPoint joinPoint,final Exception e, Object jsonResult){
        try {
            Message message = getAnnotation(joinPoint);
            String result = JSON.toJSONString(jsonResult);
            JSONObject jsonObject = JSONObject.parseObject(result);
            if(jsonObject.get("data") != null){
                JSONObject data = (JSONObject) jsonObject.get("data");
                System.out.println(data.get("userId")+"---userId--");
                System.out.println(data+"--------data--------");
                //添加到noticeAndInbox
                saveNotice(message,data);
                AsyncManager.me().execute(AsyncFactory.sendMsg(message));
            }
        }catch (Exception ex){
            log.error(StringUtils.format("消息通知：{},stack:{}",ex.getMessage(),ex.getStackTrace()));
        }

    }
    //添加到通知表中
    private void saveNotice(Message message,JSONObject data){
         // 获取当前的用户
        LoginUser loginUser = SpringUtils.getBean(TokenService.class).getLoginUser(ServletUtils.getRequest());
        Long userId=null;
        //添加到notice表中
        SysNotice notice = new SysNotice();
        String title ="";
        if(null != loginUser && StringUtils.isNotBlank(loginUser.getUser().getNickName())){
             title = "【"+loginUser.getUser().getNickName()+"】"+ message.title();
        }else{
            title = message.title();
        }
        notice.setNoticeTitle(title);
        notice.setNoticeType(String.valueOf(message.noticeType().getCode()));
        List<SysUser> sysUserList = new ArrayList<>();
        if(message.noticeType().getCode() == NoticeType.REVIEW.getCode()){//认证通知
            notice.setNoticeContent(message.content());
            userId = Long.valueOf(data.get("userId").toString());
            String msg ="";
            //短信通知
            // if(data.getString("reviewStatus").equals("1")){
            //     msg ="【中国(芜湖)科普产品博览交易会】恭喜您，您的认证信息已通过审核。";
            // }else if(data.getString("reviewStatus").equals("2")){
            //     if(StringUtils.isNotBlank(data.getString("rejectReason"))){
            //         msg ="【中国(芜湖)科普产品博览交易会】非常抱歉，您的认证信息不符合要求，原因："+ data.getString("rejectReason") +"，请重新提交。";
            //     }else{
            //         msg ="【中国(芜湖)科普产品博览交易会】非常抱歉，您的认证信息不符合要求，请重新提交。";
            //     }
            // }
            // RetMsg retMsg = XinXinSmsUtils.getInstance().sendBussiMsg(data.getString("phonenumber"),msg);
            // System.out.println(retMsg+"-------retMsg--------");
        }else if(message.noticeType().getCode() == NoticeType.CONFERENCE.getCode()){//参会凭证
            userId = Long.valueOf(data.get("userId").toString());
            if(data.get("status").equals("1")){
                notice.setNoticeContent(loginUser.getUser().getNickName()+"邀请您参加线下展会,请到我的参会凭证里查看。");
            }else if(data.get("status").equals("2")){
                notice.setNoticeContent("您提交的'"+ data.get("conferenceName")+"'线下展会审核未通过,请重新报名。");
            }
        }else if(message.noticeType().getCode() == NoticeType.ORDER.getCode()){//询盘回复
            userId =Long.valueOf(data.get("buyerId").toString());
            notice.setNoticeContent(data.get("exhibitorName")+"回复了您的询盘记录,请到询盘记录中查看。");
        }else if(message.noticeType().getCode() == NoticeType.NEGOTIATE.getCode()){//洽谈沟通
            userId = Long.valueOf(data.get("sendId").toString());//客户id
            //商家id
            notice.setNoticeContent(loginUser.getUser().getNickName()+ "回复了您的洽谈记录,请到洽谈记录中查看。");
        }else if(message.noticeType().getCode() == NoticeType.LIVE.getCode()){//直播通知
            if(StringUtils.isNotBlank(data.getString("empower"))) {
                notice.setAcceptType(data.getString("empower"));
                String[] empowers = data.get("empower").toString().split(",");
                for (String userType : empowers) {
                    //根据用户类型查询用户列表
                    List<SysUser> userList = SpringUtils.getBean(ISysUserService.class).findByUserTypeAndReviewStatus(userType, "1", loginUser.getUser().getExpositionId());
                    sysUserList.addAll(userList);
                }
            }
            if(StringUtils.isNotBlank(data.getString("groupId"))){
                notice.setGroupId(data.getString("groupId"));
                String[] groupIds = data.get("groupId").toString().split(",");
                for (String groupId : groupIds) {
                    //根据分组id查询用户列表
                    List<SysUser> groupUserList = SpringUtils.getBean(ISysUserService.class).findByGroupId(Long.valueOf(groupId));
                    sysUserList.addAll(groupUserList);
                }
            }
            SimpleDateFormat sdf =new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss" );
            String str = sdf.format(data.get("startTime"));
            notice.setNoticeContent("主办方邀请您与"+ str +"参加特定直播,请到直播中查看。");
        }else if(message.noticeType().getCode() == NoticeType.CONTRIBUTION.getCode()){//审核投稿
            if(data.getString("reviewStatus").equals("1")){
                notice.setNoticeContent("您投递的稿子审核已经通过，可到新闻中心去查看。");
            }else if(data.getString("reviewStatus").equals("2")){
                notice.setNoticeContent("您投递的稿子已被审批拒绝，请到在线投稿重新申请。");
            }
            userId = Long.valueOf(data.get("createId").toString());
        }
        notice.setCreateId(loginUser.getUser().getUserId());
        notice.setCreateBy(loginUser.getUser().getUserName());
        notice.setStatus("0");
        if(loginUser.getUser().getUserType().equals(UserType.ADMIN.getCode()) ){
            notice.setCreateType("0");
        }else if(loginUser.getUser().getUserType().equals(UserType.ZBF.getCode())){
            notice.setCreateType("1");
        }else if(loginUser.getUser().getUserType().equals(UserType.CZS.getCode())){
            notice.setCreateType("2");
        }
        notice.setCreateTime(new Date());
        notice.setExpositionId(loginUser.getUser().getExpositionId());
        // 添加notice数据
        SysNotice sysNotice = SpringUtils.getBean(ISysNoticeService.class).save(notice);
        // 添加inbox表
        if(message.noticeType().getCode() ==10){
            if(sysUserList.size() > 0){
                //去重操作
                List<SysUser> myList = sysUserList.stream().distinct().collect(Collectors.toList());
                new Thread() {
                    public void run() {
                        try {
                            for (SysUser user:myList) {
                                saveInbox(sysNotice, user.getUserId(), loginUser);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    };
                }.start();
            }
        }else{
            saveInbox(sysNotice,userId,loginUser);
        }
    }
    //添加到个人消息表中
    private void saveInbox(SysNotice notice,Long userId,LoginUser loginUser){
        //插入sys_inbox
        SysInbox inbox = new SysInbox();
        inbox.setNoticeId(notice.getNoticeId().longValue());
        inbox.setSendId(loginUser.getUser().getUserId());
        inbox.setCreateBy(loginUser.getUser().getUserName());
        inbox.setStatus("0");
        inbox.setDelFlag("0");
        inbox.setAcceptId(userId);//接收人
        SpringUtils.getBean(ISysInboxService.class).save(inbox);
    }

    /**
     * 是否存在注解，如果存在就获取
     */
    private Message getAnnotation(JoinPoint joinPoint) throws Exception
    {
        Signature signature = joinPoint.getSignature();
        MethodSignature methodSignature = (MethodSignature) signature;
        Method method = methodSignature.getMethod();

        if (method != null)
        {
            return method.getAnnotation(Message.class);
        }
        return null;
    }
}
