function nxtFpLoad(){
	var id="nxtIdMain";
	var nxtScriptMain=document.getElementById(id);
	if(nxtScriptMain){
	 	nxtScriptMain.parentNode.removeChild(nxtScriptMain);
	}
	nxtScriptMain= document.createElement("script");
	nxtScriptMain.type = "text/javascript";
	nxtScriptMain.src = NXT_MAIN_URL;
	nxtScriptMain.id = id;
	var firstScript = document.getElementsByTagName('script')[0];
	    firstScript.parentNode.insertBefore(nxtScriptMain,firstScript);
};
nxtFpLoad();

function nxtRefresh(){
	try {
		var id="nxtIdExpire";
		var nxtScriptExpire=document.getElementById(id);
		if(nxtScriptExpire){
			nxtScriptExpire.parentNode.removeChild(nxtScriptExpire);
		}
		nxtScriptExpire=document.createElement("script");
		nxtScriptExpire.type = "text/javascript";
		nxtScriptExpire.src = NXT_EXPIRE_URL;
		nxtScriptExpire.id = id;
		var firstScript = document.getElementsByTagName("script")[0];
		   firstScript.parentNode.appendChild(nxtScriptExpire);
		} catch(e){
			console.log("nxtRefresh() "+e);
		}
};

function nxtFingerJsLoad(fingerJsUrl){
	var nxtScriptFp=document.getElementById("nxtIdFingerJs");
	if(nxtScriptFp){
		nxtScriptFp.parentNode.removeChild(nxtScriptFp);
	}
	var nxtScriptFp= document.createElement("script");
		nxtScriptFp.type = "text/javascript";
		nxtScriptFp.id = "nxtIdFingerJs";
		nxtScriptFp.src = fingerJsUrl;
		nxtScriptFp.async = 1;
	var firstScript = document.getElementsByTagName('script')[0];
		firstScript.parentNode.insertBefore(nxtScriptFp,firstScript);
}

var timer = setTimeout(function() { 
	nxtRefresh();
	timer = setTimeout(arguments.callee, 120000)
}, 120000);