package com.yuejike.common.utils.sms.newxtc.fw.client.util;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CookieUtil {

	private final static Logger logger = LoggerFactory.getLogger(CookieUtil.class);

	public void setCookie(HttpServletResponse response, String domain, int expireTime, String name, String value) {
		// 如果value不为空，写入cookie
		if (StringUtils.isNotBlank(value)) {
			Cookie cookie = new Cookie(name, value);
			cookie.setPath("/");
			if (domain != null && !domain.isEmpty())
				cookie.setDomain(domain);
			cookie.setMaxAge(expireTime);
			response.addCookie(cookie);
		}
	}

	public void setCookie(HttpServletResponse response, String name, String value) {
		// 如果value不为空，写入cookie
		if (StringUtils.isNotBlank(value)) {
			Cookie cookie = new Cookie(name, value);
			cookie.setPath("/");
			response.addCookie(cookie);
		}
	}

	public String getCookie(HttpServletRequest request, String name) {
		if (name == null || "".equals(name)) {
			logger.error("getCookie() name=" + name);
			return null;
		}
		Map<String, String> cookieMap = new HashMap<String, String>();
		try {
			Cookie[] cookieArray = request.getCookies();
			String cookieName = null, cookieValue = null;
			if (cookieArray != null && cookieArray.length > 0) {
				for (Cookie cookie : request.getCookies()) {
					cookieName = cookie.getName();
					cookieValue = cookie.getValue();
					if (cookieName != null && cookieValue != null) {
						cookieMap.put(cookieName.trim(), cookieValue.trim());
					}
				}
			}
			String ret = cookieMap.get(name);
			if (ret != null) {
				return ret;
			} else {
				return null;
			}
		} catch (Exception e) {
			logger.error("getCookie() name=" + name + " cookieMap=" + cookieMap + " e=" + e.toString());
			return null;
		}
	}

	public void removeCookie(HttpServletRequest request, HttpServletResponse response, String domain, String name) {
		try {
			Cookie cookie = new Cookie(name, null);
			if (domain != null)
				cookie.setDomain(domain);
			cookie.setPath("/");
			cookie.setMaxAge(0);
			response.addCookie(cookie);
			logger.debug("removeCookie cookie=" + cookieToString(cookie));
		} catch (Exception e) {
			logger.error("removeCookie() error=" + e);
		}
	}

	private String cookieToString(Cookie cookie) {
		if (cookie == null)
			return "null";
		return "Cookie[name=" + cookie.getName() + ", value=" + cookie.getValue() + ", domain=" + cookie.getDomain() + ", path=" + cookie.getPath() + ", " + cookie.getMaxAge() + "]";
	}

	public String getDomain(HttpServletRequest request) {
		return request.getServerName();
	}

	public String getDomain(HttpServletRequest request, List<String> exclude) {
		return getDomainByInfo(request.getServerName(), exclude);
	}

	private String getDomainByInfo(String domain, List<String> exclude) {
		for (String host : exclude)
			if (domain != null && domain.contains(host))
				return domain.replaceFirst(host, "");
		return domain;
	}

	public static void main(String[] args) {
		CookieUtil cookieUtil = new CookieUtil();
		List<String> exclude = Arrays.asList("www", "fp");
		String s = cookieUtil.getDomainByInfo("www.newxtc.com", exclude);
		System.out.println(s);
		s = cookieUtil.getDomainByInfo("newxtc.com", exclude);
		System.out.println(s);
		s = cookieUtil.getDomainByInfo("fp.newxtc.com", exclude);
		System.out.println(s);
	}
}
