package com.yuejike.common.enums;

/**
 * 注册类型
 *
 * @author yuejike
 */
public enum RegisterType {

    MOBILE(0, "手机号"), EMAIL(1, "email");
    private final int code;
    private final String info;

    RegisterType(int code, String info) {
        this.code = code;
        this.info = info;
    }

    public int getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }
}
