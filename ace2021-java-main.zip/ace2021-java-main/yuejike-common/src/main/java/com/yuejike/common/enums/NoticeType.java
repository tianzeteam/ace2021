package com.yuejike.common.enums;

/**
 * @author song
 * @date 2021年09月23日 16:57
 */
public enum NoticeType {
    NOTICE(1, "通知"), BULLETIN(2, "公告"),STATIONLETTER(3,"站内信"),TEXTMESSAGE(4,"短信"),
    LETTERANDMESSAGE(5,"站内信和短信"),REVIEW(6,"认证通知"),ORDER(7,"询盘回复通知"),
    NEGOTIATE(8,"洽谈回复通知"),CONFERENCE(9,"参会凭证通知"),LIVE(10,"特定直播通知"),CONTRIBUTION(11,"审核投稿通知");

    private final int code;
    private final String info;

    NoticeType(int code, String info) {
        this.code = code;
        this.info = info;
    }

    public int getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }

}
