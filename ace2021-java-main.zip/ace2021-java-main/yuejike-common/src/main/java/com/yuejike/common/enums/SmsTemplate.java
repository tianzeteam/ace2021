package com.yuejike.common.enums;

/**
 * 短信模板
 *
 * @author yuejike
 */
public enum SmsTemplate {
    /**
     * 短信验证码
     */
    CAPTCHA("4829694","验证码：${code}，有效期为5分钟。请勿向他人泄露验证码，如非本人操作，请忽略本短信。"),

    /**
     * 参会凭证通知
     */
    CHPZTZ("4829982","${name}邀请您参加线下展会，请到我的参会凭证中查看。"),

    /**
     * 认证通知
     */
    RZTZ("4830002","您提交的${userType}审核${reviewStatus}，请到认证记录中查看详情。"),

    /**
     * 线下展会未通过通知
     */
    XXZHWTGTZ("4829990","您提交的${conferenceName}线下展会审核未通过，请重新报名。"),

    /**
     * 直播邀请通知
     */
    ZBYQTZ("4830000","主办方邀请您于${time}参加特定直播，请到直播中查看。"),

    /**
     * 回复通知
     */
    HFTZ("4830008","${exhibitorName}回复了您的${record}，请到${record}中查看。");

    private final String code;
    private final String info;

    SmsTemplate(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }
}
