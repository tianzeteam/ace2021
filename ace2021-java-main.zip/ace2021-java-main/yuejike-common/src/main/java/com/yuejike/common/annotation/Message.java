package com.yuejike.common.annotation;

import com.yuejike.common.enums.NoticeType;

import java.lang.annotation.*;

@Target({ElementType.PARAMETER, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Message {

    String title() default "";

    String content() default "";

    String phone() default "";

    NoticeType noticeType() default NoticeType.NOTICE;


}
