package com.yuejike.common.utils.sms.newxtc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Properties;

import javax.servlet.ServletContextEvent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 短信参数类
 */
public class NxtInit {
	private final static Logger logger = LoggerFactory.getLogger(NxtInit.class);

	private static Properties prop = new Properties();
	private StringBuffer desJs = new StringBuffer();
	private StringBuffer fpJs = new StringBuffer();
	private static NxtInit nxtInit = null;

	public synchronized static NxtInit getInstance() {
		if (nxtInit == null) {
			nxtInit = new NxtInit();
		}
		return nxtInit;
	}

	/**
	 * 标准初始化方式 设备指纹 + 防火墙接口
	 * 
	 * @param configPath
	 */
	public void init(String configPath) {
		loadConf(configPath);
		loadJs(configPath, "tripledes.js", desJs);
		loadJs(configPath, "fp.js", fpJs);
	}

	public String getIni(String key) {
		String value = prop.getProperty(key);
		return value;
	}

	public Boolean getIniBoolean(String key) {
		String value = prop.getProperty(key);
		return value != null && "true".equals(value);
	}

	public void setIni(String key, String value) {
		System.out.println("NxtInit setIni key=" + key + "|value=" + value);
		prop.setProperty(key, value);
	}

	public String getDesJs() {
		return desJs.toString();
	}

	public String getfPJs() {
		return fpJs.toString();
	}

	public String getUrl(String key) {
		String url = prop.getProperty(key);
		if (url != null && url.indexOf("http") >= 0) {
			if (!url.endsWith("/")) {
				url = url + "/";
			}
			return url;
		} else {
			return null;
		}
	}

	public void contextDestroyed(ServletContextEvent event) {
	}

	private void loadJs(String configPath, String configName, StringBuffer cacheJs) {
		InputStream infile = null;
		StringBuffer js = new StringBuffer();
		try {
			if (configPath == null) {
				infile = Thread.currentThread().getContextClassLoader().getResourceAsStream(configName);
			} else {
				infile = new FileInputStream(configPath + File.separator + configName);
			}
			InputStreamReader inPutStream = (infile != null) ? new InputStreamReader(infile) : null;
			BufferedReader bufferedReader = (inPutStream != null) ? new BufferedReader(inPutStream) : null;
			if (bufferedReader != null) {
				String line = null;
				while ((line = bufferedReader.readLine()) != null) {
					js.append(line);
				}
				cacheJs.append(js.toString());
				bufferedReader.close();
				System.out.println("load " + configName + " OK Len=" + cacheJs.length());
			} else {
				System.out.println("load " + configName + ",bufferedReader=" + bufferedReader);
			}
		} catch (Exception e) {
			logger.error("loadJs() configName=" + configName + ",error=" + e.toString());
		}
	}

	private Properties loadConf(String configPath) {
		InputStream infile = null;
		try {
			String configName = "newxtc.ini";
			if (configPath == null) {
				infile = Thread.currentThread().getContextClassLoader().getResourceAsStream(configName);
			} else {
				String dataConfigPath = configPath + configName;
				if (!configPath.matches(".*[\\/]"))
					dataConfigPath = configPath + File.separator + configName;
				infile = new FileInputStream(dataConfigPath);
			}
			prop.load(infile);
			System.out.println("NxtSmsClient(" + configPath + ") init finish!");
			Iterator<Object> it = prop.keySet().iterator();
			while (it.hasNext()) {
				String key = (String) it.next();
				String value = prop.getProperty(key);
				System.out.println("  |--" + key + "=" + value);
			}
		} catch (Throwable e) {
			logger.error("loadConf() error=" + e.toString());
		} finally {
			if (infile != null)
				try {
					infile.close();
				} catch (IOException e) {
				}
		}
		return prop;
	}
}
