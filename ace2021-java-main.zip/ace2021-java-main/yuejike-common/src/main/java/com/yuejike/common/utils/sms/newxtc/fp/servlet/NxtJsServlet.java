package com.yuejike.common.utils.sms.newxtc.fp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yuejike.common.utils.sms.newxtc.NxtInit;
import com.yuejike.common.utils.sms.newxtc.fw.client.FwClientApi;
import com.yuejike.common.utils.sms.newxtc.fw.client.WebCryptApi;
import com.yuejike.common.utils.sms.newxtc.fw.client.impl.FwClientImpl;
import com.yuejike.common.utils.sms.newxtc.fw.client.impl.WebCryptImpl;
import com.yuejike.common.utils.sms.newxtc.fw.client.util.*;
import org.apache.commons.lang3.time.FastDateFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

@WebServlet({ "/NxtJsServlet" })

public class NxtJsServlet extends HttpServlet {
	private static final long serialVersionUID = 1478580140226921020L;

	private final static Logger logger = LoggerFactory.getLogger(NxtJsServlet.class);
	private CookieUtil cookieUtil = new CookieUtil();
	private FwClientApi fwClient = new FwClientImpl();
	private WebCryptApi webCrypt = new WebCryptImpl();
	private final FastDateFormat fm = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss");

	private final static String fwServlet = "FwServlet";

	public NxtJsServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("P3P", "CP=CAO PSA OUR");
		response.setContentType("text/javascript;charset=UTF-8");
		PrintWriter out = response.getWriter();
		String mode = null;
		try {
			String s_ = "";
			mode = request.getParameter("mode");
			if (null == mode || "".equals(mode)) {
				StringBuffer js = new StringBuffer();
				String baseUrl = request.getRequestURL().toString().replace("http:","");
				String mainUrl = baseUrl + "?mode=getFp";
				String expireUrl = baseUrl + "?mode=getExpire";
				String callJs = request.getParameter("callJs");
				if (callJs != null && !"".equals(callJs)) {
					mainUrl += "&callJs=" + callJs;
				}
				mainUrl += "&t=" + System.currentTimeMillis();
				// 超时调用
				js.append("var NXT_MAIN_URL='" + mainUrl + "';\n");
				js.append("var NXT_EXPIRE_URL='" + expireUrl + "';\n");
				String fpJs = NxtInit.getInstance().getfPJs();
				js.append(fpJs != null ? fpJs + "\n" : "");
				out.print(js.toString());
			} else {
				// 加载远程 fingerJs
				String nxtToken = request.getParameter("nxtToken");
				nxtToken = (nxtToken != null && nxtToken.length() == 64) ? nxtToken : cookieUtil.getCookie(request, JsonParamUtil.cookToken);
				int tokenSize = (nxtToken != null) ? nxtToken.length() : 0;
				String tokenId = (tokenSize == 64) ? nxtToken.substring(0, 32) : null;
				switch (mode) {
				case "getFp":
					String noFp = NxtInit.getInstance().getIni("noFp");
					if (noFp != null && "true".equals(noFp)) {
						logger.debug("noFp=" + noFp);
						break;
					}
					StringBuffer js = new StringBuffer();
					JSONObject jsonObj = getFrontJs(request, response);
					String jsUrl = (jsonObj != null) ? jsonObj.getString("jsUrl") : null;
					if (jsUrl != null) {
						js.append("nxtFingerJsLoad(\"" + jsUrl + "\");\n");
					}
					String[] varList = new String[] { "nxtTokenId", "nxtTokenKey", "nxtClientIp", "nxtClientSign" };
					String jsVar = getJsVar(varList, jsonObj);
					js.append(jsVar);
					js.append("function NxtToken(){try{return nxtTokenId+nxtTokenKey;} catch(e){}}");
					out.print(js.toString());
					break;
				case "frontCrypt":
					StringBuffer inputJs = new StringBuffer();
					// 安全输入表单名称
					Map<String, String> inputMap = webCrypt.getCryptInputMap();
					varList = new String[] { "nxtInputSeed", "nxtAesKey", "nxtAesIv", "nxtInputName", "nxtInputKey" };
					jsVar = getJsVar(varList, inputMap);
					inputJs.append(jsVar);
					String desJs = NxtInit.getInstance().getDesJs();
					inputJs.append(desJs);
					out.print(inputJs);
					break;
				case "callBack":
					String callRet = null;
					if (nxtToken != null && nxtToken.length() == 64) {
						String scheme = request.getScheme();
						callRet = callBack(mode, scheme, nxtToken);
					} else {
						logger.error("getCallBack nxtToken=" + nxtToken);
					}
					s_ = "console.log('callBack() response=" + callRet + "');";
					out.print(s_);
					break;
				case "getDevice":
					if (nxtToken != null && nxtToken.length() == 64) {
						JSONObject deviceInfo = fwClient.getDevice(nxtToken);
						s_ = (deviceInfo != null && deviceInfo.size() > 0) ? JSON.toJSONString(deviceInfo) : JSON.toJSONString("");
					} else {
						Boolean isNginx = NxtInit.getInstance().getIniBoolean("isNginx");
						String clientIp = isNginx ? ClientIpUtil.getRealIp(request) : request.getRemoteAddr();
						logger.error("mode=" + mode + "|nxtToken=" + nxtToken + "|clientIp=" + clientIp);
					}
					out.print(s_);
					break;
				case "getExpire":
					JSONObject json = (nxtToken != null) ? getExpire(mode, nxtToken) : null;
					tokenId = (json != null && json.size() > 0) ? json.getString("tokenId") : null;
					if (tokenId != null && !"".equals(tokenId)) {
						out.print("console.log('refresh t=" + fm.format(System.currentTimeMillis()) + ",tokenId=" + tokenId + "')");
					} else {
						out.print("nxtFpLoad();");
					}
					break;
				default:
					logger.error("err not exist mode=" + mode);
				}
			}
		} catch (Throwable e) {
			logger.error("mode=" + mode + "|error =" + e.toString());
		} finally {
			out.flush();
			out.close();
		}
	}

	/**
	 * 
	 * @param nameList
	 * @param object
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private String getJsVar(String[] nameList, Object object) {
		StringBuffer sb = new StringBuffer();
		String value = null;
		JSONObject jsonObj = null;
		Map<String, String> inputMap = null;
		boolean isJson = (object instanceof JSONObject);
		if (isJson) {
			jsonObj = (JSONObject) object;
		} else {
			inputMap = (Map<String, String>) object;
		}
		for (String name : nameList) {
			value = (isJson) ? jsonObj.getString(name) : inputMap.get(name);
			sb.append("var " + name + "=\"" + (value != null ? value : "") + "\";\n");
		}
		return sb.toString();
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	private JSONObject getFrontJs(HttpServletRequest request, HttpServletResponse response) {
		JSONObject jsonObj = null;
		long beginTime = System.currentTimeMillis();
		try {
			// token proc
			CookieUtil cookieUtil = new CookieUtil();
			// 第一次加载， 为空
			String nxtToken = cookieUtil.getCookie(request, JsonParamUtil.cookToken);
			String backUrl = request.getRequestURL().toString().replace("http:","") + "?mode=callBack&t=" + System.currentTimeMillis();
			Map<String, Object> paramsMap = new LinkedHashMap<String, Object>();
			String scheme = request.getScheme();
			String callJs = request.getParameter("callJs");
			String mode = request.getParameter("mode");
			paramsMap.put("nxtToken", nxtToken);
			paramsMap.put("mode", mode);
			paramsMap.put("scheme", scheme);
			if (callJs != null && !"".equals(callJs)) {
				paramsMap.put("callJs", callJs);
			}
			paramsMap.put("backUrl", backUrl);
			String jsonResp = HttpClient.execClient("fireWareUrl", fwServlet, paramsMap, 50);
			jsonObj = (jsonResp != null && jsonResp.contains("{") && jsonResp.contains("}")) ? JSONObject.parseObject(jsonResp) : null;
			nxtToken = (jsonObj != null) ? jsonObj.getString("nxtToken") : null;
			int tokenSize = (nxtToken != null) ? nxtToken.length() : 0;
			if (tokenSize == 64) {
				String tokenId = nxtToken.substring(0, 32);
				String sign = nxtToken.substring(32);
				jsonObj.put("nxtTokenId", tokenId);
				jsonObj.put("nxtTokenKey", sign);
				// 设置token cookie
				cookieUtil.setCookie(response, JsonParamUtil.cookToken, nxtToken);
			} else {
				jsonObj = new JSONObject();
				long cost = System.currentTimeMillis() - beginTime;
				logger.error("getFrontJs() cost=" + cost + "|jsonResp=" + jsonResp + "|nxtToken=" + nxtToken);
			}
			// 获取IP地址
			String clientIp = ClientIpUtil.getRealIp(request);
			String source = clientIp + nxtToken;
			String nxtClientSign = MD5Util.getMD5Str(source);
			jsonObj.put("nxtClientIp", clientIp);
			jsonObj.put("nxtClientSign", nxtClientSign);
		} catch (Exception e) {
			logger.error("getFrontJs() e=" + e.toString());
			for (StackTraceElement elment : e.getStackTrace()) {
				logger.error(elment.toString());
			}
		}
		return jsonObj;
	}

	private String callBack(String mode, String scheme, String nxtToken) {
		Map<String, Object> paramsMap = new LinkedHashMap<>();
		paramsMap.put("mode", mode);
		paramsMap.put("scheme", scheme);
		paramsMap.put("nxtToken", nxtToken);
		String response = HttpClient.execClient("fireWareUrl", fwServlet, paramsMap, 500);
		return response;
	}

	private JSONObject getExpire(String mode, String nxtToken) {
		Map<String, Object> paramsMap = new LinkedHashMap<>();
		paramsMap.put("mode", mode);
		paramsMap.put("nxtToken", nxtToken);
		String jsonResp = HttpClient.execClient("fireWareUrl", fwServlet, paramsMap, 100);
		if (jsonResp != null) {
			JSONObject json = JSONObject.parseObject(jsonResp);
			return json;
		} else {
			return null;
		}
	}
}
