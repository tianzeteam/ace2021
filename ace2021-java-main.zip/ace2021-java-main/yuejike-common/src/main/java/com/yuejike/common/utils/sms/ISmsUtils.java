package com.yuejike.common.utils.sms;

/**
 * @author JinZJ
 * @version 1.0
 * @Description:
 * @date 2021/11/11 10:43
 */
public interface ISmsUtils {

    /**发送单条短信**/
    RetMsg sendMsg(String phoneNumber, String msg);

    /**批量发送短信**/
    RetMsg sendMsg(String[] phoneNumbers, String msg);

}
