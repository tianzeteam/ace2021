package com.yuejike.common.utils.sms;

import com.alibaba.fastjson.JSONObject;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.core.util.MultivaluedMapImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.MediaType;
import java.util.Arrays;

/**
 * @author JinZJ
 * @version 1.0
 * @Description:
 * @date 2021/11/11 10:45
 */
public abstract class LuoSiMaoSmsBaseUtils implements ISmsUtils {

    private static final Logger logger = LoggerFactory.getLogger(LuoSiMaoSmsUtils.class);

    private static String API_SINGLE_MSG = "http://sms-api.luosimao.com/v1/send.json";

    private static String API_BATCH_MSG = "http://sms-api.luosimao.com/v1/send_batch.json";

    private static String API_KEY = "84c5f7bea8377f91f7f2b89832f7c07a";

    private static String AUTOGRAPH = "【ACE家电博览会】";

    /**发送验证码**/
    public abstract RetMsg sendVerCode(String phoneNumber, String verCode);

    /**批量发送自定义内容（需要平台审核），如通知**/
    public abstract RetMsg sendCustomMsg(String[] phoneNumbers, String content);

    /**会议报名审核通过短信**/
    public abstract RetMsg sendApprovedConferenceMsg(String phoneNumber, String conferenceName, boolean isPass);

    /**发送直播预约提醒短信**/
    public abstract RetMsg sendLiveSubscribeMsg(String phoneNumber, String liveName);

    /**批量发送直播预约提醒短信**/
    public abstract RetMsg sendLiveSubscribeMsg(String[] phoneNumbers, String liveName);

    /**投稿审核通过短信**/
    public abstract RetMsg sendApprovedContentMsg(String phoneNumber, String title, boolean isPass);

    /**身份认证审核通过短信**/
    public abstract RetMsg sendApprovedAuthMsg(String phoneNumber, boolean isPass);

    /**展品审核通过短信**/
    public abstract RetMsg sendApprovedProductMsg(String phoneNumber, String productName, boolean isPass);

    /**展商精彩审核通过短信**/
    public abstract RetMsg sendApprovedExcellentVideoMsg(String phoneNumber, boolean isPass);

    /**展商基本信息审核通过短信**/
    public abstract RetMsg sendApprovedBasicInfoMsg(String phoneNumber, boolean isPass);

    /**展厅审核通过短信**/
    public abstract RetMsg sendApprovedExhibitionHallMsg(String phoneNumber, boolean isPass);

    /**线下会议审核短信**/
    public abstract RetMsg sendApprovedOfflineMeetingMsg(String phoneNumber, String name, boolean isPass);

    /**活动直播审核短信**/
    public abstract RetMsg sendApprovedLiveMsg(String phoneNumber, String name, boolean isPass);

    @Override
    public RetMsg sendMsg(String phoneNumber, String msg) {
        MultivaluedMapImpl formData = new MultivaluedMapImpl();
        formData.add("mobile", phoneNumber);
        formData.add("message", msg+AUTOGRAPH);
        Client client = Client.create();
        client.addFilter(new HTTPBasicAuthFilter("api","key-"+API_KEY));
        WebResource webResource = client.resource(API_SINGLE_MSG);
        ClientResponse response =  webResource.type( MediaType.APPLICATION_FORM_URLENCODED ).
                post(ClientResponse.class, formData);
        String textEntity = response.getEntity(String.class);
        JSONObject jsonObject = JSONObject.parseObject(textEntity);
        logger.info("sendMsg response:",textEntity);
        return new RetMsg(Integer.valueOf(jsonObject.get("error").toString()),
                jsonObject.get("error").toString().equals("0")?"发送成功":"发送失败");
    }

    @Override
    public RetMsg sendMsg(String[] phoneNumbers, String msg) {
        MultivaluedMapImpl formData = new MultivaluedMapImpl();
        formData.add("mobile_list", String.join(",", Arrays.asList(phoneNumbers)));
        formData.add("message", msg+AUTOGRAPH);
        Client client = Client.create();
        client.addFilter(new HTTPBasicAuthFilter("api","key-"+API_KEY));
        WebResource webResource = client.resource(API_BATCH_MSG);
        ClientResponse response =  webResource.type( MediaType.APPLICATION_FORM_URLENCODED ).
                post(ClientResponse.class, formData);
        String textEntity = response.getEntity(String.class);
        JSONObject jsonObject = JSONObject.parseObject(textEntity);
        logger.info("sendMsg response:",textEntity);
        return new RetMsg(Integer.valueOf(jsonObject.get("error").toString()),
                jsonObject.get("error").toString().equals("0")?"发送成功":"发送失败");
    }
}
