package com.yuejike.common.enums;

/**
 * 线下会议类型
 *
 * @author yuejike
 */
public enum ConferenceType {
    ZBF("0", "主办方创建会议"), CZS("1", "参展商创建会议");

    private final String code;
    private final String info;

    ConferenceType(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }
}
