package com.yuejike.common.utils.sms.newxtc.fw.client.run;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author RAF
 *
 */
public class FwThread {
	// log
	private final static Logger logger = LoggerFactory.getLogger(FwThread.class);

	private BlockingQueue<Runnable> taskQueue;
	private ThreadPoolExecutor pool;

	private int dispatchQueueSize = 10000;
	private int disatchThreadSize = 4;
	private static FwThread instance = null;

	public synchronized static FwThread getInstance() {
		if (instance == null) {
			instance = new FwThread();
			System.out.println("FwThread init ");
		}
		return instance;
	}

	/**
	 * 
	 * @param config_path
	 *            配置路径
	 * @param threadName
	 *            线程名称, 线程的配置文件为:配置路径 + 线程名称.ini
	 * @param taskEntityCls
	 *            任务实体类 , 必须实现ScanTaskApi 接口
	 * @param runCls
	 *            任务运行类, 必须实现 ThreadRunApi 接口
	 */

	public FwThread() {
		try {
			taskQueue = new LinkedBlockingQueue<Runnable>(dispatchQueueSize);
			pool = new ThreadPoolExecutor(disatchThreadSize, disatchThreadSize * 2, 10 * 1000L, TimeUnit.MILLISECONDS, taskQueue, new ThreadPoolExecutor.AbortPolicy());
		} catch (Exception e) {
			logger.error(e.toString());
		}
	}

	public ThreadPoolExecutor getThreadPoolExecutor() {
		return this.pool;
	}

	public void addTask(FwTask fwTask) {
		try {
			pool.execute(fwTask);
		} catch (RejectedExecutionException e) {
			logger.error(e.toString());
		} catch (Throwable e) {
			logger.error(e.toString());
		}
	}

}
