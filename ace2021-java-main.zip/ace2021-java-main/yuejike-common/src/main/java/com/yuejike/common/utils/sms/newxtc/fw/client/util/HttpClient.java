package com.yuejike.common.utils.sms.newxtc.fw.client.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;

import com.yuejike.common.utils.sms.newxtc.NxtInit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class HttpClient {
	private final static Logger logger = LoggerFactory.getLogger(HttpClient.class);

	// 默认4000 毫秒， 当出现超时后， 自动改为指定的时间
	private final static int defaultOutTime = 2000;
	private static boolean isTimeOut = false;

	public static String execClient(String urlName, String servPath, Map<String, Object> paramMap, int setTime) {
		Long beginTime = System.currentTimeMillis();
		String url = NxtInit.getInstance().getIni(urlName);
		if (url != null && url.indexOf("http") >= 0) {
			if (!url.endsWith("/")) {
				url = url + "/";
			}
			url += servPath;

			int outOfTime = (isTimeOut || setTime > defaultOutTime) ? setTime : defaultOutTime;
			// 出现超时后， 自动改为指定的时间,避免影响用户体验， 直到不再出现超时， 解决刚启动或休眠时首笔延时问题。
			if (isTimeOut) {
				logger.debug("isTimeOut=" + isTimeOut + "|outOfTime=" + outOfTime);
			}
			// 对报文进行简单加密
			StringBuffer msg = new StringBuffer();
			Long time = System.currentTimeMillis();
			String merchantCode = NxtInit.getInstance().getIni("merchantCode");
			String secKey = NxtInit.getInstance().getIni("secKey");
			String source = merchantCode + secKey + time;

			Object objToken = paramMap.get("nxtToken");
			if (objToken != null) {
				source += objToken.toString();
			} else {
				paramMap.remove("nxtToken");
				msg.append("token=" + objToken);
			}

			Object objPhone = paramMap.get("phone");
			if (objPhone != null) {
				source += objPhone.toString();
			} else {
				paramMap.remove("phone");
				msg.append((msg.length() > 0) ? "," : "");
				msg.append("phone=" + objPhone);
			}

			String sign = MD5Util.getMD5Str(source);
			paramMap.put("MERCHANT_CODE", merchantCode);
			paramMap.put("NEWXTC_TIME", time);
			paramMap.put("NEWXTC_SIGN", sign);
			String response = execRequest(url, paramMap, outOfTime);
			Long cost = System.currentTimeMillis() - beginTime;
			isTimeOut = cost.compareTo(Long.valueOf(setTime)) > 0;
			if ((response == null || "".equals(response.trim()))) {
				logger.error("execClient() response=" + response + ",paramMap=" + paramMap + "," + msg);
			}
			return response;
		} else {
			logger.error("urlName=" + urlName + "|url=" + url);
			return null;
		}
	}

	/**
	 * 
	 * @param httpUrl
	 * @param param
	 * @return
	 */
	private static String execRequest(String url, Map<String, Object> paramsMap, int outTime) {
		StringBuffer result = new StringBuffer();
		// 连接
		HttpURLConnection connection = null;
		OutputStream os = null;
		InputStream is = null;
		BufferedReader br = null;
		try {
			// 创建连接对象
			URL httpUrl = new URL(url);
			// 创建连接
			connection = (HttpURLConnection) httpUrl.openConnection();
			// 设置请求方法
			connection.setRequestMethod("POST");
			// 设置连接超时时间
			connection.setConnectTimeout(outTime);
			// 设置读取超时时间
			connection.setReadTimeout(outTime);
			// 设置是否可读取
			connection.setDoOutput(true);
			// 设置响应是否可读取
			connection.setDoInput(true);
			// 设置参数类型
			connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
			// 拼装参数
			String param = convertMap(paramsMap);
			if (param != null && !param.equals("")) {
				// 设置参数
				os = connection.getOutputStream();
				// 拼装参数
				os.write(param.getBytes("UTF-8"));
			}
			// 设置权限
			// 设置请求头等
			// 开启连接
			// connection.connect();
			// 读取响应
			if (connection.getResponseCode() == 200) {
				is = connection.getInputStream();
				if (is != null) {
					br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
					String temp = null;
					while ((temp = br.readLine()) != null) {
						result.append(temp);
					}
				}
			}
			// 关闭连接
		} catch (MalformedURLException e) {
			logger.error("execRequest() MalformedURLException url=" + url);
		} catch (IOException e) {
			logger.error("execRequest() IOException url=" + url);
		} catch (Throwable e) {
			logger.error("execRequest() e=" + e.toString());
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (os != null) {
				try {
					os.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			// 关闭连接
			connection.disconnect();
		}
		return result.toString();
	}

	private static String convertMap(Map<String, Object> paramsMap) {
		int pSize = paramsMap != null ? paramsMap.size() : 0;
		StringBuffer sb = new StringBuffer();
		if (pSize > 0) {
			int count = 0;
			String value = null;
			for (String key : paramsMap.keySet()) {
				value = String.valueOf(paramsMap.get(key));
				try {
					value = URLEncoder.encode(value, "UTF-8");
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
				sb.append(key + "=" + value);
				if (++count < pSize)
					sb.append("&");
			}
		}
		return sb.toString();
	}

}
