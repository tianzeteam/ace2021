 package com.yuejike.common.utils.sms.newxtc.fw.client.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;

public class MD5Util {
	public static String getMD5Str(String str) {
		try {
			int i;
			MessageDigest md5 = MessageDigest.getInstance("MD5");
			char[] charArray = str.toCharArray();
			byte[] byteArray = new byte[charArray.length];
			for (i = 0; i < charArray.length; i++) {
				byteArray[i] = (byte) charArray[i];
			}
			byte[] md5Bytes = md5.digest(byteArray);
			StringBuffer hexValue = new StringBuffer();
			for (byte b : md5Bytes) {
				int val = b & 255;
				if (val < 16) {
					hexValue.append("0");
				}
				hexValue.append(Integer.toHexString(val));
			}
			return hexValue.toString();
		} catch (Exception e) {
			return "";
		}
	}

	public static final String getMd5(String str, String str2) {
		if ("".equals(str)) {
			return null;
		}
		if ("".equals(str2)) {
			str2 = "utf-8";
		}
		byte[] bArr = new byte[0];
		try {
			bArr = str.getBytes(str2);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return getMd5(bArr);
	}

	public static String getMd5(byte[] bArr) {
		int i = 0;
		char[] cArr = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
		try {
			MessageDigest instance = MessageDigest.getInstance("MD5");
			instance.update(bArr);
			byte[] digest = instance.digest();
			char[] cArr2 = new char[32];
			int i2 = 0;
			while (i < 16) {
				byte b = digest[i];
				int i3 = i2 + 1;
				cArr2[i2] = cArr[(b >>> 4) & 15];
				i2 = i3 + 1;
				cArr2[i3] = cArr[b & 15];
				i++;
			}
			return new String(cArr2);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static void main(String[] args) {

		// s += "&hx_signkey=" + Constants.hx_sign;
		// s += "token=" + Constants.token;
		String sign = MD5Util.getMd5("123456", "utf-8");
		System.out.println(sign);
		System.out.println(MD5Util.getMD5Str("123456"));

	}

}