package com.yuejike.common.utils.sms.newxtc;


import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * 监听器，用于启动加载配置信息等其他工作
 */
@WebListener
public class NxtListener implements ServletContextListener {

	@Override
	public void contextInitialized(ServletContextEvent event) {
		System.out.println("NxtSmsClient Listener start !");
		NxtInit.getInstance().init(null);
	}

	@Override
	public void contextDestroyed(ServletContextEvent event) {
	}
}
