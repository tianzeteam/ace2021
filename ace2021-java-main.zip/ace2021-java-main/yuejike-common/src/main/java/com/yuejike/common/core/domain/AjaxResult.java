package com.yuejike.common.core.domain;

import com.yuejike.common.constant.HttpStatus;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.common.utils.code.BusinessBizCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.HashMap;

/**
 * 操作消息提醒
 *
 * @author yuejike
 */
@ApiModel("返回结果")
@Data
public class  AjaxResult<T extends Serializable> implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final Logger logger = LoggerFactory.getLogger(AjaxResult.class);
    /**
     * 错误码
     */
    @ApiModelProperty("状态码")
    private Integer code = 500;

    /**
     * 错误信息
     */
    @ApiModelProperty("误信息")
    private String msg = null;

    /**
     * 返回结果实体
     */
    @ApiModelProperty("返回结果")
    private T data = null;
    /**
     * 初始化一个新创建的 AjaxResult 对象，使其表示一个空消息。
     */
    public AjaxResult() {
    }

    /**
     * 初始化一个新创建的 AjaxResult 对象
     *
     * @param code 状态码
     * @param msg  返回内容
     */
    private AjaxResult(int code, String msg, T data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }

    public static <T extends Serializable> AjaxResult<T> error(String msg) {
        logger.debug("返回错误：code={}, msg={}", 500, msg);
        return new AjaxResult<T>(500, msg, null);
    }

    public static <T extends Serializable> AjaxResult<T> error(int code, String msg) {
        logger.debug("返回错误：code={}, msg={}", code, msg);
        return new AjaxResult<T>(code, msg, null);
    }

    public static <T extends Serializable> AjaxResult<T> error() {
        return new AjaxResult<T>(500, "未知错误，请联系管理员", null);
    }

    public static <T extends Serializable> AjaxResult<T> success(T data) {
        return new AjaxResult<T>(0, "操作成功", data);
    }
    public static <T extends Serializable> AjaxResult<T> success(T data, String msg) {
        return new AjaxResult<T>(0, msg, data);
    }
    public static <T extends Serializable> AjaxResult<T> success() {
        return new AjaxResult<T>(0, "操作成功",null);
    }

    @Override
    public String toString() {
        return "AjaxResult [code=" + code + ", msg=" + msg + ", data=" + data + "]";
    }

    /**
     * 返回警告消息
     *
     * @param msg 返回内容
     * @return 警告消息
     */
    public static AjaxResult warn(String msg)
    {
        return AjaxResult.warn(msg, null);
    }

    /**
     * 返回警告消息
     *
     * @param msg 返回内容
     * @param data 数据对象
     * @return 警告消息
     */
    public static <T extends Serializable> AjaxResult<T>  warn(String msg, T data)
    {
        return new AjaxResult(301, msg, data);
    }
}
