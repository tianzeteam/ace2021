package com.yuejike.common.enums;

/**
 * 订单状态查询
 *
 * @author yuejike
 */
public enum OrderStatusQueryType {

    ORDER(20L, "订单"), XUNPAN(10L, "无效询盘");
    private final Long code;
    private final String info;

    OrderStatusQueryType(Long code, String info) {
        this.code = code;
        this.info = info;
    }

    public Long getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }
}
