package com.yuejike.common.utils.oss;

//import com.obs.services.ObsClient;
//import com.obs.services.exception.ObsException;
import com.yuejike.common.utils.DateUtils;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.common.utils.uuid.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

/**
 * @author caorui
 */
@Component
public class HuaweiObsUtil {

//    private ObsClient obsClient;
//
//    private static final Logger logger = LoggerFactory.getLogger(HuaweiObsUtil.class);
//
////    private static volatile HuaweiObsUtil huaweiObsUtil = null;
////    public synchronized static HuaweiObsUtil getInstance(){
////        if(huaweiObsUtil ==null){
////            synchronized(HuaweiObsUtil.class){
////                if(huaweiObsUtil ==null){
////                    huaweiObsUtil = new HuaweiObsUtil();
////                    huaweiObsUtil.init();
////                }
////            }
////        }
////        return huaweiObsUtil;
////    }
//    @Value("obs.bucketName")
//    private String bucketName;
////    @Value("obs.prefix")
//    private String prefix;
//
//    private void init(){
//        String endPoint = "https://your-endpoint";
//        String ak = "KYGPS2BH6QQULSPYSTHS";
//        String sk = "pf4bHHtImrQn2KB7lgRS9Ut9iyhVQ7Bpug4nMFEJ";
////        obsClient = new ObsClient(ak, sk, endPoint);
//    }
//
//
//    public String upload(byte[] data, String path)
//    {
//        return upload(new ByteArrayInputStream(data), path);
//    }
//
//    public String upload(InputStream inputStream, String path)
//    {
//        try
//        {
//            init();
//            obsClient.putObject(bucketName, path, inputStream);
//        }
//        catch (Exception e)
//        {
//            throw new ObsException("上传文件失败，请检查配置信息");
//        }
//        return prefix + "/" + path;
//    }

//    public String uploadSuffix(byte[] data, String suffix)
//    {
//        return upload(data, getPath(prefix, suffix));
//    }
//
//    public String uploadSuffix(InputStream inputStream, String suffix)
//    {
//        return upload(inputStream, getPath(prefix, suffix));
//    }
//
//    /**
//     * 文件路径
//     * @param prefix 前缀
//     * @param suffix 后缀
//     * @return 返回上传路径
//     */
//    public String getPath(String prefix, String suffix)
//    {
//        // 生成uuid
//        String uuid = UUID.randomUUID().toString().replaceAll("-", "");
//        // 文件路径
//        String path = DateUtils.dateTime() + "/" + uuid;
//        if (StringUtils.isNotBlank(prefix))
//        {
//            path = prefix + "/" + path;
//        }
//        return path + suffix;
//    }
}
