package com.yuejike.common.enums;

/**
 * 用户类型
 *
 * @author yuejike
 */
public enum UserType {

    ADMIN("00", "管理员"), ZBF("01", "主办方"),CZS("02", "参展商"),
    HYDB("03", "会议代表"), MT("04", "媒体"), ZYGZ("05", "专业观众"),
    GZ("06", "观众")
    ,ZBF_JS("07", "主办方角色"),CZS_JS("08", "参展商角色");
    private final String code;
    private final String info;

    UserType(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }
}
