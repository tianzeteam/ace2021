package com.yuejike.common.utils.sms.newxtc.fw.client.util;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AesUtil {

	static String encodingFormat = "UTF-8";

	private final static Logger logger = LoggerFactory.getLogger(AesUtil.class);

	public static String aesDec(String aesKey, String aesIv, String src) {
		try {
			if (aesKey != null && aesIv != null) {
				String aesKey16 = AesUtil.convertTo16(aesKey);
				String aesIv16 = AesUtil.convertTo16(aesIv);
				String ret = AesUtil.decrypt(src, aesKey16, aesIv16);
				return ret;
			} else {
				logger.error("aesDec() tokenId=" + aesKey + "|sign=" + aesIv);
				return "";
			}
		} catch (Exception e) {
			logger.error("aesDec() src=" + src + "|error=" + e);
			return "";
		}
	}

	// 兼容32位格式
	public static String convertTo16(String key) {
		StringBuilder sKey = new StringBuilder();
		String md5Key = MD5Util.getMD5Str(key);
		for (int i = 0; i < md5Key.length(); i += 2) {
			sKey.append(md5Key.charAt(i));
		}
		return sKey.toString();
	}

	// 加密
	public static String encrypt(String sSrc, String aesKey, String aesIv) throws Exception {
		try {
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			byte[] raw = aesKey.getBytes();
			SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
			byte[] ivRaw = aesIv.getBytes();
			IvParameterSpec iv = new IvParameterSpec(ivRaw);// 使用CBC模式，需要一个向量iv，可增加加密算法的强度
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
			byte[] encrypted = cipher.doFinal(sSrc.getBytes(encodingFormat));
			return parseByte2HexStr(encrypted);// 此处使用BASE64做转码。
		} catch (Exception e) {
			logger.error("encrypt() sSrc=" + sSrc + "|sign=" + aesKey + "|ivKey=" + aesIv + " e=" + e.toString());
			return "";
		}
	}

	public static String decrypt(String sSrc, String aesKey, String aesIv) throws Exception {
		try {
			byte[] raw = aesKey.getBytes("utf-8");
			SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			byte[] ivRaw = aesIv.getBytes();
			IvParameterSpec iv = new IvParameterSpec(ivRaw);
			cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
			byte[] encrypted1 = parseHexStr2Byte(sSrc);// 先用base64解密
			byte[] original = cipher.doFinal(encrypted1);
			String originalString = new String(original, encodingFormat);
			return originalString;
		} catch (Exception e) {
			logger.error("decrypt() sSrc=" + sSrc + "|sign=" + aesKey + "|ivKey=" + aesIv + " e=" + e.toString());
			return "";
		}
	}

	/**
	 * 将二进制转换成十六进制
	 * 
	 * @param buf
	 * @return
	 */
	private static String parseByte2HexStr(byte buf[]) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < buf.length; i++) {
			String hex = Integer.toHexString(buf[i] & 0xFF);
			if (hex.length() == 1) {
				hex = '0' + hex;
			}
			sb.append(hex.toUpperCase());
		}
		return sb.toString();
	}

	/**
	 * 将十六进制转换为二进制
	 * 
	 * @param hexStr
	 * @return
	 */
	private static byte[] parseHexStr2Byte(String hexStr) {
		if (hexStr.length() < 1) {
			return null;
		} else {
			byte[] result = new byte[hexStr.length() / 2];
			for (int i = 0; i < hexStr.length() / 2; i++) {
				int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
				int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
				result[i] = (byte) (high * 16 + low);
			}
			return result;
		}
	}

	public static void main(String[] args) throws Exception {
		/*
		 * 此处使用AES-128-ECB加密模式，key需要为16位。
		 */
		String cKey = AesUtil.convertTo16("11d8fb9de48959b55ba37d5cf4c8eef6");
		String ivKey = AesUtil.convertTo16("11d8fb9de48959b55ba37d5cf4c8eef6");
		System.out.println("cKey=" + cKey);
		System.out.println("ivKey=" + ivKey);

		// 需要加密的字串
		String src = "123456789";

		String mobileEn = AesUtil.encrypt(src, cKey, ivKey);
		System.out.println("mobileEn=" + mobileEn);
		// 解密

		String mobile = AesUtil.decrypt(mobileEn, cKey, ivKey);
		System.out.println("mobile=" + mobile);
	}

}
