package com.yuejike.common.utils.sms.newxtc.fw.client;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

/**
 * 前端对手机号或用户ID进行加密，后端进行解密
 * 
 * @author topliu
 *
 */
public interface WebCryptApi {

	/**
	 * 
	 * @return
	 */
	public Map<String, String> getCryptInputMap();

	/**
	 * 一步获取手机号 支持标准 request.getParameter 表单获取方式
	 * 
	 * @param request
	 * @param response
	 * @return
	 */

	public String getMobile(HttpServletRequest request);

	/**
	 * 一步获取手机号 支持 JSON 获取方式, 一般应用在 vue 结构
	 * 
	 * @param request
	 * @param inputJson
	 * @return
	 */
	public String getMobileByJson(String inputJson);

}
