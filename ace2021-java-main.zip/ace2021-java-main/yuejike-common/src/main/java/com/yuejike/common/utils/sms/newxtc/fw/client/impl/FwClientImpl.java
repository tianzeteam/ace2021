package com.yuejike.common.utils.sms.newxtc.fw.client.impl;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.yuejike.common.utils.sms.newxtc.NxtInit;
import com.yuejike.common.utils.sms.newxtc.fw.client.FwClientApi;
import com.yuejike.common.utils.sms.newxtc.fw.client.entity.EventParam;
import com.yuejike.common.utils.sms.newxtc.fw.client.run.FwTask;
import com.yuejike.common.utils.sms.newxtc.fw.client.run.FwThread;
import com.yuejike.common.utils.sms.newxtc.fw.client.util.ClientIpUtil;
import com.yuejike.common.utils.sms.newxtc.fw.client.util.CookieUtil;
import com.yuejike.common.utils.sms.newxtc.fw.client.util.HttpClient;
import com.yuejike.common.utils.sms.newxtc.fw.client.util.JsonParamUtil;
import org.apache.commons.lang3.time.FastDateFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.parser.Feature;

public class FwClientImpl implements FwClientApi {
	private final static Logger logger = LoggerFactory.getLogger(FwClientImpl.class);
	private final int outOfTime = 200;
	private final FastDateFormat fm = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss.SSS");

	private final static String fwServlet = "FwServlet";

	// Login
	@Override
	public Map<String, Object> getLoginByMobile(HttpServletRequest request, String phone) {
		return EventParam.getMobileParam(request, "U_L", phone);
	}

	@Override
	public Map<String, Object> getLoginByUid(HttpServletRequest request, String userId) {
		return EventParam.getUidParam(request, "U_L", userId);
	}

	@Override
	public Map<String, Object> getLoginByEmail(HttpServletRequest request, String userEmail) {
		return EventParam.getEmailParam(request, "U_L", userEmail);
	}

	@Override
	public Map<String, Object> getLoginReq(HttpServletRequest request, String sJson, String uid) {
		return EventParam.getUidParam(request, "U_L", uid);
	}

	@Override
	public void loginSucc(Map<String, Object> paramMap) {
		execLogin(paramMap, "1");
	}

	@Override
	public void loginFail(Map<String, Object> paramMap) {
		execLogin(paramMap, "-1");
	}

	private void execLogin(Map<String, Object> paramMap, String status) {
		Map<String, Object> uvParamMap = new HashMap<String, Object>();
		if (paramMap != null && paramMap.size() > 0) {
			uvParamMap.putAll(paramMap);
			uvParamMap.put("EVENT_TYPE", "U_V");
			uvParamMap.remove("finish_time");
			if ("1".equals(status)) {
				uvParamMap.put("status", "0");
				FwThread.getInstance().addTask(new FwTask(uvParamMap));
			}
			uvParamMap.put("finish_time", fm.format(System.currentTimeMillis()));
			uvParamMap.put("status", status);
			FwThread.getInstance().addTask(new FwTask(uvParamMap));
		} else {
			logger.error("execLogin() uvParamMap=" + uvParamMap);
		}
	}

	// Send
	@Override
	public Map<String, Object> getSendReq(HttpServletRequest request, String phone) {
		return EventParam.getMobileParam(request, "S_S", phone);
	}

	@Override
	public Map<String, Object> getSendReq(HttpServletRequest request, String sJson, String phone) {
		return EventParam.getMobileParam(sJson, "S_S", phone);
	}

	// Verify
	@Override
	public Map<String, Object> getVerifyReq(HttpServletRequest request, String phone) {
		return EventParam.getMobileParam(request, "S_V", phone);
	}

	@Override
	public Map<String, Object> getVerifyReq(HttpServletRequest request, String sJson, String phone) {
		return EventParam.getMobileParam(sJson, "S_V", phone);
	}

	@Override
	public JSONObject execReq(Map<String, Object> paramMap) {
		JSONObject retJson = null;
		String bussResult = "req";
		String riskResult = null;
		String reasonCode = null;
		try {
			Long beginTime = System.currentTimeMillis();
			String jsonRes = HttpClient.execClient("fireWareUrl", fwServlet, paramMap, outOfTime);
			retJson = (jsonRes != null && jsonRes.contains("{") && jsonRes.contains("}")) ? JSON.parseObject(jsonRes) : null;
			if (retJson != null && retJson.size() > 0) {
				String orderNo = retJson.getString("orderNo");
				riskResult = retJson.getString("riskResult");
				reasonCode = retJson.getString("reasonCode");
				Object ipObj = paramMap.get("client_ip");
				String ip = (ipObj != null) ? (String) ipObj : "";
				Object mobileObj = paramMap.get("phone");
				Object userIdObj = paramMap.get("user_id");
				StringBuffer msg = new StringBuffer();
				if (userIdObj != null) {
					msg.append("|userId=" + (String) userIdObj);
				}
				if (mobileObj != null) {
					msg.append("|mobile=" + (String) mobileObj);
				}
				Long cost = System.currentTimeMillis() - beginTime;
				Object objEvent = paramMap.get("EVENT_TYPE");
				logger.info(objEvent + ":" + orderNo + "(" + bussResult + ") risk=" + riskResult + "|ip=" + ip + msg.toString() + ",cost=" + cost);
			} else {
				logger.error("execReq() Fw eventType=" + paramMap.get("EVENT_TYPE") + "|reasonCode=" + reasonCode + "|status=" + bussResult + "|riskResult=" + riskResult);
			}
		} catch (Throwable e) {
			// 系统异常 作放行处理
			logger.error("execReq() " + e.toString());
		}
		return retJson;
	}

	@Override
	public void execSucc(Map<String, Object> paramMap) {
		if (paramMap != null && paramMap.size() > 0) {
			paramMap.put("finish_time", fm.format(System.currentTimeMillis()));
			paramMap.put("status", "1");
			FwThread.getInstance().addTask(new FwTask(paramMap));
		} else {
			logger.error("execSucc() paramMap=" + paramMap);
		}
	}

	@Override
	public void execFail(Map<String, Object> paramMap) {
		if (paramMap != null && paramMap.size() > 0) {
			paramMap.put("finish_time", fm.format(System.currentTimeMillis()));
			paramMap.put("status", "-1");
			FwThread.getInstance().addTask(new FwTask(paramMap));
		} else {
			logger.error("execSucc() paramMap=" + paramMap);
		}
	}


	@Override
	public JSONObject getDevice(HttpServletRequest request) {
		CookieUtil cookieUtil = new CookieUtil();
		String nxtToken = cookieUtil.getCookie(request, JsonParamUtil.cookToken);
		if (nxtToken != null && nxtToken.length() == 64) {
			return getDevice(nxtToken);
		} else {
			Boolean isNginx = NxtInit.getInstance().getIniBoolean("isNginx");
			String clientIp = isNginx ? ClientIpUtil.getRealIp(request) : request.getRemoteAddr();
			logger.error("getDeviceInfo() error nxtToken=" + nxtToken + "|clientIp=" + clientIp);
			return null;
		}
	}

	@Override
	public JSONObject getDevice(String nxtToken) {
		int tokenSize = (nxtToken != null) ? nxtToken.length() : 0;
		String jsonResp = null;
		if (tokenSize == 64) {
			try {
				Map<String, Object> paramsMap = new LinkedHashMap<>();
				JSONObject deviceInfo = null;
				paramsMap.put("mode", "getDevice");
				paramsMap.put("nxtToken", nxtToken);
				jsonResp = HttpClient.execClient("fireWareUrl", fwServlet, paramsMap, 100);
				deviceInfo = (jsonResp != null && jsonResp.contains("{") && jsonResp.contains("}")) ? JSONObject.parseObject(jsonResp, Feature.OrderedField) : null;
				String deviceId = (deviceInfo != null) ? deviceInfo.getString("deviceId") : null;
				String tokenId = nxtToken.substring(0, 32);
				logger.info("getDevice() tokenId=" + tokenId + "->" + deviceId);
				return deviceInfo;
			} catch (Exception e) {
				logger.error("getDevice() nxtToken=" + nxtToken + ",jsonResp=" + jsonResp + " e=" + e.toString());
				return null;
			}
		} else {
			logger.debug("getDevice() token is null");
			return null;
		}
	}

	@Override
	public String getNxtToken(HttpServletRequest request) {
		CookieUtil cookieUtil = new CookieUtil();
		String nxtToken = request.getParameter("NXT_CLIENT_TOKEN");
		nxtToken = (nxtToken != null && nxtToken.length() == 64) ? nxtToken : cookieUtil.getCookie(request, JsonParamUtil.cookToken);
		if (nxtToken != null && nxtToken.length() == 64) {
			return nxtToken;
		} else {
			return null;
		}
	}
}
