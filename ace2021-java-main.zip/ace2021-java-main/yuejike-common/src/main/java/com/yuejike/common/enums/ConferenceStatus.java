package com.yuejike.common.enums;

/**
 * 线下会议状态
 *
 * @author yuejike
 */
public enum ConferenceStatus {
    NORMAL("0", "未审核"), PASSED("1", "已通过审核"), REJECTED("2", "已拒绝");

    private final String code;
    private final String info;

    ConferenceStatus(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }
}
