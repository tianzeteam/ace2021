package com.yuejike.common.enums;

/**
 * 短信平台
 *
 * @author yuejike
 */
public enum SmsPlatform {
    /**
     * 云片
     */
    YUNPIAN("yunpian","云片"),

    /**
     * 韵阳
     */
    YUNYANG("yunyang","韵阳");

    private final String code;
    private final String info;

    SmsPlatform(String code, String info) {
        this.code = code;
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }
}
