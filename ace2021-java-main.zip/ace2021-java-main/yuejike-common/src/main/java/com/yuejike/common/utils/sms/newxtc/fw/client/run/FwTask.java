package com.yuejike.common.utils.sms.newxtc.fw.client.run;

import java.util.LinkedHashMap;
import java.util.Map;

import com.yuejike.common.utils.sms.newxtc.fw.client.util.HttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class FwTask implements Runnable {
	private final static Logger logger = LoggerFactory.getLogger(FwTask.class);
	private final int outOfTime = 500;

	Map<String, Object> inputMap = new LinkedHashMap<String, Object>();

	public FwTask(Map<String, Object> inputMap) {
		this.inputMap.putAll(inputMap);
	}

	@Override
	public void run() {
		try {
			long beginTime = System.currentTimeMillis();
			Object obj = inputMap.get("status");
			String status = obj != null ? (String) obj : null;
			if (status.equals("0") || status.equals("1") || status.equals("-1")) {
				String jsonRes = HttpClient.execClient("fireWareUrl", "FwServlet", inputMap, outOfTime);
				JSONObject retJson = (jsonRes != null && jsonRes.contains("{") && jsonRes.contains("}")) ? JSON.parseObject(jsonRes) : null;
				if (retJson != null && retJson.size() > 0) {
					String orderNo = retJson.getString("orderNo");
					String reasonCode = retJson.getString("reasonCode");
					Object objEvent = inputMap.get("EVENT_TYPE");
					Object ipObj = inputMap.get("client_ip");
					String ip = (ipObj != null) ? (String) ipObj : "";
					long cost = System.currentTimeMillis() - beginTime;
					logger.info(objEvent + ":" + orderNo + "(" + status + "),reasonCode=" + reasonCode + "|ip=" + ip + ",cost=" + cost);
				} else {
					logger.error("run() inputMap=" + inputMap + "|jsonRes=" + jsonRes);
				}
			} else {
				logger.error("run() status not in(0,1,-1) status=" + status);
			}
		} catch (Exception e) {
			logger.error("run() e=" + e.toString());
		}
	}
}
