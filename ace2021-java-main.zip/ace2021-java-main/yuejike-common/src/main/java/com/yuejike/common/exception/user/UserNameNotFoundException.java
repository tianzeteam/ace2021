package com.yuejike.common.exception.user;

/**
 * @author song
 * @date 2021年09月30日 18:34
 */
public class UserNameNotFoundException extends UserException {
    private static final long serialVersionUID = 1L;

    public UserNameNotFoundException()
    {
        super("user.not.exists", null);
    }
}
