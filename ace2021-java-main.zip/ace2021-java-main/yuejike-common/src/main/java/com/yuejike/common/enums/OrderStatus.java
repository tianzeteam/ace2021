package com.yuejike.common.enums;

/**
 * 订单状态
 *
 * @author yuejike
 */
public enum OrderStatus {

    NORMAL(0L, "待处理"), INVALID(1L, "无效询盘"),EFFECTIVE(2L, "有效询盘/待处理"),
    PROCESSED(3L, "已处理"), VOIDEO(-1L, "已作废");
    private final Long code;
    private final String info;

    OrderStatus(Long code, String info) {
        this.code = code;
        this.info = info;
    }

    public Long getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }
}
