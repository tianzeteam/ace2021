package com.yuejike.common.utils.sms;

/**
 * @author JinZJ
 * @version 1.0
 * @Description:
 * @date 2021/11/10 10:08
 */
public class LuoSiMaoSmsUtils extends LuoSiMaoSmsBaseUtils {

    private static String TMP_VER_CODE = "验证码：%s，10分钟内有效。泄露有风险，请勿转发。";

    private static String TMP_CONFERENCE_APPROVED = "您报名的\"%s\"会议已审核通过，请准时参加";

    private static String TMP_CONFERENCE_REFUSE = "您报名的\"%s\"会议被拒绝，请检查后重新报名。";

    private static String TMP_LIVE_SUBSCRIBE = "您预约的直播会议\"%s\"即将开播，请准备参加。";

    private static String TMP_CONTENT_APPROVED = "您的投稿\"%s\"已审核通过。";

    private static String TMP_CONTENT_REFUSE = "您的投稿\"%s\"被拒绝，请修改后重新提交。";

    private static String TMP_AUTH_APPROVED = "您的认证信息已被审核，请到认证记录中查看详情。";

    private static String TMP_AUTH_REFUSE = "您的认证信息被拒绝，请检查后重新提交。";

    private static String TMP_PRODUCT_APPROVED = "您的展品\"%s\"已审核通过。";

    private static String TMP_PRODUCT_REFUSE = "您的展品\"%s\"被拒绝，请进后台修改。";

    private static String TMP_EXCELLENT_VIDEO_APPROVED = "您的展商精彩已审核通过，请到登录后台进行查看。";

    private static String TMP_EXCELLENT_VIDEO_REFUSE = "您的展商精彩被拒绝，请修改后重新提交。";

    public static String TMP_BASIC_INFO_APPROVED = "您的基本信息已审核通过，请到登录后台进行查看。";

    public static String TMP_BASIC_INFO_REFUSE = "您的基本信息被拒绝，请修改后重新提交。";

    public static String TMP_EXHIBITION_HALL_APPROVED = "您的展厅已审核通过，请到登录后台进行查看。";

    public static String TMP_EXHIBITION_HALL_REFUSE = "您的展厅被拒绝，请修改后重新提交。";

    public static String TMP_OFFLINE_MEETING_APPROVED = "您提交的线下会议\"%s\"已审核通过。";

    public static String TMP_OFFLINE_MEETING_REFUSE = "您提交的线下会议\"%s\"被拒绝，请修改后重新提交。";

    public static String TMP_LIVE_APPROVED = "您提交的活动直播\"%s\"已审核通过。";

    public static String TMP_LIVE_REFUSE = "您提交的活动直播\"%s\"被拒绝，请修改后重新提交。";

    private  static volatile LuoSiMaoSmsUtils luoSiMaoSmsUtils = null;

    public synchronized static LuoSiMaoSmsUtils getInstance() {
        if(luoSiMaoSmsUtils == null){
            synchronized(LuoSiMaoSmsUtils.class){
                if(luoSiMaoSmsUtils == null){
                    luoSiMaoSmsUtils = new LuoSiMaoSmsUtils();
                }
            }
        }
        return luoSiMaoSmsUtils;
    }

    /**
     * 功能描述: <br>
     * 〈发送验证码〉
     * @Param: [phoneNumber, verCode]
     * @Return: com.yuejike.common.utils.sms.RetMsg
     * @Author: JinZJ
     * @Date: 2021/11/10 14:26
     */
    @Override
    public RetMsg sendVerCode(String phoneNumber, String verCode) {
        return sendMsg(phoneNumber,String.format(TMP_VER_CODE, verCode));
    }

    /**
     * 功能描述: <br>
     * 〈批量发送自定义内容（需要平台审核），如通知〉
     * @Param: [phoneNumbers, content]
     * @Return: com.yuejike.common.utils.sms.RetMsg
     * @Author: JinZJ
     * @Date: 2021/11/10 14:30
     */
    @Override
    public RetMsg sendCustomMsg(String[] phoneNumbers, String content){
        return sendMsg(phoneNumbers,content);
    }

    /**
     * 功能描述: <br>
     * 〈会议报名审核通过短信〉
     * @Param: [phoneNumber, conferenceName]
     * @Return: com.yuejike.common.utils.sms.RetMsg
     * @Author: JinZJ
     * @Date: 2021/11/11 10:14
     */
    @Override
    public RetMsg sendApprovedConferenceMsg(String phoneNumber, String conferenceName, boolean isPass){
        return sendMsg(phoneNumber,String.format(isPass ? TMP_CONFERENCE_APPROVED : TMP_CONFERENCE_REFUSE, conferenceName));
    }

    /**
     * 功能描述: <br>
     * 〈发送直播预约提醒短信〉
     * @Param: [phoneNumber, liveName]
     * @Return: com.yuejike.common.utils.sms.RetMsg
     * @Author: JinZJ
     * @Date: 2021/11/11 10:40
     */
    @Override
    public RetMsg sendLiveSubscribeMsg(String phoneNumber, String liveName) {
        return sendMsg(phoneNumber,String.format(TMP_LIVE_SUBSCRIBE, liveName));
    }

    /**
     * 功能描述: <br>
     * 〈批量发送直播预约提醒短信〉
     * @Param: [phoneNumbers, liveName]
     * @Return: com.yuejike.common.utils.sms.RetMsg
     * @Author: JinZJ
     * @Date: 2021/11/11 10:42
     */
    @Override
    public RetMsg sendLiveSubscribeMsg(String[] phoneNumbers, String liveName) {
        return sendMsg(phoneNumbers,String.format(TMP_LIVE_SUBSCRIBE, liveName));
    }

    /**
     * 功能描述: <br>
     * 〈投稿审核通过短信〉
     * @Param: [phoneNumber, title]
     * @Return: com.yuejike.common.utils.sms.RetMsg
     * @Author: JinZJ
     * @Date: 2021/11/23 12:42
     */
    @Override
    public RetMsg sendApprovedContentMsg(String phoneNumber, String title, boolean isPass) {
        return sendMsg(phoneNumber,String.format(isPass ? TMP_CONTENT_APPROVED : TMP_CONTENT_REFUSE, title));
    }

    /**
     * 功能描述: <br>
     * 〈身份认证审核通过短信〉
     * @Param: [phoneNumber]
     * @Return: com.yuejike.common.utils.sms.RetMsg
     * @Author: JinZJ
     * @Date: 2021/11/23 12:54
     */
    @Override
    public RetMsg sendApprovedAuthMsg(String phoneNumber, boolean isPass) {
        return sendMsg(phoneNumber, isPass ? TMP_AUTH_APPROVED : TMP_AUTH_REFUSE);
    }

    /**
     * 功能描述: <br>
     * 〈展品审核通过短信〉
     * @Param: [phoneNumber, productName]
     * @Return: com.yuejike.common.utils.sms.RetMsg
     * @Author: JinZJ
     * @Date: 2021/11/23 13:16
     */
    @Override
    public RetMsg sendApprovedProductMsg(String phoneNumber, String productName, boolean isPass) {
        return sendMsg(phoneNumber,String.format(isPass ? TMP_PRODUCT_APPROVED : TMP_PRODUCT_REFUSE, productName));
    }

    /**
     * 功能描述: <br>
     * 〈展商精彩审核通过短信〉
     * @Param: [phoneNumber]
     * @Return: com.yuejike.common.utils.sms.RetMsg
     * @Author: JinZJ
     * @Date: 2021/11/23 13:33
     */
    @Override
    public RetMsg sendApprovedExcellentVideoMsg(String phoneNumber, boolean isPass) {
        return sendMsg(phoneNumber, isPass ? TMP_EXCELLENT_VIDEO_APPROVED : TMP_EXCELLENT_VIDEO_REFUSE);
    }

    /**
     * 功能描述: <br>
     * 〈展商基本信息审核通过短信〉
     * @Param: [phoneNumber]
     * @Return: com.yuejike.common.utils.sms.RetMsg
     * @Author: JinZJ
     * @Date: 2021/11/23 13:38
     */
    @Override
    public RetMsg sendApprovedBasicInfoMsg(String phoneNumber, boolean isPass) {
        return sendMsg(phoneNumber, isPass ? TMP_BASIC_INFO_APPROVED : TMP_BASIC_INFO_REFUSE);
    }

    /**
     * 功能描述: <br>
     * 〈展厅审核通过短信〉
     * @Param: [phoneNumber]
     * @Return: com.yuejike.common.utils.sms.RetMsg
     * @Author: JinZJ
     * @Date: 2021/11/23 14:00
     */
    @Override
    public RetMsg sendApprovedExhibitionHallMsg(String phoneNumber, boolean isPass) {
        return sendMsg(phoneNumber, isPass ? TMP_EXHIBITION_HALL_APPROVED : TMP_EXHIBITION_HALL_REFUSE);
    }

    /**
     * 功能描述: <br>
     * 〈线下会议审核短信〉
     * @Param: [phoneNumber, name, isPass]
     * @Return: com.yuejike.common.utils.sms.RetMsg
     * @Author: JinZJ
     * @Date: 2021/11/24 15:10
     */
    @Override
    public RetMsg sendApprovedOfflineMeetingMsg(String phoneNumber, String name, boolean isPass) {
        return sendMsg(phoneNumber,String.format(isPass ? TMP_OFFLINE_MEETING_APPROVED : TMP_OFFLINE_MEETING_REFUSE, name));
    }

    /**
     * 功能描述: <br>
     * 〈活动直播审核短信〉
     * @Param: [phoneNumber, name, isPass]
     * @Return: com.yuejike.common.utils.sms.RetMsg
     * @Author: JinZJ
     * @Date: 2021/11/24 15:32
     */
    @Override
    public RetMsg sendApprovedLiveMsg(String phoneNumber, String name, boolean isPass) {
        return sendMsg(phoneNumber,String.format(isPass ? TMP_LIVE_APPROVED : TMP_LIVE_REFUSE, name));
    }

    public static void main(String[] args) {
        RetMsg retMsg = LuoSiMaoSmsUtils.getInstance().sendCustomMsg(new String[]{"17326058007","15224060665"},
                "我是测试通知内容我是测试通知内容我是测试通知内容");
        System.out.println(retMsg);
    }

}
