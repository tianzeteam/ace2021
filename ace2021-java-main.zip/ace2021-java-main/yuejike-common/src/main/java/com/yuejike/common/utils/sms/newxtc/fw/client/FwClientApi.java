package com.yuejike.common.utils.sms.newxtc.fw.client;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.alibaba.fastjson.JSONObject;

public interface FwClientApi {

	/**
	 * 获取登录请求报文
	 * 
	 * @param request
	 * @param response
	 * @param phone
	 * @return
	 */

	public Map<String, Object> getLoginByMobile(HttpServletRequest request, String phone);

	public Map<String, Object> getLoginByUid(HttpServletRequest request, String uid);

	public Map<String, Object> getLoginByEmail(HttpServletRequest request, String userEmail);

	public Map<String, Object> getLoginReq(HttpServletRequest request, String sJson, String phone);

	public void loginSucc(Map<String, Object> paramMap);

	public void loginFail(Map<String, Object> paramMap);

	/**
	 * 获取短信下发请求报文
	 * 
	 * @param request
	 * @param response
	 * @param phone
	 * @return
	 */

	public Map<String, Object> getSendReq(HttpServletRequest request, String phone);

	public Map<String, Object> getSendReq(HttpServletRequest request, String sJson, String phone);

	/**
	 * 获取短信验证报文
	 * 
	 * @param request
	 * @param response
	 * @param phone
	 * @return
	 */
	public Map<String, Object> getVerifyReq(HttpServletRequest request, String phone);

	public Map<String, Object> getVerifyReq(HttpServletRequest request, String sJson, String phone);

	/**
	 * 执行请求报文
	 * 
	 * @param paramMap
	 * @return
	 */
	public JSONObject execReq(Map<String, Object> paramMap);

	/**
	 * 执行成功报文
	 * 
	 * @param paramMap
	 */

	public void execSucc(Map<String, Object> paramMap);

	/**
	 * 执行失败报文
	 * 
	 * @param paramMap
	 */

	public void execFail(Map<String, Object> paramMap);

	/**
	 * 
	 * @param nxtToken
	 * @return
	 */
	public JSONObject getDevice(String nxtToken);

	public JSONObject getDevice(HttpServletRequest request);

	/**
	 * 
	 * @param request
	 * @return
	 */
	public String getNxtToken(HttpServletRequest request);

}
