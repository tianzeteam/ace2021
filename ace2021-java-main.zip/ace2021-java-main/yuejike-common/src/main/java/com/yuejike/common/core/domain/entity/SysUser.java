package com.yuejike.common.core.domain.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.annotation.Excel.ColumnType;
import com.yuejike.common.annotation.Excel.Type;
import com.yuejike.common.annotation.Excels;
import com.yuejike.common.core.domain.BaseEntity;
import com.yuejike.common.filter.RepeatedlyRequestWrapper;
import io.swagger.annotations.ApiModelProperty;
import lombok.Setter;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Arrays;
import java.util.Date;
import java.util.List;


/**
 * 用户对象 sys_user
 *
 * @author wintersnow
 * @since 1.0  2020-12-11
 */
@Setter
@Entity
@Table(name = "sys_user")
@DynamicInsert(true)
@DynamicUpdate(true)
public class SysUser extends BaseEntity {
    private static final long serialVersionUID = 1L;


    /**
     * 用户ID
     */
    @ApiModelProperty(value = "用户ID")
    @Excel(name = "用户序号", cellType = ColumnType.NUMERIC, prompt = "用户编号")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Long userId;

    @Transient
    private List<Long> userIds;
    /**
     * 部门ID
     */
    @ApiModelProperty(value = "部门ID")
    @Excel(name = "部门编号", type = Type.IMPORT)
    @Column(name = "dept_id")
    private Long deptId;

    /**
     * 用户账号
     */
    @ApiModelProperty(value = "用户账号")
    @Excel(name = "登录名称")
    @Column(name = "user_name")
    private String userName;

    /**
     * 用户昵称
     */
    @ApiModelProperty(value = "用户昵称")
    @Excel(name = "用户名称")
    @Column(name = "nick_name")
    private String nickName;

    /**
     * 用户类型
     */
    @ApiModelProperty(value = "用户类型:01主办方，02展商，03会议代表，04媒体，05专业观众，06普通观众；")
    @Excel(name = "用户类型")
    @Column(name = "user_type")
    private String userType;

    /** 审核人id */
    @Excel(name = "审核人id")
    @Column(name="reviewer_id")
    @ApiModelProperty(value = "审核人id")
    private Long reviewerId;

    /**
     * 审核状态
     */
    @ApiModelProperty(value = "审核状态审核状态(0:待审核1:已通过2:已拒绝)")
    @Excel(name = "审核状态")
    @Column(name = "review_status")
    private String reviewStatus;

    /**
     * 审核拒绝原因
     */
    @ApiModelProperty(value = "审核拒绝原因")
    @Excel(name = "审核拒绝原因")
    @Column(name = "reject_reason")
    private String rejectReason;


    /**
     * 用户邮箱
     */
    @ApiModelProperty(value = "用户邮箱")
    @Excel(name = "用户邮箱")
    @Column(name = "email")
    private String email;

    /**
     * 手机号码
     */
    @ApiModelProperty(value = "手机号码")
    @Excel(name = "手机号码")
    @Column(name = "phonenumber")
    private String phonenumber;

    /**
     * 用户性别
     */
    @ApiModelProperty(value = "用户性别")
    @Excel(name = "用户性别", readConverterExp = "0=男,1=女,2=未知")
    @Column(name = "sex")
    private String sex;

    /**
     * 用户头像
     */
    @ApiModelProperty(value = "用户头像")
    @Column(name = "avatar")
    private String avatar;

    /**
     * 密码
     */
    @ApiModelProperty(value = "密码")
    @Column(name = "password")
    private String password;

    /**
     * 帐号状态（0正常 1停用）
     */
    @ApiModelProperty(value = "帐号状态（0正常 1停用）")
    @Excel(name = "帐号状态", readConverterExp = "0=正常,1=停用")
    @Column(name = "status")
    private String status;

    /**
     * 删除标志（0代表存在 2代表删除）
     */
    @ApiModelProperty(value = "删除标志（0代表存在 2代表删除）")
    @Column(name = "del_flag")
    private String delFlag;

    /**
     * 最后登录IP
     */
    @ApiModelProperty(value = "最后登录IP")
    @Excel(name = "最后登录IP", type = Type.EXPORT)
    @Column(name = "login_ip")
    private String loginIp;

    /**
     * 最后登录时间
     */
    @ApiModelProperty(value = "最后登录时间")
    @Excel(name = "最后登录时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss", type = Type.EXPORT)
    @Column(name = "login_date")
    private Date loginDate;

    /**
     * 创建者
     */
    @ApiModelProperty(value = "创建者")
    @Column(name = "create_by")
    private String createBy;

    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @Column(name = "create_time")
    private Date createTime;

    /**
     * 更新者
     */
    @ApiModelProperty(value = "更新者")
    @Column(name = "update_by")
    private String updateBy;

    /**
     * 更新时间
     */
    @ApiModelProperty(value = "更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @Column(name = "update_time")
    private Date updateTime;

    /**
     * 审核认证时间
     */
    @ApiModelProperty(value = "审核认证时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @Column(name = "review_time")
    private Date reviewTime;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    @Column(name = "remark")
    private String remark;

    /**
     * oauth 皖事通
     */
    @ApiModelProperty(value = "皖事通")
    @Column(name = "oauth_wst")
    private String oauthWst;

    /**
     * oauth 微信
     */
    @ApiModelProperty(value = "微信")
    @Column(name = "oauth_wechat")
    private String oauthWechat;


    /**
     * 博览会id
     */
    @ApiModelProperty(value = "博览会id")
    @Column(name = "exposition_id")
    private Long expositionId;
    /**
     * 部门对象
     */
    @ApiModelProperty(value = "部门对象")
    @Excels({
            @Excel(name = "部门名称", targetAttr = "deptName", type = Type.EXPORT),
            @Excel(name = "部门负责人", targetAttr = "leader", type = Type.EXPORT)
    })
    @Transient
    private SysDept dept;

    @Transient
    private Long groupId;

    @Transient
    private String groupName;

    // 是否查询所有非角色用户(0:非1:是)
    @Transient
    private String isAll;
    /**
     * 角色对象
     */
    @ApiModelProperty(value = "角色对象集合")
    @Transient
    private List<SysRole> roles;

    /**
     * 盐加密
     */
    @ApiModelProperty(value = "盐加密")
    @Transient
    private String salt;

    /**
     * 角色组
     */
    @ApiModelProperty(value = "角色组")
    @Transient
    private Long[] roleIds;



    /**
     * 小程序openid
     */
    @ApiModelProperty(value = "openId")
    @Column(name = "open_id")
    private String openId;


    /**
     * 岗位组
     */
    @ApiModelProperty(value = "岗位组")
    @Transient
    private Long[] postIds;

    //参展商的标签列表
    @Transient
    @ApiModelProperty(value = "参展商的标签列表")
    private String labelIdList;

    //参展商的分类id
    @Transient
    @ApiModelProperty(value = "参展商的分类id")
    private Long classificationId;

    //用户管理，根据登录人角色查看用户列表(1:查询主办方角色的用户列表2:查询参展商的角色用户列表)
    @Transient
    private String sponsorOrExhibitor;

    @Transient
    private Integer sort;

    @ApiModelProperty(value = "推广人ID")
    @Column(name = "recommend_id")
    private Long recommendId;

    @ApiModelProperty(value = "渠道二维码")
    @Column(name = "channel_qrcode")
    private String channelQrCode;

    @ApiModelProperty(value = "来源渠道ID")
    @Column(name = "channel_id")
    private Long channelId;

    public SysUser() {

    }

    public SysUser(Long userId) {
        this.userId = userId;
    }

    public Long getUserId() {
        return userId;
    }

    public boolean isAdmin() {
        return isAdmin(this.userId);
    }

    public static boolean isAdmin(Long userId) {
        return userId != null && 1L == userId;
    }

    public Long getDeptId() {
        return deptId;
    }



    @Size(min = 0, max = 40, message = "用户昵称长度不能超过40个字符")
    public String getNickName() {
        return nickName;
    }

    @NotBlank(message = "用户账号不能为空")
    @Size(min = 0, max = 40, message = "用户账号长度不能超过40个字符")
    public String getUserName() {
        return userName;
    }

    @Email(message = "邮箱格式不正确")
    @Size(min = 0, max = 50, message = "邮箱长度不能超过50个字符")
    public String getEmail() {
        return email;
    }

    @Size(min = 0, max = 11, message = "手机号码长度不能超过11个字符")
    public String getPhonenumber() {
        return phonenumber;
    }



    public String getSex() {
        return sex;
    }

    public String getAvatar() {
        return avatar;
    }

    public String getGroupName() {
        return groupName;
    }

    public String getIsAll() {
        return isAll;
    }

    public Date getReviewTime() {
        return reviewTime;
    }

    public Long getGroupId() {
        return groupId;
    }

    public String getLabelIdList() {
        return labelIdList;
    }

    public Long getClassificationId() {
        return classificationId;
    }

    public String getSponsorOrExhibitor() {
        return sponsorOrExhibitor;
    }

    public Integer getSort() {
        return sort;
    }

    public String getOpenId() {
        return openId;
    }
    public Long getRecommendId() {
        return recommendId;
    }

    public String getOauthWst() { return oauthWst; }

    public String getOauthWechat() { return oauthWechat; }

    @Override
    public String toString() {
        return "SysUser{" +
                "userId=" + userId +
                ", userIds=" + userIds +
                ", deptId=" + deptId +
                ", userName='" + userName + '\'' +
                ", nickName='" + nickName + '\'' +
                ", userType='" + userType + '\'' +
                ", reviewerId=" + reviewerId +
                ", reviewStatus='" + reviewStatus + '\'' +
                ", rejectReason='" + rejectReason + '\'' +
                ", email='" + email + '\'' +
                ", phonenumber='" + phonenumber + '\'' +
                ", sex='" + sex + '\'' +
                ", avatar='" + avatar + '\'' +
                ", password='" + password + '\'' +
                ", status='" + status + '\'' +
                ", delFlag='" + delFlag + '\'' +
                ", loginIp='" + loginIp + '\'' +
                ", loginDate=" + loginDate +
                ", createBy='" + createBy + '\'' +
                ", createTime=" + createTime +
                ", updateBy='" + updateBy + '\'' +
                ", updateTime=" + updateTime +
                ", reviewTime=" + reviewTime +
                ", remark='" + remark + '\'' +
                ", expositionId=" + expositionId +
                ", dept=" + dept +
                ", groupId=" + groupId +
                ", groupName='" + groupName + '\'' +
                ", isAll='" + isAll + '\'' +
                ", roles=" + roles +
                ", salt='" + salt + '\'' +
                ", roleIds=" + Arrays.toString(roleIds) +
                ", postIds=" + Arrays.toString(postIds) +
                ", labelIdList='" + labelIdList + '\'' +
                ", classificationId=" + classificationId +
                ", sponsorOrExhibitor='" + sponsorOrExhibitor + '\'' +
                ", sort=" + sort +
                ", recommendId=" + recommendId +
                '}';
    }


    @JsonIgnore
    @JsonProperty
    public String getPassword() {
        return password;
    }

    public String getSalt() {
        return salt;
    }

    public String getStatus() {
        return status;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public String getLoginIp() {
        return loginIp;
    }

    public Date getLoginDate() {
        return loginDate;
    }

    public SysDept getDept() {
        return dept;
    }

    public List<SysRole> getRoles() {
        return roles;
    }

    public Long[] getRoleIds() {
        return roleIds;
    }

    public Long[] getPostIds() {
        return postIds;
    }

    public String getCreateBy() {
        return createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public String getRemark() {
        return remark;
    }

    public String getUserType() {
        return userType;
    }

    public String getReviewStatus() {
        return reviewStatus;
    }

    public String getRejectReason() {
        return rejectReason;
    }

    public Long getReviewerId() {
        return reviewerId;
    }

    public Long getExpositionId() {
        return expositionId;
    }

    public List<Long> getUserIds() {
        return userIds;
    }

    public String getChannelQrCode() {
        return channelQrCode;
    }

    public void setChannelQrCode(String channelQrCode) {
        this.channelQrCode = channelQrCode;
    }

    public Long getChannelId() {
        return channelId;
    }

    public void setChannelId(Long channelId) {
        this.channelId = channelId;
    }
}
