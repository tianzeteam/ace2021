package com.yuejike.common.utils.sms.newxtc.fw.client.impl;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import com.yuejike.common.utils.sms.newxtc.NxtInit;
import com.yuejike.common.utils.sms.newxtc.fw.client.WebCryptApi;
import com.yuejike.common.utils.sms.newxtc.fw.client.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;

public class WebCryptImpl implements WebCryptApi {
	private final static Logger logger = LoggerFactory.getLogger(WebCryptImpl.class);

	boolean isTest = false;

	/**
	 * 
	 */
	@Override
	public Map<String, String> getCryptInputMap() {
		String merchantCode = NxtInit.getInstance().getIni("merchantCode");
		String secKey = NxtInit.getInstance().getIni("secKey");
		Map<String, String> inputMap = new HashMap<String, String>();
		// 安全输入表单名称
		String time = (isTest) ? "abc123456" : System.currentTimeMillis() + "";
		String nxtAesKey = MD5Util.getMD5Str(time);
		String nxtAesIv = MD5Util.getMD5Str(merchantCode + secKey + nxtAesKey);
		String nxtInputSeed = nxtAesKey + nxtAesIv;
		String nxtInputName = "NXT_" + MD5Util.getMD5Str(merchantCode + secKey + nxtInputSeed);
		inputMap.put("nxtAesKey", nxtAesKey);
		inputMap.put("nxtAesIv", nxtAesIv);
		inputMap.put("nxtInputSeed", nxtInputSeed);
		inputMap.put("nxtInputName", nxtInputName);
		try {
			// 生成随机输入表单名称，
			Random random = new Random();
			int count = 20 + random.nextInt(31);
			StringBuilder mobileName = new StringBuilder("NXT_");
			char[] codes = JsonParamUtil.CODES;
			for (int i = 0, l = codes.length; i < count; i++) {
				mobileName.append(codes[random.nextInt(l)]);
			}
			if (isTest) {
				mobileName = new StringBuilder("NXT_abc123456");
			}
			String aesKey = AesUtil.convertTo16(nxtAesKey);
			String aesIv = AesUtil.convertTo16(nxtAesIv);
			String intPutKey = AesUtil.encrypt(mobileName.toString(), aesKey, aesIv);
			inputMap.put("nxtInputKey", intPutKey);
			return inputMap;
		} catch (Exception e) {
			logger.error("getInputKey() nxtAesKey=" + nxtAesKey + ",nxtAesIv=" + nxtAesIv + ",nxtInputName=" + nxtInputName + " e=" + e.toString());
			return inputMap;
		}
	}

	/**
	 * 一步获取 支持标准 request.getParameter 表单获取方式
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@Override
	public String getMobile(HttpServletRequest request) {
		JSONObject inputJson = new JSONObject();
		Enumeration<String> enu = request.getParameterNames();
		String inputName, inputValue;
		Set<String> inputSet = new HashSet<String>();
		while (enu.hasMoreElements()) {
			inputName = enu.nextElement();
			inputValue = request.getParameter(inputName);
			inputJson.put(inputName, inputValue);
			if (inputSet.contains(inputName)) {
				logger.debug("nxtInputName=" + inputName);
			} else {
				inputSet.add(inputName);
			}
		}
		Boolean isNginx = NxtInit.getInstance().getIniBoolean("isNginx");
		String clientIp = isNginx ? ClientIpUtil.getRealIp(request) : request.getRemoteAddr();
		if (clientIp != null) {
			inputJson.put("NXT_CLIENT_IP", clientIp);
		} else {
			logger.error("getMobile() clientIp=" + clientIp);
		}
		int size = inputJson.size();
		if (inputJson.size() > 0) {
			return mobileDec(inputJson);
		} else {
			logger.error("getMobile()  inputJson size=" + size + "|ip=" + clientIp);
			return "";
		}
	}

	/**
	 * 一步获取手机号 支持 JSON 获取方式, 一般应用在 vue 结构
	 * 
	 * @param request
	 * @param inputJson
	 * @return
	 */
	@Override
	public String getMobileByJson(String inputJson) {
		try {
			JSONObject jsonObj = (inputJson != null && inputJson.contains("{") && inputJson.contains("}")) ? JSONObject.parseObject(inputJson) : null;
			if (jsonObj != null && jsonObj.size() > 0) {
				String mobile = mobileDec(jsonObj);
				return mobile;
			} else {
				logger.error("getMobileByJson() inputJson=" + inputJson);
				return "";
			}
		} catch (Exception e) {
			logger.error("getMobileByJson() e=" + e.toString());
			return "";
		}
	}

	/**
	 * 手机号解密
	 * 
	 * @param request
	 * @param jsonObj
	 * @return
	 */
	private String mobileDec(JSONObject jsonObj) {
		String merchantCode = NxtInit.getInstance().getIni("merchantCode");
		String secKey = NxtInit.getInstance().getIni("secKey");

		String mobile = "";
		String ip = (jsonObj != null) ? jsonObj.getString("NXT_CLIENT_IP") : null;
		String nxtClientSeed = (jsonObj != null) ? jsonObj.getString("NXT_CLIENT_SEED") : null;
		String mobileTxt = null;
		int seedLen = (nxtClientSeed != null) ? nxtClientSeed.length() : 0;
		String aesKey = (seedLen == 64) ? nxtClientSeed.substring(0, 32) : null;
		String aesIv = (aesKey != null) ? nxtClientSeed.substring(32) : null;
		String sign = MD5Util.getMD5Str(merchantCode + secKey + aesKey);
		if (aesIv != null && sign != null && aesIv.equals(sign)) {
			// 1 获取安全密钥表单名称
			String nxtInputName = "NXT_" + MD5Util.getMD5Str(merchantCode + secKey + nxtClientSeed);
			// 2 从request 获取安全密钥
			String nxtInputKey = jsonObj.getString(nxtInputName);

			// 3 获取手机号表单名称
			String mobileName = (nxtInputKey != null) ? AesUtil.aesDec(aesKey, aesIv, nxtInputKey) : null;
			// 4 获取手机号密文
			String mobileEnc = (mobileName != null) ? jsonObj.getString(mobileName) : null;
			// 5 解密手机号
			mobileTxt = (mobileEnc != null) ? AesUtil.aesDec(aesKey, aesIv, mobileEnc) : null;
			if (mobileTxt != null && !"".equals(mobileTxt)) {
				mobile = mobileTxt;
			} else {
				String mobileBase64 = (jsonObj != null) ? jsonObj.getString("NXT_MOBILE_OR_PASS") : null;
				mobileTxt = (mobileBase64 != null && !"".equals(mobileBase64)) ? Base64.decodeString(mobileBase64) : null;
				if (mobileTxt != null && !"".equals(mobileTxt)) {
					mobile = mobileTxt;
				}
				StringBuffer sb = new StringBuffer("," + nxtClientSeed + "->aesKey=" + aesKey + ",aesIv=" + aesIv);
				if (nxtInputKey == null)
					sb.append(",1:nxtInputKey(nxtInputName:" + nxtInputName + ")=" + nxtInputKey);
				if (mobileName == null)
					sb.append(",2:mobileName=" + mobileName);
				if (mobileEnc == null)
					sb.append(",3:mobileEnc=" + mobileEnc);

				logger.error("mobileDec() fail,mobile=" + mobile + sb.toString() + "|ip=" + ip);
			}
		} else {
			logger.error("mobileDec() sign err,nxtClientSeed=" + nxtClientSeed + ",seedLen=" + seedLen + ",aesIv=" + aesIv + " no eq (" + sign + ")|ip=" + ip);
		}
		return mobile;
	}
}
