package com.yuejike.common.utils.sms.newxtc.fw.client.util;

import javax.servlet.http.HttpServletRequest;

import com.yuejike.common.utils.sms.newxtc.NxtInit;
import com.yuejike.common.utils.sms.newxtc.fw.client.entity.EventParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;

public class JsonParamUtil {

	public static final String cookToken = "NXT_CLIENT_TOKEN";
	public static final String inputSeed = "NXT_INPUT_SEED";

	private final static Logger logger = LoggerFactory.getLogger(EventParam.class);
	public static final char[] CODES = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };

	public static JSONObject getRequestJson(HttpServletRequest request) {
		CookieUtil cookieUtil = new CookieUtil();
		String nxtToken = cookieUtil.getCookie(request, cookToken);
		JSONObject inputJson = new JSONObject();
		if (nxtToken != null) {
			inputJson.put(cookToken, nxtToken);
		}
		Boolean isNginx = NxtInit.getInstance().getIniBoolean("isNginx");
		String clientIp = isNginx ? ClientIpUtil.getRealIp(request) : request.getRemoteAddr();
		if (clientIp != null) {
			inputJson.put("NXT_CLIENT_IP", clientIp);
		} else {
			logger.error("getJson() clientIp=" + clientIp);
		}
		return inputJson;
	}

	public static JSONObject getInputJson(String sJson) {
		JSONObject inputJson = (sJson != null) ? JSONObject.parseObject(sJson) : null;
		String nxtToken = inputJson.getString("NXT_CLIENT_TOKEN");
		String nxtClientIp = inputJson.getString("NXT_CLIENT_IP");
		String nxtClientSign = inputJson.getString("NXT_CLIENT_SIGN");
		String source = nxtClientIp + nxtToken;
		String vSign = MD5Util.getMD5Str(source);
		boolean vRet = (nxtClientSign != null && vSign != null && vSign.equals(nxtClientSign));
		if (!vRet) {
			inputJson.remove("NXT_CLIENT_IP");
			logger.error("getLoginReq() err vRet=" + vRet + " sJson=" + sJson);
		}
		return inputJson;
	}

}
