package com.yuejike.common.utils.ip;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.alibaba.fastjson.JSONObject;
import com.yuejike.common.config.YueJiKeConfig;
import com.yuejike.common.constant.Constants;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.common.utils.http.HttpUtils;

/**
 * 获取地址类
 * 
 * @author yuejike
 */
public class AddressUtils
{
    private static final Logger log = LoggerFactory.getLogger(AddressUtils.class);

    // IP地址查询
    public static final String IP_URL = "http://whois.pconline.com.cn/ipJson.jsp";

    // 未知地址
    public static final String UNKNOWN = "XX XX";
    // 内网IP
    public static final String INTRANET_IP = "内网IP";

    public static String getRealAddressByIP(String ip)
    {
        // 无法调用外部服务
        // 直接返回
        if(true){
            return INTRANET_IP;
        }

        String address = UNKNOWN;
        // 内网不查询
        if (IpUtils.internalIp(ip))
        {
            return INTRANET_IP;
        }
        if (YueJiKeConfig.isAddressEnabled())
        {
            try
            {
                String rspStr = HttpUtils.sendGet(IP_URL, "ip=" + ip + "&json=true", Constants.GBK);
                if (StringUtils.isEmpty(rspStr))
                {
                    log.error("获取地理位置异常 {}", ip);
                    return UNKNOWN;
                }
                JSONObject obj = JSONObject.parseObject(rspStr);
                String region = obj.getString("pro");
                String city = obj.getString("city");
                return String.format("%s %s", region, city);
            }
            catch (Exception e)
            {
                log.error("获取地理位置异常 {}", ip);
            }
        }
        return address;
    }
}
