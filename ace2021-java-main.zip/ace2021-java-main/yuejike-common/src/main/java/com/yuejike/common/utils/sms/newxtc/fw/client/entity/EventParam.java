package com.yuejike.common.utils.sms.newxtc.fw.client.entity;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.yuejike.common.utils.sms.newxtc.fw.client.util.JsonParamUtil;
import org.apache.commons.lang3.time.FastDateFormat;

import com.alibaba.fastjson.JSONObject;

public class EventParam {
	
	private final static FastDateFormat fm = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss.SSS");

	public static Map<String, Object> getMobileParam(HttpServletRequest request, String eventType, String phone) {
		return getParam(request, eventType, phone, null, phone);
	}

	public static Map<String, Object> getMobileParam(String sJson, String eventType, String phone) {
		return getParam(sJson, eventType, phone, null, phone);
	}

	public static Map<String, Object> getUidParam(HttpServletRequest request, String eventType, String userId) {
		return getParam(request, eventType, null, null, userId);
	}

	public static Map<String, Object> getEmailParam(HttpServletRequest request, String eventType, String userEmail) {
		return getParam(request, eventType, null, userEmail, userEmail);
	}

	/**
	 * 
	 * @param request
	 * @param eventType
	 * @param clientMobile
	 * @param userEmail
	 * @param userId
	 * @return
	 */

	private static Map<String, Object> getParam(HttpServletRequest request, String eventType, String phone, String userEmail, String userId) {
		JSONObject jsonObj = JsonParamUtil.getRequestJson(request);
		return getParamByObj(jsonObj, eventType, phone, userEmail, userId);
	}

	private static Map<String, Object> getParam(String sJson, String eventType, String phone, String userEmail, String userId) {
		JSONObject jsonObj =JsonParamUtil.getInputJson(sJson);
		return getParamByObj(jsonObj, eventType, phone, userEmail, userId);
	}

	/**
	 * @param request
	 * @param userId
	 * @param inputMap
	 */
	private static Map<String, Object> getParamByObj(JSONObject jsonObj, String eventType, String phone, String userEmail, String userId) {
		String nxtToken = (jsonObj != null) ? jsonObj.getString(JsonParamUtil.cookToken) : null;
		Map<String, Object> paramMap = new LinkedHashMap<String, Object>();
		String clientIp = (jsonObj != null) ? jsonObj.getString("NXT_CLIENT_IP") : null;
		if (clientIp != null) {
			paramMap.put("client_ip", clientIp);
		}
		if (nxtToken != null && nxtToken.length() == 64) {
			paramMap.put("nxtToken", nxtToken);
		}
		if (phone != null) {
			paramMap.put("phone", phone);
		}
		paramMap.put("mode", "fw");
		paramMap.put("EVENT_TYPE", eventType);
		paramMap.put("status", "0");// 首次请求状态参数，必填
		paramMap.put("occur_time", fm.format(System.currentTimeMillis()));// 发生事件，必填

		if (userId != null) {
			paramMap.put("user_id", userId);
		}
		if (userEmail != null) {
			paramMap.put("client_email", userEmail);
		}
		return paramMap;
	}
}
