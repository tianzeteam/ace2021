package com.yuejike.web.controller.cms;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.SysInbox;
import com.yuejike.cms.service.ISysInboxService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 站内信Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/inbox")
@Api(tags = "站内信",description = "站内信")
public class SysInboxController extends BaseController {
    @Autowired
    private ISysInboxService sysInboxService;
    @Autowired
    private TokenService tokenService;

    /**
     * 查询站内信列表
     */
    @ApiOperation("查询站内信列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:inbox:list')")
    @GetMapping("/list")
    public TableDataInfo<SysInbox> list(SysInbox sysInbox) {
        Page<SysInbox> page = sysInboxService.findSysInboxPage(sysInbox);
        return getDataTable(page);
    }

    @ApiOperation("根据用户id查询站内信列表接口")
    @GetMapping("/ui/list")
    public TableDataInfo<SysInbox> findListByUserId(SysInbox sysInbox) {
        Page<SysInbox> page = sysInboxService.findSysInboxByUserId(sysInbox);
        return getDataTable(page);
    }
    /**
     * 导出站内信列表
     */
    @ApiOperation("导出站内信列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:inbox:export')")
    @Log(title = "站内信", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(SysInbox sysInbox) {
        List<SysInbox> list = sysInboxService.findSysInboxList(sysInbox);
        ExcelUtil<SysInbox> util = new ExcelUtil<>(SysInbox.class);
        return util.exportExcel(list, "inbox");
    }

    /**
     * 获取站内信详细信息
     */
    @ApiOperation("获取站内信详细信息接口")
    @PreAuthorize("@ss.hasPermi('cms:inbox:query')")
    @GetMapping(value = "/{inboxId}")
    public AjaxResult<SysInbox> getInfo(@PathVariable("inboxId") Long inboxId) {
        return AjaxResult.success(sysInboxService.findById(inboxId));
    }

    /**
     * 新增站内信
     */
    @ApiOperation("新增站内信接口")
    @PreAuthorize("@ss.hasPermi('cms:inbox:add')")
    @Log(title = "站内信", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SysInbox sysInbox) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        sysInbox.setCreateBy(loginUser.getUsername());
        sysInbox.setCreateTime(new Date());
        sysInbox.setStatus("0");
        sysInbox.setDelFlag("0");
        sysInboxService.save(sysInbox);
        return AjaxResult.success();
    }

    /**
     * 修改站内信
     */
    @ApiOperation("修改站内信接口")
    @PreAuthorize("@ss.hasPermi('cms:inbox:edit')")
    @Log(title = "站内信", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SysInbox sysInbox) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        sysInbox.setUpdateBy(loginUser.getUsername());
        sysInbox.setUpdateTime(new Date());
        sysInboxService.save(sysInbox);
        return AjaxResult.success();
    }

    /**
     * 删除站内信
     */
    @ApiOperation("删除站内信接口")
    @PreAuthorize("@ss.hasPermi('cms:inbox:remove')")
    @Log(title = "站内信", businessType = BusinessType.DELETE)
	@DeleteMapping("/{inboxIds}")
    public AjaxResult remove(@PathVariable Long[] inboxIds) {
        sysInboxService.deleteByIds(Arrays.asList(inboxIds));
        return AjaxResult.success();
    }
}
