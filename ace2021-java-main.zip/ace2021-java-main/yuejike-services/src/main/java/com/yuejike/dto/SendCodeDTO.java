package com.yuejike.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel("获取验证码信息")
public class SendCodeDTO implements Serializable{

    /**
     * 用户邮箱
     */
    @ApiModelProperty(value = "用户邮箱/手机号")
    private String account;


    @ApiModelProperty(value = "注册类型:0手机号1邮箱")
    private int registerType;
}
