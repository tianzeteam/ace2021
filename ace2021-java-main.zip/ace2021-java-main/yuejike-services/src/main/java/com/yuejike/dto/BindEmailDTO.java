package com.yuejike.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

@Data
@ApiModel("绑定邮箱或者更换邮箱信息")
public class BindEmailDTO implements Serializable{
    /**
     * 用户邮箱
     */
    @Email(message = "请输入正确的邮箱")
    @ApiModelProperty(value = "用户邮箱")
    private String email;
    /**
     * 用户性别
     */
    @ApiModelProperty(value = "验证码")
    private String code;
}
