package com.yuejike.web.controller.cms;

import com.yuejike.cms.domain.CmsExposition;
import com.yuejike.cms.service.ICmsExpositionService;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.SecurityUtils;
import com.yuejike.common.utils.StringUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsHall;
import com.yuejike.cms.service.ICmsHallService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.*;
import java.util.stream.Collectors;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 场馆信息Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/hall")
@Api(tags = "场馆信息",description = "场馆信息")
public class CmsHallController extends BaseController {
    @Autowired
    private ICmsHallService cmsHallService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private ICmsExpositionService expositionService;

    /**
     * 查询场馆信息列表
     */
    @ApiOperation("查询场馆信息列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:hall:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsHall> list(CmsHall cmsHall) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser.getUser().getUserType().equals("02")){
            List<Long> hallIds = new ArrayList<>();
            CmsExposition exposition = expositionService.findById(loginUser.getUser().getExpositionId());
            if(StringUtils.isNotBlank(exposition.getHallId())){
                String[] hallId =exposition.getHallId().split(",");
                for (String s : hallId) {
                    hallIds.add(Long.parseLong(s));
                }
                cmsHall.setHallIds(hallIds);
            }
        }
        Page<CmsHall> page = cmsHallService.findCmsHallPage(cmsHall);
        return getDataTable(page);
    }

    /**
     * 导出场馆信息列表
     */
    @ApiOperation("导出场馆信息列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:hall:export')")
    @Log(title = "场馆信息", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsHall cmsHall) {
        List<CmsHall> list = cmsHallService.findCmsHallList(cmsHall);
        ExcelUtil<CmsHall> util = new ExcelUtil<>(CmsHall.class);
        return util.exportExcel(list, "hall");
    }

    /**
     * 获取场馆信息详细信息
     */
    @ApiOperation("获取场馆信息详细信息接口")
    @PreAuthorize("@ss.hasPermi('cms:hall:query')")
    @GetMapping(value = "/{hallId}")
    public AjaxResult<CmsHall> getInfo(@PathVariable("hallId") Long hallId) {
        return AjaxResult.success(cmsHallService.findById(hallId));
    }

    /**
     * 新增场馆信息
     */
    @ApiOperation("新增场馆信息接口")
    @PreAuthorize("@ss.hasPermi('cms:hall:add')")
    @Log(title = "场馆信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsHall cmsHall) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsHall.setCreateBy(loginUser.getUsername());
        cmsHall.setCreateTime(new Date());
        cmsHall.setDelFlag("0");
        CmsHall hall = cmsHallService.save(cmsHall);
        //将新增的场馆更新到博览会表中
        if(loginUser.getUser().getUserType().equals(UserType.ZBF.getCode()) || loginUser.getUser().getUserType().equals(UserType.ADMIN.getCode())){
            CmsExposition exposition = expositionService.findById(loginUser.getUser().getExpositionId());
            String hallIds = "";
            if(StringUtils.isNotBlank(exposition.getHallId())){
                hallIds = exposition.getHallId() +","+hall.getHallId();
            }else{
                hallIds = hall.getHallId().toString();
            }
            exposition.setHallId(hallIds);
            exposition.setUpdateBy(loginUser.getUsername());
            exposition.setUpdateTime(new Date());
            expositionService.update(exposition);
        }
        return AjaxResult.success();
    }

    /**
     * 修改场馆信息
     */
    @ApiOperation("修改场馆信息接口")
    @PreAuthorize("@ss.hasPermi('cms:hall:edit')")
    @Log(title = "场馆信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsHall cmsHall) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsHall.setUpdateBy(loginUser.getUsername());
        cmsHall.setUpdateTime(new Date());
        cmsHallService.save(cmsHall);
        return AjaxResult.success();
    }

    /**
     * 删除场馆信息
     */
    @ApiOperation("删除场馆信息接口")
    @PreAuthorize("@ss.hasPermi('cms:hall:remove')")
    @Log(title = "场馆信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{hallId}")
    public AjaxResult remove(@PathVariable Long hallId) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        // cmsHallService.deleteByIds(Arrays.asList(hallId));
        cmsHallService.deleteCmsHallById(hallId);
        //删除博览会表中的场馆id
        if(loginUser.getUser().getUserType().equals(UserType.ZBF.getCode())){
            CmsExposition exposition = expositionService.findById(loginUser.getUser().getExpositionId());
            String[] hallIds = exposition.getHallId().split(",");
            List<String> hallIdList = Arrays.asList(hallIds);
            hallIdList= hallIdList.stream().filter(e -> Long.parseLong(e) != hallId).collect(Collectors.toList());
            String newHallIds = StringUtils.join(hallIdList,",");
            System.out.println("-----"+hallIdList+"------删除后的数据--------");
            System.out.println("-----"+newHallIds+"------添加后的数据--------");

            exposition.setHallId(newHallIds);
            expositionService.update(exposition);
        }
        return AjaxResult.success();
    }

    /**
     * 场馆状态修改
     * @param cmsHall
     * @return
     */
    @ApiOperation("场馆状态修改接口")
    @PreAuthorize("@ss.hasPermi('system:hall:edit')")
    @Log(title = "场馆管理", businessType = BusinessType.UPDATE)
    @PutMapping("/changeStatus")
    public AjaxResult changeStatus(@RequestBody CmsHall cmsHall) {
        cmsHall.setUpdateBy(SecurityUtils.getUsername());
        return toAjax(cmsHallService.updateHallStatus(cmsHall));
    }
}
