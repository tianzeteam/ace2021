package com.yuejike.web.controller.cms;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.yuejike.cms.domain.CmsLive;
import com.yuejike.cms.domain.CmsLiveAppointment;
import com.yuejike.cms.domain.SysUserGroupRelation;
import com.yuejike.cms.dto.BaiJiaYunInterfaceUrl;
import com.yuejike.cms.service.ICmsEnrollService;
import com.yuejike.cms.service.ICmsLiveAppointmentService;
import com.yuejike.cms.service.ICmsLiveService;
import com.yuejike.cms.service.ISysUserGroupRelationService;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.annotation.Message;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.page.TableDataInfo;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.common.enums.NoticeType;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.utils.sms.LuoSiMaoSmsUtils;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.system.service.ISysUserService;
import com.yuejike.web.util.RestTemplateUtil;
import com.yuejike.web.util.SignUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * 直播Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/live")
@Api(tags = "直播",description = "直播")
@CrossOrigin
public class CmsLiveController extends BaseController {
    @Autowired
    private ICmsLiveService cmsLiveService;

    @Autowired
    private ICmsLiveAppointmentService  cmsLiveAppointmentService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private ISysUserGroupRelationService userGroupRelationService;
    @Autowired
    private ICmsEnrollService cmsEnrollService;
    @Autowired
    private ISysUserService sysUserService;
    /**
     * 查询直播列表
     */
    @ApiOperation("查询直播列表接口")
    @PreAuthorize("@ss.hasPermi('cms:live:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsLive> list(CmsLive cmsLive) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser.getUser().getUserType().equals(UserType.CZS.getCode())){
            cmsLive.setDeptId(loginUser.getUser().getDeptId());
        }
        cmsLive.setDelFlag("0");
        Page<CmsLive> page = cmsLiveService.findCmsLivePage(cmsLive);
        return getDataTable(page);
    }

    /**
     * 根据角色类型查询直播列表
     */
    @ApiOperation("根据角色类型查询直播列表接口")
    @GetMapping("/ui/list")
    public TableDataInfo<CmsLive> findLiveListByUserId(CmsLive cmsLive) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser != null){
            if(loginUser.getUser().getUserType().equals("02")){
                cmsLive.setEmpower("00,02");
            }else if(loginUser.getUser().getUserType().equals("03")){
                cmsLive.setEmpower("00,03");
            }else if(loginUser.getUser().getUserType().equals("04")){
                cmsLive.setEmpower("00,04");
            }else if(loginUser.getUser().getUserType().equals("05")){
                cmsLive.setEmpower("00,05");
            }else if(loginUser.getUser().getUserType().equals("06")){
                cmsLive.setEmpower("00,06");
            }
            //查询登录人是否在分组中
            SysUserGroupRelation userGroupRelation =userGroupRelationService.findByUserIdAndGroupId(loginUser.getUser().getUserId());
            if(null != userGroupRelation){
                cmsLive.setGroupId(userGroupRelation.getGroupId().toString());
            }
        }else{
            cmsLive.setEmpower("00");
        }
        cmsLive.setStatus("1");
        // cmsLive.setLiveForm("0");//在线直播
        cmsLive.setIsUiList("1");//标识是前端显示用，需要直播类型为在线直播和外部链接直播
        cmsLive.setDelFlag("0");
        Page<CmsLive> page = cmsLiveService.findCmsLivePage(cmsLive);
        return getDataTable(page);
    }



    /**
     * 导出直播列表
     */
    @ApiOperation("导出直播列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:live:export')")
    @Log(title = "直播", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsLive cmsLive) {
        List<CmsLive> list = cmsLiveService.findCmsLiveList(cmsLive);
        ExcelUtil<CmsLive> util = new ExcelUtil<>(CmsLive.class);
        return util.exportExcel(list, "live");
    }

    /**
     * 获取直播详细信息
     */
    @ApiOperation("获取直播详细信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:live:query')")
    @GetMapping(value = "/{liveId}")
    public AjaxResult<CmsLive> getInfo(@PathVariable("liveId") Long liveId) {
        return AjaxResult.success(cmsLiveService.findById(liveId));
    }

    /**
     * 新增直播
     */
    @ApiOperation("新增直播接口")
    @PreAuthorize("@ss.hasPermi('cms:live:add')")
    @Log(title = "直播", businessType = BusinessType.INSERT)
    @Message(title = "特定直播通知",noticeType = NoticeType.LIVE)
    @PostMapping
    public AjaxResult add(@RequestBody CmsLive cmsLive) {
        AjaxResult ajaxResult = new AjaxResult();
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsLive.setCreateBy(loginUser.getUsername());
        cmsLive.setCreateTime(new Date());
        cmsLive.setCreateId(loginUser.getUser().getUserId());
        //创建人为展商时，需要保存展商的部门id
        if(loginUser.getUser().getUserType().equals(UserType.CZS.getCode())){
            cmsLive.setDeptId(loginUser.getUser().getDeptId());
        }
        cmsLive.setExpositionId(loginUser.getUser().getExpositionId());
        cmsLive.setDelFlag("0");
        cmsLive.setProcess("0");//直播进程默认未开始
        if(loginUser.getUser().getUserType().equals("02")){
            cmsLive.setEmpower("00");//展商创建的直播，所有人可见
            cmsLive.setCreateType("1");
            cmsLive.setStatus("0");
            cmsLive.setType("1");
        }else{
            cmsLive.setCreateType("0");
            cmsLive.setStatus("1");
            cmsLive.setReviewerId(loginUser.getUser().getUserId());
            cmsLive.setReviewTime(new Date());
        }
        CmsLive live = cmsLiveService.save(cmsLive);
        // saveLiveUser(live);
        if(cmsLive.getLiveForm().equals("0")){
            //数据库保存成功后，将创建直播房间
            JSONObject result = createRoom(cmsLive);
            System.out.println("--------百家云返回信息-------"+result);
            if(result.getInteger("code") != 0){
                //code≠0,表明直播创建失败
                cmsLiveService.deleteCmsLiveById(live.getLiveId());
                ajaxResult.setCode(500);
                ajaxResult.setMsg(result.getString("msg"));
            }else{
                //直播创建成功,将直播信息更新到数据库中
                String data =result.getString("data");
                JSONObject jsonData = JSON.parseObject(data);
                live.setRoomId(jsonData.getString("room_id"));
                live.setAdminCode(jsonData.getString("admin_code"));
                live.setStudentCode(jsonData.getString("student_code"));
                live.setTeacherCode(jsonData.getString("teacher_code"));
                cmsLiveService.save(live);
                ajaxResult.setCode(0);
                if((StringUtils.isNotBlank(live.getEmpower()) && !live.getEmpower().equals("00")) || StringUtils.isNotBlank(live.getGroupId())){
                    ajaxResult.setData(live);
                }
                ajaxResult.setCode(0);
                ajaxResult.setMsg("直播创建成功！");
            }
        }else{
            if(StringUtils.isNotBlank(live.getEmpower()) && !live.getEmpower().equals("00")){
                System.out.println(live+"-----live-------");
                ajaxResult.setData(live);
            }
            ajaxResult.setCode(0);
            ajaxResult.setMsg("创建成功！");
        }
        return ajaxResult;
    }



    // 调用百家云创建room的接口方法
    private JSONObject createRoom(CmsLive cmsLive){
        Map<String,Object> map = new HashMap<>();
        map.put("title",cmsLive.getName());
        map.put("start_time",cmsLive.getStartTime().getTime()/1000);
        map.put("end_time",cmsLive.getEndTime().getTime()/1000);
        map.put("partner_id",BaiJiaYunInterfaceUrl.partner_id);
        map.put("timestamp",new Date().getTime()/1000);
        map.put("type",2);
        map.put("is_push_live",1);
        map.put("push_live_record",1);
        String sign = SignUtil.getSign(map);
        map.put("sign",sign);

        StringBuilder parameter = new StringBuilder();
        for (Map.Entry<String, Object> m : map.entrySet()) {
//            System.out.println("key:" + m.getKey() + " value:" + m.getValue());
            parameter.append(m.getKey()+"="+m.getValue()).append("&");
        }
        //调用创建房间接口
        String result= RestTemplateUtil.sendPost(BaiJiaYunInterfaceUrl.private_domain + BaiJiaYunInterfaceUrl.createRoom, parameter.toString());
        JSONObject jsonObject = JSONObject.parseObject(result);
        return jsonObject;
    }

    @ApiOperation("进入直播间的接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "liveId", value = "直播ID", required = true, paramType="path", dataType = "Long",defaultValue = "0")
    })
    @GetMapping(value = "/enterLiveRoom/{liveId}")
    public AjaxResult enterLiveRoom(@PathVariable("liveId") Long liveId) {
        System.out.println(liveId+"------直播id-----");
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        CmsLive live = cmsLiveService.findById(liveId);
        Map<String,Object> map = new HashMap<>();
        map.put("room_id",live.getRoomId());
        map.put("user_number",loginUser.getUser().getUserId());
        if(loginUser.getUser().getUserType().equals("00")){
            map.put("user_role",2);//管理员
        }else if( loginUser.getUser().getUserType().equals("01")|| loginUser.getUser().getUserType().equals("02")){
            map.put("user_role",1);//老师
        }else{
            map.put("user_role",0);//学生
        }
        map.put("user_name",loginUser.getUser().getNickName());
//        map.put("user_avatar",loginUser.getUser().getAvatar());
        String sign = SignUtil.getSign(map);
        map.put("sign",sign);
        //开始拼接参数
        StringBuilder parameter = new StringBuilder();
        for (Map.Entry<String, Object> m : map.entrySet()) {
//            System.out.println("key:" + m.getKey() + " value:" + m.getValue());
            parameter.append(m.getKey()+"="+m.getValue()).append("&");
        }
        String result =BaiJiaYunInterfaceUrl.private_domain + BaiJiaYunInterfaceUrl.enterRoom +"?"+parameter;
        AjaxResult ajaxResult = new AjaxResult();
        ajaxResult.setCode(0);
        ajaxResult.setData(result);
        return ajaxResult;
    }

    @ApiOperation("获取直播上下课状态")
    @PostMapping(value = "/getClassStatus")
    public AjaxResult getClassStatus(@RequestParam Map<String,Object> map){
        System.out.println("----进入接收直播上下课的方法中----");
        System.out.println("------"+map+"-------");
        // map = {room_id=21092656716327, op_time=2021-09-26 10:51:21, op=end, qid=202109261051213547245675, timestamp=1632624681, sign=acf92b4463f0d240c81d3f6d299520f8}
        CmsLive live = cmsLiveService.findByRoomId(map.get("room_id").toString());
        if(map.get("op").equals("start")){
            live.setProcess("1");
        }else if(map.get("op").equals("end")){
            live.setProcess("2");
        }
        cmsLiveService.save(live);
        return AjaxResult.success();
    }

    /**
     * 修改直播
     */
    @ApiOperation("修改直播接口")
    @PreAuthorize("@ss.hasPermi('cms:live:edit')")
    @Log(title = "直播", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsLive cmsLive) {
        AjaxResult ajaxResult = new AjaxResult();
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(null != loginUser){
            if(loginUser.getUser().getUserType().equals(UserType.ZBF.getCode()) || loginUser.getUser().getUserType().equals(UserType.ADMIN.getCode())){
                if(StringUtils.isNotBlank(cmsLive.getIsReview()) && cmsLive.getIsReview().equals("1")) {
                    //审核
                    cmsLive.setReviewerId(loginUser.getUser().getUserId());
                    cmsLive.setReviewTime(new Date());
                    cmsLiveService.save(cmsLive);
                    ajaxResult.setCode(0);
                    ajaxResult.setMsg("审核成功");
                }else{
                    //修改
                    if(cmsLive.getLiveForm().equals("0")){//在线直播
                        //更新百家云房间信息
                        JSONObject jsonObject = updateRoom(cmsLive);
                        if(jsonObject.getInteger("code")==0){
                            cmsLive.setUpdateBy(loginUser.getUsername());
                            cmsLive.setUpdateTime(new Date());
                            cmsLiveService.save(cmsLive);
                            ajaxResult.setCode(0);
                            ajaxResult.setMsg("修改成功");
                        }else{
                            ajaxResult.setCode(500);
                            ajaxResult.setMsg(jsonObject.getString("msg"));
                        }
                    }else{//外部链接直播or图文直播
                        cmsLive.setUpdateBy(loginUser.getUsername());
                        cmsLive.setUpdateTime(new Date());
                        cmsLiveService.save(cmsLive);
                        ajaxResult.setCode(0);
                        ajaxResult.setMsg("修改成功");
                    }
                }
            }else if(loginUser.getUser().getUserType().equals(UserType.CZS.getCode())){
                cmsLive.setUpdateBy(loginUser.getUsername());
                cmsLive.setUpdateTime(new Date());
                cmsLiveService.save(cmsLive);
                ajaxResult.setCode(0);
                ajaxResult.setMsg("修改成功");
            }
        }
        return ajaxResult;
    }
    // 调用百家云更新room的接口方法
    private JSONObject updateRoom(CmsLive cmsLive){
        Map<String,Object> map = new HashMap<>();
        map.put("room_id",cmsLive.getRoomId());
        map.put("title",cmsLive.getName());
        map.put("start_time",cmsLive.getStartTime().getTime()/1000);
        map.put("end_time",cmsLive.getEndTime().getTime()/1000);
        map.put("partner_id",BaiJiaYunInterfaceUrl.partner_id);
        map.put("timestamp",new Date().getTime()/1000);
        String sign = SignUtil.getSign(map);
        map.put("sign",sign);

        StringBuilder parameter = new StringBuilder();
        for (Map.Entry<String, Object> m : map.entrySet()) {
            parameter.append(m.getKey()+"="+m.getValue()).append("&");
        }
        //调用更新房间接口
        String result= RestTemplateUtil.sendPost(BaiJiaYunInterfaceUrl.private_domain + BaiJiaYunInterfaceUrl.updateRoom, parameter.toString());
        JSONObject jsonObject = JSONObject.parseObject(result);
        return jsonObject;
    }


    /**
     * 删除直播
     */
    @ApiOperation("删除直播接口")
    @PreAuthorize("@ss.hasPermi('cms:live:remove')")
    @Log(title = "直播", businessType = BusinessType.DELETE)
	@DeleteMapping("/{liveId}")
    public AjaxResult remove(@PathVariable Long liveId) {
        // cmsLiveService.deleteByIds(Arrays.asList(liveIds));
        AjaxResult ajaxResult = new AjaxResult();
        CmsLive live = cmsLiveService.findById(liveId);
        if(live.getLiveForm().equals("0")){
            JSONObject jsonObject = deleteRoom(live);
            if(jsonObject.getInteger("code") ==0){
                live.setDelFlag("1");
                cmsLiveService.save(live);
                // cmsLiveService.deleteCmsLiveById(liveId);
                //将报名表中的这条直播也得进行删除
                cmsEnrollService.updateByLiveId(liveId);

                ajaxResult.setCode(0);
                ajaxResult.setMsg("删除成功");
            }else{
                ajaxResult.setCode(500);
                ajaxResult.setMsg(jsonObject.getString("msg"));
            }
        }else{
            // cmsLiveService.deleteCmsLiveById(liveId);
            live.setDelFlag("1");
            cmsLiveService.save(live);
            ajaxResult.setCode(0);
            ajaxResult.setMsg("删除成功");
        }
        return ajaxResult;
    }


    // 调用百家云删除room的接口方法
    private JSONObject deleteRoom(CmsLive cmsLive){
        Map<String,Object> map = new HashMap<>();
        map.put("room_id",cmsLive.getRoomId());
        map.put("partner_id",BaiJiaYunInterfaceUrl.partner_id);
        map.put("timestamp",new Date().getTime()/1000);
        String sign = SignUtil.getSign(map);
        map.put("sign",sign);

        StringBuilder parameter = new StringBuilder();
        for (Map.Entry<String, Object> m : map.entrySet()) {
            parameter.append(m.getKey()+"="+m.getValue()).append("&");
        }
        //调用删除房间接口
        String result= RestTemplateUtil.sendPost(BaiJiaYunInterfaceUrl.private_domain + BaiJiaYunInterfaceUrl.deleteRoom, parameter.toString());
        JSONObject jsonObject = JSONObject.parseObject(result);
        return jsonObject;
    }

    @ApiOperation("根据roomid获取token")
    @PostMapping(value = "/getPlayBackToken")
    public AjaxResult getPlayBackToken(@RequestParam("roomId")String roomId){
        AjaxResult ajaxResult = new AjaxResult();
        Map<String,Object> map = new HashMap<>();
        map.put("partner_id",BaiJiaYunInterfaceUrl.partner_id);
        map.put("room_id",roomId);
        map.put("expires_in",7200);
        map.put("timestamp",System.currentTimeMillis());
        String sign = SignUtil.getSign(map);
        map.put("sign",sign);
        //开始拼接参数
        StringBuilder parameter = new StringBuilder();
        for (Map.Entry<String, Object> m : map.entrySet()) {
            parameter.append(m.getKey()+"="+m.getValue()).append("&");
        }
        String result= RestTemplateUtil.sendPost(BaiJiaYunInterfaceUrl.private_domain + BaiJiaYunInterfaceUrl.playbackToken, parameter.toString());
        JSONObject jsonObject = JSONObject.parseObject(result);
        if(jsonObject.getInteger("code") ==0){
            ajaxResult.setCode(0);
            ajaxResult.setMsg("获取成功");
            HashMap<String,Object> retMap = new HashMap<>();
            ajaxResult.setData(jsonObject.get("data").toString());
        }else{
            ajaxResult.setCode(500);
            String msg = jsonObject.getString("msg");
            if(msg.equals("回放教室不存在或已删除")){
                msg = "回放地址不存在或已删除";
            }
            ajaxResult.setMsg(msg);
        }
        return ajaxResult;
    }
    @ApiOperation("根据roomid获取推流地址")
    @GetMapping(value = "/getPlayBackToken/{roomId}")
    public AjaxResult getPushLiveUrl(@PathVariable("roomId")String roomId){
        AjaxResult ajaxResult = new AjaxResult();
        Map<String,Object> map = new HashMap<>();
        map.put("partner_id",BaiJiaYunInterfaceUrl.partner_id);
        map.put("room_id",roomId);
        map.put("timestamp",System.currentTimeMillis());
        String sign = SignUtil.getSign(map);
        map.put("sign",sign);
        //开始拼接参数
        StringBuilder parameter = new StringBuilder();
        for (Map.Entry<String, Object> m : map.entrySet()) {
            parameter.append(m.getKey()+"="+m.getValue()).append("&");
        }
        String result= RestTemplateUtil.sendPost(BaiJiaYunInterfaceUrl.private_domain + BaiJiaYunInterfaceUrl.pushLiveUrl, parameter.toString());
        JSONObject jsonObject = JSONObject.parseObject(result);
        if(jsonObject.getInteger("code") ==0){
            ajaxResult.setCode(0);
            ajaxResult.setMsg("获取成功");
            HashMap<String,Object> retMap = new HashMap<>();
            ajaxResult.setData(jsonObject.get("data").toString());
        }else{
            ajaxResult.setCode(500);
            ajaxResult.setMsg(jsonObject.getString("msg"));
        }
        return ajaxResult;
    }


    /**
     * 新增直播预约
     */
    @ApiOperation("新增直播预约接口")
   // @PreAuthorize("@ss.hasPermi('cms:live:add')")
    @Log(title = "直播预约", businessType = BusinessType.INSERT)
    @PostMapping("/appointment")
    public AjaxResult addAppointment(@RequestBody CmsLiveAppointment cmsLive) {
        //Assert.notNull(cmsLive.getMobile(),"手机号码不能为空");
        Assert.notNull(cmsLive.getType(),"直播类型不能为空");
        CmsLive cmsLiveTmp = cmsLiveService.findById(cmsLive.getLiveId());
        if(cmsLiveTmp == null) {
            return AjaxResult.error("未找到对应直播");
        }
        AjaxResult ajaxResult = new AjaxResult();
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsLive.setUserId(loginUser.getUser().getUserId());
        cmsLive.setCreateBy(loginUser.getUsername());
        cmsLive.setCreateTime(new Date());
        cmsLive.setStatus("0");
        SysUser sysUser = sysUserService.selectUserById(loginUser.getUser().getUserId());
        cmsLive.setMobile(sysUser.getPhonenumber());
        cmsLive.setName(cmsLiveTmp.getName());
        CmsLiveAppointment live = cmsLiveAppointmentService.save(cmsLive);

        ajaxResult.setCode(0);
        ajaxResult.setMsg("预约成功！");

        return ajaxResult;
    }

    @ApiOperation("审核直播接口")
    @PreAuthorize("@ss.hasPermi('cms:live:review')")
    @Log(title = "直播", businessType = BusinessType.UPDATE)
    @PutMapping("/review/{liveIds}")
    public AjaxResult review(@PathVariable Long[] liveIds, @RequestBody CmsLive cmsLive){
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsLive.setReviewerId(loginUser.getUser().getUserId());
        cmsLive.setReviewTime(new Date());
        cmsLiveService.review(liveIds, cmsLive);
        if(cmsLive.getStatus().equals("1") || cmsLive.getStatus().equals("2")){
            Arrays.stream(liveIds).forEach(id -> {
                CmsLive cmsLive1 = cmsLiveService.findById(id);
                if(cmsLive1 != null) {
                    SysUser user = sysUserService.selectUserById(cmsLive1.getCreateId());
                    if(user != null && StringUtils.isNotEmpty(user.getPhonenumber())){
                        LuoSiMaoSmsUtils.getInstance().sendApprovedLiveMsg(user.getPhonenumber(), cmsLive1.getName(),
                                cmsLive.getStatus().equals("1"));
                    }
                }
            });
        }
        return AjaxResult.success("审核成功");
    }

}
