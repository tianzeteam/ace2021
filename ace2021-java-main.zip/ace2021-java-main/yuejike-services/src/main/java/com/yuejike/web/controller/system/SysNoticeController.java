package com.yuejike.web.controller.system;

import com.alibaba.fastjson.JSONObject;
import com.yuejike.cms.domain.*;
import com.yuejike.cms.dto.MessageDTO;
import com.yuejike.cms.service.*;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.utils.http.HttpUtils;
import com.yuejike.common.utils.sms.LuoSiMaoSmsUtils;
import com.yuejike.system.domain.SysNotice;
import com.yuejike.system.service.ISysNoticeService;
import com.yuejike.system.service.ISysUserService;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;

import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.multipart.MultipartFile;


/**
 * 通知公告Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-28
 */
@RestController
@RequestMapping("/cms/notice")
@Api(tags = "通知公告",description = "通知公告")
public class SysNoticeController extends BaseController {
    @Autowired
    private ISysNoticeService sysNoticeService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private ISysUserService sysUserService;
    @Autowired
    private ISysInboxService inboxService;
    @Autowired
    private ISysUserGroupRelationService userGroupRelationService;
    @Autowired
    private ICmsOrderService orderService;
    @Autowired
    private ICmsNegotiateService negotiateService;
    @Autowired
    private ICmsUserCardExchangeService userCardExchangeService;


    /**
     * 查询通知公告列表
     */
    @ApiOperation("查询通知公告列表接口")
    @PreAuthorize("@ss.hasPermi('system:notice:list')")
    @GetMapping("/list")
    public TableDataInfo<SysNotice> list(SysNotice sysNotice) {
        Page<SysNotice> page = sysNoticeService.findSysNoticePage(sysNotice);
        return getDataTable(page);
    }

    /**
     * 导出通知公告列表
     */
    @ApiOperation("导出通知公告列表数据接口")
    @PreAuthorize("@ss.hasPermi('system:notice:export')")
    @Log(title = "通知公告", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(SysNotice sysNotice) {
        List<SysNotice> list = sysNoticeService.findSysNoticeList(sysNotice);
        ExcelUtil<SysNotice> util = new ExcelUtil<>(SysNotice.class);
        return util.exportExcel(list, "notice");
    }

    /**
     * 获取通知公告详细信息
     */
    @ApiOperation("获取通知公告详细信息接口")
    @PreAuthorize("@ss.hasPermi('system:notice:query')")
    @GetMapping(value = "/{noticeId}")
    public AjaxResult<SysNotice> getInfo(@PathVariable("noticeId") Integer noticeId) {
        return AjaxResult.success(sysNoticeService.findById(noticeId));
    }

    /**
     * 新增通知公告
     */
    @ApiOperation("新增通知公告接口")
    @PreAuthorize("@ss.hasPermi('system:notice:add')")
//    @Log(title = "通知公告", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(SysNotice sysNotice) throws IOException {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser.getUser().getUserType().equals("00")){
            sysNotice.setCreateType("0");
        }else if(loginUser.getUser().getUserType().equals("01")){
            sysNotice.setCreateType("1");
        }else if (loginUser.getUser().getUserType().equals("02")){
            sysNotice.setCreateType("2");
        }
        //3站内信 4短信 5站内信+短信
        if(sysNotice.getNoticeType().equals("3")){
            sysNotice.setNoticeTitle("【"+ loginUser.getUser().getNickName() + "】站内信通知");
        }else if(sysNotice.getNoticeType().equals("4")){
            sysNotice.setNoticeTitle("【"+ loginUser.getUser().getNickName() + "】短信通知");
            if(null != sysNotice.getFile()){
                //读取文件
                byte[] bytes = sysNotice.getFile().getBytes();
                InputStream inputStream = new ByteArrayInputStream(bytes);
                // String fileName = sysNotice.getFile().getOriginalFilename().substring(0,sysNotice.getFile().getOriginalFilename().indexOf("."));
                String fileName = sysNotice.getFile().getOriginalFilename();
                sysNotice.setAcceptType(fileName);
                //调上传接口
                String backParam = HttpUtils.sendFile("https://pro-obs.zgkbh.cn",MultipartFileToFile(sysNotice.getFile()));
                JSONObject jsonObject =JSONObject.parseObject(backParam);
                JSONObject dataObject = JSONObject.parseObject(jsonObject.getString("data"));
                sysNotice.setFileUrl(dataObject.getString("fileName"));
                new Thread() {
                    public void run() {
                        try {
                            sendMsg(sysNotice,inputStream);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    };
                }.start();
            }else if(sysNotice.getAcceptType() != null || sysNotice.getGroupId() != null){
                List<String> phoneNumbers = new ArrayList<>();
                if(sysNotice.getAcceptType() != null){
                    phoneNumbers.addAll(sysUserService.getPhoneNumberByUserType(sysNotice.getAcceptType().split(",")));
                }
                if(sysNotice.getGroupId() != null){
                    phoneNumbers.addAll(sysUserService.getPhoneNumberByGroupId(
                            Arrays.stream(sysNotice.getGroupId().split(",")).map(it->Long.valueOf(it)).toArray(Long[]::new)));
                }
                if(phoneNumbers.size()>0)
                    LuoSiMaoSmsUtils.getInstance().sendCustomMsg(phoneNumbers.stream().toArray(String[]::new),sysNotice.getNoticeContent());
            }

        }else if(sysNotice.getNoticeType().equals("5")){
            sysNotice.setNoticeTitle("【"+ loginUser.getUser().getNickName() + "】站内信+短信通知");
            if(null != sysNotice.getFile()){
                byte[] bytes = sysNotice.getFile().getBytes();
                InputStream inputStream = new ByteArrayInputStream(bytes);
                //调上传接口
                String backParam = HttpUtils.sendFile("https://pro-obs.zgkbh.cn",MultipartFileToFile(sysNotice.getFile()));
                JSONObject jsonObject =JSONObject.parseObject(backParam);
                JSONObject dataObject = JSONObject.parseObject(jsonObject.getString("data"));
                sysNotice.setFileUrl(dataObject.getString("fileName"));
                new Thread() {
                    public void run() {
                        try {
                            sendMsg(sysNotice,inputStream);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    };
                }.start();
            }
            if(sysNotice.getAcceptType() != null || sysNotice.getGroupId() != null){
                List<String> phoneNumbers = new ArrayList<>();
                if(sysNotice.getAcceptType() != null){
                    phoneNumbers.addAll(sysUserService.getPhoneNumberByUserType(sysNotice.getAcceptType().split(",")));
                }
                if(sysNotice.getGroupId() != null){
                    phoneNumbers.addAll(sysUserService.getPhoneNumberByGroupId(
                            Arrays.stream(sysNotice.getGroupId().split(",")).map(it->Long.valueOf(it)).toArray(Long[]::new)));
                }
                if(phoneNumbers.size()>0)
                    LuoSiMaoSmsUtils.getInstance().sendCustomMsg(phoneNumbers.stream().toArray(String[]::new),sysNotice.getNoticeContent());
            }
        }
        sysNotice.setCreateId(loginUser.getUser().getUserId());
        sysNotice.setCreateBy(loginUser.getUsername());
        sysNotice.setCreateTime(new Date());
        sysNotice.setStatus("0");
        sysNotice.setExpositionId(loginUser.getUser().getExpositionId());
        SysNotice notice = sysNoticeService.save(sysNotice);
        if(sysNotice.getNoticeType().equals("3") || sysNotice.getNoticeType().equals("5")){
            if(loginUser.getUser().getUserType().equals("00") || loginUser.getUser().getUserType().equals("01")){
                new Thread() {
                    public void run() {
                        try {
                            saveInboxBySponsor(notice,loginUser);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    };
                }.start();
            }else if(loginUser.getUser().getUserType().equals("02")){
                new Thread() {
                    public void run() {
                        try {
                            saveInboxByExhibitor(notice,loginUser);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    };
                }.start();
            }
        }
        return AjaxResult.success();
    }
    //MultipartFile转file
    public static File MultipartFileToFile(MultipartFile multiFile) {
        // 获取文件名
        String fileName = multiFile.getOriginalFilename();
        // 获取文件后缀
        String prefix = fileName.substring(fileName.lastIndexOf("."));
        // 若须要防止生成的临时文件重复,能够在文件名后添加随机码
        try {
            File file = File.createTempFile(fileName, prefix);
            multiFile.transferTo(file);
            return file;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    //发送短信
    private void sendMsg(SysNotice notice,InputStream inputStream) {
        try {
            //读取文件
            ExcelUtil<MessageDTO> util = new ExcelUtil<>(MessageDTO.class);
            List<MessageDTO> list = util.importExcel(inputStream);
            LuoSiMaoSmsUtils.getInstance().sendCustomMsg(list.stream().map(it -> it.getPhone()).toArray(String[]::new),notice.getNoticeContent());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }



    //将消息推送人群存入到inbox中
    private void saveInboxBySponsor(SysNotice notice,LoginUser loginUser){
        //将推送人群添加到详情表中
        if(com.yuejike.common.utils.StringUtils.isNotBlank(notice.getAcceptType())){
            //用,切割字符串
            String[] userTypeTemp = notice.getAcceptType().split(",");
            for (String userType:userTypeTemp) {
                //根据userType查询用户列表
                List<SysUser> userList = sysUserService.findByUserTypeAndReviewStatus(userType,"1",loginUser.getUser().getExpositionId());
                if(userList.size() >0){
                    for (SysUser user:userList) {
                        SysInbox inbox = new SysInbox();
                        inbox.setNoticeId(notice.getNoticeId().longValue());
                        inbox.setAcceptId(user.getUserId());
                        inbox.setSendId(notice.getCreateId());
                        inbox.setStatus("0");
                        inbox.setDelFlag("0");
                        inbox.setCreateBy(notice.getCreateBy());
                        inbox.setCreateTime(new Date());
                        inboxService.save(inbox);
                    }
                }
            }
        }
        if(com.yuejike.common.utils.StringUtils.isNotBlank(notice.getGroupId())){
            //根据选中的分组，将分组中的用户添加到inbox
            //用,切割字符串
            String[] groupTemp = notice.getGroupId().split(",");
            for (String groupId:groupTemp) {
                //根据groupId查询该分组中的user列表
                List<SysUserGroupRelation> groupRelationListList = userGroupRelationService.findByGroupId(Long.parseLong(groupId));
                if(groupRelationListList.size()>0){
                    for (SysUserGroupRelation userGroupRelation:groupRelationListList) {
                        SysInbox inbox = new SysInbox();
                        inbox.setNoticeId(notice.getNoticeId().longValue());
                        inbox.setAcceptId(userGroupRelation.getUserId());
                        inbox.setSendId(notice.getCreateId());
                        inbox.setStatus("0");
                        inbox.setDelFlag("0");
                        inbox.setCreateBy(notice.getCreateBy());
                        inbox.setCreateTime(new Date());
                        inboxService.save(inbox);
                    }
                }
            }
        }
    }
    private void saveInboxByExhibitor(SysNotice notice,LoginUser loginUser){
//        List<Long> userIds = new ArrayList<>();
        if(notice!=null){
//            //获取与参展商有关联的订单用户列表
//            CmsOrder order = new CmsOrder();
//            order.setUserId(loginUser.getUser().getDeptId());//部门id
//            List<CmsOrder> orderList =orderService.findCmsOrderList(order);
//            if(orderList.size() >0) {
//                userIds.addAll(orderList.stream().map(CmsOrder::getUserId).collect(Collectors.toList()));
//            }
//            //获取与参展商有关联的洽谈沟通用户列表
//            CmsNegotiate negotiate = new CmsNegotiate();
//            negotiate.setAcceptId(loginUser.getUser().getDeptId());//部门id
//            List<CmsNegotiate> negotiateList = negotiateService.findCmsNegotiateList(negotiate);
//            if(negotiateList.size() >0) {
//                userIds.addAll(negotiateList.stream().map(CmsNegotiate::getSendId).collect(Collectors.toList()));
//            }
//            //获取与参展商交换名片的用户列表
//            CmsUserCardExchange exchange = new CmsUserCardExchange();
//            exchange.setAcceptId(loginUser.getUser().getUserId());
//            List<CmsUserCardExchange> cardExchangeList = userCardExchangeService.findCmsUserCardExchangeList(exchange);
//            if(cardExchangeList.size() >0) {
//                userIds.addAll(cardExchangeList.stream().map(CmsUserCardExchange::getSendId).collect(Collectors.toList()));
//            }
            //查询与当前展商有过沟通，询价，交换名片的用户列表
            List<SysUser> userList = sysUserService.findUserListByExhibitorId(loginUser.getUser().getDeptId(),loginUser.getUser().getUserId());
            if(userList.size()>0){
                for (SysUser user:userList) {
                    SysInbox inbox = new SysInbox();
                    inbox.setNoticeId(notice.getNoticeId().longValue());
                    inbox.setAcceptId(user.getUserId());
                    inbox.setSendId(notice.getCreateId());
                    inbox.setCreateBy(notice.getCreateBy());
                    inbox.setCreateTime(new Date());
                    inboxService.save(inbox);
                }
            }

        }
    }
    /**
     * 修改通知公告
     */
    @ApiOperation("修改通知公告接口")
    @PreAuthorize("@ss.hasPermi('system:notice:edit')")
    @Log(title = "通知公告", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SysNotice sysNotice) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        sysNotice.setUpdateBy(loginUser.getUsername());
        sysNotice.setUpdateTime(new Date());
        sysNoticeService.save(sysNotice);
        return AjaxResult.success();
    }

    /**
     * 删除通知公告
     */
    @ApiOperation("删除通知公告接口")
    @PreAuthorize("@ss.hasPermi('system:notice:remove')")
    @Log(title = "通知公告", businessType = BusinessType.DELETE)
	@DeleteMapping("/{noticeIds}")
    public AjaxResult remove(@PathVariable Integer[] noticeIds) {
        sysNoticeService.deleteByIds(Arrays.asList(noticeIds));
        return AjaxResult.success();
    }

    @ApiOperation("下载发送短信模板接口")
    @GetMapping("/importMsgTemplate")
    public AjaxResult importMsgTemplate() {
        ExcelUtil<MessageDTO> util = new ExcelUtil<>(MessageDTO.class);
        return util.importTemplateExcel("模板");
    }
}
