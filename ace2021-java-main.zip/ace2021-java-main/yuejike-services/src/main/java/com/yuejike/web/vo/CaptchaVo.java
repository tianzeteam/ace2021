package com.yuejike.web.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel("验证码信息")
public class CaptchaVo implements Serializable {
    @ApiModelProperty("验证码唯一值")
    private String uuid;
    @ApiModelProperty("验证码文件流")
    private String img;
}
