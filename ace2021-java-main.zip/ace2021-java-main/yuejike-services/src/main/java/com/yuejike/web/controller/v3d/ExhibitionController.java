package com.yuejike.web.controller.v3d;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.v3d.dto.ExhibitionQueryCriteria;
import com.yuejike.v3d.service.ExhibitionService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 展台相关
 * @author yunwei
 *
 */
@RestController
@RequestMapping("/v3d/exhibition")
@Api(tags = "3D展台相关")
public class ExhibitionController {
	
	@Autowired
	private ExhibitionService eService;
	
	@Autowired
    private TokenService tokenService;
	
	
	@ApiOperation("展台条件查询不分页")
    @GetMapping("/list")
//    @PreAuthorize("@ss.hasPermi('exhibition:list')")
    public ResponseEntity<Object> findAll(ExhibitionQueryCriteria criteria){
         return new ResponseEntity<>(eService.queryAll(criteria),HttpStatus.OK);
    }
    
   
    @ApiOperation("展台详情")
    @GetMapping("/getExhibition")
//    @PreAuthorize("@ss.hasPermi('exhibition:getExhibition')")
    public ResponseEntity<Object> getExhibition(){
    	LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        SysUser user = loginUser.getUser();
        return new ResponseEntity<>(eService.findById(user.getUserId()),HttpStatus.OK);
    }

    
}
