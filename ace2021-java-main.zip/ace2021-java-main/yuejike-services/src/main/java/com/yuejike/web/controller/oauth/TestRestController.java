package com.yuejike.web.controller.oauth;


import com.iflytek.fsp.shield.java.sdk.constant.HttpConstant;
import com.iflytek.fsp.shield.java.sdk.constant.SdkConstant;
import com.iflytek.fsp.shield.java.sdk.enums.Method;
import com.iflytek.fsp.shield.java.sdk.enums.ParamPosition;
import com.iflytek.fsp.shield.java.sdk.http.ApiClient;
import com.iflytek.fsp.shield.java.sdk.http.BaseApp;
import com.iflytek.fsp.shield.java.sdk.model.ApiRequest;
import com.iflytek.fsp.shield.java.sdk.model.ApiResponse;
import com.iflytek.fsp.shield.java.sdk.model.MultipartFile;
import com.iflytek.fsp.shield.java.sdk.model.ApiSignStrategy;
import com.iflytek.fsp.shield.java.sdk.model.ResultInfo;

import com.alibaba.fastjson.JSONObject;
import com.iflytek.wst.gateway.sdk.enums.HttpMethod;

import com.yuejike.common.constant.Constants;
import com.yuejike.common.core.domain.MapResult;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.utils.SecurityUtils;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.common.utils.uuid.UUID;
import com.yuejike.framework.web.domain.server.Sys;
import com.yuejike.framework.web.service.SysLoginService;
import com.yuejike.system.dao.SysUserDao;
import com.yuejike.web.util.FspClient;
import com.yuejike.web.util.WstClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.spring.web.json.Json;

import java.io.UnsupportedEncodingException;
import java.util.Optional;

/**
 * 测试
 * @author kosku
 *
 */
@RestController
@RequestMapping("/oauth")
public class TestRestController {
    
//    @Autowired
//    private SysUserDao userDao;
//
//    @Autowired
//    private SysLoginService loginService;
//
//	@GetMapping("/test")
//	public MapResult test() {
//
//		// 请求
//		ApiResponse apiResponse;
//		JSONObject jsonDataReal;
//
//		// 验证身份证信息
//		try{
//			// send
//			apiResponse = new FspClient().CheckIdCard(
//					"谷秋实","220822199210222810"
//			);
//
//			// code err
//			if(apiResponse.getStatusCode() != 200){
//				return MapResult.error("安康码服务请求繁忙，请重试");
//			}
//
//			// statusCode == 200
//			JSONObject jsonObject = JSONObject.parseObject(new String(apiResponse.getBody()));
//
//			// errCode 错误
//			if(!jsonObject.get("errCode").equals("-1")){
//				return MapResult.error("安康码服务繁忙，请重试");
//			}
//
//			// 解析data 错误
//			JSONObject jsonData = jsonObject.getJSONObject("data");
//			if(!jsonData.getString("errCode").equals("-1")){
//				return MapResult.error(jsonData.getString("errMsg"));
//			}
//
//			// 数据
//			jsonDataReal = jsonData.getJSONObject("data");
//
//		}catch (Exception e){
//			return MapResult.error("安康码服务链接超时，请重试");
//		}
//
//		// 健康状态
//		if(!jsonDataReal.getString("healthLevel").equals("1")){
//			return MapResult.error("您的健康状态异常，按防疫要求不允许您预约入场。");
//		}
//
//		MapResult ajax = MapResult.success();
////		ajax.put("errCode",xxx);
//		return ajax;
//	}
}
