package com.yuejike.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * 门票预约记录对象 cms_ticket_record
 *
 * @author tangdw
 * @since 1.0 2021-10-18
 */
@Data
public class CmsTicketRecordDTO {

    private static final long serialVersionUID = 1L;

    /** 用户姓名 */
    @NotBlank(message = "姓名不能为空",groups={CmsTicketRecordDTO.class})
    @ApiModelProperty(value = "姓名")
    private String userName;

    /** 身份证号码 */
    @NotBlank(message = "身份证号码不能为空",groups={CmsTicketRecordDTO.class})
    @ApiModelProperty(value = "身份证号码")
    private String idCard;

    /** 参会时间段 1.2021-10-23 09:00:00-13:00:00;2.2021-10-23 13:00:00-15:00:00;3.2021-10-24 09:00:00-13:00:00;4.2021-10-24 13:00:00-15:00:00;5.2021-10-22 00:00:00-2021-10-24 23:59:59*/
    @NotNull(message = "参会时间不能为空",groups = {CmsTicketRecordDTO.class})
    @ApiModelProperty(value = "参会时间段1.2021-10-22 13:00:00-15:00:00;2.2021-10-23 09:00:00-13:00:00;3.2021-10-23 13:00:00-17:00:00;4.2021-10-24 09:00:00-13:00:00;5.2021-10-24 13:00:00-16:00:00;6.2021-10-22 00:00:00-2021-10-24 23:59:59")
    private Integer timeLine;
}
