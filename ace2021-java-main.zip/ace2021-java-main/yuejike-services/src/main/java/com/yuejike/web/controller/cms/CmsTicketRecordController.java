package com.yuejike.web.controller.cms;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.zxing.common.BitMatrix;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.core.redis.RedisCache;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.exception.CustomException;
import com.yuejike.common.utils.QrUtils;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.common.utils.ValidatorUtils;
import com.yuejike.common.utils.http.HttpUtils;
import com.yuejike.common.utils.spring.SpringUtils;
import com.yuejike.dto.CmsTicketRecordDTO;
import com.yuejike.system.service.ISysUserService;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.util.FastByteArrayOutputStream;
import org.springframework.validation.ValidationUtils;
import org.springframework.web.bind.annotation.*;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsTicketRecord;
import com.yuejike.cms.service.ICmsTicketRecordService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;
import com.yuejike.web.util.FspClient;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.Function;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import javax.imageio.ImageIO;

/**
 * 门票预约记录Controller
 *
 * @author tangdw
 * @since 1.0 2021-10-18
 */
@RestController
@RequestMapping("/cms/ticket")
@Api(tags = "门票预约记录",description = "门票预约记录")
public class CmsTicketRecordController extends BaseController {
    @Autowired
    private ICmsTicketRecordService cmsTicketRecordService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private ISysUserService userService;
    @Autowired
    private RedisCache redisCache;

    /**
     * 查询门票预约记录列表
     */
    @ApiOperation("查询门票预约记录列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:record:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsTicketRecord> list(CmsTicketRecord cmsTicketRecord) {
        try {
            LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
            if (loginUser == null) {
                throw new CustomException("参数错误");
            }
            cmsTicketRecord.setUserId(loginUser.getUser().getUserId());
            Page<CmsTicketRecord> page = cmsTicketRecordService.findCmsTicketRecordPage(cmsTicketRecord);
            return getDataTable(page);
        }catch (Exception ex){
            Page<CmsTicketRecord> page = new Page<CmsTicketRecord>() {
                @Override
                public int getTotalPages() {
                    return 0;
                }

                @Override
                public long getTotalElements() {
                    return 0;
                }

                @Override
                public <U> Page<U> map(Function<? super CmsTicketRecord, ? extends U> function) {
                    return null;
                }

                @Override
                public int getNumber() {
                    return 0;
                }

                @Override
                public int getSize() {
                    return 0;
                }

                @Override
                public int getNumberOfElements() {
                    return 0;
                }

                @Override
                public List<CmsTicketRecord> getContent() {
                    return null;
                }

                @Override
                public boolean hasContent() {
                    return false;
                }

                @Override
                public Sort getSort() {
                    return null;
                }

                @Override
                public boolean isFirst() {
                    return false;
                }

                @Override
                public boolean isLast() {
                    return false;
                }

                @Override
                public boolean hasNext() {
                    return false;
                }

                @Override
                public boolean hasPrevious() {
                    return false;
                }

                @Override
                public Pageable nextPageable() {
                    return null;
                }

                @Override
                public Pageable previousPageable() {
                    return null;
                }

                @Override
                public Iterator<CmsTicketRecord> iterator() {
                    return null;
                }
            };
            return getDataTable(page);
        }

    }
//
//    /**
//     * 导出门票预约记录列表
//     */
//    @ApiOperation("导出门票预约记录列表数据接口")
//    @PreAuthorize("@ss.hasPermi('cms:record:export')")
//    @Log(title = "门票预约记录", businessType = BusinessType.EXPORT)
//    @GetMapping("/export")
//    public AjaxResult export(CmsTicketRecord cmsTicketRecord) {
//        List<CmsTicketRecord> list = cmsTicketRecordService.findCmsTicketRecordList(cmsTicketRecord);
//        ExcelUtil<CmsTicketRecord> util = new ExcelUtil<>(CmsTicketRecord.class);
//        return util.exportExcel(list, "record");
//    }

    /**
     * 获取门票预约记录详细信息
     */
//    @ApiOperation("获取门票预约记录详细信息接口")
////    @PreAuthorize("@ss.hasPermi('cms:record:query')")
//    @GetMapping(value = "/{userId}")
//    public AjaxResult<CmsTicketRecord> getInfo(@PathVariable("userId") Long userId) {
//        return AjaxResult.success(cmsTicketRecordService.findById(userId));
//    }
//
//    /**
//     * 新增门票预约记录
//     */
//    @ApiOperation("新增门票预约记录接口")
////    @PreAuthorize("@ss.hasPermi('cms:record:add')")
//    @Log(title = "门票预约记录", businessType = BusinessType.INSERT)
//    @PostMapping
//    public AjaxResult add(@RequestBody CmsTicketRecord cmsTicketRecord) {
//        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
//        cmsTicketRecord.setCreateBy(loginUser.getUsername());
//        cmsTicketRecord.setCreateTime(new Date());
//        cmsTicketRecordService.save(cmsTicketRecord);
//        return AjaxResult.success();
//    }
    @ApiOperation("新增门票接口")
    @PostMapping
    public AjaxResult add(@RequestBody CmsTicketRecordDTO cmsTicketRecordDTO) {

        try {

            LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
            if(loginUser == null){
                throw new CustomException("参数错误");
            }

            // 非普通用户必需认证后可以申请

            if(!loginUser.getUser().getUserType().equals("06") &&
                    !loginUser.getUser().getReviewStatus().equals("1")
            ){
                throw new CustomException("请先认证后,再进行此操");
            }

//            if(!loginUser.getUser().getUserType().equals("06") &&
//                    !loginUser.getUser().getReviewStatus().equals("1")
//            ){
//                throw new CustomException("请先认证后,再进行此操");
//            }

            if(cmsTicketRecordDTO.getTimeLine() > 6){
                throw new CustomException("参数错误");
            }

            Long userId = loginUser.getUser().getUserId();
            SysUser user = userService.selectUserById(userId);

            if(cmsTicketRecordDTO.getTimeLine().intValue() == 6 && user.getUserType().equals(UserType.GZ.getCode())){
                throw new CustomException("参数错误");
            }

            ValidatorUtils.validateEntity(cmsTicketRecordDTO);

            // 验证安康码状态
            AjaxResult fspAjaxResult = new FspClient().GetUserHealth(
                    cmsTicketRecordDTO.getUserName(),
                    cmsTicketRecordDTO.getIdCard()
            );
            if(fspAjaxResult != null){
                logger.error(StringUtils.format(
                        "安康码验证异常：{}/{}：{}",
                        cmsTicketRecordDTO.getUserName(),
                        cmsTicketRecordDTO.getIdCard(),
                        fspAjaxResult.getMsg())
                );
                return fspAjaxResult;
            }


            String[] startTimes = new String[]{"2021-10-22 13:00:00", "2021-10-23 09:00:00", "2021-10-23 13:00:00", "2021-10-24 09:00:00", "2021-10-24 13:00:00", "2021-10-22 00:00:00"};
            String[] endTimes = new String[]{"2021-10-22 17:00:00", "2021-10-23 13:00:00", "2021-10-23 17:00:00", "2021-10-24 13:00:00", "2021-10-24 16:00:00", "2021-10-24 23:59:59"};
//            String[] startTimes = new String[]{"2021-10-18 09:00:00", "2021-10-19 13:00:00", "2021-10-19 09:00:00", "2021-10-19 13:00:00", "2021-10-18 00:00:00"};
//            String[] endTimes = new String[]{"2021-10-18 13:00:00", "2021-10-19 15:00:00", "2021-10-19 13:00:00", "2021-10-19 15:00:00", "2021-10-20 23:59:59"};
            String[] times = new String[]{"2021-10-22 13:00:00-17:00:00", "2021-10-23 09:00:00-13:00:00", "2021-10-23 13:00:00-17:00:00", "2021-10-24 09:00:00-13:00:00", "2021-10-24 13:00:00-16:00:00", "2021-10-22 00:00:00-2021-10-24 23:59:59"};
            //根据用户类型来生成次数
            String profile = SpringUtils.getActiveProfile();
            String key = profile+":ticket:"+user.getUserType()+":";
            String cardNo = null;
            //默认从1开始
            Integer defaultVlue = 0;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

            //场次目前一共分为5个场次，普通观众23号上午场，23号下午场，24号上午场，24号下午场，其他用户的通票
            int sequence = cmsTicketRecordDTO.getTimeLine();

            // 开始时间
            Date start = sdf.parse(startTimes[sequence - 1]);
            // 结束时间
            Date end = sdf.parse(endTimes[sequence - 1]);
            if(System.currentTimeMillis() > end.getTime()){
                return AjaxResult.error("当前预约时间段已结束，请选择其他时间段");
            }


            //判断vip只能预约1次门票
            if(!user.getUserType().equals(UserType.GZ.getCode())){
                CmsTicketRecord cmsTicketRecordQ = new CmsTicketRecord();
//                BeanUtils.copyProperties(cmsTicketRecordDTO, cmsTicketRecordQ);
                cmsTicketRecordQ.setUserId(userId);
                cmsTicketRecordQ.setIsVip(user.getUserType().equals(UserType.GZ.getCode()) ? "0" : "1");

                List<CmsTicketRecord> list = cmsTicketRecordService.findCmsTicketRecordList(cmsTicketRecordQ);
                if (list != null && list.size() > 0) {
                    return AjaxResult.error("当前账号只能预约一次，不能多次预约");
                }
            }

            //判断同一个身份证和姓名再同一个时间段是否有多次预约
            CmsTicketRecord cmsTicketRecordQ = new CmsTicketRecord();
            BeanUtils.copyProperties(cmsTicketRecordDTO, cmsTicketRecordQ);
            cmsTicketRecordQ.setStartTime(start);
            cmsTicketRecordQ.setEndTime(end);
            cmsTicketRecordQ.setIsVip(user.getUserType().equals(UserType.GZ.getCode()) ? "0" : "1");

            List<CmsTicketRecord> list = cmsTicketRecordService.findCmsTicketRecordList(cmsTicketRecordQ);
            if (list != null && list.size() > 0) {
                return AjaxResult.error(StringUtils.format("该证件号已在该{}时间段预约，不能重复预约", times[sequence-1]));
            } else {

                CmsTicketRecord cmsTicketRecord = new CmsTicketRecord();
                BeanUtils.copyProperties(cmsTicketRecordDTO, cmsTicketRecord);
                cmsTicketRecord.setUserId(userId);
                cmsTicketRecord.setSort(Long.parseLong(cmsTicketRecordDTO.getTimeLine().toString()));
                cmsTicketRecord.setCardType("0");//默认身份证0
                cmsTicketRecord.setDelFlag("0");
                cmsTicketRecord.setStartTime(start);
                cmsTicketRecord.setEndTime(end);
                cmsTicketRecord.setIsVip(user.getUserType().equals(UserType.GZ.getCode()) ? "0" : "1");
                cmsTicketRecord.setCreateBy(loginUser.getUsername());
                cmsTicketRecord.setCreateTime(new Date());
                cmsTicketRecord.setTime(times[sequence-1]);

                //定义每场普通观众最大门票数量
                // 数量9000，但是id到了9000，数据库中不足9000，所以补一下
                Long maxCount = 11000L;
                String skey = key+sequence;
                //开始生成门票号码
                Object obj = redisCache.getCacheObject(skey);
                if (null == obj) {
                    redisCache.setCacheObject(skey, 1);
                    obj = 1;
                } else {
                    // 除vip全部停止
                    if(sequence <= 5){
                        return AjaxResult.error(StringUtils.format("该时间段预约限额已经满，请预约其他时间。", maxCount));
                    }
                    if ((Long.parseLong(obj.toString()) - (defaultVlue + maxCount)) > 0) {
                        return AjaxResult.error(StringUtils.format("该时间段预约限额已经满，请预约其他时间。", maxCount));
                    }
                    obj = redisCache.incr(skey);
                }
                /**
                 * ****************************************************************************
                 * *                                                                         **
                 * *    门票号码规则共9位，时间段（1位）+uuid随机hashcode（4位）+序列增长数（4位）     **
                 * *                                                                         **
                 * ****************************************************************************
                 */
                int hashCodeV = UUID.randomUUID().toString().hashCode();
                if(hashCodeV < 0){
                    hashCodeV = -hashCodeV;
                }
                cardNo = sequence + String.format("%03d",hashCodeV % 1000) + String.format("%05d", Long.parseLong(obj.toString()));

                //开始调用三方闸机接口生成门票

                HashMap<String, Object> paramsMap = new HashMap<>();
                paramsMap.put("pin", cardNo);
                paramsMap.put("cardNo", cardNo);
                paramsMap.put("accStartTime", startTimes[sequence - 1]);
                paramsMap.put("accEndTime", endTimes[sequence - 1]);
                paramsMap.put("isVip", cmsTicketRecord.getIsVip());
                paramsMap.put("accLevelIds", "402881ef7c995705017ca128d5376668,402881ef7c995705017ca12a228a6679");
                /**
                 * ****************************************************************************
                 * *                                                                         **
                 * *    开始调用闸机接口,创建成功后生成二维码上传到文件服务器,并保存二维码url         **
                 * *                                                                         **
                 * ****************************************************************************
                 */
                String rsp = HttpUtils.doPost("https://220.178.163.137:14461/api/person/add?access_token=E8EB6EB38CBC057F35CB19C70C2A9577CF7A707B4B72E763D6DC2B8DDA97BA97", JSON.toJSONString(paramsMap), "utf-8");
                if (StringUtils.isNotBlank(rsp)) {
                    JSONObject rspJson = JSONObject.parseObject(rsp);
                    if (rspJson.getIntValue("code") == 0 && rspJson.getString("message").equals("success")) {
                        //准备生成二维码
                        BitMatrix bitMatrix = QrUtils.setBitMatrix(cardNo, 300, 300);
                        BufferedImage image = QrUtils.toBufferedImage(bitMatrix);
                        FastByteArrayOutputStream os = new FastByteArrayOutputStream();
                        try {
                            ImageIO.write(image, "jpg", os);
                            ByteArrayInputStream bais = new ByteArrayInputStream(os.toByteArray());
                            BufferedImage bi1 = ImageIO.read(bais);
                            File f1 = File.createTempFile(cardNo, ".jpg");
                            ImageIO.write(bi1, "jpg", f1);
                            String fileRSP = HttpUtils.sendFile("https://pro-obs.zgkbh.cn", f1);
                            JSONObject jsonObject = JSONObject.parseObject(fileRSP);
                            JSONObject dataObject = JSONObject.parseObject(jsonObject.getString("data"));
                            String fileUrl = dataObject.getString("fileName");
                            System.out.println(fileUrl);
                            cmsTicketRecord.setTicketNumber(cardNo);
                            cmsTicketRecord.setCodeAddress(fileUrl);
                            cmsTicketRecordService.save(cmsTicketRecord);
                            return AjaxResult.success(fileUrl);
                        } catch (IOException e) {
                            return AjaxResult.error(e.getMessage());
                        }
                    } else {
                        logger.error(StringUtils.format("生成门票失败：调用闸机接口返回:{}，请求参数：{}}", rsp, JSON.toJSONString(paramsMap)));
                        return AjaxResult.error("生成门票失败，请联系管理员");
                    }
                } else {
                    logger.error(StringUtils.format("生成门票失败：调用闸机接口返回空，请求参数：{}}", JSON.toJSONString(paramsMap)));
                    return AjaxResult.error("生成门票失败，请联系管理员");

                }
            }
        }catch (CustomException ex){
            return AjaxResult.error(ex.getMessage());
        }
        catch (Exception ex){
            logger.error(StringUtils.format("生成门票失败：异常：{}}", ex.getMessage()));
            return AjaxResult.error("生成门票失败，请联系管理员");
        }
    }
//
//    /**
//     * 修改门票预约记录
//     */
//    @ApiOperation("修改门票预约记录接口")
//    @PreAuthorize("@ss.hasPermi('cms:record:edit')")
//    @Log(title = "门票预约记录", businessType = BusinessType.UPDATE)
//    @PutMapping
//    public AjaxResult edit(@RequestBody CmsTicketRecord cmsTicketRecord) {
//        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
//        cmsTicketRecord.setUpdateBy(loginUser.getUsername());
//        cmsTicketRecord.setUpdateTime(new Date());
//        cmsTicketRecordService.save(cmsTicketRecord);
//        return AjaxResult.success();
//    }
//
//    /**
//     * 删除门票预约记录
//     */
//    @ApiOperation("删除门票预约记录接口")
//    @PreAuthorize("@ss.hasPermi('cms:record:remove')")
//    @Log(title = "门票预约记录", businessType = BusinessType.DELETE)
//	@DeleteMapping("/{userIds}")
//    public AjaxResult remove(@PathVariable Long[] userIds) {
//        cmsTicketRecordService.deleteByIds(Arrays.asList(userIds));
//        return AjaxResult.success();
//    }
}
