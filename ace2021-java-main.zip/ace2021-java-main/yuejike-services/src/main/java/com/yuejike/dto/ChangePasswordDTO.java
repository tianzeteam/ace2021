package com.yuejike.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Data
@ApiModel("修改密码信息")
public class ChangePasswordDTO implements Serializable{

    @NotBlank(message = "旧密码不能为空",groups={ChangePasswordDTO.class})
    @ApiModelProperty(value = "旧密码")
    private String oldPassword;

    @NotBlank(message = "新密码不能为空",groups={ChangePasswordDTO.class})
    @ApiModelProperty(value = "新密码")
    private String newPassword;

    @NotBlank(message = "再次新密码不能为空",groups={ChangePasswordDTO.class})
    @ApiModelProperty(value = "确认密码")
    private String repeatPassword;
}
