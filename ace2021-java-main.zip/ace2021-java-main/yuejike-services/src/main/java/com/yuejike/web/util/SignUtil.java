package com.yuejike.web.util;

import com.yuejike.cms.dto.BaiJiaYunInterfaceUrl;
import com.yuejike.common.utils.sms.newxtc.fw.client.util.MD5Util;

import java.util.*;

/**
 * 生成百家云签名
 * @author song
 * @date 2021年09月11日 16:11
 */
public class SignUtil {

    // 生成sign
    public static String getSign(Map<String,Object> map){
        //1.将map排序
        Map<String,Object> sortByKey = sortByKey(map);
        //2.拼接参数
        StringBuilder parameter = new StringBuilder();
        for (Map.Entry<String, Object> m : sortByKey.entrySet()) {
            System.out.println("key:" + m.getKey() + " value:" + m.getValue());
            parameter.append(m.getKey()+"="+m.getValue()).append("&");
        }
        parameter.append("partner_key="+BaiJiaYunInterfaceUrl.partner_key);
        System.out.println(parameter+"---拼接后的param----");
        //3.md5加密
        String md5 = MD5Util.getMd5(parameter.toString(), "utf-8");
        return md5;
    }

    public static void main(String[] args) {
        HashMap map = new HashMap();
        map.put("d", 2);
        map.put("c", 1);
        map.put("b", 1);
        map.put("a", 3);
        String md5= MD5Util.getMd5("room_id=21091463215588&user_name=mta&user_number=365&user_role=0&partner_key=lzNWup2UwzsAE+Xz+TCOue2TzTEF9M7kK+mx61jhHxG9K4lVJ0GH1ouzcLXJ738YIeBPcypK3VkmPtavUHm+GA9PtM8","utf-8");

        System.out.println(md5);
    }

    //map排序
    public static  <K extends Comparable<? super K>, V > Map<K, V> sortByKey(Map<K, V> map) {
        Map<K, V> result = new LinkedHashMap<>();
        map.entrySet().stream()
                .sorted(Map.Entry.<K, V>comparingByKey()).forEachOrdered(e -> result.put(e.getKey(), e.getValue()));
        return result;
    }
}
