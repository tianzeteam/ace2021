package com.yuejike.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Column;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

@Data
@ApiModel("注册用户信息")
public class UserDTO implements Serializable{



    @ApiModelProperty(value = "用户账号")
    private String userName;

    /**
     * 用户昵称
     */
    @ApiModelProperty(value = "用户昵称")
    private String nickName;

    /**
     * 用户类型
     */
    @ApiModelProperty(value = "用户类型：01主办方，02展商，03会议代表，04媒体，05专业观众，06普通观众；")
    private String userType;

    /**
     * 用户邮箱
     */
    @ApiModelProperty(value = "用户邮箱")
    private String email;

    /**
     * 手机号码
     */
    @Pattern(regexp = "^\\s{0}$|^0{0,1}(13[0-9]|15[0-9]|16[0-9]|17[0-9]|14[0-9]|18[0-9]|19[0-9])[0-9]{8}$")
    @ApiModelProperty(value = "手机号码")
    private String phonenumber;

    /**
     * 用户性别
     */
    @ApiModelProperty(value = "用户性别")
    private String sex;

    @ApiModelProperty(value = "密码")
    private String password;

    /**
     * 用户性别
     */
    @ApiModelProperty(value = "验证码")
    private String code;

    @ApiModelProperty(value = "注册类型：0手机注册；1邮箱注册；")
    private int registerType;

    @ApiModelProperty(value = "推广人ID")
    private Long recommendId;

    @ApiModelProperty(value = "来源渠道ID")
    @Column(name = "channel_id")
    private Long channelId;
}
