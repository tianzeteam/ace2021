package com.yuejike.web.util;

import com.alibaba.fastjson.JSONObject;

/**
 * 微信授权登陆，通过code拉取用户信息
 * @author kosku
 *
 */
public class WechatClient {

    /**
     * 配置信息
     */
    private static final String appID = "wxf895723cbb3dcc12";
    private static final String appSecret = "1cc46ad9421bee2f0c01ef0481884061";
    private static final String host = "https://api.weixin.qq.com";

    /**
     * 通过微信code拉取OpenID
     * @param code 微信返回code
     * @return
     */
    public static String getWechatUserByCode(String code){
        String WechatUser = ""; // WechatUser
        try {
            // post request
            String returnJsonStr = RestTemplateUtil.sendPost(
                    host+"/sns/oauth2/access_token?appid="+appID+"&secret="+appSecret+"&code="+code+"&grant_type=authorization_code",
                    ""
            );
            JSONObject parseObject = JSONObject.parseObject(returnJsonStr);
            String accessToken = parseObject.getString("access_token");
            String openid = parseObject.getString("openid");

            // 拉取用户信息
            WechatUser = RestTemplateUtil.sendPost(
                    host+"/sns/userinfo?access_token="+accessToken+"&openid="+openid,
                    ""
            );

        }catch (Exception e) {
            System.out.println("使用code拉取openid错误！"+e);
            e.printStackTrace();
            throw e;
        }
        return WechatUser;
    }
    /**
     * 通过小程序code拉取openid
     * @param code 微信返回code
     */
    public static JSONObject getMiniUserByCode(String code,String miniAppId,String miniSecret){
        try {
            // send request
            String returnJsonStr = RestTemplateUtil.sendGet(
                    host+"/sns/jscode2session?appid="+miniAppId+"&secret="+miniSecret+"&js_code="+code+"&grant_type=authorization_code",
                    ""
            );
            JSONObject parseObject = JSONObject.parseObject(returnJsonStr);
            return parseObject;
        }catch (Exception e) {
            System.out.println("使用code拉取openid错误！"+e);
            e.printStackTrace();
            throw e;
        }

    }

}
