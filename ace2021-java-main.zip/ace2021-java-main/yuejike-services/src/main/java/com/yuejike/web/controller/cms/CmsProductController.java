package com.yuejike.web.controller.cms;

import com.google.common.collect.Lists;
import com.yuejike.cms.domain.*;
import com.yuejike.cms.service.*;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.page.TableDataInfo;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.QrUtils;
import com.yuejike.common.utils.SecurityUtils;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.utils.sms.LuoSiMaoSmsUtils;
import com.yuejike.framework.web.domain.server.Sys;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.system.service.ISysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 展品信息Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/product")
@Api(tags = "C-展品信息接口", description = "展品信息")
public class CmsProductController extends BaseController {
    @Autowired
    private ICmsProductService cmsProductService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private ISysUserExhibitorService sysUserExhibitorService;
    @Autowired
    private ICmsFavoritesService favoritesService;
    @Autowired
    private ISysUserService userService;
    @Autowired
    private ICmsClassificationService classificationService;
    @Autowired
    private ICmsProductCategoryService productCategoryService;
    @Value(value="${yuejike.domainName}")
    private String domainName;
    @Autowired
    private ISysAccessRecService sysAccessRecService;
    @Autowired
    private ICmsFavoritesService cmsFavoritesService;

    /**
     * 查询展品信息列表
     */
    @ApiOperation("前端查询展品信息列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:product:list')")
    @GetMapping("/ui/list")
    public TableDataInfo<CmsProduct> list(CmsProduct cmsProduct) {
        cmsProduct.setStatus("1");
        cmsProduct.setVisible("0");
        cmsProduct.setIsUi(true);
        if(null != cmsProduct.getUserId()){
            SysUser user = userService.selectUserById(cmsProduct.getUserId());
            cmsProduct.setUserId(user.getDeptId());//部门id
        }
        if(null != cmsProduct.getClassificationId()){
            if(classificationService.hasChildByMenuId(cmsProduct.getClassificationId())){
                List<Long> ids = new ArrayList<>();
                ids.add(cmsProduct.getClassificationId());
                //递归查询所选节点下的所有的子节点
                List<CmsClassification> classificationIdList = queryAllClassificationId(ids);
                List<Long> classificationIds = new ArrayList<>();
                classificationIds.add(cmsProduct.getClassificationId());
                if(CollectionUtils.isNotEmpty(classificationIdList)){
                    System.out.println("-------"+ classificationIdList +"------所有子节点---");
                    classificationIds.addAll(classificationIdList.stream().map(item -> item.getClassificationId()).collect(Collectors.toList()));
                }
                cmsProduct.setClassificationIds(classificationIds);
            }
        }
        if(null != cmsProduct.getCategoryId()) {
            if(productCategoryService.hasChildByMenuId(cmsProduct.getCategoryId())) {
                List<Long> ids = new ArrayList<>();
                ids.add(cmsProduct.getCategoryId());
                //递归查询所选节点下的所有的子节点
                List<CmsProductCategory> categoryList = queryAllCategoryId(ids);
                List<Long> categoryIds = new ArrayList<>();
                categoryIds.add(cmsProduct.getCategoryId());
                if(CollectionUtils.isNotEmpty(categoryList)) {
                    categoryIds.addAll(categoryList.stream().map(item -> item.getCategoryId()).collect(Collectors.toList()));
                }
                cmsProduct.setCategoryIds(categoryIds);
            }
        }else if(null != cmsProduct.getCategoryIds() && cmsProduct.getCategoryIds().size() > 0) {
            List<Long> categoryIds = new ArrayList<>();
            List<Long> ids = new ArrayList<>();
            cmsProduct.getCategoryIds().forEach(categoryId -> {
                if(productCategoryService.hasChildByMenuId(categoryId)) {
                    ids.add(categoryId);
                }
                categoryIds.add(categoryId);
            });
            if(ids.size()>0){
                List<CmsProductCategory> categoryList = queryAllCategoryId(ids);
                if(CollectionUtils.isNotEmpty(categoryList)) {
                    categoryIds.addAll(categoryList.stream().map(item -> item.getCategoryId()).collect(Collectors.toList()));
                }
            }
            cmsProduct.setCategoryIds(categoryIds);
        }
        Page<CmsProduct> page = cmsProductService.findCmsProductPage(cmsProduct);
        if(page != null && page.getContent() != null && page.getContent().size()>0) {
            Long[] productIds = page.getContent().stream().map(it-> it.getProductId()).toArray(Long[]::new);
            List<Map<String, Long>> listUv = sysAccessRecService.getProductUv(productIds);
            List<Map<String, Long>> listBookmarkCount = cmsFavoritesService.getFavoritesCountByProductId(productIds);
            page.getContent().forEach(product -> {
                List<Map<String, Long>> tmp = listUv.stream().filter(it->it.get("productId").equals(product.getProductId())).collect(Collectors.toList());
                if(tmp != null && tmp.size()>0) product.setUv(tmp.get(0).get("aCount"));
                List<Map<String, Long>> tmp2 = listBookmarkCount.stream().filter(it->it.get("productId")
                        .equals(product.getProductId())).collect(Collectors.toList());
                if(tmp2 != null && tmp2.size()>0) product.setBookmarkCount(tmp2.get(0).get("aCount"));
            });
        }
        return getDataTable(page);
    }
    /**
     * 获取某个父节点下面的所有子节点
     * @param ids
     * @return
     */
    private List<CmsClassification> queryAllClassificationId(List<Long> ids){
        //根据父ID查询子节点列表
        List<CmsClassification> departments = classificationService.findByParentId(ids);
        if (CollectionUtils.isNotEmpty(departments)) {
            //拿到当前所有子节点ID
            List<Long> parentIds = departments.stream().map(item -> item.getClassificationId()).collect(Collectors.toList());
            //拼接子节点查询结果
            departments.addAll(queryAllClassificationId(parentIds));
            return departments;
        } else {
            //如果没有下级节点那么我们就返回空集合，结束递归。
            return Lists.newArrayList();
        }
    }

    private List<CmsProductCategory> queryAllCategoryId(List<Long> ids){
        //根据父ID查询子节点列表
        List<CmsProductCategory> departments = productCategoryService.findByParentId(ids);
        if (CollectionUtils.isNotEmpty(departments)) {
            //拿到当前所有子节点ID
            List<Long> parentIds = departments.stream().map(item -> item.getCategoryId()).collect(Collectors.toList());
            //拼接子节点查询结果
            departments.addAll(queryAllCategoryId(parentIds));
            return departments;
        } else {
            //如果没有下级节点那么我们就返回空集合，结束递归。
            return Lists.newArrayList();
        }
    }

    /**
     * CMS查询展品信息列表
     */
    @ApiOperation("查询展品信息列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:product:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsProduct> cmslist(CmsProduct cmsProduct) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser.getUser() != null) {
            if (loginUser.getUser().getUserType().equals(UserType.CZS.getCode()) || loginUser.getUser().getUserType().equals(UserType.CZS_JS.getCode())) {
                cmsProduct.setUserId(loginUser.getUser().getDeptId());
                if(loginUser.getUser().getDeptId() == null || loginUser.getUser().getDeptId().equals(0)){
                    TableDataInfo rspData = new TableDataInfo();
                    rspData.setCode(0);
                    rspData.setMsg("请认证后查询");
                    rspData.setRows(null);
                    rspData.setTotal(0);
                    return rspData;
                }
            }

            Page<CmsProduct> page = cmsProductService.findCmsProductPage(cmsProduct);
            return getDataTable(page);
        }else{
            TableDataInfo rspData = new TableDataInfo();
            rspData.setCode(500);
            rspData.setMsg("查询失败");
            rspData.setRows(null);
            rspData.setTotal(0);
            return rspData;
        }
    }

    /**
     * 导出展品信息列表
     */
    @ApiOperation("导出展品信息列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:product:export')")
    @Log(title = "展品信息", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsProduct cmsProduct) {
        List<CmsProduct> list = cmsProductService.findCmsProductList(cmsProduct);
        ExcelUtil<CmsProduct> util = new ExcelUtil<>(CmsProduct.class);
        return util.exportExcel(list, "product");
    }

    /**
     * 获取展品信息详细信息
     */
    @ApiOperation("获取展品信息详细信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:product:query')")
    @GetMapping(value = "/{productId}")
    public AjaxResult<CmsProduct> getInfo(@PathVariable("productId") Long productId) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        CmsProduct product = cmsProductService.findById(productId);
//        SysUser userQ = new SysUser();
//        userQ.setUserType(UserType.CZS.getCode());
//        userQ.setDeptId(product.getUserId());
        List<SysUser> exList = userService.getUserExListByDeptIdAndUserType(product.getUserId());
        SysUser exInfo = exList.get(0);
        product.setSysUserExhibitor(sysUserExhibitorService.findById(exInfo.getUserId()));
        product.setUv(sysAccessRecService.getProductUv(product.getProductId()));
        product.setBookmarkCount(cmsFavoritesService.getFavoritesCountByProductId(product.getProductId()));
        //查询该商品是否被收藏
        if(loginUser != null){
            //根据登录人查看该展品是否被收藏
            CmsFavorites favorites = favoritesService.findByUserIdAndBusinessTypeAndBusinessId(loginUser.getUser().getUserId(),"0",productId);
            if(favorites != null){
                product.setFavorites(favorites);//已收藏
            }else{
                product.setFavorites(null);//未收藏
            }
        }
        return AjaxResult.success(product);
    }

    @ApiOperation("重新生成展品二维码，系统管理员用")
    @PreAuthorize("@ss.hasPermi('cms:product:rebuildQrCode')")
    @Log(title = "展品信息", businessType = BusinessType.UPDATE)
    @PutMapping("/rebuildQrCode")
    public AjaxResult rebuildQrCode(){
        CmsProduct cmsProduct = new CmsProduct();
        List<CmsProduct> cmsProducts = cmsProductService.findCmsProductList(cmsProduct);
        cmsProducts.forEach(product -> {
            String strContent = domainName+"#/pages/zhanpin/detail?productId="+product.getProductId();
            product.setQrcode(QrUtils.createRemoteQrCode(strContent,202,202));
            cmsProductService.save(product);
        });
        return AjaxResult.success();
    }

    /**
     * 新增展品信息
     */
    @ApiOperation("新增展品信息接口")
    @PreAuthorize("@ss.hasPermi('cms:product:add')")
    @Log(title = "展品信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsProduct cmsProduct) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsProduct.setCreateBy(loginUser.getUsername());
        if(loginUser.getUser() != null && loginUser.getUser().getDeptId() != null) {
            cmsProduct.setUserId(loginUser.getUser().getDeptId());
        }else{
            SysUser sysUser = userService.selectUserById(loginUser.getUser().getUserId());
            cmsProduct.setUserId(sysUser.getDeptId());
        }
        cmsProduct.setPv(0);
        if(loginUser.getUser().getUserType().equals("02")){
            SysUserExhibitor userExhibitor= sysUserExhibitorService.findById(loginUser.getUser().getUserId());
            cmsProduct.setExhibitorName(userExhibitor.getName());
        }
        // cmsProduct.setExhibitorName(loginUser.getUser().getNickName());
        cmsProduct.setCreateTime(new Date());
//        cmsProduct.setExhibitorName(loginUser.getUser().getNickName());
        cmsProduct.setDelFlag("0");
        if(StringUtils.isEmpty(cmsProduct.getQrcode())){
            String strContent = domainName+"#/pages/zhanpin/detail?productId="+cmsProduct.getProductId();
            cmsProduct.setQrcode(QrUtils.createRemoteQrCode(strContent,202,202));
        }
        cmsProductService.save(cmsProduct);
        return AjaxResult.success();
    }

    /**
     * 修改展品信息
     */
    @ApiOperation("修改展品信息接口")
    @PreAuthorize("@ss.hasPermi('cms:product:edit')")
    @Log(title = "展品信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsProduct cmsProduct) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsProduct.setUpdateBy(loginUser.getUsername());
        cmsProduct.setUpdateTime(new Date());
        if(StringUtils.isEmpty(cmsProduct.getQrcode())){
            String strContent = domainName+"#/pages/zhanpin/detail?productId="+cmsProduct.getProductId();
            cmsProduct.setQrcode(QrUtils.createRemoteQrCode(strContent,202,202));
        }
        cmsProductService.save(cmsProduct);
        return AjaxResult.success();
    }

    /**
     * 删除展品信息
     */
    @ApiOperation("删除展品信息接口")
    @PreAuthorize("@ss.hasPermi('cms:product:remove')")
    @Log(title = "展品信息", businessType = BusinessType.DELETE)
    @DeleteMapping("/{productIds}")
    public AjaxResult remove(@PathVariable Long[] productIds) {
        cmsProductService.deleteByIds(Arrays.asList(productIds));
        return AjaxResult.success();
    }

    /**
     * 审核状态修改
     *
     * @param cmsProduct
     * @return
     */
    @ApiOperation("审核状态修改接口")
//    @PreAuthorize("@ss.hasPermi('system:product:audit')")
    @Log(title = "展品管理", businessType = BusinessType.UPDATE)
    @PutMapping("/changeStatus")
    public AjaxResult changeStatus(@RequestBody CmsProduct cmsProduct) {
        cmsProduct.setUpdateBy(SecurityUtils.getUsername());
        if(cmsProduct.getStatus().equals("1") || cmsProduct.getStatus().equals("2")){
            CmsProduct productTmp = cmsProductService.findById(cmsProduct.getProductId());
            if(productTmp != null && productTmp.getUserId() != null) {
                List<SysUser> users = userService.selectUserByDeptId(productTmp.getUserId());
                if(users != null && users.size()>0){
                    users.forEach(user -> {
                        if(StringUtils.isNotEmpty(user.getPhonenumber())) {
                            LuoSiMaoSmsUtils.getInstance().sendApprovedProductMsg(user.getPhonenumber(), productTmp.getName(), cmsProduct.getStatus().equals("1"));
                        }
                    });
                }
            }
        }
        return toAjax(cmsProductService.updateAuditStatus(cmsProduct));
    }

    /**
     * 上下架状态状态修改
     *
     * @param cmsProduct
     * @return
     */
    @ApiOperation("上下架状态修改接口")
//    @PreAuthorize("@ss.hasPermi('system:product:audit')")
    @Log(title = "展品管理", businessType = BusinessType.UPDATE)
    @PutMapping("/changeVisible")
    public AjaxResult changeVisible(@RequestBody CmsProduct cmsProduct) {
        cmsProduct.setUpdateBy(SecurityUtils.getUsername());
        return toAjax(cmsProductService.updateVisibleStatus(cmsProduct));
    }

    @ApiOperation("批量排序")
    @Log(title = "展品信息", businessType = BusinessType.UPDATE)
    @PutMapping("/resort")
    public AjaxResult resort(@RequestBody List<CmsProduct> cmsProducts) {
        cmsProductService.batchReSorted(cmsProducts);
        return AjaxResult.success();
    }

    @ApiOperation("推荐/取消推荐")
    @PreAuthorize("@ss.hasPermi('cms:product:recommend')")
    @Log(title = "展品信息", businessType = BusinessType.UPDATE)
    @PutMapping("/recommend/{type}/{productIds}")
    public AjaxResult recommend(@PathVariable String type, @PathVariable Long[] productIds){
        cmsProductService.batchRecommend(productIds, type);
        return AjaxResult.success();
    }

}
