package com.yuejike.web.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@ApiModel("返回多级联调dto")
@Data
public class CmsIndustryTreeVo {

    @ApiModelProperty(value = "值")
    private String value;

    @ApiModelProperty(value = "标签")
    private String label;

    @ApiModelProperty(value = "递归下级")
    private List<CmsIndustryTreeVo> children;

}
