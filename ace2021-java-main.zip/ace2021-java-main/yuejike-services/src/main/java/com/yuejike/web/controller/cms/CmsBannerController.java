package com.yuejike.web.controller.cms;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsBanner;
import com.yuejike.cms.service.ICmsBannerService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 轮播图Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/banner")
@Api(tags = "轮播图",description = "轮播图")
public class CmsBannerController extends BaseController {
    @Autowired
    private ICmsBannerService cmsBannerService;
    @Autowired
    private TokenService tokenService;

    /**
     * 查询轮播图列表
     */
    @ApiOperation("查询轮播图列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:banner:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsBanner> list(CmsBanner cmsBanner) {
        Page<CmsBanner> page = cmsBannerService.findCmsBannerPage(cmsBanner);
        return getDataTable(page);
    }

    /**
     * 导出轮播图列表
     */
    @ApiOperation("导出轮播图列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:banner:export')")
    @Log(title = "轮播图", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsBanner cmsBanner) {
        List<CmsBanner> list = cmsBannerService.findCmsBannerList(cmsBanner);
        ExcelUtil<CmsBanner> util = new ExcelUtil<>(CmsBanner.class);
        return util.exportExcel(list, "banner");
    }

    /**
     * 获取轮播图详细信息
     */
    @ApiOperation("获取轮播图详细信息接口")
    @PreAuthorize("@ss.hasPermi('cms:banner:query')")
    @GetMapping(value = "/{bannerId}")
    public AjaxResult<CmsBanner> getInfo(@PathVariable("bannerId") Long bannerId) {
        return AjaxResult.success(cmsBannerService.findById(bannerId));
    }

    /**
     * 新增轮播图
     */
    @ApiOperation("新增轮播图接口")
    @PreAuthorize("@ss.hasPermi('cms:banner:add')")
    @Log(title = "轮播图", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsBanner cmsBanner) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsBanner.setCreateBy(loginUser.getUsername());
        cmsBanner.setCreateTime(new Date());
        cmsBanner.setDelFlag("0");
        cmsBanner.setExpositionId(loginUser.getUser().getExpositionId());
        cmsBannerService.save(cmsBanner);
        return AjaxResult.success();
    }

    /**
     * 修改轮播图
     */
    @ApiOperation("修改轮播图接口")
    @PreAuthorize("@ss.hasPermi('cms:banner:edit')")
    @Log(title = "轮播图", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsBanner cmsBanner) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsBanner.setUpdateBy(loginUser.getUsername());
        cmsBanner.setUpdateTime(new Date());
        cmsBannerService.save(cmsBanner);
        return AjaxResult.success();
    }

    /**
     * 删除轮播图
     */
    @ApiOperation("删除轮播图接口")
    @PreAuthorize("@ss.hasPermi('cms:banner:remove')")
    @Log(title = "轮播图", businessType = BusinessType.DELETE)
	@DeleteMapping("/{bannerIds}")
    public AjaxResult remove(@PathVariable Long[] bannerIds) {
        cmsBannerService.deleteByIds(Arrays.asList(bannerIds));
        return AjaxResult.success();
    }
}
