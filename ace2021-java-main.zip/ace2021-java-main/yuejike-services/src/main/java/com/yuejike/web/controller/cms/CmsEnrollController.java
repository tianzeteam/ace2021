package com.yuejike.web.controller.cms;

import com.yuejike.cms.domain.CmsConference;
import com.yuejike.cms.domain.CmsEnroll;
import com.yuejike.cms.domain.CmsLive;
import com.yuejike.cms.service.ICmsConferenceService;
import com.yuejike.cms.service.ICmsEnrollService;
import com.yuejike.cms.service.ICmsLiveService;
import com.yuejike.cms.service.ISysInboxService;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.annotation.Message;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.page.TableDataInfo;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.common.enums.NoticeType;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.PhoneUtils;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.utils.sms.LuoSiMaoSmsUtils;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.system.service.ISysNoticeService;
import com.yuejike.system.service.ISysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * 会议报名Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/enroll")
@Api(tags = "会议报名",description = "会议报名")
public class CmsEnrollController extends BaseController {
    @Autowired
    private ICmsEnrollService cmsEnrollService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private ICmsConferenceService conferenceService;
    @Autowired
    private ISysNoticeService noticeService;
    @Autowired
    private ISysInboxService sysInboxService;
    @Autowired
    private ICmsLiveService liveService;
    @Autowired
    private ISysUserService userService;


    /**
     * 查询会议报名列表
     */
    @ApiOperation("查询会议报名列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:enroll:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsEnroll> list(CmsEnroll cmsEnroll) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser.getUser() != null) {
            if (loginUser.getUser().getUserType().equals(UserType.CZS.getCode()) || loginUser.getUser().getUserType().equals(UserType.CZS_JS.getCode())) {
                cmsEnroll.setExhibitorId(loginUser.getUser().getUserId());
                if(loginUser.getUser().getDeptId() == null || loginUser.getUser().getDeptId().equals(0)){
                    TableDataInfo rspData = new TableDataInfo();
                    rspData.setCode(0);
                    rspData.setMsg("请认证后查询");
                    rspData.setRows(null);
                    rspData.setTotal(0);
                    return rspData;
                }
            }else if(loginUser.getUser().getUserType().equals(UserType.GZ.getCode()) || loginUser.getUser().getUserType().equals(UserType.ZYGZ.getCode()) ||
                    loginUser.getUser().getUserType().equals(UserType.MT.getCode()) || loginUser.getUser().getUserType().equals(UserType.HYDB.getCode())){
                cmsEnroll.setUserId(loginUser.getUser().getUserId());
            }else if(loginUser.getUser().getUserType().equals(UserType.ZBF.getCode())){
               // cmsEnroll.setExhibitorId(loginUser.getUser().getUserId());
            }
            cmsEnroll.setDelFlag("0");
            Page<CmsEnroll> page = cmsEnrollService.findCmsEnrollPage(cmsEnroll);
            return getDataTable(page);
        }else{
            TableDataInfo rspData = new TableDataInfo();
            rspData.setCode(500);
            rspData.setMsg("查询失败");
            rspData.setRows(null);
            rspData.setTotal(0);
            return rspData;
        }
    }

    /**
     * 导出会议报名列表
     */
    @ApiOperation("导出会议报名列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:enroll:export')")
    @Log(title = "会议报名", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsEnroll cmsEnroll) {
        List<CmsEnroll> list = cmsEnrollService.findCmsEnrollList(cmsEnroll);
        ExcelUtil<CmsEnroll> util = new ExcelUtil<>(CmsEnroll.class);
        return util.exportExcel(list, "enroll");
    }

    /**
     * 获取会议报名详细信息
     */
    @ApiOperation("获取会议报名详细信息接口")
    @PreAuthorize("@ss.hasPermi('cms:enroll:query')")
    @GetMapping(value = "/{enrollId}")
    public AjaxResult<CmsEnroll> getInfo(@PathVariable("enrollId") Long enrollId) {
        return AjaxResult.success(cmsEnrollService.findById(enrollId));
    }

    /**
     * 新增会议报名
     */
    @ApiOperation("新增会议报名接口")
//    @PreAuthorize("@ss.hasPermi('cms:enroll:add')")
    @Log(title = "会议报名", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsEnroll cmsEnroll) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        AjaxResult ajaxResult = new AjaxResult();
        if(StringUtils.isNotEmpty(cmsEnroll.getPhoneNumber()) && !PhoneUtils.isChinaPhoneLegal(cmsEnroll.getPhoneNumber())){
            return AjaxResult.error("手机号格式不对");
        }
        if(null != cmsEnroll.getConferenceId()){
            CmsConference conference = conferenceService.findById(cmsEnroll.getConferenceId());
            if(conference != null) {
                cmsEnroll.setCreateBy(loginUser.getUsername());
                cmsEnroll.setExhibitorId(conference.getExhibitorId());
                if (conference.getExhibitorId() != null) {
                    cmsEnroll.setExhibitorId(conference.getExhibitorId());
                }
//                SysUser exInfo = userService.selectUserById(conference.getExhibitorId());
//                if(exInfo.getUserType().equals(UserType.CZS.getCode()) || exInfo.getUserType().equals(UserType.CZS_JS.getCode())){
//                    cmsEnroll.setExhibitorId(exInfo.getUserId());
//                }else {
//                    cmsEnroll.setExhibitorId(conference.getExhibitorId());
//                }
                cmsEnroll.setExhibitorId(conference.getExhibitorId());
                cmsEnroll.setExhibitorName(conference.getExhibitorCnName());
                cmsEnroll.setConferenceName(conference.getTitle());
                cmsEnroll.setStatus("0");
                cmsEnroll.setType("1");
                cmsEnroll.setCreateTime(new Date());
                cmsEnroll.setDelFlag("0");
                cmsEnrollService.save(cmsEnroll);
                return AjaxResult.success();
            }else{
                ajaxResult.setCode(500);
                ajaxResult.setMsg("请选择正确的会议");
            }
        }else if(null != cmsEnroll.getLiveId()){
           CmsLive live = liveService.findById(cmsEnroll.getLiveId());
           List<CmsEnroll> enrollList = cmsEnrollService.findByLiveId(cmsEnroll.getLiveId());
           if(enrollList.size() < live.getLimitNumberPeople()){
               //该直播审核通过的不到限制人数时，可以继续报名
               SysUser exInfo = userService.selectUserById(live.getCreateId());
               cmsEnroll.setExhibitorName(exInfo.getNickName());
//               if(exInfo.getUserType().equals(UserType.CZS.getCode()) || exInfo.getUserType().equals(UserType.CZS_JS.getCode())){
//                   cmsEnroll.setExhibitorId(exInfo.getUserId());
//               }else {
//                   cmsEnroll.setExhibitorId(live.getCreateId());
//               }
               cmsEnroll.setExhibitorId(live.getCreateId());
               cmsEnroll.setConferenceName(live.getName());
               cmsEnroll.setStatus("0");
               if(live.getType().equals("0")){
                   cmsEnroll.setType("0");//论坛直播
               }else {
                   cmsEnroll.setType("2");//活动直播
               }
               cmsEnroll.setCreateTime(new Date());
               cmsEnroll.setDelFlag("0");
               cmsEnrollService.save(cmsEnroll);
               return AjaxResult.success();
           }else{
               ajaxResult.setCode(500);
               ajaxResult.setMsg("报名人数已满,请选择其他直播!");
           }
        }
        return ajaxResult;
    }

    @ApiOperation("检测是否已报名")
    @PostMapping("/isEnroll")
    public AjaxResult isEnroll(@RequestBody CmsEnroll cmsEnroll) {
        // LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        AjaxResult ajaxResult = new AjaxResult();
        List<CmsEnroll> enrollList = cmsEnrollService.findCmsEnrollList(cmsEnroll);
        if(enrollList.size()>0){
            enrollList.forEach(enroll -> {
                if(enroll.getStatus().equals("0")){
                    ajaxResult.setCode(500);
                    ajaxResult.setMsg("您已提交报名信息,请等待审核!");
                }else if(enroll.getStatus().equals("1")){
                    ajaxResult.setCode(500);
                    ajaxResult.setMsg("您已成功报名该会议,请勿重复操作!");
                }else if(enroll.getStatus().equals("2")){
                    ajaxResult.setCode(200);
                    ajaxResult.setMsg("审核不通过！");
                    ajaxResult.setData(enroll.getRejectReason());
                }
            });
        }else{
            ajaxResult.setCode(0);
            ajaxResult.setMsg("赶快去报名吧！");
        }
        return ajaxResult;

    }

    /**
     * 修改会议报名
     */
    @ApiOperation("修改会议报名接口")
    // @PreAuthorize("@ss.hasPermi('cms:enroll:edit')")
    @Message(title = "参会凭证通知",noticeType = NoticeType.CONFERENCE,content = "")
    @Log(title = "会议报名", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsEnroll cmsEnroll) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        CmsEnroll enroll  = new CmsEnroll();
        enroll.setUserId(cmsEnroll.getUserId());
        if(cmsEnroll.getConferenceId() != null){
            enroll.setConferenceId(cmsEnroll.getConferenceId());
        }
        if(cmsEnroll.getLiveId() != null){
            enroll.setLiveId(cmsEnroll.getLiveId());
        }
        List<CmsEnroll> enrollList = cmsEnrollService.findCmsEnrollList(cmsEnroll);
        if(enrollList.size() >0){
            enrollList.forEach(en -> {
                en.setName(cmsEnroll.getName());
                en.setCardType(cmsEnroll.getCardType());
                en.setCardNumber(cmsEnroll.getCardNumber());
                en.setPhoneNumber(cmsEnroll.getPhoneNumber());
                en.setCompanyNam(cmsEnroll.getCompanyNam());
                en.setAvatar(cmsEnroll.getAvatar());
                en.setUpdateBy(loginUser.getUsername());
                en.setUpdateTime(new Date());
                en.setStatus("0");//再次提交的审核资料后，将审核状态改为"待审核"
                en.setRejectReason("");
                cmsEnrollService.save(en);
            });
        }
        // cmsEnroll.setUpdateBy(loginUser.getUsername());
        // cmsEnroll.setUpdateTime(new Date());
        // cmsEnrollService.save(cmsEnroll);
        return AjaxResult.success();
    }
    /**
     * 报名审核
     */
    @ApiOperation("报名审核")
    @Log(title = "报名审核", businessType = BusinessType.UPDATE)
    @Message(title = "参会凭证通知",noticeType = NoticeType.CONFERENCE)
    @PutMapping("/audit")
    public AjaxResult auditEdit(@RequestBody CmsEnroll cmsEnroll) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
//        cmsEnroll.setUpdateBy(loginUser.getUsername());
        //cmsEnroll.setUpdateTime(new Date());

        cmsEnroll.setReviewerId(loginUser.getUser().getUserId());
        cmsEnroll.setReviewerName(loginUser.getUser().getUserName());
        cmsEnrollService.save(cmsEnroll);
        //审核通过发短信通知
        if(cmsEnroll.getStatus().equals("1") || cmsEnroll.getStatus().equals("2")){
            String phoneNumber = cmsEnroll.getPhoneNumber();
            if(StringUtils.isEmpty(phoneNumber)){
                SysUser user = userService.selectUserById(cmsEnroll.getUserId());
                if(user != null) {
                    phoneNumber = user.getPhonenumber();
                }
            }
            if(!StringUtils.isEmpty(phoneNumber))
                LuoSiMaoSmsUtils.getInstance().sendApprovedConferenceMsg(phoneNumber, cmsEnroll.getConferenceName(), cmsEnroll.getStatus().equals("1"));
        }
        AjaxResult ajaxResult = new AjaxResult();
        ajaxResult.setCode(0);
        ajaxResult.setMsg("报名已审核");
        ajaxResult.setData(cmsEnroll);
        return ajaxResult;
    }

    /**
     * 删除会议报名
     */
    @ApiOperation("删除会议报名接口")
    @PreAuthorize("@ss.hasPermi('cms:enroll:remove')")
    @Log(title = "会议报名", businessType = BusinessType.DELETE)
	@DeleteMapping("/{enrollIds}")
    public AjaxResult remove(@PathVariable Long[] enrollIds) {
        cmsEnrollService.deleteByIds(Arrays.asList(enrollIds));
        return AjaxResult.success();
    }
}
