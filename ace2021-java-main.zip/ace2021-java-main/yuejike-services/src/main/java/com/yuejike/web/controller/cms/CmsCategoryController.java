package com.yuejike.web.controller.cms;

import com.yuejike.common.core.domain.MapResult;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsCategory;
import com.yuejike.cms.service.ICmsCategoryService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 栏目管理Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/category")
@Api(tags = "栏目管理",description = "栏目管理")
public class CmsCategoryController extends BaseController {
    @Autowired
    private ICmsCategoryService cmsCategoryService;
    @Autowired
    private TokenService tokenService;

    /**
     * 查询栏目管理列表
     */
    @ApiOperation("查询栏目管理列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:category:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsCategory> list(CmsCategory cmsCategory) {
//        Page<CmsCategory> page = cmsCategoryService.findCmsCategoryPage(cmsCategory);
        Page<CmsCategory> page = cmsCategoryService.findCmsCategoryTreePage(cmsCategory);
        return getDataTable(page);
    }

    /**
     * 导出栏目管理列表
     */
    @ApiOperation("导出栏目管理列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:category:export')")
    @Log(title = "栏目管理", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsCategory cmsCategory) {
        List<CmsCategory> list = cmsCategoryService.findCmsCategoryList(cmsCategory);
        ExcelUtil<CmsCategory> util = new ExcelUtil<>(CmsCategory.class);
        return util.exportExcel(list, "category");
    }

    /**
     * 获取栏目管理详细信息
     */
    @ApiOperation("获取栏目管理详细信息接口")
    @PreAuthorize("@ss.hasPermi('cms:category:query')")
    @GetMapping(value = "/{categoryId}")
    public AjaxResult<CmsCategory> getInfo(@PathVariable("categoryId") Long categoryId) {
        return AjaxResult.success(cmsCategoryService.findById(categoryId));
    }

    /**
     * 新增栏目管理
     */
    @ApiOperation("新增栏目管理接口")
    @PreAuthorize("@ss.hasPermi('cms:category:add')")
    @Log(title = "栏目管理", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsCategory cmsCategory) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsCategory.setExpositionId(loginUser.getUser().getExpositionId());
        cmsCategory.setDelFlag("0");
        cmsCategory.setCreateBy(loginUser.getUsername());
        cmsCategory.setCreateTime(new Date());
        cmsCategoryService.save(cmsCategory);
        return AjaxResult.success();
    }

    /**
     * 获取栏目层级结构树
     */
    @ApiOperation("获取栏目层级结构树")
    @PostMapping(value = "/getTreeByPid")
    public List<Map<String, Object>> getTreeByPid() {
        List<Map<String, Object>> cmsCategorySelectByPid = cmsCategoryService.getCmsCategorySelectByPid();
        return cmsCategorySelectByPid;
    }

//    /**
////     * 获取部门下拉树列表
////     */
////    @ApiOperation("获取部门下拉树列表接口")
////    @GetMapping("/treeselect")
////    public MapResult treeselect(CmsCategory cmsCategory) {
////        List<CmsCategory> cmsCategoryList = cmsCategoryService.findCmsCategoryList(cmsCategory);
////        return MapResult.success(cmsCategoryService.buildCategoryTreeSelect(cmsCategoryList));
////    }

    /**
     * 修改栏目管理
     */
    @ApiOperation("修改栏目管理接口")
    @PreAuthorize("@ss.hasPermi('cms:category:edit')")
    @Log(title = "栏目管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsCategory cmsCategory) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsCategory.setUpdateBy(loginUser.getUsername());
        cmsCategory.setUpdateTime(new Date());
        cmsCategoryService.save(cmsCategory);
        return AjaxResult.success();
    }

    /**
     * 删除栏目管理
     */
    @ApiOperation("删除栏目管理接口")
    @PreAuthorize("@ss.hasPermi('cms:category:remove')")
    @Log(title = "栏目管理", businessType = BusinessType.DELETE)
	@DeleteMapping("/{categoryIds}")
    public AjaxResult remove(@PathVariable Long[] categoryIds) {
        cmsCategoryService.deleteByIds(Arrays.asList(categoryIds));
        return AjaxResult.success();
    }
}
