package com.yuejike.web.controller.cms;

import com.yuejike.common.core.domain.entity.SysDept;
import org.springframework.data.domain.Example;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.SysUserGroupRelation;
import com.yuejike.cms.service.ISysUserGroupRelationService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 人员分组关联Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/relation")
@Api(tags = "人员分组关联",description = "人员分组关联")
public class SysUserGroupRelationController extends BaseController {
    @Autowired
    private ISysUserGroupRelationService sysUserGroupRelationService;
    @Autowired
    private TokenService tokenService;

    /**
     * 查询人员分组关联列表
     */
    @ApiOperation("查询人员分组关联列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:relation:list')")
    @GetMapping("/list")
    public TableDataInfo<SysUserGroupRelation> list(SysUserGroupRelation sysUserGroupRelation) {
        Page<SysUserGroupRelation> page = sysUserGroupRelationService.findSysUserGroupRelationPage(sysUserGroupRelation);
        return getDataTable(page);
    }

    /**
     * 导出人员分组关联列表
     */
    @ApiOperation("导出人员分组关联列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:relation:export')")
    @Log(title = "人员分组关联", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(SysUserGroupRelation sysUserGroupRelation) {
        List<SysUserGroupRelation> list = sysUserGroupRelationService.findSysUserGroupRelationList(sysUserGroupRelation);
        ExcelUtil<SysUserGroupRelation> util = new ExcelUtil<>(SysUserGroupRelation.class);
        return util.exportExcel(list, "relation");
    }

    /**
     * 获取人员分组关联详细信息
     */
    @ApiOperation("获取人员分组关联详细信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:relation:query')")
    @GetMapping(value = "/{userId}")
    public AjaxResult<SysUserGroupRelation> getInfo(@PathVariable("userId") Long userId) {
        return AjaxResult.success(sysUserGroupRelationService.findByUserIdAndGroupId(userId));
    }



    /**
     * 新增人员分组关联
     */
    @ApiOperation("新增人员分组关联接口")
    @PreAuthorize("@ss.hasPermi('cms::arelationdd')")
    @Log(title = "人员分组关联", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SysUserGroupRelation sysUserGroupRelation) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        sysUserGroupRelation.setCreateBy(loginUser.getUsername());
        sysUserGroupRelation.setCreateTime(new Date());
        sysUserGroupRelation.setDelFlag("0");
        sysUserGroupRelationService.save(sysUserGroupRelation);
        return AjaxResult.success();
    }

    /**
     * 修改人员分组关联
     */
    @ApiOperation("修改人员分组关联接口")
    // @PreAuthorize("@ss.hasPermi('cms:relation:edit')")
    @Log(title = "人员分组关联", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SysUserGroupRelation sysUserGroupRelation) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        for (Long userId: sysUserGroupRelation.getUserIds()) {
            SysUserGroupRelation relation = sysUserGroupRelationService.findByUserIdAndGroupId(userId);
            if(relation == null){
                //不存在执行添加
                SysUserGroupRelation userGroupRelation = new SysUserGroupRelation();
                userGroupRelation.setCreateBy(loginUser.getUsername());
                userGroupRelation.setCreateTime(new Date());
                userGroupRelation.setGroupId(sysUserGroupRelation.getGroupId());
                userGroupRelation.setUserId(userId);
                sysUserGroupRelationService.save(userGroupRelation);
            }else{
                //存在执行修改
                relation.setGroupId(sysUserGroupRelation.getGroupId());
                relation.setUpdateBy(loginUser.getUsername());
                relation.setUpdateTime(new Date());
                sysUserGroupRelationService.save(relation);
            }
        }
        return AjaxResult.success();
    }



    /**
     * 删除人员分组关联
     */
    @ApiOperation("删除人员分组关联接口")
    @PreAuthorize("@ss.hasPermi('cms:relation:remove')")
    @Log(title = "人员分组关联", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        sysUserGroupRelationService.deleteByIds(Arrays.asList(ids));
        return AjaxResult.success();
    }
}
