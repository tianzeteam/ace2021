package com.yuejike.web.controller.v3d;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.v3d.service.ViewsService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/v3d/views")
@Api(tags = "3D浏览量相关")
public class ViewsController {
	
	@Autowired
	private ViewsService vService;
	
	@Autowired
    private TokenService tokenService;
	
    
    @ApiOperation("生成指定展商当前时间之前任意天数统计数据")
    @GetMapping("/generateViews")
//    @PreAuthorize("@ss.hasPermi('exhibition:saveAndUpdate')")
    public Object generateViews(@RequestParam Integer days){
    	LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        SysUser user = loginUser.getUser();
        return vService.generateViews(user.getUserId(), days);
    }
    
}
