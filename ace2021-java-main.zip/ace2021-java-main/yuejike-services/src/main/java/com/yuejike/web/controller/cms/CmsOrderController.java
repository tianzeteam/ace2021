package com.yuejike.web.controller.cms;

import com.yuejike.cms.domain.CmsOrder;
import com.yuejike.cms.domain.CmsProduct;
import com.yuejike.cms.service.ICmsOrderService;
import com.yuejike.cms.service.ICmsProductService;
import com.yuejike.cms.service.ISysUserExhibitorService;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.annotation.Message;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.page.TableDataInfo;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.common.enums.NoticeType;
import com.yuejike.common.enums.OrderStatus;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.SecurityUtils;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.framework.web.service.TokenService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * 订单Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/order")
@Api(tags = "C-询盘/订单信息接口",description = "询盘/订单信息接口")
public class CmsOrderController extends BaseController {
    @Autowired
    private ICmsOrderService cmsOrderService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private ISysUserExhibitorService exhibitorService;
    @Autowired
    private ICmsProductService productService;

    /**
     * 查询订单列表
     */
    @ApiOperation("查询询盘个人询盘")
//   @PreAuthorize("@ss.hasPermi('cms:order:list')")
    @GetMapping("/ui/list")
    public TableDataInfo<CmsOrder> listSelf(CmsOrder cmsOrder) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser.getUser() != null) {
            if (loginUser.getUser().getUserType().equals(UserType.CZS.getCode()) || loginUser.getUser().getUserType().equals(UserType.CZS_JS.getCode())) {
                cmsOrder.setUserId(loginUser.getUser().getDeptId());
            }
            cmsOrder.setBuyerId(loginUser.getUser().getUserId());
            Page<CmsOrder> page = cmsOrderService.findCmsOrderPage(cmsOrder);
            return getDataTable(page);
        }else{
            TableDataInfo rspData = new TableDataInfo();
            rspData.setCode(500);
            rspData.setMsg("查询失败");
            rspData.setRows(null);
            rspData.setTotal(0);
            return rspData;
        }

    }

    /**
     * 查询订单列表
     */
    @ApiOperation("查询询盘/订单列表接口,询盘传orderStatus=10,订单传orderStatus=20")
//   @PreAuthorize("@ss.hasPermi('cms:order:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsOrder> list(CmsOrder cmsOrder) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser.getUser() != null) {
            if (loginUser.getUser().getUserType().equals(UserType.CZS.getCode()) || loginUser.getUser().getUserType().equals(UserType.CZS_JS.getCode())) {
                cmsOrder.setUserId(loginUser.getUser().getDeptId());
                cmsOrder.setBuyerId(loginUser.getUser().getUserId());
                if(loginUser.getUser().getDeptId() == null || loginUser.getUser().getDeptId().equals(0)){
                    TableDataInfo rspData = new TableDataInfo();
                    rspData.setCode(0);
                    rspData.setMsg("请认证后查询");
                    rspData.setRows(null);
                    rspData.setTotal(0);
                    return rspData;
                }
            }else if(loginUser.getUser().getUserType().equals(UserType.GZ.getCode()) || loginUser.getUser().getUserType().equals(UserType.ZYGZ.getCode()) ||
                    loginUser.getUser().getUserType().equals(UserType.MT.getCode()) || loginUser.getUser().getUserType().equals(UserType.HYDB.getCode())){
                cmsOrder.setBuyerId(loginUser.getUser().getUserId());
            }
            Page<CmsOrder> page = cmsOrderService.findCmsOrderPage(cmsOrder);
            return getDataTable(page);
        }else{
            TableDataInfo rspData = new TableDataInfo();
            rspData.setCode(500);
            rspData.setMsg("查询失败");
            rspData.setRows(null);
            rspData.setTotal(0);
            return rspData;
        }

    }

    /**
     * 导出订单列表
     */
    @ApiOperation("导出订单列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:order:export')")
    @Log(title = "订单", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsOrder cmsOrder) {
        List<CmsOrder> list = cmsOrderService.findCmsOrderList(cmsOrder);
        ExcelUtil<CmsOrder> util = new ExcelUtil<>(CmsOrder.class);
        return util.exportExcel(list, "order");
    }

    /**
     * 获取订单详细信息
     */
    @ApiOperation("获取订单详细信息接口")
    @PreAuthorize("@ss.hasPermi('cms:order:query')")
    @GetMapping(value = "/{orderId}")
    public AjaxResult<CmsOrder> getInfo(@PathVariable("orderId") Long orderId) {
        return AjaxResult.success(cmsOrderService.findById(orderId));
    }

    /**
     * 新增订单
     */
    @ApiOperation("新增订单接口")
    @PreAuthorize("@ss.hasPermi('cms:order:add')")
    @Log(title = "订单", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsOrder cmsOrder) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        CmsProduct product = productService.findById(cmsOrder.getProductId());
        if(product != null) {
            cmsOrder.setUserId(product.getUserId());
            cmsOrder.setUserName(loginUser.getUser().getNickName());
            cmsOrder.setExhibitorName(product.getExhibitorName());
            cmsOrder.setBuyerId(loginUser.getUser().getUserId());
            cmsOrder.setCreateBy(loginUser.getUsername());
            cmsOrder.setCreateTime(new Date());
            cmsOrder.setOrderStatus(OrderStatus.NORMAL.getCode());
            cmsOrder.setDelFlag("0");
            cmsOrder.setPhoneNumber(loginUser.getUser().getPhonenumber());
            cmsOrder.setEmail(loginUser.getUser().getEmail());
            cmsOrderService.save(cmsOrder);
            return AjaxResult.success();
        }else{
            return AjaxResult.error("请选择正确的展品");
        }
    }

    /**
     * 修改订单
     */
    @ApiOperation("修改订单接口")
//    @PreAuthorize("@ss.hasPermi('cms:order:edit')")
    @Message(title = "询盘回复通知",noticeType = NoticeType.ORDER)
    @Log(title = "订单", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsOrder cmsOrder) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsOrder.setUpdateBy(loginUser.getUsername());
        cmsOrder.setUpdateTime(new Date());
        CmsOrder order = cmsOrderService.save(cmsOrder);
        AjaxResult ajaxResult = new AjaxResult();
        ajaxResult.setCode(0);
        ajaxResult.setMsg("修改成功");
        if(StringUtils.isNotBlank(cmsOrder.getReply())){
            ajaxResult.setData(order);
        }
        return ajaxResult;
    }

    /**
     * 删除订单
     */
    @ApiOperation("删除订单接口")
//    @PreAuthorize("@ss.hasPermi('cms:order:remove')")
    @Log(title = "订单", businessType = BusinessType.DELETE)
	@DeleteMapping("/{orderIds}")
    public AjaxResult remove(@PathVariable Long[] orderIds) {
        cmsOrderService.deleteByIds(Arrays.asList(orderIds));
        return AjaxResult.success();
    }

    /**
     * 订单状态修改
     * @param
     * @return
     */
    @ApiOperation("订单状态修改接口")
//    @PreAuthorize("@ss.hasPermi('system:order:edit')")
    @Log(title = "订单管理", businessType = BusinessType.UPDATE)
    @PutMapping("/changeStatus")
    public AjaxResult changeStatus(@RequestBody CmsOrder cmsOrder) {
        cmsOrder.setUpdateBy(SecurityUtils.getUsername());
        return toAjax(cmsOrderService.updateOrderStatus(cmsOrder));
    }
}
