package com.yuejike.web.controller.cms;

import com.yuejike.cms.domain.SysUserAudience;
import com.yuejike.cms.dto.SysUserAudienceDTO;
import com.yuejike.cms.service.ISysUserAudienceService;
import com.yuejike.cms.service.ISysUserDelegateService;
import com.yuejike.cms.service.ISysUserExhibitorService;
import com.yuejike.cms.service.ISysUserMediaService;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.entity.SysRole;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.page.TableDataInfo;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.system.service.ISysRoleService;
import com.yuejike.system.service.ISysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * 专业观众信息Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-26
 */
@RestController
@RequestMapping("/cms/audience")
@Api(tags = "B-专业观众信息接口",description = "专业观众信息接口")
public class SysUserAudienceController extends BaseController {
    @Autowired
    private ISysUserAudienceService sysUserAudienceService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private ISysUserService sysUserService;
    @Autowired
    private ISysUserExhibitorService sysUserExhibitorService;
    @Autowired
    private ISysUserDelegateService sysUserDelegateService;
    @Autowired
    private ISysUserMediaService sysUserMediaService;
    @Autowired
    private ISysRoleService roleService;

    /**
     * 查询专业观众信息列表
     */
    @ApiOperation("查询专业观众信息列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:audience:list')")
    @GetMapping("/list")
    public TableDataInfo<SysUserAudience> list(SysUserAudience sysUserAudience) {
        Page<SysUserAudience> page = sysUserAudienceService.findSysUserAudiencePage(sysUserAudience);
        return getDataTable(page);
    }

    /**
     * 导出专业观众信息列表
     */
    @ApiOperation("导出专业观众信息列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:audience:export')")
    @Log(title = "专业观众信息", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(SysUserAudience sysUserAudience) {
        List<SysUserAudience> list = sysUserAudienceService.findSysUserAudienceList(sysUserAudience);
        list.forEach(item->{
            item.setUserName(item.getUser().getUserName());
            item.setPhoneNumber(item.getUser().getPhonenumber());
            item.setEmail(item.getUser().getEmail());
            item.setCityName(item.getCity().getCityName());
            item.setProvinceName(item.getProvince().getProvinceName());
            item.setCountryName(item.getCountry().getCountryName());
            item.setReviewStatus(formatterReviewStatus(item.getUser().getReviewStatus()));
        });
        ExcelUtil<SysUserAudience> util = new ExcelUtil<>(SysUserAudience.class);
        return util.exportExcel(list, "audience");
    }

    private String formatterReviewStatus(String reviewStatus){
        switch (reviewStatus){
            case "1":
                return "审核通过";
            case "2":
                return "审核拒绝";
            default:
               return  "待审核";
        }
    }

    /**
     * 获取专业观众信息详细信息
     */
    @ApiOperation("获取专业观众信息详细信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:audience:query')")
    @GetMapping(value = "/{userId}")
    public AjaxResult<SysUserAudience> getInfo(@PathVariable("userId") Long userId) {
        return AjaxResult.success(sysUserAudienceService.findById(userId));
    }

    /**
     * 新增专业观众信息
     */
    @ApiOperation("新增专业观众信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:audience:add')")
    @Log(title = "专业观众信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SysUserAudienceDTO sysUserAudienceDTO) {

        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser != null && loginUser.getUser() != null) {
            if(!loginUser.getUser().getUserId().equals(sysUserAudienceDTO.getUserId())){
                return AjaxResult.error("无权操作，只有用户本人可提交认证");
            }
            SysUser user = sysUserService.selectUserById(sysUserAudienceDTO.getUserId());
            if (user == null) {
                return AjaxResult.error("未知错误，未找到数据库记录");
            }
            //角色转化
            if(!user.getUserType().equals(UserType.ZYGZ.getCode())){
                String[] arrUserType = {"02","03","04","05","06"};//可转化角色列表
                Set<String> userTypes = new HashSet<>(Arrays.asList(arrUserType));
                if(!userTypes.contains(user.getUserType())){
                    return AjaxResult.error("此用户类型不支持转化");
                }
                if((user.getUserType().equals(UserType.CZS.getCode()) && sysUserExhibitorService.findById(user.getUserId()) != null)
                        || (user.getUserType().equals(UserType.HYDB.getCode()) && sysUserDelegateService.findById(user.getUserId()) != null)
                        || (user.getUserType().equals(UserType.MT.getCode()) && sysUserMediaService.findById(user.getUserId()) != null)){
                    return AjaxResult.error("用户已经提交认证，无法再认证为其他角色");
                }
                user.setUserType(UserType.ZYGZ.getCode());
                user.setUpdateTime(new Date());
                user.setUpdateBy(loginUser.getUsername());
                user.setReviewStatus("0");
                SysRole sysRole = roleService.selectRoleByRoleKey("guest");
                if(sysRole != null){
                    user.setRoleIds(new Long[]{sysRole.getRoleId()});
                }else{
                    return AjaxResult.error("获取嘉宾角色失败");
                }
                sysUserService.updateUser(user);
            }
            //提交认证
            SysUserAudience sysUserAudience = new SysUserAudience();
            BeanUtils.copyProperties(sysUserAudienceDTO,sysUserAudience);
            sysUserAudience.setCreateBy(loginUser.getUsername());
            sysUserAudience.setCreateTime(new Date());
            sysUserAudience.setDelFlag("0");
            sysUserAudienceService.save(sysUserAudience);
            return AjaxResult.success();
        }else{
            return AjaxResult.error("未登录或登录失效，请重新登录");
        }
    }

    /**
     * 修改专业观众信息
     */
    @ApiOperation("修改专业观众信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:audience:edit')")
    @Log(title = "专业观众信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SysUserAudienceDTO sysUserAudienceDTO) {
        try{
                SysUserAudience sysUserAudience = new SysUserAudience();
                BeanUtils.copyProperties(sysUserAudienceDTO,sysUserAudience);
                LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
            if(StringUtils.isNotBlank(sysUserAudienceDTO.getReviewStatus()) && sysUserAudienceDTO.getReviewStatus().equals("2")){
                //用户被拒绝后再次提交审核时,将审核状态修改待审核
                sysUserService.updateReviewStatus(sysUserAudienceDTO.getUserId());
                //根据id查询专业观众
                SysUserAudience userAudience = sysUserAudienceService.findById(sysUserAudienceDTO.getUserId());
                userAudience.setCompanyName(sysUserAudienceDTO.getCompanyName());
                userAudience.setCountryId(sysUserAudienceDTO.getCountryId());
                userAudience.setProvinceId(sysUserAudienceDTO.getProvinceId());
                userAudience.setCityId(sysUserAudienceDTO.getCityId());
                userAudience.setIntent(sysUserAudienceDTO.getIntent());
                userAudience.setUpdateBy(loginUser.getUsername());
                userAudience.setUpdateTime(new Date());
                sysUserAudienceService.save(userAudience);
            }else{
                sysUserAudience.setUpdateBy(loginUser.getUsername());
                sysUserAudience.setUpdateTime(new Date());
                sysUserAudienceService.save(sysUserAudience);
            }
            return AjaxResult.success();
        }catch (Exception ex) {
            ex.printStackTrace();
            logger.error(ex.getMessage());
            return AjaxResult.error(ex.getMessage());
        }
    }

    /**
     * 删除专业观众信息
     */
    @ApiOperation("删除专业观众信息接口")
    @PreAuthorize("@ss.hasPermi('cms:audience:remove')")
    @Log(title = "专业观众信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{userIds}")
    public AjaxResult remove(@PathVariable Long[] userIds) {
        sysUserAudienceService.deleteByIds(Arrays.asList(userIds));
        return AjaxResult.success();
    }
}
