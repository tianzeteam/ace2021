package com.yuejike.web.controller.oauth;

import java.util.Optional;

import com.yuejike.common.core.redis.RedisCache;
import com.yuejike.common.utils.uuid.UUID;
import com.yuejike.dto.BindWxMobileDTO;
import com.yuejike.dto.MiniLoginDTO;
import com.yuejike.web.util.WechatDecryptUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.Assert;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import com.alibaba.fastjson.JSONObject;

import com.yuejike.common.constant.Constants;
import com.yuejike.common.core.domain.MapResult;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.utils.SecurityUtils;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.framework.web.service.SysLoginService;
import com.yuejike.system.dao.SysUserDao;
import com.yuejike.web.util.WechatClient;


/**
 * 微信OAUTH与 登录
 * @author kosku
 *
 */
@RestController
@RequestMapping("/v2/oauth")
@Api(tags = "小程序快捷登陆",description = "小程序登陆,微信手机绑定")
public class WeiXinRestController {

    // 小程序appid
    @Value("${weixin.miniAppId}")
    private String miniAppId;

    // 小程序AppSecret
    @Value("${weixin.miniSecret}")
    private String miniSecret;

    @Autowired
    private SysUserDao userDao;

    @Autowired
    private SysLoginService loginService;

    @Autowired
    private RedisCache redisCache;

    @ApiOperation("取得小程序openid")
    @GetMapping("/wx/openId")
    @ApiResponses({
            @ApiResponse(code = 200, message = "OK", response = MapResult.class)
    })
    public MapResult wxOpenid(@RequestParam String wxCode){
        MapResult ajax = MapResult.success();
        JSONObject wstJson = getWx(wxCode);
        if(ObjectUtils.isEmpty(wstJson)) {
            ajax.put(MapResult.CODE_TAG,500);
            ajax.put(MapResult.MSG_TAG,"无法获取您的信息，请尝试重新授权");
            return ajax;
        }else {
            String openid = wstJson.getString("openid");
            String session_key = wstJson.getString("session_key");
            System.out.println("session_key:::::"+session_key);
            ajax.put(Constants.OPEN_ID, openid);
            ajax.put(MapResult.CODE_TAG,200);
            redisCache.setCacheMapValue(Constants.OPEN_ID_KEY,openid,session_key);
        }

        return ajax;
    }

    @ApiOperation("小程序手机号码绑定")
    @PostMapping("/wx/bindPhone")
    public MapResult bindWxPhone(@RequestBody BindWxMobileDTO mobileDto){
        Assert.notNull(mobileDto.getOpenId(),"openid 不能为空");
        Assert.notNull(mobileDto.getEncryptedData(),"encryptedData 不能为空");
        Assert.notNull(mobileDto.getIv(),"iv 不能为空");

        String session_key = redisCache.getCacheMapValue(Constants.OPEN_ID_KEY,mobileDto.getOpenId());
        String decryptText = WechatDecryptUtil.decryptData(mobileDto.getEncryptedData(),session_key,mobileDto.getIv());
        JSONObject jsonObject = JSONObject.parseObject(decryptText);
        MapResult ajax = MapResult.success();
        String purePhoneNumber = jsonObject.getString("purePhoneNumber");
        System.out.println("purePhoneNumber:::::"+purePhoneNumber);
        //TODO: 原逻辑-根据手机号码查找用户，如果找到，就绑定openId，如果找不到，就新增记录。这样存在openId重复的问题，会导致小程序登录时出错
        //TODO: 新逻辑-先搜索openId是否绑定过，如果有绑定过就在此记录上操作，如果未绑定再来按老的逻辑走。
        Optional<SysUser> findByOpenId = userDao.findByOpenId(mobileDto.getOpenId());
        if(!ObjectUtils.isEmpty(findByOpenId)) {
            findByOpenId.get().setPhonenumber(purePhoneNumber);
            userDao.save(findByOpenId.get());
        }else {
            Optional<SysUser> findByPhonenumber = userDao.findByPhonenumber(purePhoneNumber);
            if(!ObjectUtils.isEmpty(findByPhonenumber)) {
                findByPhonenumber.get().setOpenId(mobileDto.getOpenId());
                userDao.save(findByPhonenumber.get());
            }else {
                SysUser user = new SysUser();
                user.setOpenId(mobileDto.getOpenId());
                user.setUserName("wx_"+UUID.randomUUID().toString().replace("-",""));
                user.setNickName(mobileDto.getNickName());
                user.setUserType("06");
                user.setPhonenumber(purePhoneNumber);
                user.setPassword(SecurityUtils.encryptPassword("123456@jbh2021"));
                user.setExpositionId(10L);
                user.setAvatar(mobileDto.getAvatar());
                userDao.save(user);
            }
        }

        ajax.put(MapResult.CODE_TAG,0);
        return ajax;
    }
    @ApiOperation("小程序登陆")
    @PostMapping("/wx/miniLogin")
    public MapResult wxMiniLogin(@RequestBody MiniLoginDTO miniLoginDTO){
        MapResult ajax = MapResult.success();
        SysUser wstUser = null;
        Assert.notNull(miniLoginDTO.getOpenId(),"openid 不能为空");

        Optional<SysUser> byOpenId = userDao.findByOpenId(miniLoginDTO.getOpenId());
        wstUser = byOpenId.get();

        if(ObjectUtils.isEmpty(wstUser)){
            ajax.put(MapResult.CODE_TAG,404);
            ajax.put(MapResult.MSG_TAG,"该用户还未注册或者未绑定");
            return ajax;
        }

        String loginU = loginService.loginByUserName(wstUser.getUserName());
        ajax.put(Constants.TOKEN, loginU);
        return ajax;
    }


    private JSONObject getWx(String wxCode) {
        JSONObject wxUser = null; //class
        try {
            wxUser = WechatClient.getMiniUserByCode(wxCode,miniAppId,miniSecret);
        }catch(Exception e) {
            return null;
        }

        if(StringUtils.isEmpty(wxUser.getString("openid"))) {
            return null;
        }
        return wxUser;
    }
}
