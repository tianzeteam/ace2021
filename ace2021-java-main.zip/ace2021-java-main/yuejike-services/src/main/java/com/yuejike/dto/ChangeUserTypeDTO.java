package com.yuejike.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author JinZJ
 * @version 1.0
 * @Description:
 * @date 2021/11/3 13:20
 */
@Data
@ApiModel("修改角色信息")
public class ChangeUserTypeDTO {

    /**
     * 用户类型
     */
    @ApiModelProperty(value = "用户角色：02展商，03会议代表，04媒体，05专业观众，06普通观众；")
    private String userType;

}
