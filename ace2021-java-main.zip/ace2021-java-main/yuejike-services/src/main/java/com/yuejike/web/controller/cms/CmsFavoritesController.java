package com.yuejike.web.controller.cms;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsFavorites;
import com.yuejike.cms.service.ICmsFavoritesService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 收藏Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/favorites")
@Api(tags = "收藏",description = "收藏")
public class CmsFavoritesController extends BaseController {
    @Autowired
    private ICmsFavoritesService cmsFavoritesService;
    @Autowired
    private TokenService tokenService;

    /**
     * 查询收藏列表
     */
    @ApiOperation("查询收藏列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:favorites:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsFavorites> list(CmsFavorites cmsFavorites) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsFavorites.setUserId(loginUser.getUser().getUserId());
        Page<CmsFavorites> page = cmsFavoritesService.findCmsFavoritesPage(cmsFavorites);
        return getDataTable(page);
    }

    /**
     * 导出收藏列表
     */
    @ApiOperation("导出收藏列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:favorites:export')")
    @Log(title = "收藏", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsFavorites cmsFavorites) {
        List<CmsFavorites> list = cmsFavoritesService.findCmsFavoritesList(cmsFavorites);
        ExcelUtil<CmsFavorites> util = new ExcelUtil<>(CmsFavorites.class);
        return util.exportExcel(list, "favorites");
    }

    /**
     * 获取收藏详细信息
     */
    @ApiOperation("获取收藏详细信息接口")
    @PreAuthorize("@ss.hasPermi('cms:favorites:query')")
    @GetMapping(value = "/{favoritesId}")
    public AjaxResult<CmsFavorites> getInfo(@PathVariable("favoritesId") Long favoritesId) {
        return AjaxResult.success(cmsFavoritesService.findById(favoritesId));
    }

    /**
     * 新增收藏
     */
    @ApiOperation("新增收藏接口")
    // @PreAuthorize("@ss.hasPermi('cms:favorites:add')")
    @Log(title = "收藏", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsFavorites cmsFavorites) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsFavorites.setUserId(loginUser.getUser().getUserId());
        cmsFavorites.setCreateBy(loginUser.getUsername());
        cmsFavorites.setCreateTime(new Date());
        cmsFavorites.setDelFlag("0");
        CmsFavorites favorites = cmsFavoritesService.save(cmsFavorites);
        return AjaxResult.success(favorites);
    }

    /**
     * 修改收藏
     */
    @ApiOperation("修改收藏接口")
    @PreAuthorize("@ss.hasPermi('cms:favorites:edit')")
    @Log(title = "收藏", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsFavorites cmsFavorites) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsFavorites.setUpdateBy(loginUser.getUsername());
        cmsFavorites.setUpdateTime(new Date());
        cmsFavoritesService.save(cmsFavorites);
        return AjaxResult.success();
    }

    /**
     * 删除收藏
     */
    @ApiOperation("删除收藏接口")
    // @PreAuthorize("@ss.hasPermi('cms:favorites:remove')")
    @Log(title = "收藏", businessType = BusinessType.DELETE)
	@DeleteMapping("/{favoritesIds}")
    public AjaxResult remove(@PathVariable Long[] favoritesIds) {
        cmsFavoritesService.deleteByIds(Arrays.asList(favoritesIds));
        return AjaxResult.success();
    }
}
