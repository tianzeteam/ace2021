package com.yuejike.web.controller.v3d;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.yuejike.v3d.dto.SysExhibitorQyeryCtiteria;
import com.yuejike.v3d.service.BusinessmanService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/v3d/web")
@Api(tags = "3D展商相关(前端)")
public class WebController {
	
	@Autowired
	private BusinessmanService businessmanService;
	
//	@Autowired
//	private SysUserExhibitorDao sDao;
//	
//	@Autowired
//	private BusinessmanExhibitionDao dDao;

	@ApiOperation("所有展商列表分页")
    @GetMapping("/all")
    public ResponseEntity<Object> getArchives(SysExhibitorQyeryCtiteria criteria, Pageable pageable){
//		criteria.setStatus(TypeConstant.ADOPT);
        criteria.setIsUi(true);
        return new ResponseEntity<>(businessmanService.webAll(criteria, pageable),HttpStatus.OK);
    }

	
	@ApiOperation("指定展商详情")
    @GetMapping("/findByUserId")
    public ResponseEntity<Object> findByUserId(@RequestParam Long uid){
        return new ResponseEntity<>(businessmanService.getWeb(uid),HttpStatus.OK);
    }
	
	
//    @GetMapping("/szm")
//    public ResponseEntity<Object> szm(){
//    	List<BusinessmanExhibition> findAll = dDao.findAll();
//    	int i = 0;
//    	for (BusinessmanExhibition b : findAll) {
//    		SysUserExhibitor findByUserId = sDao.findByUserId(b.getUserId());
//    		if(!ObjectUtils.isEmpty(findByUserId)) {
//    			if(ObjectUtils.isEmpty(b.getSysExhibitor())) {
//    				System.out.println(b.getUserId());
//    				b.setSysExhibitor(findByUserId);
//    				dDao.save(b);
//    			}
////    			findByUserId.setHistoryViews(b.getHistoryViews());
////        		findByUserId.setStatus(b.getStatus());
////        		sDao.save(findByUserId);
//        		i++;
//    		}
//    		
//		}
//    	System.out.println("成功同步："+i+"条数据");
//        return new ResponseEntity<>("成功同步："+i+"条数据",HttpStatus.OK);
//    }
	
	
}
