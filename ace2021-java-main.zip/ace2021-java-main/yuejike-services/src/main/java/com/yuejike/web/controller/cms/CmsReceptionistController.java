package com.yuejike.web.controller.cms;

import com.yuejike.cms.domain.CmsOrder;
import com.yuejike.cms.domain.ExhibitionMaterials;
import com.yuejike.cms.domain.Receptionist;
import com.yuejike.cms.service.ICmsReceptionistService;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.annotation.Message;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.page.TableDataInfo;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.common.enums.NoticeType;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.framework.web.service.TokenService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

/**
 * @author JinZJ
 * @version 1.0
 * @Description:
 * @date 2021/11/17 17:10
 */
@RestController
@RequestMapping("/cms/receptionist")
@Api(tags = "3D形象")
public class CmsReceptionistController extends BaseController {

    @Autowired
    private TokenService tokenService;
    @Autowired
    private ICmsReceptionistService cmsReceptionistService;

    @ApiOperation("条件分页查询3D形象")
    //@PreAuthorize("@ss.hasPermi('cms:receptionist:list')")
    @GetMapping("/list")
    public TableDataInfo<Receptionist> list(Receptionist receptionist){
        Page<Receptionist> page = cmsReceptionistService.selectReceptionistList(receptionist);
        return getDataTable(page);
    }

    @ApiOperation("新增3D形象")
    @Log(title = "3D形象管理", businessType = BusinessType.INSERT)
    @PreAuthorize("@ss.hasPermi('cms:receptionist:add')")
    @PostMapping
    public AjaxResult add(@Validated @RequestBody Receptionist receptionist) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        receptionist.setCreateTime(new Date());
        receptionist.setCreateBy(loginUser.getUsername());
        return cmsReceptionistService.save(receptionist) != null ? AjaxResult.success() : AjaxResult.error();
    }

    @ApiOperation("删除3D形象")
    @Log(title = "3D形象管理", businessType = BusinessType.DELETE)
    @PreAuthorize("@ss.hasPermi('cms:materials:remove')")
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        cmsReceptionistService.deleteReceptionistByIds(ids);
        return AjaxResult.success();
    }

    @ApiOperation("修改3D形象")
    @PreAuthorize("@ss.hasPermi('cms:receptionist:edit')")
    @Log(title = "3D形象管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@Validated @RequestBody Receptionist receptionist) {
        return cmsReceptionistService.save(receptionist) != null ? AjaxResult.success() : AjaxResult.error();
    }

}
