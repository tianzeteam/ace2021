package com.yuejike.web.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel("上传文件返回信息")
public class UploadFileVo implements Serializable {
    @ApiModelProperty("链接地址")
    private String url;
    @ApiModelProperty("文件名称")
    private String fileName;
}
