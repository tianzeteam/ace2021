package com.yuejike.web.controller.system;

import com.yuejike.cms.service.ISysUserAudienceService;
import com.yuejike.cms.service.ISysUserDelegateService;
import com.yuejike.cms.service.ISysUserExhibitorService;
import com.yuejike.cms.service.ISysUserMediaService;
import com.yuejike.common.constant.Constants;
import com.yuejike.common.constant.UserConstants;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.MapResult;
import com.yuejike.common.core.domain.entity.SysMenu;
import com.yuejike.common.core.domain.entity.SysRole;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.core.domain.model.LoginBody;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.redis.RedisCache;
import com.yuejike.common.enums.RegisterType;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.SecurityUtils;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.common.utils.code.BusinessBizCode;
import com.yuejike.common.utils.email.IMailService;
import com.yuejike.common.utils.sms.LuoSiMaoSmsUtils;
import com.yuejike.common.utils.sms.RetMsg;
import com.yuejike.common.utils.uuid.UUID;
import com.yuejike.dto.*;
import com.yuejike.framework.web.service.SysLoginService;
import com.yuejike.framework.web.service.SysPermissionService;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.system.dto.RouterVo;
import com.yuejike.system.service.ISysMenuService;
import com.yuejike.system.service.ISysRoleService;
import com.yuejike.system.service.ISysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 登录验证
 *
 * @author yuejike
 */
@Api(tags = "A-登录接口",description = "登录接口")
@RestController
@CrossOrigin
public class SysLoginController extends BaseController {
    @Autowired
    private SysLoginService loginService;

    @Autowired
    private ISysMenuService menuService;

    @Autowired
    private SysPermissionService permissionService;

    @Autowired
    private TokenService tokenService;

    @Autowired
    private ISysUserService userService;

    @Autowired
    private ISysRoleService roleService;

    @Autowired
    private RedisCache redisCache;

    @Autowired
    private IMailService mailService;

    @Autowired
    private ISysUserExhibitorService sysUserExhibitorService;
    @Autowired
    private ISysUserDelegateService sysUserDelegateService;
    @Autowired
    private ISysUserMediaService sysUserMediaService;
    @Autowired
    private ISysUserAudienceService sysUserAudienceService;

    /**
     * 登录方法
     *
     * @param loginBody 登录信息
     * @return 结果
     */
    @ApiOperation("账号密码登录接口（有验证码）")
    @PostMapping("/login")
    public MapResult login(@RequestBody LoginBody loginBody) {
        MapResult ajax = MapResult.success();
        //根据用户名查询用户状态
        SysUser user = userService.selectUserByUserName(loginBody.getUsername());
        if(user == null)  {
            ajax.put(MapResult.CODE_TAG,500);
            ajax.put(MapResult.MSG_TAG,"用户名或密码错误");
            return ajax;
        } else if(user.getUserType().equals(UserType.HYDB.getCode()) || user.getUserType().equals(UserType.GZ.getCode())
                || user.getUserType().equals(UserType.MT.getCode()) || user.getUserType().equals(UserType.ZYGZ.getCode())){
            ajax.put(MapResult.CODE_TAG,500);
            ajax.put(MapResult.MSG_TAG,"您的身份暂不支持登录后台管理系统");
            return ajax;
        }else{
            if(!user.getReviewStatus().equals("1")){
                ajax.put(MapResult.CODE_TAG,500);
                ajax.put(MapResult.MSG_TAG,"您还未被审核通过,暂时不能登录！");
                return ajax;
            }
        }

        // 生成令牌
        String token;
        if(user.getUserType().equals(UserType.CZS.getCode()) && Constants.CZS_FIXED_PWD.equals(loginBody.getPassword())) {
            token = loginService.loginWithFixedPwd(loginBody.getUsername());
        }else {
            token = loginService.login(loginBody.getUsername(), loginBody.getPassword(), loginBody.getCode(),
                    loginBody.getUuid());
        }

        ajax.put(Constants.TOKEN, token);
        //展商刷新年份
        if(user.getUserType().equals(UserType.CZS.getCode())){
            sysUserExhibitorService.refreshJoinYears(user.getUserId());
        }
        return ajax;
    }

    @ApiOperation("账号密码登录接口（无验证码）")
    @PostMapping("/login2")
    public MapResult login2(@RequestBody LoginBody loginBody) {
        MapResult ajax = MapResult.success();
        SysUser user = userService.selectUserByUserName(loginBody.getUsername());
        if(user == null)  {
            ajax.put(MapResult.CODE_TAG,500);
            ajax.put(MapResult.MSG_TAG,"用户名或密码错误");
            return ajax;
        }

        // 生成令牌
        String token;
        if(user.getUserType().equals(UserType.CZS.getCode()) && Constants.CZS_FIXED_PWD.equals(loginBody.getPassword())) {
            token = loginService.loginWithFixedPwd(loginBody.getUsername());
        }else {
            token = loginService.login2(loginBody.getUsername(), loginBody.getPassword());
        }
        ajax.put(Constants.TOKEN, token);

        //展商刷新年份
        if(user.getUserType().equals(UserType.CZS.getCode())){
            sysUserExhibitorService.refreshJoinYears(user.getUserId());
        }
        return ajax;
    }

    /**
     * 获取用户信息
     *
     * @return 用户信息
     */
    @ApiOperation("获取当前登录用户信息接口")
    @GetMapping("getInfo")
    public MapResult getInfo() {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        SysUser user = loginUser.getUser();
        user = userService.selectUserById(user.getUserId());
        // 角色集合
        Set<String> roles = permissionService.getRolePermission(user);
        // 权限集合
        Set<String> permissions = permissionService.getMenuPermission(user);
        MapResult ajax = MapResult.success();
        ajax.put("user", user);
        ajax.put("roles", roles);
        ajax.put("permissions", permissions);
        return ajax;
    }

    /**
     * 获取路由信息
     *
     * @return 路由信息
     */
    @ApiOperation("获取当前登录用户路由信息接口")
    @GetMapping("getRouters")
    public MapResult getRouters() {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        // 用户信息
        SysUser user = loginUser.getUser();
        List<SysMenu> menus = menuService.selectMenuTreeByUserId(user.getUserId());
        List<RouterVo> routerVos = menuService.buildMenus(menus);
        return MapResult.success(routerVos);
    }

    /**
     * 用户注册
     * @param
     * @return
     */
    @ApiOperation("用户注册")
    @PostMapping("/v2/register")
    public AjaxResult register(@RequestBody UserDTO userDto, HttpServletRequest request){
        SysUser user = new SysUser();
        BeanUtils.copyProperties(userDto,user);
        if(RegisterType.MOBILE.getCode() == userDto.getRegisterType() && StringUtils.isEmpty(userDto.getPhonenumber())){
            return AjaxResult.error("请输入手机号");
        }
        if(RegisterType.EMAIL.getCode() == userDto.getRegisterType() && StringUtils.isEmpty(userDto.getEmail())){
            return AjaxResult.error("请输入邮箱");
        }
        if (UserConstants.NOT_UNIQUE.equals(userService.checkUserNameUnique(user.getUserName()))) {
            return AjaxResult.error("注册用户'" + user.getUserName() + "'失败，登录账号已存在");
        } else if (userDto.getRegisterType() == RegisterType.MOBILE.getCode() && UserConstants.NOT_UNIQUE.equals(userService.checkPhoneUnique(user))) {
            return AjaxResult.error("注册用户'" + user.getUserName() + "'失败，手机号码已存在");
        } else if (userDto.getRegisterType() == RegisterType.EMAIL.getCode() && UserConstants.NOT_UNIQUE.equals(userService.checkEmailUnique(user))) {
            return AjaxResult.error("注册用户'" + user.getUserName() + "'失败，邮箱账号已存在");
        } else if(UserConstants.NOT_UNIQUE.equals(userService.checkSponsorUnique())){
            return AjaxResult.error("博览会已结束！");
        }
        String code = userDto.getCode();
        String mobile = userDto.getRegisterType() == RegisterType.EMAIL.getCode()? userDto.getEmail():userDto.getPhonenumber();
        Object smsCodeObj = redisCache.getCacheObject(StringUtils.format("sms:{}",mobile));

        String fixCode = "231564"; //固定的验证码
        if(smsCodeObj!=null || code.equals(fixCode)){
            String smsCode = smsCodeObj!=null ? smsCodeObj.toString() : fixCode;
            if(userDto.getRegisterType() == 1) {
//                XinXinSmsUtils.getInstance().verifyCodeMsg(request, mobile, code, smsCode);
            }
            if(code.equals(smsCode)){
                redisCache.deleteObject(StringUtils.format("sms:{}",mobile));
            }else{
                return AjaxResult.error("验证码错误");
            }
        }else{
            return AjaxResult.error("验证码已失效，请重新获取");
        }
        if(RegisterType.MOBILE.getCode() == userDto.getRegisterType() ){
           String  subPhone =userDto.getPhonenumber().substring(userDto.getPhonenumber().length()-4);
            user.setNickName("用户"+subPhone);
        }
        if(RegisterType.EMAIL.getCode() == userDto.getRegisterType() ){
            user.setNickName(userDto.getEmail().split("@")[0]);
        }

        user.setUserName("jbh_"+ UUID.randomUUID().toString().replace("-",""));
        String password = user.getPassword();
        user.setPassword(SecurityUtils.encryptPassword(password));
        if(userService.registerUser(user) == BusinessBizCode.OPTION_SUCCESS.getCode()) {
            // 生成令牌
            String token = loginService.login2(user.getUserName(), password);
            //展商刷新年份
            if(user.getUserType().equals(UserType.CZS.getCode())){
                sysUserExhibitorService.refreshJoinYears(user.getUserId());
            }

            return AjaxResult.success(token, "注册成功");
        }
        return AjaxResult.error();
    }

    @ApiOperation("发送验证码")
    @PostMapping("/sendCode")
    public AjaxResult sendSmsCode(@RequestBody SendCodeDTO sendCodeDto, HttpServletRequest request){
        RetMsg retMsg = new RetMsg(-1,"发送失败");
        String code = null;
        try {
            code = StringUtils.getMsgCode();
            if(sendCodeDto.getRegisterType() == RegisterType.MOBILE.getCode()){
                Pattern p = Pattern.compile("^\\s{0}$|^0{0,1}(13[0-9]|15[0-9]|16[0-9]|17[0-9]|14[0-9]|18[0-9]|19[0-9])[0-9]{8}$");
                Matcher m = p.matcher(sendCodeDto.getAccount());
                if(m.matches()) {
                    retMsg = LuoSiMaoSmsUtils.getInstance().sendVerCode(sendCodeDto.getAccount(),code);
                }else{
                    retMsg.setMsg("请输入正确的手机号");
                }
            }else{
                Pattern p = Pattern.compile("^[A-Za-z0-9\\u4e00-\\u9fa5_\\.]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$");
                Matcher m = p.matcher(sendCodeDto.getAccount());
                if(m.matches()) {
                    String [] toMailList = {sendCodeDto.getAccount()};
                    String[] ccMailList = {"iluohe@163.com"};
                    mailService.sendHtmlMail("注册用户邮箱验证码",StringUtils.format("验证码：{}，有效期为5分钟。请勿向他人泄露验证码，如非本人操作，请忽略本短信。",code),toMailList);
                    retMsg.setCode(0);
                    retMsg.setMsg("发送成功");
                }else{
                    retMsg.setMsg("请输入正确的邮箱");
                }
            }

        }catch (Exception ex){
            ex.printStackTrace();
        }finally {
            if(retMsg.getCode() == 0){
                redisCache.setCacheObject(StringUtils.format("sms:{}",sendCodeDto.getAccount()), code, Constants.SMS_CODE_EXPIRATION, TimeUnit.MINUTES);
                return AjaxResult.success();
            }else{
                return AjaxResult.error(retMsg.getMsg());
            }
        }
    }

    @ApiOperation("绑定手机号")
    @PostMapping("/bindMobile")
    public AjaxResult bindMobile(@RequestBody BindMobileDTO mobileDto, HttpServletRequest request){
        try{
            if(mobileDto == null){
                return AjaxResult.error("参数错误");
            }
            if(StringUtils.isEmpty(mobileDto.getPhonenumber())){
                return AjaxResult.error("请输入手机号");
            }
            if(StringUtils.isEmpty(mobileDto.getCode())){
                return AjaxResult.error("请输入验证码");
            }

            LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
            if(loginUser != null && loginUser.getUser() != null) {
                SysUser user = userService.selectUserById(loginUser.getUser().getUserId());
                if (user == null) {
                    return AjaxResult.error("未知错误，未找到数据库记录");
                }
                if (mobileDto.getPhonenumber().equals(user.getPhonenumber())) {
                    return AjaxResult.error("更改前后一致，未作更改");
                }
                if (UserConstants.NOT_UNIQUE.equals(userService.checkPhoneUnique(user))) {
                    return AjaxResult.error("注册用户'" + user.getUserName() + "'失败，手机号码已存在");
                }else if(UserConstants.NOT_UNIQUE.equals(userService.checkSponsorUnique())){
                    return AjaxResult.error("博览会已结束！");
                }
                Object smsCodeObj = redisCache.getCacheObject(StringUtils.format("sms:{}",mobileDto.getPhonenumber()));
                if(smsCodeObj!=null){
                    //XinXinSmsUtils.getInstance().verifyCodeMsg(request, mobileDto.getPhonenumber(),mobileDto.getCode(), smsCodeObj.toString());
                    if(mobileDto.getCode().equals(smsCodeObj.toString())){
                        redisCache.deleteObject(StringUtils.format("sms:{}",mobileDto.getPhonenumber()));
                        user.setPhonenumber(mobileDto.getPhonenumber());
                        user.setUpdateTime(new Date());
                        user.setUpdateBy(user.getUserName());
                        return toAjax(userService.updateUser(user));
                    }else{
                        return AjaxResult.error("验证码错误");
                    }

                }else{
                    //XinXinSmsUtils.getInstance().verifyCodeMsg(request,mobileDto.getPhonenumber(),mobileDto.getCode(),"");
                    return AjaxResult.error("验证码已失效，请重新获取");
                }
            }else{
                return AjaxResult.error("未登录或登录失效，请重新登录");
            }
        }catch (Exception e){
            return AjaxResult.error(e.getMessage());
        }

    }

    @ApiOperation("绑定邮箱")
    @PostMapping("/bindEmail")
    public AjaxResult bindEmail(@RequestBody BindEmailDTO emailDto, HttpServletRequest request){
        if(emailDto == null || StringUtils.isEmpty(emailDto.getEmail()) || StringUtils.isEmpty(emailDto.getCode())){
            return AjaxResult.error("参数错误");
        }

        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser != null && loginUser.getUser() != null) {
            SysUser user = userService.selectUserById(loginUser.getUser().getUserId());
            if (user == null) {
                return AjaxResult.error("未知错误，未找到数据库记录");
            }
            if (emailDto.getEmail().equals(user.getEmail())) {
                return AjaxResult.error("更改前后一致，未作更改");
            }
            Object smsCodeObj = redisCache.getCacheObject(StringUtils.format("sms:{}",emailDto.getEmail()));
            if(smsCodeObj!=null){
                if(emailDto.getCode().equals(smsCodeObj)){
                    redisCache.deleteObject(StringUtils.format("sms:{}",emailDto.getEmail()));
                    user.setEmail(emailDto.getEmail());
                    user.setUpdateTime(new Date());
                    user.setUpdateBy(user.getUserName());
                    return toAjax(userService.updateUser(user));
                }else{
                    return AjaxResult.error("验证码错误");
                }
            }else{
                return AjaxResult.error("验证码已失效，请重新获取");
            }
        }else{
            return AjaxResult.error("未登录或登录失效，请重新登录");
        }
    }

    @ApiOperation("修改昵称")
    @PostMapping("/changeName")
    @ApiImplicitParams(@ApiImplicitParam(name="name",value = "昵称",dataType = "String",required = true,defaultValue = ""))
    public AjaxResult changeNickName(@RequestParam("name") String name,HttpServletRequest request){
        if(StringUtils.isEmpty(name)){
            return AjaxResult.error("昵称不能为空");
        }

        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser != null && loginUser.getUser() != null){
            SysUser user = userService.selectUserById(loginUser.getUser().getUserId());
            if(user == null){
                return AjaxResult.error("未知错误，未找到数据库记录");
            }
            if(name.equals(user.getNickName())){
                return AjaxResult.error("更改前后一致，未作更改");
            }
            user.setNickName(name);
            user.setUpdateTime(new Date());
            user.setUpdateBy(user.getUserName());
            return toAjax(userService.updateUser(user));
        }else{
            return AjaxResult.error("未登录或登录失效，请重新登录");
        }
    }
    @ApiOperation("修改密码")
    @PostMapping("/changePassword")
    public AjaxResult changePassword(@RequestBody ChangePasswordDTO passwordDto, HttpServletRequest request){
        if(passwordDto == null){
            return AjaxResult.error("参数错误");
        }
        if(StringUtils.isEmpty(passwordDto.getOldPassword())){
            return AjaxResult.error("请输入旧密码");
        }
        if(StringUtils.isEmpty(passwordDto.getNewPassword())){
            return AjaxResult.error("请输入新密码");
        }
        if(StringUtils.isEmpty(passwordDto.getRepeatPassword())){
            return AjaxResult.error("请再次输入新密码");
        }
        if(!passwordDto.getNewPassword().equals(passwordDto.getRepeatPassword())){
            return AjaxResult.error("两次输入的密码不一致");
        }
        if(passwordDto.getOldPassword().equals(passwordDto.getNewPassword())){
            return AjaxResult.error("更改前后一致，未作更改");
        }

        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser != null && loginUser.getUser() != null){
            SysUser user = userService.selectUserById(loginUser.getUser().getUserId());
            if(user == null){
                return AjaxResult.error("未知错误，未找到数据库记录");
            }
            if(!SecurityUtils.matchesPassword(passwordDto.getOldPassword(),user.getPassword())){
                return AjaxResult.error("输入的旧密码不正确");
            }
            user.setPassword(SecurityUtils.encryptPassword(passwordDto.getNewPassword()));
            user.setUpdateTime(new Date());
            user.setUpdateBy(user.getUserName());
            return toAjax(userService.updateUser(user));
        }else{
            return AjaxResult.error("未登录或登录失效，请重新登录");
        }
    }

    @ApiOperation(value="更改角色",notes="此接口只用作特殊角色转普通观众，由普通观众认证为其它角色，直接调用之前的各原先提交认证接口就好，接口中已经加了自动转角色实现")
    @PostMapping("/v2/changeUserType")
    public AjaxResult changeUserType(@RequestBody ChangeUserTypeDTO userTypeDTO, HttpServletRequest request){
        if(userTypeDTO == null || StringUtils.isEmpty(userTypeDTO.getUserType())){
            return AjaxResult.error("用户角色参数不能为空");
        }
        String[] arrUserType = {"02","03","04","05","06"};
        Set<String> userTypes = new HashSet<>(Arrays.asList(arrUserType));
        if(!userTypes.contains(userTypeDTO.getUserType())){
            return AjaxResult.error("参数错误");
        }

        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser != null && loginUser.getUser() != null){
            SysUser user = userService.selectUserById(loginUser.getUser().getUserId());
            if(user == null){
                return AjaxResult.error("未知错误，未找到数据库记录");
            }
            if(user.getUserType().equals(userTypeDTO.getUserType())){
                return AjaxResult.error("更改前后一致，未作更改");
            }
            if((user.getUserType().equals(UserType.HYDB.getCode()) && sysUserDelegateService.findById(user.getUserId()) != null)
                    || (user.getUserType().equals(UserType.MT.getCode()) && sysUserMediaService.findById(user.getUserId()) != null)
                    || (user.getUserType().equals(UserType.ZYGZ.getCode()) && sysUserAudienceService.findById(user.getUserId()) != null)
                    || (user.getUserType().equals(UserType.CZS.getCode()) && sysUserExhibitorService.findById(user.getUserId()) != null)){
                return AjaxResult.error("用户已经提交认证，无法再认证为其他角色");
            }
            user.setUserType(userTypeDTO.getUserType());
            user.setUpdateTime(new Date());
            user.setUpdateBy(user.getUserName());
            //观众身份默认审批通过
            if(userTypeDTO.getUserType().equals(UserType.GZ.getCode())){
                user.setReviewStatus("1");
            }else{
                user.setReviewStatus("0");
            }
            //展商需要更新角色权限
            if(userTypeDTO.getUserType().equals(UserType.CZS.getCode())){
                SysRole sysRole = roleService.selectRoleByRoleKey("exhibitor");
                if(sysRole != null){
                    user.setRoleIds(new Long[]{sysRole.getRoleId()});
                }else{
                    return AjaxResult.error("获取展商角色失败");
                }
            }else{
                user.setRoleIds(null);
            }
            return toAjax(userService.updateUser(user));
        }else{
            return AjaxResult.error("未登录或登录失效，请重新登录");
        }
    }

}
