package com.yuejike.web.controller.v3d;

import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.common.utils.sms.LuoSiMaoSmsUtils;
import com.yuejike.system.service.ISysUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.v3d.dto.BusinessmanQueryCriteria;
import com.yuejike.v3d.service.BusinessmanService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 展商相关
 * @author sha
 *
 */
@RestController
@RequestMapping("/v3d/businessman")
@Api(tags = "3D展商相关")
public class BusinessmanController {
	
	@Autowired
	private BusinessmanService businessmanService;
	
	@Autowired
    private TokenService tokenService;

    @Autowired
    private ISysUserService sysUserService;
	
	
	
    @ApiOperation("条件分页查询展商")
    @GetMapping
//    @PreAuthorize("@ss.hasPermi('businessman:list')")
    public ResponseEntity<Object> findAll(BusinessmanQueryCriteria criteria, Pageable pageable){
        return new ResponseEntity<>(businessmanService.queryAll(criteria, pageable),HttpStatus.OK);
    }
    
   
    @ApiOperation("当前展商详情")
    @GetMapping("/getUser")
//    @PreAuthorize("@ss.hasPermi('businessman:findbyId')")
    public ResponseEntity<Object> getUser(){
    	Long userId = getUserId();
        return new ResponseEntity<>(businessmanService.findById(userId),HttpStatus.OK);
    }
    
    @ApiOperation("指定展商详情")
    @GetMapping("/findByUserId")
//    @PreAuthorize("@ss.hasPermi('businessman:findbyId')")
    public ResponseEntity<Object> getArchives(@RequestParam Long uid){
        return new ResponseEntity<>(businessmanService.findById(uid),HttpStatus.OK);
    }

    
    @ApiOperation("审核展商")
    @PostMapping("/examine")
//    @PreAuthorize("@ss.hasPermi('businessman:examineBusinessman')")
    public ResponseEntity<Object> getArchives(@RequestParam Long uid, String status){
        if(status.equals("审核通过") || status.equals("驳回")){
            SysUser user = sysUserService.selectUserById(uid);
            if(user != null && StringUtils.isNotEmpty(user.getPhonenumber())){
                LuoSiMaoSmsUtils.getInstance().sendApprovedExhibitionHallMsg(user.getPhonenumber(), status.equals("审核通过"));
            }
        }
        return new ResponseEntity<>(businessmanService.examineBusinessman(uid,status),HttpStatus.OK);
    }
    
    @ApiOperation("保存展商展台")
    @PostMapping("/saveExhibition")
//    @PreAuthorize("@ss.hasPermi('businessman:saveExhibition')")
    public Object saveExhibition(@RequestParam Long eid){
    	Long userId = getUserId();
        return businessmanService.saveExhibition(userId,eid);
    }
    
    @ApiOperation("保存接待员")
    @PostMapping("/saveReceptionist")
//    @PreAuthorize("@ss.hasPermi('businessman:saveReceptionist')")
    public Object saveReceptionist(@RequestParam Integer receptionist){
    	Long userId = getUserId();
        return businessmanService.saveReceptionist(userId, receptionist);
    }
    
    @ApiOperation("保存logo")
    @PostMapping("/saveLogo")
//    @PreAuthorize("@ss.hasPermi('businessman:saveLogo')")
    public Object saveLogo(@RequestParam String logoPath){
    	Long userId = getUserId();
        return businessmanService.saveLogo(userId, logoPath);
    }
    
    @ApiOperation("保存海报")
    @PostMapping("/savePosters")
//    @PreAuthorize("@ss.hasPermi('businessman:savePosters')")
    public Object savePosters(@RequestParam String posters, @RequestParam(required = false) String bgmUrl,
                              @RequestParam(required = false) String welcomeUrl,
                              @RequestParam(required = false) String introductionUrl){
    	Long userId = getUserId();
        return businessmanService.savePosters(userId, posters, bgmUrl, welcomeUrl, introductionUrl);
    }
    
    @ApiOperation("保存视频")
    @PostMapping("/saveVideo")
//    @PreAuthorize("@ss.hasPermi('businessman:saveVideo')")
    public Object saveExhibition(@RequestParam String videoPath){
    	Long userId = getUserId();
        return businessmanService.saveVideo(userId, videoPath);
    }
    
    
    private Long getUserId() {
    	LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        SysUser user = loginUser.getUser();
    	return user.getUserId();
    }

    @ApiOperation("展台客服配置")
    @PreAuthorize("@ss.hasPermi('cms:3D:customerService')")
    @Log(title = "展台客服配置", businessType = BusinessType.UPDATE)
    @PostMapping("/saveKefu")
    public AjaxResult saveKefu(@RequestParam(required = true) String gender, @RequestParam(required = true) String logoUrl){
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser == null || loginUser.getUser() == null){
            return AjaxResult.error("未登录，无权操作");
        }
        businessmanService.saveKefu(loginUser.getUser().getUserId(), gender, logoUrl);
        return AjaxResult.success();
    }
	
}
