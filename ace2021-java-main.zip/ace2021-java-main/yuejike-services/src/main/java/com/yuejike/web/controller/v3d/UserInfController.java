package com.yuejike.web.controller.v3d;

import com.alibaba.fastjson.JSONObject;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.page.TableDataInfo;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.common.utils.http.HttpUtils;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.v3d.domain.UserInf;
import com.yuejike.v3d.service.V3dUserInfService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.Base64;

/**
 * @author ：JinZj
 * @date ：Created in 2022/1/7 11:05 上午
 * @description：3D用户信息含形象昵称
 * @modified By：
 */
@RestController
@RequestMapping("/v3d/userInf")
@Api(tags = "3D用户信息含形象昵称")
public class UserInfController extends BaseController {

    @Autowired
    private V3dUserInfService v3dUserInfService;
    @Autowired
    private TokenService tokenService;

    @ApiOperation("随机获取10个3D用户信息")
    @GetMapping(value = "/list")
    public TableDataInfo<UserInf> List() {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        Long curUserId = null;
        if(loginUser != null && loginUser.getUser() != null){
            curUserId = loginUser.getUser().getUserId();
        }
        return getDataTable(v3dUserInfService.List(curUserId));
    }

    @ApiOperation("获取3D用户信息")
    @GetMapping(value = "/{userId}")
    public AjaxResult<UserInf> getInfo(@PathVariable("userId") Long userId) {
        return AjaxResult.success(v3dUserInfService.findById(userId));
    }

    @ApiOperation("新增/编辑3D用户信息")
    @Log(title = "3D用户信息", businessType = BusinessType.UPDATE)
    @PostMapping
    public AjaxResult edit(@RequestBody UserInf userInf){
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser == null || loginUser.getUser() == null){
            return AjaxResult.error("未登录，无权操作");
        }
        userInf.setUserId(loginUser.getUser().getUserId());
        if(StringUtils.isNotEmpty(userInf.getPhotoBase64())){
            Base64.Decoder decoder = Base64.getDecoder();
            String imageBase64Str;
            String fileName;
            if (userInf.getPhotoBase64().indexOf("data:image/jpeg;") != -1){
                imageBase64Str = userInf.getPhotoBase64().replace("data:image/jpeg;base64,", "");
                fileName = "jpeg";
            }else if (userInf.getPhotoBase64().indexOf("data:image/png;") != -1){
                imageBase64Str = userInf.getPhotoBase64().replace("data:image/png;base64,", "");
                fileName = "png";
            }else{
                imageBase64Str = userInf.getPhotoBase64();
                fileName = "png";
            }
            try {
                byte[] bytes1 = decoder.decode(imageBase64Str);
                ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes1);
                BufferedImage bufferedImage = ImageIO.read(byteArrayInputStream);
                File f1 = File.createTempFile(StringUtils.getGUID(), "."+fileName);
                ImageIO.write(bufferedImage, fileName, f1);
                String fileRSP = HttpUtils.sendFile("https://pro-obs.zgkbh.cn", f1);
                JSONObject jsonObject = JSONObject.parseObject(fileRSP);
                JSONObject dataObject = JSONObject.parseObject(jsonObject.getString("data"));
                String fileUrl = dataObject.getString("fileName");
                System.out.println(fileUrl);
                userInf.setPhotoUrl(fileUrl);
            } catch (IOException e) {
                e.printStackTrace();
                return AjaxResult.error("base64图片有误");
            }
        }
        v3dUserInfService.modify(userInf);
        return AjaxResult.success();
    }

}
