package com.yuejike.web.controller.cms;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsExposition;
import com.yuejike.cms.service.ICmsExpositionService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 博览会Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/exposition")
@Api(tags = "博览会",description = "博览会")
public class CmsExpositionController extends BaseController {
    @Autowired
    private ICmsExpositionService cmsExpositionService;
    @Autowired
    private TokenService tokenService;

    /**
     * 查询博览会列表
     */
    @ApiOperation("查询博览会列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:exposition:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsExposition> list(CmsExposition cmsExposition) {
        Page<CmsExposition> page = cmsExpositionService.findCmsExpositionPage(cmsExposition);
        return getDataTable(page);
    }

    /**
     * 导出博览会列表
     */
    @ApiOperation("导出博览会列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:exposition:export')")
    @Log(title = "博览会", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsExposition cmsExposition) {
        List<CmsExposition> list = cmsExpositionService.findCmsExpositionList(cmsExposition);
        ExcelUtil<CmsExposition> util = new ExcelUtil<>(CmsExposition.class);
        return util.exportExcel(list, "exposition");
    }

    /**
     * 获取博览会详细信息
     */
    @ApiOperation("获取博览会详细信息接口")
    @PreAuthorize("@ss.hasPermi('cms:exposition:query')")
    @GetMapping(value = "/{expositionId}")
    public AjaxResult<CmsExposition> getInfo(@PathVariable("expositionId") Long expositionId) {
        return AjaxResult.success(cmsExpositionService.findById(expositionId));
    }

    /**
     * 新增博览会
     */
    @ApiOperation("新增博览会接口")
    @PreAuthorize("@ss.hasPermi('cms:exposition:add')")
    @Log(title = "博览会", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsExposition cmsExposition) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsExposition.setCreateBy(loginUser.getUsername());
        cmsExposition.setCreateTime(new Date());
        cmsExposition.setDelFlag("0");
        cmsExpositionService.save(cmsExposition);
        return AjaxResult.success();
    }

    /**
     * 修改博览会
     */
    @ApiOperation("修改博览会接口")
    @PreAuthorize("@ss.hasPermi('cms:exposition:edit')")
    @Log(title = "博览会", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsExposition cmsExposition) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsExposition.setUpdateBy(loginUser.getUsername());
        cmsExposition.setUpdateTime(new Date());
        cmsExpositionService.save(cmsExposition);
        return AjaxResult.success();
    }

    /**
     * 删除博览会
     */
    @ApiOperation("删除博览会接口")
    @PreAuthorize("@ss.hasPermi('cms:exposition:remove')")
    @Log(title = "博览会", businessType = BusinessType.DELETE)
	@DeleteMapping("/{expositionIds}")
    public AjaxResult remove(@PathVariable Long[] expositionIds) {
        cmsExpositionService.deleteByIds(Arrays.asList(expositionIds));
        return AjaxResult.success();
    }
}
