package com.yuejike.web.util;

import com.yuejike.cms.domain.CmsIndustry;
import com.yuejike.framework.web.domain.server.Sys;
import com.yuejike.web.vo.CmsIndustryTreeVo;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class IndustryTreeBuilerUtil {

    /**
     * 结果树
     */
    private List<CmsIndustryTreeVo> tree;

    /**
     * 原始数据
     */
    private List<CmsIndustry> industries;

    public IndustryTreeBuilerUtil(List<CmsIndustry> cmsIndustries) {
        this.industries = cmsIndustries;
        this.tree = buildNext(null, 0);
    }

    private List<CmsIndustryTreeVo> buildNext(String parentId, Integer level){

        // 强制返回到三级
        if(level > 2){
            return null;
        }

        List<CmsIndustryTreeVo> trees = new ArrayList<>();
        for (CmsIndustry cmsIndustry : this.industries) {
            // 级别筛选，默认到第三级
            if(level.equals(cmsIndustry.getLevelType())){
                // 父级筛选
                if(
                        (parentId == null && cmsIndustry.getParentId() == null) ||
                        (parentId != null && parentId.equals(cmsIndustry.getParentId()))
                ){
                    // 添加数组
                    CmsIndustryTreeVo cmsIndustryTreeVo = new CmsIndustryTreeVo();
                    cmsIndustryTreeVo.setValue(cmsIndustry.getIndustryId());
                    cmsIndustryTreeVo.setLabel(cmsIndustry.getName());
                    List<CmsIndustryTreeVo> children = buildNext(
                            cmsIndustry.getIndustryId(),
                            level+1
                    );
                    cmsIndustryTreeVo.setChildren(children);
                    trees.add(cmsIndustryTreeVo);
                }
            }
        }
        return trees;
    }
}
