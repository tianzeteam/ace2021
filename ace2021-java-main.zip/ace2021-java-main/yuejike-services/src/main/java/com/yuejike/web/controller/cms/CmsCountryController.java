package com.yuejike.web.controller.cms;

import com.yuejike.common.core.domain.MapResult;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsCountry;
import com.yuejike.cms.service.ICmsCountryService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 国家字典Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-26
 */
@RestController
@RequestMapping("/cms/country")
@Api(tags = "A-B-A-国家字典接口",description = "国家字典接口")
public class CmsCountryController extends BaseController {
    @Autowired
    private ICmsCountryService cmsCountryService;
    @Autowired
    private TokenService tokenService;

    /**
     * 查询国家字典列表
     */
//     @ApiOperation("查询国家字典列表接口")
// //    @PreAuthorize("@ss.hasPermi('cms:country:list')")
//     @GetMapping("/list")
//     public TableDataInfo<CmsCountry> list(CmsCountry cmsCountry) {
//         Page<CmsCountry> page = cmsCountryService.findCmsCountryPage(cmsCountry);
//         return getDataTable(page);
//     }

    @ApiOperation("查询国家字典列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:country:list')")
    @GetMapping("/list")
    public MapResult list(CmsCountry cmsCountry) {
        List<CmsCountry> list = cmsCountryService.findCmsCountryList(cmsCountry);
        return MapResult.success("查询成功",list);
    }

    /**
     * 导出国家字典列表
     */
    @ApiOperation("导出国家字典列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:country:export')")
    @Log(title = "国家字典", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsCountry cmsCountry) {
        List<CmsCountry> list = cmsCountryService.findCmsCountryList(cmsCountry);
        ExcelUtil<CmsCountry> util = new ExcelUtil<>(CmsCountry.class);
        return util.exportExcel(list, "country");
    }

    /**
     * 获取国家字典详细信息
     */
    @ApiOperation("获取国家字典详细信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:country:query')")
    @GetMapping(value = "/{countryId}")
    public AjaxResult<CmsCountry> getInfo(@PathVariable("countryId") Long countryId) {
        return AjaxResult.success(cmsCountryService.findById(countryId));
    }

    /**
     * 新增国家字典
     */
    @ApiOperation("新增国家字典接口")
    @PreAuthorize("@ss.hasPermi('cms:country:add')")
    @Log(title = "国家字典", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsCountry cmsCountry) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsCountry.setCreateBy(loginUser.getUsername());
        cmsCountry.setCreateTime(new Date());
        cmsCountry.setDelFlag("0");
        cmsCountryService.save(cmsCountry);
        return AjaxResult.success();
    }

    /**
     * 修改国家字典
     */
    @ApiOperation("修改国家字典接口")
    @PreAuthorize("@ss.hasPermi('cms:country:edit')")
    @Log(title = "国家字典", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsCountry cmsCountry) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsCountry.setUpdateBy(loginUser.getUsername());
        cmsCountry.setUpdateTime(new Date());
        cmsCountryService.save(cmsCountry);
        return AjaxResult.success();
    }

    /**
     * 删除国家字典
     */
    @ApiOperation("删除国家字典接口")
    @PreAuthorize("@ss.hasPermi('cms:country:remove')")
    @Log(title = "国家字典", businessType = BusinessType.DELETE)
	@DeleteMapping("/{countryIds}")
    public AjaxResult remove(@PathVariable Long[] countryIds) {
        cmsCountryService.deleteByIds(Arrays.asList(countryIds));
        return AjaxResult.success();
    }
}
