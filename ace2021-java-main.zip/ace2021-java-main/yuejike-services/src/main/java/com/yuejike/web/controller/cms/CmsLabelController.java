package com.yuejike.web.controller.cms;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsLabel;
import com.yuejike.cms.service.ICmsLabelService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 标签Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/label")
@Api(tags = "标签",description = "标签")
public class CmsLabelController extends BaseController {
    @Autowired
    private ICmsLabelService cmsLabelService;
    @Autowired
    private TokenService tokenService;

    /**
     * 查询标签列表
     */
    @ApiOperation("查询标签列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:label:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsLabel> list(CmsLabel cmsLabel) {
        Page<CmsLabel> page = cmsLabelService.findCmsLabelPage(cmsLabel);
        return getDataTable(page);
    }

    /**
     * 导出标签列表
     */
    @ApiOperation("导出标签列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:label:export')")
    @Log(title = "标签", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsLabel cmsLabel) {
        List<CmsLabel> list = cmsLabelService.findCmsLabelList(cmsLabel);
        ExcelUtil<CmsLabel> util = new ExcelUtil<>(CmsLabel.class);
        return util.exportExcel(list, "label");
    }

    /**
     * 获取标签详细信息
     */
    @ApiOperation("获取标签详细信息接口")
    @PreAuthorize("@ss.hasPermi('cms:label:query')")
    @GetMapping(value = "/{labelId}")
    public AjaxResult<CmsLabel> getInfo(@PathVariable("labelId") Long labelId) {
        return AjaxResult.success(cmsLabelService.findById(labelId));
    }

    /**
     * 新增标签
     */
    @ApiOperation("新增标签接口")
    @PreAuthorize("@ss.hasPermi('cms:label:add')")
    @Log(title = "标签", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsLabel cmsLabel) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsLabel.setExpositionId(loginUser.getUser().getExpositionId());
        cmsLabel.setUserId(loginUser.getUser().getUserId());
        cmsLabel.setCreateBy(loginUser.getUsername());
        cmsLabel.setCreateTime(new Date());
        cmsLabel.setDelFlag("0");
        cmsLabelService.save(cmsLabel);
        return AjaxResult.success();
    }

    /**
     * 修改标签
     */
    @ApiOperation("修改标签接口")
    @PreAuthorize("@ss.hasPermi('cms:label:edit')")
    @Log(title = "标签", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsLabel cmsLabel) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsLabel.setUpdateBy(loginUser.getUsername());
        cmsLabel.setUpdateTime(new Date());
        cmsLabelService.save(cmsLabel);
        return AjaxResult.success();
    }

    /**
     * 删除标签
     */
    @ApiOperation("删除标签接口")
    @PreAuthorize("@ss.hasPermi('cms:label:remove')")
    @Log(title = "标签", businessType = BusinessType.DELETE)
	@DeleteMapping("/{labelIds}")
    public AjaxResult remove(@PathVariable Long[] labelIds) {
        for(Long labelId:labelIds){
            if(labelId<=100) {
                return AjaxResult.error("内置标签不允许删除");
            }
        }
        cmsLabelService.deleteByIds(Arrays.asList(labelIds));
        return AjaxResult.success();
    }
}
