package com.yuejike.web.controller.cms;

import com.yuejike.cms.domain.SysUserMedia;
import com.yuejike.cms.dto.SysUserMediaDTO;
import com.yuejike.cms.service.ISysUserAudienceService;
import com.yuejike.cms.service.ISysUserDelegateService;
import com.yuejike.cms.service.ISysUserExhibitorService;
import com.yuejike.cms.service.ISysUserMediaService;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.entity.SysDictData;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.page.TableDataInfo;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.system.service.ISysDictDataService;
import com.yuejike.system.service.ISysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * 媒体Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-27
 */
@RestController
@RequestMapping("/cms/media")
@Api(tags = "B-媒体信息接口",description = "媒体信息接口")
public class SysUserMediaController extends BaseController {
    @Autowired
    private ISysUserMediaService sysUserMediaService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private ISysUserService sysUserService;
    @Autowired
    private ISysDictDataService dictDataService;
    @Autowired
    private ISysUserExhibitorService sysUserExhibitorService;
    @Autowired
    private ISysUserDelegateService sysUserDelegateService;
    @Autowired
    private ISysUserAudienceService sysUserAudienceService;

    /**
     * 查询媒体列表
     */
    @ApiOperation("查询媒体列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:media:list')")
    @GetMapping("/list")
    public TableDataInfo<SysUserMedia> list(SysUserMedia sysUserMedia) {
        Page<SysUserMedia> page = sysUserMediaService.findSysUserMediaPage(sysUserMedia);
        return getDataTable(page);
    }

    /**
     * 导出媒体列表
     */
    @ApiOperation("导出媒体列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:media:export')")
    @Log(title = "媒体", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(SysUserMedia sysUserMedia) {
        List<SysUserMedia> list = sysUserMediaService.findSysUserMediaList(sysUserMedia);
        list.forEach(item->{
            item.setUserName(item.getUser().getUserName());
            item.setUserCountryName(item.getUserCountry().getCountryName());
            item.setCompanyCountryName(item.getCompanyCountry().getCountryName());
            item.setReviewStatus(formatterReviewStatus(item.getUser().getReviewStatus()));
            String sex = item.getSex().equals("0")?"男":"女";
            item.setSex(sex);
            item.setCredentialsType(formatterCredentialsType(item.getCredentialsType()));
            item.setReporterType(formatterReportType(item.getReporterType()));
        });
        ExcelUtil<SysUserMedia> util = new ExcelUtil<>(SysUserMedia.class);
        return util.exportExcel(list, "media");
    }
    //格式化审核状态
    private String formatterReviewStatus(String reviewStatus){
        switch (reviewStatus){
            case "1":
                return "审核通过";
            case "2":
                return "审核拒绝";
            default:
                return  "待审核";
        }
    }
    //格式化证件类型
    private String formatterCredentialsType(String credentialsType){
        String credentialsName="";
        //查询字典表数据
        List<SysDictData> dictData = dictDataService.findByDictType("sys_card_type");
        for (SysDictData data:dictData) {
            if(credentialsType.equals(data.getDictValue())){
                credentialsName = data.getDictLabel();
                break;
            }
        }
        return credentialsName;
    }
    //格式化记者类型
    private String formatterReportType(String reportType){
        String reportTypeName="";
        //查询字典表数据
        List<SysDictData> dictData = dictDataService.findByDictType("sys_reporter_type");
        for (SysDictData data:dictData) {
            if(reportType.equals(data.getDictValue())){
                reportTypeName = data.getDictLabel();
                break;
            }
        }
        return reportTypeName;
    }


    /**
     * 获取媒体详细信息
     */
    @ApiOperation("获取媒体详细信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:media:query')")
    @GetMapping(value = "/{userId}")
    public AjaxResult<SysUserMedia> getInfo(@PathVariable("userId") Long userId) {
        return AjaxResult.success(sysUserMediaService.findById(userId));
    }

    /**
     * 新增媒体
     */
    @ApiOperation("新增媒体接口")
//    @PreAuthorize("@ss.hasPermi('cms:media:add')")
    @Log(title = "媒体", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SysUserMediaDTO sysUserMediaDTO) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser != null && loginUser.getUser() != null) {
            if(!loginUser.getUser().getUserId().equals(sysUserMediaDTO.getUserId())){
                return AjaxResult.error("无权操作，只有用户本人可提交认证");
            }
            SysUser user = sysUserService.selectUserById(sysUserMediaDTO.getUserId());
            if (user == null) {
                return AjaxResult.error("未知错误，未找到数据库记录");
            }
            //角色转化
            if(!user.getUserType().equals(UserType.MT.getCode())){
                String[] arrUserType = {"02","03","04","05","06"};//可转化角色列表
                Set<String> userTypes = new HashSet<>(Arrays.asList(arrUserType));
                if(!userTypes.contains(user.getUserType())){
                    return AjaxResult.error("此用户类型不支持转化");
                }
                if((user.getUserType().equals(UserType.CZS.getCode()) && sysUserExhibitorService.findById(user.getUserId()) != null)
                        || (user.getUserType().equals(UserType.HYDB.getCode()) && sysUserDelegateService.findById(user.getUserId()) != null)
                        || (user.getUserType().equals(UserType.ZYGZ.getCode()) && sysUserAudienceService.findById(user.getUserId()) != null)){
                    return AjaxResult.error("用户已经提交认证，无法再认证为其他角色");
                }
                user.setUserType(UserType.MT.getCode());
                user.setUpdateTime(new Date());
                user.setUpdateBy(loginUser.getUsername());
                user.setReviewStatus("0");
                user.setRoleIds(null);
                sysUserService.updateUser(user);
            }
            //提交认证
            SysUserMedia sysUserMedia = new SysUserMedia();
            BeanUtils.copyProperties(sysUserMediaDTO,sysUserMedia);
            sysUserMedia.setCreateBy(loginUser.getUsername());
            sysUserMedia.setCreateTime(new Date());
            sysUserMedia.setDelFlag("0");
            sysUserMediaService.save(sysUserMedia);
            return AjaxResult.success();
        }else{
            return AjaxResult.error("未登录或登录失效，请重新登录");
        }
    }

    /**
     * 修改媒体
     */
    @ApiOperation("修改媒体接口")
//    @PreAuthorize("@ss.hasPermi('cms:media:edit')")
    @Log(title = "媒体", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SysUserMediaDTO sysUserMediaDTO) {
        try{
            SysUserMedia sysUserMedia = new SysUserMedia();
            BeanUtils.copyProperties(sysUserMediaDTO,sysUserMedia);
            LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
            if(StringUtils.isNotBlank(sysUserMediaDTO.getReviewStatus()) && sysUserMediaDTO.getReviewStatus().equals("2")){
                //用户被拒绝后再次提交审核时,将审核状态修改待审核
                sysUserService.updateReviewStatus(sysUserMediaDTO.getUserId());
                SysUserMedia userMedia = sysUserMediaService.findById(sysUserMediaDTO.getUserId());
                userMedia.setUserCountryId(sysUserMediaDTO.getUserCountryId());
                userMedia.setCredentialsType(sysUserMediaDTO.getCredentialsType());
                userMedia.setCredentialsNumber(sysUserMediaDTO.getCredentialsNumber());
                userMedia.setIdCardPicture(sysUserMediaDTO.getIdCardPicture());
                userMedia.setCompanyCountryId(sysUserMediaDTO.getCompanyCountryId());
                userMedia.setCompanyName(sysUserMediaDTO.getCompanyName());
                userMedia.setChineseSurname(sysUserMediaDTO.getChineseSurname());
                userMedia.setChineseName(sysUserMediaDTO.getChineseName());
                userMedia.setEnglishSurname(sysUserMediaDTO.getEnglishSurname());
                userMedia.setEnglishName(sysUserMediaDTO.getEnglishName());
                userMedia.setEnglishCenterName(sysUserMediaDTO.getEnglishCenterName());
                userMedia.setPinyinSurname(sysUserMediaDTO.getPinyinSurname());
                userMedia.setPinyinName(sysUserMediaDTO.getPinyinName());
                userMedia.setSex(sysUserMediaDTO.getSex());
                userMedia.setBorth(sysUserMediaDTO.getBorth());
                userMedia.setReporterType(sysUserMediaDTO.getReporterType());
                userMedia.setPhoneNumber(sysUserMediaDTO.getPhoneNumber());
                userMedia.setEmail(sysUserMediaDTO.getEmail());
                userMedia.setCompanyLicensePicture(sysUserMediaDTO.getCompanyLicensePicture());
                userMedia.setPressCardPicture(sysUserMediaDTO.getPressCardPicture());
                userMedia.setUpdateBy(loginUser.getUsername());
                userMedia.setUpdateTime(new Date());
                sysUserMediaService.save(userMedia);
            }else{
                sysUserMedia.setUpdateBy(loginUser.getUsername());
                sysUserMedia.setUpdateTime(new Date());
                sysUserMediaService.save(sysUserMedia);
            }
            return AjaxResult.success();
        }catch (Exception ex) {
            ex.printStackTrace();
            logger.error(ex.getMessage());
            return AjaxResult.error(ex.getMessage());
        }
    }

    /**
     * 删除媒体
     */
    @ApiOperation("删除媒体接口")
    @PreAuthorize("@ss.hasPermi('cms:media:remove')")
    @Log(title = "媒体", businessType = BusinessType.DELETE)
	@DeleteMapping("/{userIds}")
    public AjaxResult remove(@PathVariable Long[] userIds) {
        sysUserMediaService.deleteByIds(Arrays.asList(userIds));
        return AjaxResult.success();
    }
}
