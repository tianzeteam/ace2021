package com.yuejike.web.controller.cms;

import com.yuejike.cms.domain.FullText;
import com.yuejike.cms.domain.SysUserGroupRelation;
import com.yuejike.cms.service.IFullTextService;
import com.yuejike.cms.service.ISysUserGroupRelationService;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.page.TableDataInfo;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.framework.web.service.TokenService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author ：JinZj
 * @date ：Created in 2022/1/4 4:46 下午
 * @description：全站搜索
 * @modified By：
 */
@RestController
@RequestMapping("/fullText")
@Api(tags = "全文搜索", description = "全文搜索")
public class FullTextController extends BaseController {

    @Autowired
    private IFullTextService fullTextService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private ISysUserGroupRelationService userGroupRelationService;

    @ApiOperation("全文搜索")
    @GetMapping("search")
    public TableDataInfo<FullText> search(@ApiParam(name = "keyWord", value = "搜索关键词", required = true) @RequestParam String keyWord) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        String empower = "00";
        String groupId = null;
        if(loginUser != null){
            empower = empower + "," + loginUser.getUser().getUserType();
            //查询登录人是否在分组中
            SysUserGroupRelation userGroupRelation =userGroupRelationService.findByUserIdAndGroupId(loginUser.getUser().getUserId());
            if(null != userGroupRelation){
                groupId = userGroupRelation.getGroupId().toString();
            }
        }
        return getDataTable(fullTextService.search(keyWord, empower, groupId));
    }

}
