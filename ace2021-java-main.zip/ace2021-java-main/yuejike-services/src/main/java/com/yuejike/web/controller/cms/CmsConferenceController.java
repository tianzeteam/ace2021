package com.yuejike.web.controller.cms;

import com.yuejike.cms.domain.SysUserExhibitor;
import com.yuejike.cms.service.ICmsEnrollService;
import com.yuejike.cms.service.ISysUserExhibitorService;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.enums.ConferenceStatus;
import com.yuejike.common.enums.ConferenceType;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.sms.LuoSiMaoSmsUtils;
import com.yuejike.system.service.ISysUserService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsConference;
import com.yuejike.cms.service.ICmsConferenceService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 线下会议Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/conference")
@Api(tags = "线下会议",description = "线下会议")
public class CmsConferenceController extends BaseController {
    @Autowired
    private ICmsConferenceService cmsConferenceService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private ISysUserExhibitorService sysUserExhibitorService;
    @Autowired
    private ICmsEnrollService cmsEnrollService;
    @Autowired
    private ISysUserService sysUserService;

    /**
     * 查询线下会议列表
     */
    @ApiOperation("查询线下会议列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:conference:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsConference> list(CmsConference cmsConference) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser.getUser() != null) {
            if (loginUser.getUser().getUserType().equals(UserType.CZS.getCode()) || loginUser.getUser().getUserType().equals(UserType.CZS_JS.getCode())) {
                cmsConference.setCreateId(loginUser.getUser().getUserId());
            }
            cmsConference.setDelFlag("0");
            Page<CmsConference> page = cmsConferenceService.findCmsConferencePage(cmsConference);
            return getDataTable(page);
        }else{
            TableDataInfo rspData = new TableDataInfo();
            rspData.setCode(500);
            rspData.setMsg("查询失败");
            rspData.setRows(null);
            rspData.setTotal(0);
            return rspData;
        }
    }

    /**
     * pc端查询会议列表
     * @param cmsConference
     * @return
     */
    @ApiOperation("查询pc端查询会议列表接口")
    @GetMapping("/ui/list")
    public TableDataInfo<CmsConference> conferenceList(CmsConference cmsConference) {
        cmsConference.setDelFlag("0");
        Page<CmsConference> page = cmsConferenceService.findCmsConferencePage(cmsConference);
        return getDataTable(page);
    }
    /**
     * 导出线下会议列表
     */
    @ApiOperation("导出线下会议列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:conference:export')")
    @Log(title = "线下会议", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsConference cmsConference) {
        List<CmsConference> list = cmsConferenceService.findCmsConferenceList(cmsConference);
        ExcelUtil<CmsConference> util = new ExcelUtil<>(CmsConference.class);
        return util.exportExcel(list, "conference");
    }

    /**
     * 获取线下会议详细信息
     */
    @ApiOperation("获取线下会议详细信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:conference:query')")
    @GetMapping(value = "/{conferenceId}")
    public AjaxResult<CmsConference> getInfo(@PathVariable("conferenceId") Long conferenceId) {
        return AjaxResult.success(cmsConferenceService.findById(conferenceId));
    }

    /**
     * 新增线下会议
     */
    @ApiOperation("新增线下会议接口")
//    @PreAuthorize("@ss.hasPermi('cms:conference:add')")
    @Log(title = "线下会议", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsConference cmsConference) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsConference.setCreateBy(loginUser.getUsername());
        cmsConference.setCreateId(loginUser.getUser().getUserId());
        cmsConference.setCreateTime(new Date());
        cmsConference.setStatus(ConferenceStatus.NORMAL.getCode());
        cmsConference.setDelFlag("0");
        if (loginUser.getUser().getUserType().equals(UserType.ZBF.getCode()) || loginUser.getUser().getUserType().equals(UserType.ZBF_JS.getCode())) {
            cmsConference.setType(ConferenceType.ZBF.getCode());
            cmsConference.setStatus(ConferenceStatus.PASSED.getCode());
            cmsConference.setExhibitorId(loginUser.getUser().getUserId());
            cmsConference.setExhibitorCnName(loginUser.getUser().getNickName());
            cmsConference.setExhibitorEnName(loginUser.getUser().getNickName());
        }else if (loginUser.getUser().getUserType().equals(UserType.CZS.getCode()) || loginUser.getUser().getUserType().equals(UserType.CZS_JS.getCode())){
            cmsConference.setType(ConferenceType.CZS.getCode());
            //添加参展商中英文名字
            Long userId = loginUser.getUser().getUserId();
            if (userId != null) {
                SysUserExhibitor exhibitor = sysUserExhibitorService.findById(userId);
                if (exhibitor != null) {
                    cmsConference.setExhibitorId(userId);
                    cmsConference.setExhibitorCnName(exhibitor.getName());
                    cmsConference.setExhibitorEnName(exhibitor.getEnName());
                    cmsConference.setDeptId(loginUser.getUser().getDeptId());
                }
            }
        }

       // cmsConference.setType();
        cmsConference.setExpositionId(loginUser.getUser().getExpositionId());
        cmsConferenceService.save(cmsConference);

        return AjaxResult.success();
    }

    /**
     * 修改线下会议
     */
    @ApiOperation("修改线下会议接口")
//    @PreAuthorize("@ss.hasPermi('cms:conference:edit')")
    @Log(title = "线下会议", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsConference cmsConference) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsConference.setUpdateBy(loginUser.getUsername());
        cmsConference.setCreateId(loginUser.getUser().getUserId());

        cmsConference.setUpdateTime(new Date());
        if (loginUser.getUser().getUserType().equals(UserType.ZBF.getCode()) || loginUser.getUser().getUserType().equals(UserType.ZBF_JS.getCode())) {
            cmsConference.setType(ConferenceType.ZBF.getCode());
            cmsConference.setStatus("1");
        }else if (loginUser.getUser().getUserType().equals(UserType.CZS.getCode()) || loginUser.getUser().getUserType().equals(UserType.CZS_JS.getCode())){
            cmsConference.setType(ConferenceType.CZS.getCode());
            cmsConference.setStatus("0");
        }

        // cmsConference.setType();
        cmsConference.setExpositionId(loginUser.getUser().getExpositionId());
        cmsConferenceService.save(cmsConference);
        return AjaxResult.success();
    }

    //审核

    @ApiOperation("审核线下会议接口")
//    @PreAuthorize("@ss.hasPermi('cms:conference:edit')")
    @Log(title = "审核线下会议", businessType = BusinessType.UPDATE)
    @PutMapping("/audit")
    public AjaxResult auditedit(@RequestBody CmsConference cmsConference) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        //审核人id
        cmsConference.setReviewerId(loginUser.getUser().getUserId());
        //博览会id
        cmsConference.setExpositionId(loginUser.getUser().getExpositionId());
        if (loginUser.getUser().getUserType().equals(UserType.ZBF.getCode()) || loginUser.getUser().getUserType().equals(UserType.ZBF_JS.getCode())) {
            cmsConference.setType(ConferenceType.ZBF.getCode());
        }else if (loginUser.getUser().getUserType().equals(UserType.CZS.getCode()) || loginUser.getUser().getUserType().equals(UserType.CZS_JS.getCode())){
            cmsConference.setType(ConferenceType.CZS.getCode());
        }
        cmsConference.setReviewerName(loginUser.getUser().getUserName());
        cmsConferenceService.save(cmsConference);
        if(cmsConference.getStatus().equals("1") || cmsConference.getStatus().equals("1")){
            SysUser user = sysUserService.selectUserById(cmsConference.getExhibitorId());
            if(user != null && StringUtils.isNotEmpty(user.getPhonenumber())){
                LuoSiMaoSmsUtils.getInstance().sendApprovedOfflineMeetingMsg(user.getPhonenumber(), cmsConference.getTitle(),
                        cmsConference.getStatus().equals("1"));
            }
        }
        return AjaxResult.success();
    }

    @ApiOperation("批量审核线下会议接口")
    @PreAuthorize("@ss.hasPermi('cms:conference:review')")
    @Log(title = "审核线下会议", businessType = BusinessType.UPDATE)
    @PutMapping("/batchAudit/{conferenceIds}")
    public AjaxResult batchAudit(@PathVariable Long[] conferenceIds, @RequestBody CmsConference cmsConference) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        //审核人id
        cmsConference.setReviewerId(loginUser.getUser().getUserId());
        //博览会id
        cmsConference.setExpositionId(loginUser.getUser().getExpositionId());
        cmsConference.setReviewerName(loginUser.getUser().getUserName());
        cmsConference.setUpdateBy(loginUser.getUsername());
        cmsConference.setUpdateTime(new Date());
        cmsConferenceService.batchAudit(conferenceIds, cmsConference);
        if(cmsConference.getStatus().equals("1") || cmsConference.getStatus().equals("2")){
            Arrays.stream(conferenceIds).forEach(id -> {
                CmsConference cmsConference1 = cmsConferenceService.findById(id);
                if(cmsConference1 != null) {
                    SysUser user = sysUserService.selectUserById(cmsConference1.getExhibitorId());
                    if(user != null && StringUtils.isNotEmpty(user.getPhonenumber())){
                        LuoSiMaoSmsUtils.getInstance().sendApprovedOfflineMeetingMsg(user.getPhonenumber(), cmsConference1.getTitle(),
                                cmsConference.getStatus().equals("1"));
                    }
                }
            });

        }

        return AjaxResult.success();
    }


    /**
     * 删除线下会议
     */
    @ApiOperation("删除线下会议接口")
    @PreAuthorize("@ss.hasPermi('cms:conference:remove')")
    @Log(title = "线下会议", businessType = BusinessType.DELETE)
	@DeleteMapping("/{conferenceIds}")
    public AjaxResult remove(@PathVariable Long[] conferenceIds) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        // cmsConferenceService.deleteByIds(Arrays.asList(conferenceIds));
        for (Long conferenceId:conferenceIds) {
            CmsConference conference = cmsConferenceService.findById(conferenceId);
            conference.setDelFlag("1");
            conference.setUpdateBy(loginUser.getUsername());
            conference.setUpdateTime(new Date());
            cmsConferenceService.save(conference);
            //将报名表中的这条会议也得进行删除
            cmsEnrollService.updateByConferenceId(conferenceId);
        }
        return AjaxResult.success();
    }
}
