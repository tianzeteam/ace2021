package com.yuejike.web.controller.cms;

import com.yuejike.cms.domain.CmsUserCard;
import com.yuejike.cms.domain.CmsUserCardExchange;
import com.yuejike.cms.service.ICmsUserCardExchangeService;
import com.yuejike.cms.service.ICmsUserCardService;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.page.TableDataInfo;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.system.service.ISysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

/**
 * 名片关联Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/exchange")
@Api(tags = "C-名片关联",description = "名片关联")
public class CmsUserCardExchangeController extends BaseController {
    @Autowired
    private ICmsUserCardExchangeService cmsUserCardExchangeService;
    @Autowired
    private ICmsUserCardService cmsUserCardService;

    @Autowired
    private TokenService tokenService;

    @Autowired
    private ISysUserService userService;

    /**
     * 查询名片关联列表
     */
    @ApiOperation("查询名片关联列表接口-前端")
    @PreAuthorize("@ss.hasPermi('cms:exchange:list')")
    @GetMapping("/ui/list")
    public TableDataInfo<CmsUserCardExchange> listCust(CmsUserCardExchange cmsUserCardExchange) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser.getUser() != null) {
                 cmsUserCardExchange.setSendId(loginUser.getUser().getUserId());

                if (loginUser.getUser().getUserType().equals(UserType.CZS.getCode()) || loginUser.getUser().getUserType().equals(UserType.CZS_JS.getCode())) {
                    cmsUserCardExchange.setSendDelFlag("1");
                }else {
                   cmsUserCardExchange.setAcceptDelFlag("1");
                }




            Page<CmsUserCardExchange> page = cmsUserCardExchangeService.findCmsUserCardExchangePage(cmsUserCardExchange);
            return getDataTable(page);
        }else{
            TableDataInfo rspData = new TableDataInfo();
            rspData.setCode(500);
            rspData.setMsg("查询失败");
            rspData.setRows(null);
            rspData.setTotal(0);
            return rspData;
        }
    }

    /**
     * 查询名片关联列表
     */
    @ApiOperation("查询名片关联列表接口")
    @PreAuthorize("@ss.hasPermi('cms:exchange:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsUserCardExchange> list(CmsUserCardExchange cmsUserCardExchange) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser.getUser() != null) {
            if (loginUser.getUser().getUserType().equals(UserType.CZS.getCode()) || loginUser.getUser().getUserType().equals(UserType.CZS_JS.getCode())) {
                cmsUserCardExchange.setAcceptId(loginUser.getUser().getUserId());
                cmsUserCardExchange.setSendDelFlag("1");
                if(loginUser.getUser().getDeptId() == null || loginUser.getUser().getDeptId().equals(0)){
                    TableDataInfo rspData = new TableDataInfo();
                    rspData.setCode(0);
                    rspData.setMsg("请认证后查询");
                    rspData.setRows(null);
                    rspData.setTotal(0);
                    return rspData;
                }

            }else if(loginUser.getUser().getUserType().equals(UserType.GZ.getCode()) || loginUser.getUser().getUserType().equals(UserType.ZYGZ.getCode()) ||
                    loginUser.getUser().getUserType().equals(UserType.MT.getCode()) || loginUser.getUser().getUserType().equals(UserType.HYDB.getCode())){
                cmsUserCardExchange.setSendId(loginUser.getUser().getUserId());

                cmsUserCardExchange.setAcceptDelFlag("1");
            }
            Page<CmsUserCardExchange> page = cmsUserCardExchangeService.findCmsUserCardExchangePage(cmsUserCardExchange);
            return getDataTable(page);
        }else{
            TableDataInfo rspData = new TableDataInfo();
            rspData.setCode(500);
            rspData.setMsg("查询失败");
            rspData.setRows(null);
            rspData.setTotal(0);
            return rspData;
        }
    }

    /**
     * 导出名片关联列表
     */
    @ApiOperation("导出名片关联列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:exchange:export')")
    @Log(title = "名片关联", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsUserCardExchange cmsUserCardExchange) {
        List<CmsUserCardExchange> list = cmsUserCardExchangeService.findCmsUserCardExchangeList(cmsUserCardExchange);
        ExcelUtil<CmsUserCardExchange> util = new ExcelUtil<>(CmsUserCardExchange.class);
        return util.exportExcel(list, "exchange");
    }

    /**
     * 获取名片关联详细信息
     */
    @ApiOperation("获取名片关联详细信息接口")
    @PreAuthorize("@ss.hasPermi('cms:exchange:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult<CmsUserCardExchange> getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(cmsUserCardExchangeService.findById(id));
    }

    /**
     * 新增名片关联
     */
    @ApiOperation("新增名片关联接口")
    @PreAuthorize("@ss.hasPermi('cms:exchange:add')")
    @Log(title = "名片关联", businessType = BusinessType.INSERT)
    @GetMapping("/accept/{acceptId}")
    public AjaxResult add(@PathVariable("acceptId") Long acceptId) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        CmsUserCardExchange cmsUserCardExchange = new CmsUserCardExchange();
        Long sendId = loginUser.getUser().getUserId();

        cmsUserCardExchange.setCreateBy(loginUser.getUsername());
        cmsUserCardExchange.setCreateTime(new Date());
        cmsUserCardExchange.setSendId(sendId);
        cmsUserCardExchange.setAcceptId(acceptId);
//        SysUser exInfo = userService.selectUserById(acceptId);
//        cmsUserCardExchange.setAcceptId(exInfo.getDeptId());
//        acceptId = exInfo.getDeptId();


        if (acceptId!=null && loginUser.getUser().getUserId()!=null ) {
            if (cmsUserCardExchangeService.findCardExchange(acceptId, sendId)>0) {
                //判断是否之前删除过
                try {
                    if (cmsUserCardExchangeService.findCardExchangeByStatus(acceptId, sendId) > 0) {
//                        cmsUserCardExchangeService.updateByStatus(acceptId,sendId);
//                        return AjaxResult.success();
                        cmsUserCardExchange.setUpdateBy(loginUser.getUsername());
                        cmsUserCardExchange.setUpdateTime(new Date());
                        CmsUserCardExchange exQ = new CmsUserCardExchange();
                        exQ.setAcceptId(acceptId);
                        exQ.setSendId(sendId);
                        List<CmsUserCardExchange> hasList = cmsUserCardExchangeService.findCmsUserCardExchangeList(exQ);
                        if(hasList.size()>0){
                            CmsUserCardExchange old = hasList.get(0);
                            cmsUserCardExchange.setId(old.getId());
                            cmsUserCardExchange.setCreateTime(old.getCreateTime());
                            cmsUserCardExchange.setCreateBy(old.getCreateBy());
                        }

                    } else {
                        return AjaxResult.error("您已经交换过名片了");
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    return AjaxResult.error("交换失败");
                }
            }
        }
        //用户信息
        CmsUserCard userCard = cmsUserCardService.findByUserId(sendId);
        if (userCard == null) {
            return AjaxResult.error("您还没有创建名片，请您创建后再来交换。");
        } else {
            cmsUserCardExchange.setSendAddress(userCard.getAddress());
            cmsUserCardExchange.setSendName(userCard.getName());
            cmsUserCardExchange.setSendPosition(userCard.getPosition());
            cmsUserCardExchange.setSendEmail(userCard.getEmail());
            cmsUserCardExchange.setSendPhone(userCard.getPhone());
            cmsUserCardExchange.setSendCompanyName(userCard.getCompanyName());
            cmsUserCardExchange.setSendDelFlag("0");
            cmsUserCardExchange.setCardId(userCard.getCardId());
        }
        //展商信息
        CmsUserCard accept = cmsUserCardService.findByUserId(acceptId);
        if (accept == null) {
            return AjaxResult.error("展商还未创建名片");
        } else {
            cmsUserCardExchange.setAcceptAddress(accept.getAddress());
            cmsUserCardExchange.setAcceptName(accept.getName());
            cmsUserCardExchange.setAcceptPosition(accept.getPosition());
            cmsUserCardExchange.setAcceptEmail(accept.getEmail());
            cmsUserCardExchange.setAcceptPhone(accept.getPhone());
            cmsUserCardExchange.setAcceptCompanyName(accept.getCompanyName());
            cmsUserCardExchange.setAcceptDelFlag("0");
        }



        cmsUserCardExchangeService.save(cmsUserCardExchange);

        return AjaxResult.success();
    }

    /**
     * 修改名片关联
     */
//    @ApiOperation("修改名片关联接口")
////    @PreAuthorize("@ss.hasPermi('cms:exchange:edit')")
//    @Log(title = "名片关联", businessType = BusinessType.UPDATE)
//    @PutMapping
//    public AjaxResult edit(@RequestBody CmsUserCardExchange cmsUserCardExchange) {
//        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
//        cmsUserCardExchange.setUpdateBy(loginUser.getUsername());
//        cmsUserCardExchange.setUpdateTime(new Date());
//        cmsUserCardExchangeService.save(cmsUserCardExchange);
//        return AjaxResult.success();
//    }

    /**
     * 删除名片关联
     */
//    @ApiOperation("删除名片关联接口")
////    @PreAuthorize("@ss.hasPermi('cms:exchange:remove')")
//    @Log(title = "名片关联", businessType = BusinessType.DELETE)
//	@DeleteMapping("/{ids}")
//    public AjaxResult remove(@PathVariable Long[] ids) {
//        cmsUserCardExchangeService.deleteByIds(Arrays.asList(ids));
//        return AjaxResult.success();
//    }
    @ApiOperation("删除名片关联接口")
    @DeleteMapping("/delete/{id}")
    public AjaxResult deleteById(@PathVariable Long id) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser.getUser() != null) {
            if (loginUser.getUser().getUserType().equals(UserType.CZS.getCode()) || loginUser.getUser().getUserType().equals(UserType.CZS_JS.getCode())) {
                int flag = cmsUserCardExchangeService.updateSendById("1", id);
                return flag>0 ? AjaxResult.success() : AjaxResult.error("删除失败");
            }else if(loginUser.getUser().getUserType().equals(UserType.GZ.getCode()) || loginUser.getUser().getUserType().equals(UserType.ZYGZ.getCode()) ||
                    loginUser.getUser().getUserType().equals(UserType.MT.getCode()) || loginUser.getUser().getUserType().equals(UserType.HYDB.getCode())){
//                CmsUserCardExchange exchange = new CmsUserCardExchange();
//                exchange.setId(id);
//                exchange.setAcceptDelFlag("1");
//                cmsUserCardExchangeService.save(exchange);
                int flag = cmsUserCardExchangeService.updateAcceptById(id);
                return flag>0 ? AjaxResult.success() : AjaxResult.error("删除失败");
            }

        }else{
            return AjaxResult.error("删除失败！");
        }
        return AjaxResult.error("没有登陆人信息！");
    }
}
