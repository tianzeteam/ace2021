package com.yuejike.web.util;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.iflytek.wst.gateway.sdk.client.ApacheHttpClient;
import com.iflytek.wst.gateway.sdk.constant.SdkConstant;
import com.iflytek.wst.gateway.sdk.enums.HttpMethod;
import com.iflytek.wst.gateway.sdk.enums.ParamPosition;
import com.iflytek.wst.gateway.sdk.enums.Scheme;
import com.iflytek.wst.gateway.sdk.model.ApiRequest;
import com.iflytek.wst.gateway.sdk.model.ApiResponse;
import com.iflytek.wst.gateway.sdk.model.HttpClientBuilderParams;

import javax.net.ssl.*;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

/**
 * 皖事通OAUTH
 * @author kosku
 *
 */
public class WstClient extends ApacheHttpClient {

    // 单例模式
    private static WstClient instance = new WstClient();
    public static WstClient getInstance() {
        return instance;
    }

    private String appKey = "e2a307503d064215a63b90a440f6f499";
    private String appSecret = "960D6595788173DE66CE0DB8FCA383AE";
    private Scheme scheme = Scheme.HTTPS;
//    private String host = "61.190.70.197:8801";
//    private String host = "61.190.70.197:8800";
    private String host = "www.ahzwfw.gov.cn";
    private String contextPath = "/wst-gateway";

    private WstClient() {
        // HTTP Client init
        HttpClientBuilderParams httpClientBuilderParams = new HttpClientBuilderParams();
        httpClientBuilderParams.setAppKey(appKey);
        httpClientBuilderParams.setAppSecret(appSecret);
        httpClientBuilderParams.setScheme(scheme);
        httpClientBuilderParams.setHost(host);
        httpClientBuilderParams.setContextPath(contextPath);

        // HTTPS客户端需要单独设置，禁用证书校验
        if (scheme == Scheme.HTTPS) {
            //HTTPS Client init
            /**
             * HTTPS request use DO_NOT_VERIFY mode only for demo
             * Suggest verify for security
             */
            X509TrustManager xtm = new X509TrustManager() {
                @Override
                public void checkClientTrusted(X509Certificate[] chain, String authType) {
                }

                @Override
                public void checkServerTrusted(X509Certificate[] chain, String authType) {
                }

                @Override
                public X509Certificate[] getAcceptedIssuers() {
                    X509Certificate[] x509Certificates = new X509Certificate[0];
                    return x509Certificates;
                }
            };

            SSLContext sslContext = null;
            try {
                sslContext = SSLContext.getInstance("SSL");
                sslContext.init(null, new TrustManager[]{xtm}, new SecureRandom());

            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException(e);
            } catch (KeyManagementException e) {
                throw new RuntimeException(e);
            }
            HostnameVerifier DO_NOT_VERIFY = new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };

            httpClientBuilderParams.setSslSocketFactory(sslContext.getSocketFactory());
            httpClientBuilderParams.setX509TrustManager(xtm);
            httpClientBuilderParams.setHostnameVerifier(DO_NOT_VERIFY);
        }

        super.init(httpClientBuilderParams);
    }

}
