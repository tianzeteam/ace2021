package com.yuejike.web.controller.cms;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.zxing.common.BitMatrix;
import com.mysql.cj.xdevapi.JsonArray;
import com.yuejike.cms.domain.CmsClassification;
import com.yuejike.cms.domain.CmsFavorites;
import com.yuejike.cms.domain.SysUserExhibitor;
import com.yuejike.cms.domain.SysUserExhibitorIndustry;
import com.yuejike.cms.dto.SysUserExhibitorDTO;
import com.yuejike.cms.service.*;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.constant.UserConstants;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.entity.SysRole;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.page.TableDataInfo;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.DateUtils;
import com.yuejike.common.utils.QrUtils;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.utils.sign.Base64;
import com.yuejike.common.utils.sms.LuoSiMaoSmsUtils;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.system.service.ISysRoleService;
import com.yuejike.system.service.ISysUserService;
import com.yuejike.web.vo.CaptchaVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.FastByteArrayOutputStream;
import org.springframework.web.bind.annotation.*;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 参展商信息Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/exhibitor")
@Api(tags = "B-参展商信息接口", description = "参展商信息接口")
public class SysUserExhibitorController extends BaseController {
    @Autowired
    private ISysUserExhibitorService sysUserExhibitorService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private ISysUserService sysUserService;
    @Autowired
    private ICmsClassificationService classificationService;
    @Autowired
    private ISysUserDelegateService sysUserDelegateService;
    @Autowired
    private ISysUserMediaService sysUserMediaService;
    @Autowired
    private ISysUserAudienceService sysUserAudienceService;
    @Autowired
    private ICmsFavoritesService favoritesService;
    @Autowired
    private ISysRoleService roleService;
    @Value(value="${yuejike.domainName}")
    private String domainName;

    @Autowired
    private ICmsIndustryService cmsIndustryService ;

    /**
     * 查询参展商信息列表
     */
    @ApiOperation("查询参展商信息列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:exhibitor:list')")
    @GetMapping("/ui/list")
    public TableDataInfo<SysUserExhibitor> list(SysUserExhibitor sysUserExhibitor) {
        //展商分类
        if(null != sysUserExhibitor.getClassificationId()){
            if(classificationService.hasChildByMenuId(sysUserExhibitor.getClassificationId())){
                List<Long> ids = new ArrayList<>();
                ids.add(sysUserExhibitor.getClassificationId());
                //递归查询所选节点下的所有的子节点
                List<CmsClassification> classificationIdList = queryAllClassificationId(ids);
                List<Long> classificationIds = new ArrayList<>();
                classificationIds.add(sysUserExhibitor.getClassificationId());
                if(CollectionUtils.isNotEmpty(classificationIdList)){
                    System.out.println("-----------"+ classificationIdList+"------所有子节点---");
                    classificationIds.addAll(classificationIdList.stream().map(item -> item.getClassificationId()).collect(Collectors.toList()));
                }
                sysUserExhibitor.setClassificationIds(classificationIds);
            }
        }
        //展商精彩分类
        if(null != sysUserExhibitor.getExcellentVideoClassificationId()){
            if(classificationService.hasChildByMenuId(sysUserExhibitor.getExcellentVideoClassificationId())){
                List<Long> ids = new ArrayList<>();
                ids.add(sysUserExhibitor.getExcellentVideoClassificationId());
                //递归查询所选节点下的所有的子节点
                List<CmsClassification> classificationIdList = queryAllClassificationId(ids);
                List<Long> classificationIds = new ArrayList<>();
                classificationIds.add(sysUserExhibitor.getExcellentVideoClassificationId());
                if(CollectionUtils.isNotEmpty(classificationIdList)){
                    System.out.println("-----------"+ classificationIdList+"------所有子节点---");
                    classificationIds.addAll(classificationIdList.stream().map(item -> item.getClassificationId()).collect(Collectors.toList()));
                }
                sysUserExhibitor.setExcellentVideoClassificationIds(classificationIds);
            }
        }
        Page<SysUserExhibitor> page = sysUserExhibitorService.findSysUserExhibitorPage(sysUserExhibitor);
        return getDataTable(page);
    }

    /**
     * 查询参展商信息列表
     */
    @ApiOperation("CMS查询参展商信息列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:exhibitor:list')")
    @GetMapping("/list")
    public TableDataInfo<SysUserExhibitor> cmslist(SysUserExhibitor sysUserExhibitor) {
        // 展商分类
        if(null != sysUserExhibitor.getClassificationId()){
            if(classificationService.hasChildByMenuId(sysUserExhibitor.getClassificationId())){
                List<Long> ids = new ArrayList<>();
                ids.add(sysUserExhibitor.getClassificationId());
                //递归查询所选节点下的所有的子节点
                List<CmsClassification> classificationIdList = queryAllClassificationId(ids);
                List<Long> classificationIds = new ArrayList<>();
                classificationIds.add(sysUserExhibitor.getClassificationId());
                if(CollectionUtils.isNotEmpty(classificationIdList)){
                    System.out.println(classificationIdList+"------所有子节点---");
                    classificationIds.addAll(classificationIdList.stream().map(item -> item.getClassificationId()).collect(Collectors.toList()));
                }
                sysUserExhibitor.setClassificationIds(classificationIds);
            }
        }
        //展商精彩分类
        if(null != sysUserExhibitor.getExcellentVideoClassificationId()){
            if(classificationService.hasChildByMenuId(sysUserExhibitor.getExcellentVideoClassificationId())){
                List<Long> ids = new ArrayList<>();
                ids.add(sysUserExhibitor.getExcellentVideoClassificationId());
                //递归查询所选节点下的所有的子节点
                List<CmsClassification> classificationIdList = queryAllClassificationId(ids);
                List<Long> classificationIds = new ArrayList<>();
                classificationIds.add(sysUserExhibitor.getExcellentVideoClassificationId());
                if(CollectionUtils.isNotEmpty(classificationIdList)){
                    System.out.println("-----------"+ classificationIdList+"------所有子节点---");
                    classificationIds.addAll(classificationIdList.stream().map(item -> item.getClassificationId()).collect(Collectors.toList()));
                }
                sysUserExhibitor.setExcellentVideoClassificationIds(classificationIds);
            }
        }
        Page<SysUserExhibitor> page = sysUserExhibitorService.cmsFindSysUserExhibitorPage(sysUserExhibitor);
        return getDataTable(page);
    }
    /**
     * 获取某个父节点下面的所有子节点
     * @param ids
     * @return
     */
    private List<CmsClassification> queryAllClassificationId(List<Long> ids){
        //根据父ID查询子节点列表
        List<CmsClassification> departments = classificationService.findByParentId(ids);
        if (CollectionUtils.isNotEmpty(departments)) {
            //拿到当前所有子节点ID
            List<Long> parentIds = departments.stream().map(item -> item.getClassificationId()).collect(Collectors.toList());
            //拼接子节点查询结果
            departments.addAll(queryAllClassificationId(parentIds));
            return departments;
        } else {
            //如果没有下级节点那么我们就返回空集合，结束递归。
            return Lists.newArrayList();
        }
    }

    /**
     * 导出参展商信息列表
     */
    @ApiOperation("导出参展商信息列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:exhibitor:export')")
    @Log(title = "参展商信息", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(SysUserExhibitor sysUserExhibitor) {
        List<SysUserExhibitor> list = sysUserExhibitorService.findSysUserExhibitorList(sysUserExhibitor);
        ExcelUtil<SysUserExhibitor> util = new ExcelUtil<>(SysUserExhibitor.class);
        return util.exportExcel(list, "exhibitor");
    }

    /**
     * 获取参展商信息详细信息
     */
    @ApiOperation("获取参展商信息详细信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:exhibitor:query')")
    @GetMapping(value = "/{userId}")
    public AjaxResult<SysUserExhibitor> getInfo(@PathVariable("userId") Long userId) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        SysUserExhibitor  exhibitor  = sysUserExhibitorService.findById(userId);

        //查询该商品是否被收藏
        if(loginUser != null){
            //根据登录人查看该展品是否被收藏
            CmsFavorites favorites = favoritesService.findByUserIdAndBusinessTypeAndBusinessId(loginUser.getUser().getUserId(),"1",userId);
           if(exhibitor!=null) {
               if (favorites != null) {
                   exhibitor.setFavorites(favorites);//已收藏
               } else {
                   exhibitor.setFavorites(null);//未收藏
               }
           }
        }
        return AjaxResult.success(exhibitor);
    }

    /**
     * 新增参展商信息
     */
    @ApiOperation("新增参展商信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:exhibitor:add')")
    @Log(title = "参展商信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SysUserExhibitorDTO sysUserExhibitorDTO) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser != null && loginUser.getUser() != null){
            if(!loginUser.getUser().getUserId().equals(sysUserExhibitorDTO.getUserId())){
                return AjaxResult.error("无权操作，只有用户本人可提交认证");
            }
            SysUser user = sysUserService.selectUserById(sysUserExhibitorDTO.getUserId());
            if(user == null){
                return AjaxResult.error("未知错误，未找到数据库记录");
            }
            //角色转化
            if(!user.getUserType().equals(UserType.CZS.getCode())){
                String[] arrUserType = {"02","03","04","05","06"};//可转化角色列表
                Set<String> userTypes = new HashSet<>(Arrays.asList(arrUserType));
                if(!userTypes.contains(user.getUserType())){
                    return AjaxResult.error("此用户类型不支持转化");
                }
                if((user.getUserType().equals(UserType.HYDB.getCode()) && sysUserDelegateService.findById(user.getUserId()) != null)
                        || (user.getUserType().equals(UserType.MT.getCode()) && sysUserMediaService.findById(user.getUserId()) != null)
                        || (user.getUserType().equals(UserType.ZYGZ.getCode()) && sysUserAudienceService.findById(user.getUserId()) != null)){
                    return AjaxResult.error("用户已经提交认证，无法再认证为其他角色");
                }
                user.setUserType(UserType.CZS.getCode());
                user.setUpdateTime(new Date());
                user.setUpdateBy(loginUser.getUsername());
                user.setReviewStatus("0");
                SysRole sysRole = roleService.selectRoleByRoleKey("exhibitor");
                if(sysRole != null){
                    user.setRoleIds(new Long[]{sysRole.getRoleId()});
                }else{
                    return AjaxResult.error("获取展商角色失败");
                }
                sysUserService.updateUser(user);
            }
            //提交认证
            SysUserExhibitor sysUserExhibitor = new SysUserExhibitor();
            BeanUtils.copyProperties(sysUserExhibitorDTO, sysUserExhibitor);
            if (UserConstants.NOT_UNIQUE.equals(sysUserExhibitorService.checkExhibitorUnique(sysUserExhibitor))) {
                return AjaxResult.error("公司:'" + sysUserExhibitor.getName() + "'已存在");
            }
            sysUserExhibitor.setTargetMarket("中国大陆");
            sysUserExhibitor.setCreateBy(loginUser.getUsername());
            sysUserExhibitor.setCreateTime(new Date());
            sysUserExhibitor.setDelFlag("0");
            sysUserExhibitor.setVisible("0");
            sysUserExhibitor.setOnlineOnly("1");
            //提交认证时应该取当前年份
            sysUserExhibitor.setJoinYearsArr(DateUtils.dateTimeNow(DateUtils.YYYY));
            sysUserExhibitorService.save(sysUserExhibitor, 1);
            return AjaxResult.success();
        }else{
            return AjaxResult.error("未登录或登录失效，请重新登录");
        }
    }

    /**
     * 修改参展商信息
     */
    @ApiOperation("修改参展商信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:exhibitor:edit')")
    @Log(title = "参展商信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SysUserExhibitorDTO sysUserExhibitorDTO) {
    	//更新3d用户
    	// businessmanService.updateUser(sysUserExhibitorDTO.getUserId());
        try {
            SysUserExhibitor sysUserExhibitor = new SysUserExhibitor();
            BeanUtils.copyProperties(sysUserExhibitorDTO, sysUserExhibitor);
            LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
            if (StringUtils.isNotBlank(sysUserExhibitorDTO.getReviewStatus()) && sysUserExhibitorDTO.getReviewStatus().equals("2")) {
                //用户被拒绝后再次修改提交,将审核状态修改待审核
                sysUserService.updateReviewStatus(sysUserExhibitorDTO.getUserId());
                //查询展商信息
                SysUserExhibitor exhibitor = sysUserExhibitorService.findById(sysUserExhibitorDTO.getUserId());
                exhibitor.setAddress(sysUserExhibitorDTO.getAddress());
                exhibitor.setCountryId(sysUserExhibitorDTO.getCountryId());
                exhibitor.setProvinceId(sysUserExhibitorDTO.getProvinceId());
                exhibitor.setCityId(sysUserExhibitorDTO.getCityId());
                exhibitor.setLicenseUrl(sysUserExhibitorDTO.getLicenseUrl());
                exhibitor.setName(sysUserExhibitorDTO.getName());
                exhibitor.setSocialCode(sysUserExhibitorDTO.getSocialCode());
                exhibitor.setWebsite(sysUserExhibitor.getWebsite());
                exhibitor.setUpdateBy(loginUser.getUsername());
                exhibitor.setUpdateTime(new Date());
                sysUserExhibitorService.save(exhibitor, 2);
            }else{
                if(StringUtils.isNotEmpty(sysUserExhibitor.getLabelId())){
                    List<String> ids = Arrays.asList(sysUserExhibitor.getLabelId().split(",").clone());
                    if(ids.stream().filter(id->id.equals("2")).count()>0){
                        if(sysUserExhibitorService.canRecommend(new Long[]{sysUserExhibitor.getUserId()})){
                            return AjaxResult.error("最多只能设置6个推荐位");
                        }else{
                            sysUserExhibitor.setRecommend("1");
                        }
                    }else{
                        sysUserExhibitor.setRecommend("0");
                    }
                }
                sysUserExhibitor.setUpdateBy(loginUser.getUsername());
                sysUserExhibitor.setUpdateTime(new Date());
                sysUserExhibitorService.save(sysUserExhibitor, 2);
            }
            return AjaxResult.success();
        } catch (Exception ex) {
            ex.printStackTrace();
            logger.error(ex.getMessage());
            return AjaxResult.error(ex.getMessage());
        }
    }
    @ApiOperation("审核参展商精彩接口")
    @PreAuthorize("@ss.hasPermi('cms:exhibitor:review')")
    @Log(title = "参展商信息", businessType = BusinessType.UPDATE)
    @PutMapping("/review")
    public AjaxResult review(@RequestBody SysUserExhibitorDTO sysUserExhibitorDTO) {
        try {
            SysUserExhibitor sysUserExhibitor = new SysUserExhibitor();
            BeanUtils.copyProperties(sysUserExhibitorDTO, sysUserExhibitor);
            LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
            sysUserExhibitor.setExcellectVideoReviewerId(loginUser.getUser().getUserId());
            sysUserExhibitor.setExcellentVideoReviewTime(new Date());
            sysUserExhibitorService.save(sysUserExhibitor, 2);
            if(sysUserExhibitorDTO.getExcellentVideoStatus().equals("1") || sysUserExhibitorDTO.getExcellentVideoStatus().equals("2")){
                SysUser user = sysUserService.selectUserById(sysUserExhibitorDTO.getUserId());
                if(user != null && StringUtils.isNotEmpty(user.getPhonenumber())){
                    LuoSiMaoSmsUtils.getInstance().sendApprovedExcellentVideoMsg(user.getPhonenumber(), sysUserExhibitorDTO.getExcellentVideoStatus().equals("1"));
                }
            }
            return AjaxResult.success();
        } catch (Exception ex) {
            ex.printStackTrace();
            logger.error(ex.getMessage());
            return AjaxResult.error(ex.getMessage());
        }
    }


    /**
     * 删除参展商信息
     */
    @ApiOperation("删除参展商信息接口")
    @PreAuthorize("@ss.hasPermi('cms:exhibitor:remove')")
    @Log(title = "参展商信息", businessType = BusinessType.DELETE)
    @DeleteMapping("/{userIds}")
    public AjaxResult remove(@PathVariable Long[] userIds) {
        sysUserExhibitorService.deleteByIds(Arrays.asList(userIds));
        return AjaxResult.success();
    }

    @ApiOperation("获取参展商推广二维码接口")
    @GetMapping("/qrcode")
    public AjaxResult<CaptchaVo> getQr() {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        Long recommendId = loginUser.getUser().getUserId();
        BitMatrix bitMatrix = QrUtils.setBitMatrix(domainName+"#/pages/onRegister/register?recommendId="+recommendId, 202, 202);
        BufferedImage image = QrUtils.toBufferedImage(bitMatrix);
        FastByteArrayOutputStream os = new FastByteArrayOutputStream();
        try {
            ImageIO.write(image, "png", os);
        } catch (IOException e) {
            return AjaxResult.error(e.getMessage());
        }
        CaptchaVo captchaVo = new CaptchaVo();
        captchaVo.setImg(Base64.encode(os.toByteArray()));
        return AjaxResult.success(captchaVo);
    }

    /**
     * logo、营业执照上传
     */
//    @ApiOperation("图片上传接口")
//    @Log(title = "图片上传接口", businessType = BusinessType.UPDATE)
//    @PostMapping("/upload")
//    public MapResult upload(@RequestParam("file") MultipartFile file) throws IOException {
//        if (!file.isEmpty()) {
//            String fileUrl = FileUploadUtils.upload(YueJiKeConfig.getAvatarPath(), file);
//            if(StringUtils.isNotBlank(fileUrl)){
//                MapResult ajax = MapResult.success();
//                ajax.put("imgUrl", fileUrl);
//                return ajax;
//            }
//        }
//        return MapResult.error("上传图片异常，请联系管理员");
//    }

   @ApiOperation("展商-修改基本信息接口")
   @Log(title = "参展商信息", businessType = BusinessType.UPDATE)
   @PutMapping("/update")
   public AjaxResult updateExhibitor(@RequestBody SysUserExhibitorDTO sysUserExhibitorDTO) {
       SysUserExhibitor sysUserExhibitor = new SysUserExhibitor();
       BeanUtils.copyProperties(sysUserExhibitorDTO, sysUserExhibitor);
       LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
       SysUserExhibitor userExhibitor = sysUserExhibitorService.findById(sysUserExhibitorDTO.getUserId());
       userExhibitor.setName(sysUserExhibitorDTO.getName());
       userExhibitor.setEnName(sysUserExhibitorDTO.getEnName());
       userExhibitor.setJaName(sysUserExhibitorDTO.getJaName());
       userExhibitor.setKoName(sysUserExhibitorDTO.getKoName());
       userExhibitor.setCnProfile(sysUserExhibitorDTO.getCnProfile());
       userExhibitor.setEnProfile(sysUserExhibitorDTO.getEnProfile());
       userExhibitor.setJaProfile(sysUserExhibitorDTO.getJaProfile());
       userExhibitor.setKoProfile(sysUserExhibitorDTO.getKoProfile());
       userExhibitor.setBasicinfoReviewStatus("0");
       userExhibitor.setBasicinfoReviewRejectReason(null);
       userExhibitor.setShortName(sysUserExhibitorDTO.getShortName());
       userExhibitor.setEnShortName(sysUserExhibitorDTO.getEnShortName());
       userExhibitor.setJaShortName(sysUserExhibitorDTO.getJaShortName());
       userExhibitor.setKoShortName(sysUserExhibitorDTO.getKoShortName());
       userExhibitor.setUpdateObj(sysUserExhibitorDTO.getUpdateObj());
       userExhibitor.setUpdateBy(loginUser.getUsername());
       userExhibitor.setUpdateTime(new Date());
       sysUserExhibitorService.save(userExhibitor, 2);
       return AjaxResult.success();
   }

    /**
     * 审核-展商基本信息
     * @param sysUserExhibitorDTO
     * @return
     */
    @ApiOperation("主办方审核-展商基本信息")
    @PreAuthorize("@ss.hasPermi('cms:exhibitor:review')")
    @Log(title = "参展商信息", businessType = BusinessType.UPDATE)
    @PutMapping("/reviewExhibitorBasicInfo")
    public AjaxResult reviewExhibitorBasicInfo(@RequestBody SysUserExhibitorDTO sysUserExhibitorDTO) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        SysUserExhibitor userExhibitor = sysUserExhibitorService.findById(sysUserExhibitorDTO.getUserId());
        userExhibitor.setBasicinfoReviewId(loginUser.getUser().getUserId());
        userExhibitor.setBasicinfoReviewStatus(sysUserExhibitorDTO.getBasicinfoReviewStatus());
        userExhibitor.setBasicinfoReviewRejectReason(sysUserExhibitorDTO.getBasicinfoReviewRejectReason());
        userExhibitor.setBasicinfoReviewTime(new Date());
        if(sysUserExhibitorDTO.getBasicinfoReviewStatus().equals("1") && userExhibitor.getUpdateObj() != null ){
            //审核通过后，将修改的信息重新赋值到各个字段上
            String updateObj = userExhibitor.getUpdateObj();
            JSONObject jsonObject = JSON.parseObject(updateObj);
            userExhibitor.setEnName(jsonObject.getString("enName"));
            userExhibitor.setLogo(jsonObject.getString("logo"));
            userExhibitor.setEnProfile(jsonObject.getString("enProfile"));
            userExhibitor.setCnProfile(jsonObject.getString("cnProfile"));
            userExhibitor.setTargetMarket(jsonObject.getString("targetMarket"));
            userExhibitor.setExhibitionNumber(jsonObject.getString("exhibitionNumber"));
            userExhibitor.setImgUrl(jsonObject.getString("imgUrl"));
            userExhibitor.setBannerUrl(jsonObject.getString("bannerUrl"));
            userExhibitor.setVideoUrl(jsonObject.getString("videoUrl"));
            userExhibitor.setContacts(jsonObject.getString("contacts"));
            userExhibitor.setContactsDept(jsonObject.getString("contactsDept"));
            userExhibitor.setPhone(jsonObject.getString("phone"));
            userExhibitor.setEmail(jsonObject.getString("email"));
            userExhibitor.setAddress(jsonObject.getString("address"));

            // 维护industry 数据
            List<SysUserExhibitorIndustry> sysUserExhibitorIndustries = new ArrayList<>();
            String[][] updateIndustries = jsonObject.getObject("industriesData", String[][].class);
            for (String[] updateIndustry : updateIndustries) {
                SysUserExhibitorIndustry sysUserExhibitorIndustry = new SysUserExhibitorIndustry();
                sysUserExhibitorIndustry.setIndustryMap(StringUtils.join(updateIndustry,","));
                sysUserExhibitorIndustry.setExhibitor(userExhibitor);
                sysUserExhibitorIndustries.add(sysUserExhibitorIndustry);
            }
            userExhibitor.getIndustries().clear();
            userExhibitor.getIndustries().addAll(sysUserExhibitorIndustries);
            userExhibitor.setUpdateObj(null);
        }
        sysUserExhibitorService.save(userExhibitor, 2);
        if(sysUserExhibitorDTO.getBasicinfoReviewStatus().equals("1") || sysUserExhibitorDTO.getBasicinfoReviewStatus().equals("2")){
            SysUser user = sysUserService.selectUserById(sysUserExhibitorDTO.getUserId());
            if(user != null && StringUtils.isNotEmpty(user.getPhonenumber())){
                LuoSiMaoSmsUtils.getInstance().sendApprovedBasicInfoMsg(user.getPhonenumber(), sysUserExhibitorDTO.getBasicinfoReviewStatus().equals("1"));
            }
        }
        return AjaxResult.success();
    }

}
