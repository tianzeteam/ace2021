package com.yuejike.web.controller.system;

import com.alibaba.fastjson.JSONObject;
import com.google.zxing.common.BitMatrix;
import com.yuejike.cms.service.ISysUserAudienceService;
import com.yuejike.cms.service.ISysUserDelegateService;
import com.yuejike.cms.service.ISysUserExhibitorService;
import com.yuejike.cms.service.ISysUserMediaService;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.annotation.Message;
import com.yuejike.common.constant.UserConstants;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.MapResult;
import com.yuejike.common.core.domain.entity.SysRole;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.page.TableDataInfo;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.common.enums.NoticeType;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.QrUtils;
import com.yuejike.common.utils.SecurityUtils;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.common.utils.http.HttpUtils;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.utils.sms.LuoSiMaoSmsUtils;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.system.service.ISysPostService;
import com.yuejike.system.service.ISysRoleService;
import com.yuejike.system.service.ISysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.FastByteArrayOutputStream;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 用户信息
 *
 * @author yuejike
 */
@Api(tags = "用户信息接口",description = "用户信息接口")
@RestController
@RequestMapping("/system/user")
public class SysUserController extends BaseController {
    @Autowired
    private ISysUserService userService;

    @Autowired
    private ISysRoleService roleService;

    @Autowired
    private ISysPostService postService;

    @Autowired
    private TokenService tokenService;

    @Autowired
    private ISysUserExhibitorService userExhibitorService;

    @Autowired
    private ISysUserDelegateService userDelegateService;

    @Autowired
    private ISysUserMediaService userMediaService;

    @Autowired
    private ISysUserAudienceService userAudienceService;

    @Value(value="${yuejike.domainName}")
    private String domainName;

    /**
     * 获取用户列表
     */
    @ApiOperation("获取用户列表接口")
    @PreAuthorize("@ss.hasPermi('system:user:list')")
    @GetMapping("/list")
    public TableDataInfo<SysUser> list(SysUser user) {
        Page<SysUser> page = userService.selectUserList(user);
        return getDataTable(page);
    }

    @ApiOperation("根据登录人类型获取用户列表接口")
    @PreAuthorize("@ss.hasPermi('system:user:list')")
    @GetMapping("/listByUserType")
    public TableDataInfo<SysUser> listByUserType(SysUser user) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser.getUser().getUserType().equals("00")){
            user.setUserType(user.getUserType());
            Page<SysUser> page = userService.selectUserList(user);
            return getDataTable(page);
        }else if(loginUser.getUser().getUserType().equals("01")){
            user.setUserType("01");
            Page<SysUser> page = userService.selectUserList(user);
            return getDataTable(page);
        }else if(loginUser.getUser().getUserType().equals("02") && null != loginUser.getUser().getDeptId()){
            user.setUserType("02");
            user.setDeptId(loginUser.getUser().getDeptId());
            Page<SysUser> page = userService.selectUserList(user);
            return getDataTable(page);
        }
        TableDataInfo rspData = new TableDataInfo();
        rspData.setCode(500);
        rspData.setMsg("查询失败");
        rspData.setRows(null);
        rspData.setTotal(0);
        return rspData;
    }

    @ApiOperation("根据userIdList获取用户列表")
    @GetMapping("/userListByIds")
    public MapResult userListByIds(SysUser user) {
        LoginUser loginUser =tokenService.getLoginUser(ServletUtils.getRequest());
        List<SysUser> userList = userService.findByUserIdIn("1",user.getUserIds(),loginUser.getUser().getExpositionId());
        return MapResult.success(userList);
    }

    /**
     * 用户数据列表导出
     * @param user
     * @return
     */
    @ApiOperation("用户数据列表导出接口")
    @Log(title = "用户管理", businessType = BusinessType.EXPORT)
    @PreAuthorize("@ss.hasPermi('system:user:export')")
    @GetMapping("/export")
    public AjaxResult export(SysUser user) {
        Page<SysUser> page = userService.selectUserList(user);
        ExcelUtil<SysUser> util = new ExcelUtil<SysUser>(SysUser.class);
        return util.exportExcel(page.getContent(), "用户数据");
    }

    /**
     * 用户导入模板
     * @param file
     * @param updateSupport
     * @return
     * @throws Exception
     */
    @ApiOperation("用户导入模板接口")
    @Log(title = "用户管理", businessType = BusinessType.IMPORT)
    @PreAuthorize("@ss.hasPermi('system:user:import')")
    @PostMapping("/importData")
    public AjaxResult importData(MultipartFile file, boolean updateSupport) throws Exception {
        ExcelUtil<SysUser> util = new ExcelUtil<SysUser>(SysUser.class);
        List<SysUser> userList = util.importExcel(file.getInputStream());
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        String operName = loginUser.getUsername();
        String message = userService.importUser(userList, updateSupport, operName);
        return AjaxResult.success(message);
    }

    /**
     * 下载用户导入模板
     * @return
     */
    @ApiOperation("下载用户导入模板接口")
    @GetMapping("/importTemplate")
    public AjaxResult importTemplate() {
        ExcelUtil<SysUser> util = new ExcelUtil<SysUser>(SysUser.class);
        return util.importTemplateExcel("用户数据");
    }

    /**
     * 根据用户编号获取详细信息
     */
    @ApiOperation("根据用户编号获取详细信息接口")
    @PreAuthorize("@ss.hasPermi('system:user:query')")
    @GetMapping(value = {"/", "/{userId}"})
    public MapResult getInfo(@PathVariable(value = "userId", required = false) Long userId) {
        MapResult ajax = MapResult.success();
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        List<SysRole> roles = new ArrayList<>();
        if(loginUser.getUser().getUserType().equals("01")){//主办方
            roles = roleService.findByRoleType("0");
        }else if(loginUser.getUser().getUserType().equals("02")){//参展商
            roles = roleService.findByRoleType("1");
        }else{
            roles = roleService.selectRoleAll();
        }
        // List<SysRole> roles = roleService.selectRoleAll();
        ajax.put("roles", SysUser.isAdmin(userId) ? roles : roles.stream().filter(r -> !r.isAdmin()).collect(Collectors.toList()));
        // ajax.put("posts", postService.selectPostAll());
        if (StringUtils.isNotNull(userId)) {
            ajax.put("data", userService.selectUserById(userId));
            ajax.put("postIds", postService.selectPostListByUserId(userId));
            ajax.put("roleIds", roleService.selectRoleListByUserId(userId));
        }
        return ajax;
    }

    /**
     * 新增用户
     */
    @ApiOperation("新增用户接口")
    @PreAuthorize("@ss.hasPermi('system:user:add')")
    @Log(title = "用户管理", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@Validated @RequestBody SysUser user) {
        if (UserConstants.NOT_UNIQUE.equals(userService.checkUserNameUnique(user.getUserName()))) {
            return AjaxResult.error("新增用户'" + user.getUserName() + "'失败，账号已存在");
        } else if (UserConstants.NOT_UNIQUE.equals(userService.checkPhoneUnique(user))) {
            return AjaxResult.error("新增用户'" + user.getUserName() + "'失败，手机号码已存在");
        } else if (UserConstants.NOT_UNIQUE.equals(userService.checkEmailUnique(user))) {
            return AjaxResult.error("新增用户'" + user.getUserName() + "'失败，邮箱账号已存在");
        } else if(UserConstants.NOT_UNIQUE.equals(userService.checkSponsorUnique())){
            return AjaxResult.error("博览会已结束！");
        }
        user.setCreateBy(SecurityUtils.getUsername());
        user.setPassword(SecurityUtils.encryptPassword(user.getPassword()));
        int i = userService.insertUser(user);
        //判断是否是渠道，是的话生成二维码
        if(StringUtils.isEmpty(user.getChannelQrCode())){
            if(roleService.checkChannelUser(user.getRoleIds())) {
                String qrCodePath = getChannelQrCode(user.getUserId(), true);
                if(!StringUtils.isEmpty(qrCodePath)){
                    user.setChannelQrCode(qrCodePath);
                    userService.updateUser(user);
                }
            }
        }
        return toAjax(i);
    }

    private String getChannelQrCode(Long userId, Boolean isChannel){
        String strContent = domainName;
        if(isChannel) {
            strContent = strContent + "#/pages/onRegister/register?type=06&channelId="+userId;
        }else{
            strContent = strContent + "#/pages/qiyedianpu/qiyedianpu?userId="+userId;
        }
        return QrUtils.createRemoteQrCode(strContent, 202, 202);
    }

    /**
     * 修改用户
     */
    @ApiOperation("修改用户接口")
    @PreAuthorize("@ss.hasPermi('system:user:edit')")
    @Log(title = "用户管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@Validated @RequestBody SysUser user) {
        userService.checkUserAllowed(user);
        if (UserConstants.NOT_UNIQUE.equals(userService.checkPhoneUnique(user))) {
            return AjaxResult.error("修改用户'" + user.getUserName() + "'失败，手机号码已存在");
        } else if (UserConstants.NOT_UNIQUE.equals(userService.checkEmailUnique(user))) {
            return AjaxResult.error("修改用户'" + user.getUserName() + "'失败，邮箱账号已存在");
        }
        user.setUpdateBy(SecurityUtils.getUsername());
        //判断是否是渠道，是的话生成二维码
        if(StringUtils.isEmpty(user.getChannelQrCode())){
            if(roleService.checkChannelUser(user.getRoleIds())) {
                String qrCodePath = getChannelQrCode(user.getUserId(), true);
                if(!StringUtils.isEmpty(qrCodePath)){
                    user.setChannelQrCode(qrCodePath);
                }
            }else if(user.getUserType().equals(UserType.CZS.getCode()) || user.getUserType().equals(UserType.CZS_JS.getCode())){
                String qrCodePath = getChannelQrCode(user.getUserId(), false);
                if(!StringUtils.isEmpty(qrCodePath)){
                    user.setChannelQrCode(qrCodePath);
                }
            }
        }
        return toAjax(userService.updateUser(user));
    }

    @ApiOperation("重新生成用户二维码，系统管理员用")
    @PreAuthorize("@ss.hasPermi('cms:user:rebuildQrCode')")
    @Log(title = "用户管理", businessType = BusinessType.UPDATE)
    @PutMapping("/rebuildQrCode")
    public AjaxResult rebuildQrCode(){
        List<SysUser> sysUsers = userService.selectAllUserList();
        sysUsers.forEach( user -> {
            if(StringUtils.isNotEmpty(user.getChannelQrCode())) {

                System.out.println(user);
                if(user.getUserType().equals(UserType.ZBF.getCode()) || user.getUserType().equals(UserType.ZBF_JS.getCode())){
                    String qrCodePath = getChannelQrCode(user.getUserId(), true);
                    if(!StringUtils.isEmpty(qrCodePath)){
                        user.setChannelQrCode(qrCodePath);
                        userService.rebuildQrCode(user);
                    }
                }else if(user.getUserType().equals(UserType.CZS.getCode()) || user.getUserType().equals(UserType.CZS_JS.getCode())){
                    String qrCodePath = getChannelQrCode(user.getUserId(), false);
                    if(!StringUtils.isEmpty(qrCodePath)){
                        user.setChannelQrCode(qrCodePath);
                        userService.rebuildQrCode(user);
                    }
                }
            }
        });
        return AjaxResult.success();
    }

    /**
     * 删除用户
     */
    @ApiOperation("删除用户接口")
    @PreAuthorize("@ss.hasPermi('system:user:remove')")
    @Log(title = "用户管理", businessType = BusinessType.DELETE)
    @DeleteMapping("/{userIds}")
    public AjaxResult remove(@PathVariable Long[] userIds) {
        return toAjax(userService.deleteUserByIds(userIds));
    }

    /**
     * 重置密码
     */
    @ApiOperation("重置密码接口")
    @PreAuthorize("@ss.hasPermi('system:user:resetPwd')")
    @Log(title = "用户管理", businessType = BusinessType.UPDATE)
    @PutMapping("/resetPwd")
    public AjaxResult resetPwd(@RequestBody SysUser user) {
        userService.checkUserAllowed(user);
        user.setPassword(SecurityUtils.encryptPassword(user.getPassword()));
        user.setUpdateBy(SecurityUtils.getUsername());
        return toAjax(userService.resetPwd(user));
    }

    /**
     * 状态修改
     */
    @ApiOperation("状态修改接口")
    @PreAuthorize("@ss.hasPermi('system:user:edit')")
    @Log(title = "用户管理", businessType = BusinessType.UPDATE)
    @PutMapping("/changeStatus")
    public AjaxResult changeStatus(@RequestBody SysUser user) {
        userService.checkUserAllowed(user);
        user.setUpdateBy(SecurityUtils.getUsername());
        int flag = userService.updateUserStatus(user);
        return toAjax(flag);
    }

    /**
     * 普通观众进行角色升级接口
     * @param user
     * @return
     */
    @ApiOperation("普通观众进行角色升级接口")
    // @PreAuthorize("@ss.hasPermi('system:user:edit')")
    @Log(title = "用户管理", businessType = BusinessType.UPDATE)
    @PutMapping("/upgrade")
    public AjaxResult upgrade(@RequestBody SysUser user) {
        int flag = 0;
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(null != loginUser && loginUser.getUser().getUserType().equals(UserType.GZ.getCode())){
            SysUser sysUser = userService.selectUserById(loginUser.getUser().getUserId());
            sysUser.setUserType(user.getUserType());
            sysUser.setReviewStatus("0");//升级角色后，需要将该用户的审核状态置为待审核
            sysUser.setUpdateBy(loginUser.getUsername());
            sysUser.setUpdateTime(new Date());
            flag = userService.updateUserProfile(sysUser);
        }
        return toAjax(flag);
    }

    /**
     * 审核认证用户身份状态修改
     */
    @ApiOperation("审核认证用户身份状态接口")
    @PreAuthorize("@ss.hasPermi('system:user:review')")
    @Log(title = "用户管理", businessType = BusinessType.UPDATE)
    @Message(title = "认证通知",noticeType = NoticeType.REVIEW,content = "您的认证信息已被审核,请到认证记录中查看详情。")
    @PutMapping("/reviewUser")
    public AjaxResult reviewUserStatus(@RequestBody SysUser user) {
        userService.checkUserAllowed(user);
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        user.setReviewerId(loginUser.getUser().getUserId());
        user.setUpdateBy(loginUser.getUsername());
        user.setReviewTime(new Date());
        user.setUpdateTime(new Date());
        //如果是展商审核通过就生成一下展商二维码
        if(user.getUserType().equals(UserType.CZS.getCode()) && StringUtils.isEmpty(user.getChannelQrCode())
                && user.getReviewStatus().equals("1")){
            String qrCodePath = getChannelQrCode(user.getUserId(), false);
            if(!StringUtils.isEmpty(qrCodePath)){
                user.setChannelQrCode(qrCodePath);
            }
        }

        int flag = userService.reviewUserStatus(user);
        AjaxResult ajaxResult = new AjaxResult();
        if(flag > 1){
            if(user.getReviewStatus().equals("1") || user.getReviewStatus().equals("2")) {
                if(user != null && StringUtils.isNotEmpty(user.getPhonenumber())){
                    LuoSiMaoSmsUtils.getInstance().sendApprovedAuthMsg(user.getPhonenumber(), user.getReviewStatus().equals("1"));
                }
            }
            ajaxResult.setCode(0);
            ajaxResult.setData(user);
            ajaxResult.setMsg("审核完成");
        }
        return ajaxResult;
    }

    @ApiOperation("根据展商id获取相关的用户列表接口")
    @GetMapping("/findUserListByExhibitor")
    public TableDataInfo<SysUser> getUserListByExhibitor(SysUser user){
        LoginUser loginUser =tokenService.getLoginUser(ServletUtils.getRequest());
        user.setUserId(loginUser.getUser().getUserId());
        user.setDeptId(loginUser.getUser().getDeptId());
        Page<SysUser> userPage =userService.findUserListByExhibitor(user);
       return getDataTable(userPage);
    }

}
