package com.yuejike.web.controller.cms;

import com.yuejike.common.core.domain.MapResult;
import com.yuejike.model.TreeSelectModel;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsClassification;
import com.yuejike.cms.service.ICmsClassificationService;
import com.yuejike.common.utils.poi.ExcelUtil;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 分类Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/classification")
@Api(tags = "分类",description = "分类")
public class CmsClassificationController extends BaseController {
    @Autowired
    private ICmsClassificationService cmsClassificationService;
    @Autowired
    private TokenService tokenService;

    /**
     * 查询分类列表
     */
    @ApiOperation("查询分类列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:classification:list')")
    @GetMapping("/list")
    public MapResult list(CmsClassification cmsClassification) {
        List<CmsClassification> list = cmsClassificationService.findCmsClassificationList(cmsClassification);
        return MapResult.success("查询成功",list) ;
    }

    /**
     * 导出分类列表
     */
    @ApiOperation("导出分类列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:classification:export')")
    @Log(title = "分类", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsClassification cmsClassification) {
        List<CmsClassification> list = cmsClassificationService.findCmsClassificationList(cmsClassification);
        ExcelUtil<CmsClassification> util = new ExcelUtil<>(CmsClassification.class);
        return util.exportExcel(list, "classification");
    }

    /**
     * 获取分类详细信息
     */
    @ApiOperation("获取分类详细信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:classification:query')")
    @GetMapping(value = "/{classificationId}")
    public AjaxResult<CmsClassification> getInfo(@PathVariable("classificationId") Long classificationId) {
        return AjaxResult.success(cmsClassificationService.findById(classificationId));
    }

    /**
     * 新增分类
     */
    @ApiOperation("新增分类接口")
    @PreAuthorize("@ss.hasPermi('cms:classification:add')")
    @Log(title = "分类", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsClassification cmsClassification) {
        if (cmsClassification.getParentId() == null|| "".equals(cmsClassification.getParentId())) {
            cmsClassification.setParentId(new Long(0));
        }
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsClassification.setExpositionId(loginUser.getUser().getExpositionId());
        cmsClassification.setCreateBy(loginUser.getUsername());
        cmsClassification.setCreateTime(new Date());
        cmsClassification.setDelFlag("0");
        cmsClassificationService.save(cmsClassification);
        return AjaxResult.success();
    }

    /**
     * 修改分类
     */
    @ApiOperation("修改分类接口")
    @PreAuthorize("@ss.hasPermi('cms:classification:edit')")
    @Log(title = "分类", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsClassification cmsClassification) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsClassification.setUpdateBy(loginUser.getUsername());
        cmsClassification.setUpdateTime(new Date());
        cmsClassificationService.save(cmsClassification);
        return AjaxResult.success();
    }

    /**
     * 删除分类
     */
    @ApiOperation("删除分类接口")
    @PreAuthorize("@ss.hasPermi('cms:classification:remove')")
    @Log(title = "分类", businessType = BusinessType.DELETE)
	@DeleteMapping("/{classificationId}")
    public AjaxResult remove(@PathVariable("classificationId") Long classificationId) {
        if (cmsClassificationService.hasChildByMenuId(classificationId)) {
            return AjaxResult.error("存在子分类,不允许删除");
        }
        cmsClassificationService.deleteByIds(Arrays.asList(classificationId));
        return AjaxResult.success();
    }

    /**
     * 获取部门下拉树列表
     */
    @ApiOperation("获取分类下拉树列表接口")
    @GetMapping("/treeselect")
    public MapResult treeselect(CmsClassification dept) {
        List<CmsClassification> depts = cmsClassificationService.selectClassList(dept);
        List<TreeSelectModel> treeSelectModels = cmsClassificationService.buildTreeSelect(depts);
        return MapResult.success(treeSelectModels);
    }
}
