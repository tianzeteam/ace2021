package com.yuejike.web.controller.cms;

import com.yuejike.cms.domain.SysUserGroupRelation;
import com.yuejike.cms.service.ISysUserGroupRelationService;
import com.yuejike.common.core.domain.MapResult;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.SysUserGroup;
import com.yuejike.cms.service.ISysUserGroupService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.*;
import java.util.stream.Collectors;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 标签分组Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/group")
@Api(tags = "标签分组",description = "标签分组")
public class SysUserGroupController extends BaseController {
    @Autowired
    private ISysUserGroupService sysUserGroupService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private ISysUserGroupRelationService userGroupRelationService;

    /**
     * 查询标签分组列表
     */
    @ApiOperation("查询标签分组列表接口")
    // @PreAuthorize("@ss.hasPermi('cms:group:list')")
    @GetMapping("/list")
    public TableDataInfo<SysUserGroup> list(SysUserGroup sysUserGroup) {
        Page<SysUserGroup> page = sysUserGroupService.findSysUserGroupPage(sysUserGroup);
        return getDataTable(page);
    }

    /**
     * 导出标签分组列表
     */
    @ApiOperation("导出标签分组列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:group:export')")
    @Log(title = "标签分组", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(SysUserGroup sysUserGroup) {
        List<SysUserGroup> list = sysUserGroupService.findSysUserGroupList(sysUserGroup);
        ExcelUtil<SysUserGroup> util = new ExcelUtil<>(SysUserGroup.class);
        return util.exportExcel(list, "group");
    }

    /**
     * 获取标签分组详细信息
     */
    @ApiOperation("获取标签分组详细信息接口")
    @PreAuthorize("@ss.hasPermi('cms:group:query')")
    @GetMapping(value = "/{groupId}")
    public AjaxResult<SysUserGroup> getInfo(@PathVariable("groupId") Long groupId) {
        return AjaxResult.success(sysUserGroupService.findById(groupId));
    }

    @ApiOperation("批量查询分组详情")
    @PostMapping("/getInfoByGroupIds")
    public MapResult getInfoByGroupIds(@RequestBody SysUserGroup sysUserGroup) {
        List<SysUserGroup> groupList = sysUserGroupService.findByGroupIdIn(sysUserGroup.getGroupIds());
        return MapResult.success(groupList);
    }

    /**
     * 新增标签分组
     */
    @ApiOperation("新增标签分组接口")
    @PreAuthorize("@ss.hasPermi('cms:group:add')")
    @Log(title = "标签分组", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SysUserGroup sysUserGroup) {
        AjaxResult ajaxResult = new AjaxResult();
        //查询分组名称是否已存在
        SysUserGroup userGroup = sysUserGroupService.findByName(sysUserGroup.getName());
        if(null != userGroup){
            ajaxResult.setCode(500);
            ajaxResult.setMsg("分组名称已存在！");
        }else{
            LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
            sysUserGroup.setCreateId(loginUser.getUser().getUserId());
            sysUserGroup.setCreateBy(loginUser.getUsername());
            sysUserGroup.setCreateTime(new Date());
            sysUserGroup.setDelFlag("0");
            sysUserGroupService.save(sysUserGroup);
            ajaxResult.setCode(0);
            ajaxResult.setMsg("添加成功！");
        }
        return ajaxResult;
    }

    /**
     * 修改标签分组
     */
    @ApiOperation("修改标签分组接口")
    @PreAuthorize("@ss.hasPermi('cms:group:edit')")
    @Log(title = "标签分组", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SysUserGroup sysUserGroup) {
        AjaxResult ajaxResult = new AjaxResult();
        SysUserGroup userGroup = sysUserGroupService.findByName(sysUserGroup.getName());
        if(sysUserGroup.getGroupId() != userGroup.getGroupId() && userGroup.getName().equals(sysUserGroup.getName())){
            ajaxResult.setCode(500);
            ajaxResult.setMsg("分组名称已存在！");
        }else{
            LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
            sysUserGroup.setUpdateBy(loginUser.getUsername());
            sysUserGroup.setUpdateTime(new Date());
            sysUserGroupService.save(sysUserGroup);
            ajaxResult.setCode(0);
            ajaxResult.setMsg("修改成功！");
        }

        return ajaxResult;
    }

    /**
     * 删除标签分组
     */
    @ApiOperation("删除标签分组接口")
    @PreAuthorize("@ss.hasPermi('cms:group:remove')")
    @Log(title = "标签分组", businessType = BusinessType.DELETE)
	@DeleteMapping("/{groupIds}")
    public AjaxResult remove(@PathVariable Long[] groupIds) {

        sysUserGroupService.deleteByIds(Arrays.asList(groupIds));
        return AjaxResult.success();
    }
}
