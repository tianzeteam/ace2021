package com.yuejike.web.controller.cms;

import com.yuejike.common.core.domain.MapResult;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsCity;
import com.yuejike.cms.service.ICmsCityService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 城市字典Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-26
 */
@RestController
@RequestMapping("/cms/city")
@Api(tags = "A-B-C-城市字典接口",description = "城市字典接口")
public class CmsCityController extends BaseController {
    @Autowired
    private ICmsCityService cmsCityService;
    @Autowired
    private TokenService tokenService;

    /**
     * 查询城市字典列表
     */
//     @ApiOperation("查询城市字典列表接口")
// //    @PreAuthorize("@ss.hasPermi('cms:city:list')")
//     @GetMapping("/list")
//     public TableDataInfo<CmsCity> list(CmsCity cmsCity) {
//         Page<CmsCity> page = cmsCityService.findCmsCityPage(cmsCity);
//         return getDataTable(page);
//     }

    @ApiOperation("查询城市字典列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:city:list')")
    @GetMapping("/list")
    public MapResult list(CmsCity cmsCity) {
        List<CmsCity> list = cmsCityService.findCmsCityList(cmsCity);
        return MapResult.success("查询成功",list);
    }

    /**
     * 导出城市字典列表
     */
    @ApiOperation("导出城市字典列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:city:export')")
    @Log(title = "城市字典", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsCity cmsCity) {
        List<CmsCity> list = cmsCityService.findCmsCityList(cmsCity);
        ExcelUtil<CmsCity> util = new ExcelUtil<>(CmsCity.class);
        return util.exportExcel(list, "city");
    }

    /**
     * 获取城市字典详细信息
     */
    @ApiOperation("获取城市字典详细信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:city:query')")
    @GetMapping(value = "/{cityId}")
    public AjaxResult<CmsCity> getInfo(@PathVariable("cityId") Long cityId) {
        return AjaxResult.success(cmsCityService.findById(cityId));
    }

    /**
     * 新增城市字典
     */
    @ApiOperation("新增城市字典接口")
    @PreAuthorize("@ss.hasPermi('cms:city:add')")
    @Log(title = "城市字典", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsCity cmsCity) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsCity.setCreateBy(loginUser.getUsername());
        cmsCity.setCreateTime(new Date());
        cmsCity.setDelFlag("0");
        cmsCityService.save(cmsCity);
        return AjaxResult.success();
    }

    /**
     * 修改城市字典
     */
    @ApiOperation("修改城市字典接口")
    @PreAuthorize("@ss.hasPermi('cms:city:edit')")
    @Log(title = "城市字典", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsCity cmsCity) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsCity.setUpdateBy(loginUser.getUsername());
        cmsCity.setUpdateTime(new Date());
        cmsCityService.save(cmsCity);
        return AjaxResult.success();
    }

    /**
     * 删除城市字典
     */
    @ApiOperation("删除城市字典接口")
    @PreAuthorize("@ss.hasPermi('cms:city:remove')")
    @Log(title = "城市字典", businessType = BusinessType.DELETE)
	@DeleteMapping("/{cityIds}")
    public AjaxResult remove(@PathVariable Long[] cityIds) {
        cmsCityService.deleteByIds(Arrays.asList(cityIds));
        return AjaxResult.success();
    }
}
