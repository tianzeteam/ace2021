package com.yuejike.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Pattern;
import java.io.Serializable;

@Data
@ApiModel("绑定手机或者更换手机信息")
public class BindMobileDTO implements Serializable{

    @Pattern(regexp = "^\\s{0}$|^0{0,1}(13[0-9]|15[0-9]|16[0-9]|17[0-9]|14[0-9]|18[0-9]|19[0-9])[0-9]{8}$")
    @ApiModelProperty(value = "用户手机号")
    private String phonenumber;

    @ApiModelProperty(value = "验证码")
    private String code;
}
