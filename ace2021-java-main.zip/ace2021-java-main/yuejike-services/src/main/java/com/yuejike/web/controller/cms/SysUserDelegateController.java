package com.yuejike.web.controller.cms;

import com.yuejike.cms.dto.SysUserDelegateDTO;
import com.yuejike.cms.service.ISysUserAudienceService;
import com.yuejike.cms.service.ISysUserExhibitorService;
import com.yuejike.cms.service.ISysUserMediaService;
import com.yuejike.common.core.domain.entity.SysRole;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.system.service.ISysUserService;
import org.springframework.beans.BeanUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.SysUserDelegate;
import com.yuejike.cms.service.ISysUserDelegateService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 会议代表表Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-27
 */
@RestController
@RequestMapping("/cms/delegate")
@Api(tags = "B-会议代表信息接口",description = "会议代表信息借口")
public class SysUserDelegateController extends BaseController {
    @Autowired
    private ISysUserDelegateService sysUserDelegateService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private ISysUserService sysUserService;
    @Autowired
    private ISysUserExhibitorService sysUserExhibitorService;
    @Autowired
    private ISysUserMediaService sysUserMediaService;
    @Autowired
    private ISysUserAudienceService sysUserAudienceService;
    /**
     * 查询会议代表列表
     */
    @ApiOperation("查询会议代表列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:delegate:list')")
    @GetMapping("/list")
    public TableDataInfo<SysUserDelegate> list(SysUserDelegate sysUserDelegate) {
        Page<SysUserDelegate> page = sysUserDelegateService.findSysUserDelegatePage(sysUserDelegate);
        return getDataTable(page);
    }

    /**
     * 导出会议代表列表
     */
    @ApiOperation("导出会议代表列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:delegate:export')")
    @Log(title = "会议代表", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(SysUserDelegate sysUserDelegate) {
        List<SysUserDelegate> list = sysUserDelegateService.findSysUserDelegateList(sysUserDelegate);
        list.forEach(item->{
            item.setUserName(item.getUser().getUserName());
            item.setPhoneNumber(item.getUser().getPhonenumber());
            item.setEmail(item.getUser().getEmail());
            item.setCityName(item.getCity().getCityName());
            item.setProvinceName(item.getProvince().getProvinceName());
            item.setCountryName(item.getCountry().getCountryName());
            item.setReviewStatus(formatterReviewStatus(item.getUser().getReviewStatus()));
        });
        ExcelUtil<SysUserDelegate> util = new ExcelUtil<>(SysUserDelegate.class);
        return util.exportExcel(list, "delegate");
    }

    private String formatterReviewStatus(String reviewStatus){
        switch (reviewStatus){
            case "1":
                return "审核通过";
            case "2":
                return "审核拒绝";
            default:
                return  "待审核";
        }
    }
    /**
     * 获取会议代表详细信息
     */
    @ApiOperation("获取会议代表详细信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:delegate:query')")
    @GetMapping(value = "/{userId}")
    public AjaxResult<SysUserDelegate> getInfo(@PathVariable("userId") Long userId) {
        return AjaxResult.success(sysUserDelegateService.findById(userId));
    }

    /**
     * 新增会议代表
     */
    @ApiOperation("新增会议代表接口")
//    @PreAuthorize("@ss.hasPermi('cms:delegate:add')")
    @Log(title = "会议代表", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SysUserDelegateDTO sysUserDelegateDTO) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser != null && loginUser.getUser() != null) {
            if(!loginUser.getUser().getUserId().equals(sysUserDelegateDTO.getUserId())){
                return AjaxResult.error("无权操作，只有用户本人可提交认证");
            }
            SysUser user = sysUserService.selectUserById(sysUserDelegateDTO.getUserId());
            if (user == null) {
                return AjaxResult.error("未知错误，未找到数据库记录");
            }
            //角色转化
            if(!user.getUserType().equals(UserType.HYDB.getCode())){
                String[] arrUserType = {"02","03","04","05","06"};//可转化角色列表
                Set<String> userTypes = new HashSet<>(Arrays.asList(arrUserType));
                if(!userTypes.contains(user.getUserType())){
                    return AjaxResult.error("此用户类型不支持转化");
                }
                if((user.getUserType().equals(UserType.CZS.getCode()) && sysUserExhibitorService.findById(user.getUserId()) != null)
                        || (user.getUserType().equals(UserType.MT.getCode()) && sysUserMediaService.findById(user.getUserId()) != null)
                        || (user.getUserType().equals(UserType.ZYGZ.getCode()) && sysUserAudienceService.findById(user.getUserId()) != null)){
                    return AjaxResult.error("用户已经提交认证，无法再认证为其他角色");
                }
                user.setUserType(UserType.HYDB.getCode());
                user.setUpdateTime(new Date());
                user.setUpdateBy(loginUser.getUsername());
                user.setReviewStatus("0");
                user.setRoleIds(null);
                sysUserService.updateUser(user);
            }
            //提交认证
            SysUserDelegate sysUserDelegate = new SysUserDelegate();
            BeanUtils.copyProperties(sysUserDelegateDTO,sysUserDelegate);
            sysUserDelegate.setCreateBy(loginUser.getUsername());
            sysUserDelegate.setCreateTime(new Date());
            sysUserDelegate.setDelFlag("0");
            sysUserDelegateService.save(sysUserDelegate);
            return AjaxResult.success();
        }else{
            return AjaxResult.error("未登录或登录失效，请重新登录");
        }
    }

    /**
     * 修改会议代表
     */
    @ApiOperation("修改会议代表接口")
//    @PreAuthorize("@ss.hasPermi('cms:delegate:edit')")
    @Log(title = "会议代表", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SysUserDelegateDTO sysUserDelegateDTO) {

        try{
            SysUserDelegate sysUserDelegate = new SysUserDelegate();
            BeanUtils.copyProperties(sysUserDelegateDTO,sysUserDelegate);
            LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());

            if(StringUtils.isNotBlank(sysUserDelegateDTO.getReviewStatus()) && sysUserDelegateDTO.getReviewStatus().equals("2")){
                //用户被拒绝后再次提交审核时,将审核状态修改待审核
                sysUserService.updateReviewStatus(sysUserDelegateDTO.getUserId());
                SysUserDelegate userDelegate = sysUserDelegateService.findById(sysUserDelegateDTO.getUserId());
                userDelegate.setCompanyName(sysUserDelegateDTO.getCompanyName());
                userDelegate.setName(sysUserDelegateDTO.getName());
                userDelegate.setIdCard(sysUserDelegateDTO.getIdCard());
                userDelegate.setCountryId(sysUserDelegateDTO.getCountryId());
                userDelegate.setProvinceId(sysUserDelegateDTO.getProvinceId());
                userDelegate.setCityId(sysUserDelegateDTO.getCityId());
                userDelegate.setConferenceType(sysUserDelegateDTO.getConferenceType());
                userDelegate.setConferenceInfo(sysUserDelegateDTO.getConferenceInfo());
                userDelegate.setHotel(sysUserDelegateDTO.getHotel());
                userDelegate.setUpdateBy(loginUser.getUsername());
                userDelegate.setUpdateTime(new Date());
                sysUserDelegateService.save(userDelegate);
            }else{
                sysUserDelegate.setUpdateBy(loginUser.getUsername());
                sysUserDelegate.setUpdateTime(new Date());
                sysUserDelegateService.save(sysUserDelegate);
            }
            return AjaxResult.success();
        }catch (Exception ex) {
            ex.printStackTrace();
            logger.error(ex.getMessage());
            return AjaxResult.error(ex.getMessage());
        }
    }

    /**
     * 删除会议代表
     */
    @ApiOperation("删除会议代表接口")
    @PreAuthorize("@ss.hasPermi('cms:delegate:remove')")
    @Log(title = "会议代表", businessType = BusinessType.DELETE)
	@DeleteMapping("/{userIds}")
    public AjaxResult remove(@PathVariable Long[] userIds) {
        sysUserDelegateService.deleteByIds(Arrays.asList(userIds));
        return AjaxResult.success();
    }
}
