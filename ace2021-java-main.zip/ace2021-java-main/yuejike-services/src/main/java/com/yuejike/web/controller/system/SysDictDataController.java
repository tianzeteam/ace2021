package com.yuejike.web.controller.system;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import com.yuejike.common.core.domain.MapResult;
import com.yuejike.framework.web.domain.server.Sys;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.entity.SysDictData;
import com.yuejike.common.core.page.TableDataInfo;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.common.utils.SecurityUtils;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.system.service.ISysDictDataService;
import com.yuejike.system.service.ISysDictTypeService;

/**
 * 数据字典信息
 *
 * @author yuejike
 */
@RestController
@RequestMapping("/system/dict/data")
public class SysDictDataController extends BaseController {
    @Autowired
    private ISysDictDataService dictDataService;

    @Autowired
    private ISysDictTypeService dictTypeService;

    // @PreAuthorize("@ss.hasPermi('system:dict:list')")
    @GetMapping("/list")
    public TableDataInfo<SysDictData> list(SysDictData dictData) {
        Page<SysDictData> page = dictDataService.selectDictDataList(dictData);
        return getDataTable(page);
    }

    @Log(title = "字典数据", businessType = BusinessType.EXPORT)
    // @PreAuthorize("@ss.hasPermi('system:dict:export')")
    @GetMapping("/export")
    public AjaxResult export(SysDictData dictData) {
        Page<SysDictData> page = dictDataService.selectDictDataList(dictData);
        List<SysDictData> list = page.getContent();
        ExcelUtil<SysDictData> util = new ExcelUtil<SysDictData>(SysDictData.class);
        return util.exportExcel(list, "字典数据");
    }

    /**
     * 查询字典数据详细
     */
    // @PreAuthorize("@ss.hasPermi('system:dict:query')")
    @GetMapping(value = "/{dictCode}")
    public AjaxResult<SysDictData> getInfo(@PathVariable Long dictCode) {
        return AjaxResult.success(dictDataService.selectDictDataById(dictCode));
    }

    /**
     * 根据字典类型查询字典数据信息
     */
    @GetMapping(value = "/type/{dictType}")
    public MapResult dictType(@PathVariable String dictType) {
        List<SysDictData> data = dictTypeService.selectDictDataByType(dictType);
        if (StringUtils.isNull(data)) {
            data = new ArrayList<SysDictData>();
        }
        return MapResult.success(data);
    }

    /**
     * 新增字典类型
     */
    // @PreAuthorize("@ss.hasPermi('system:dict:add')")
    @Log(title = "字典数据", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@Validated @RequestBody SysDictData dict) {
        AjaxResult ajaxResult  = new AjaxResult();
        //查询字典标签是否存在
        List<SysDictData> sysDictDataList = dictDataService.findByDictLabel(dict.getDictLabel());
        if(sysDictDataList.size() >0){
            ajaxResult.setCode(500);
            ajaxResult.setMsg("标签名称已存在");
        }else{
            dict.setCreateBy(SecurityUtils.getUsername());
            dict.setCreateTime(new Date());
            dictDataService.insertDictData(dict);
            ajaxResult.setCode(0);
            ajaxResult.setMsg("添加成功");
        }
        return ajaxResult;
    }

    /**
     * 修改保存字典类型
     */
    // @PreAuthorize("@ss.hasPermi('system:dict:edit')")
    @Log(title = "字典数据", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@Validated @RequestBody SysDictData dict) {
        AjaxResult ajaxResult = new AjaxResult();
        List<SysDictData> sysDictDataList = dictDataService.findByDictLabel(dict.getDictLabel());
        sysDictDataList.stream().filter(s->s.getDictCode() != dict.getDictCode() && s.getDictLabel().equals(dict.getDictLabel())).collect(Collectors.toList());
        if(sysDictDataList.size() >0){
            ajaxResult.setCode(500);
            ajaxResult.setMsg("名称已存在！");
        }else{
            dict.setUpdateBy(SecurityUtils.getUsername());
            dict.setUpdateTime(new Date());
            dictDataService.updateDictData(dict);
            ajaxResult.setCode(0);
            ajaxResult.setMsg("修改成功！");
        }
        return ajaxResult;
    }

    /**
     * 删除字典类型
     */
    // @PreAuthorize("@ss.hasPermi('system:dict:remove')")
    @Log(title = "字典类型", businessType = BusinessType.DELETE)
    @DeleteMapping("/{dictCodes}")
    public AjaxResult remove(@PathVariable Long[] dictCodes) {
        return toAjax(dictDataService.deleteDictDataByIds(dictCodes));
    }
}
