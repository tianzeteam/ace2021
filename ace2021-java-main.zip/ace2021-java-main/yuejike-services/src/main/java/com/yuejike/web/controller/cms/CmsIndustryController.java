package com.yuejike.web.controller.cms;

import com.yuejike.cms.domain.CmsEnroll;
import com.yuejike.cms.domain.CmsIndustry;
import com.yuejike.cms.service.ICmsIndustryService;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.page.TableDataInfo;
import com.yuejike.web.util.IndustryTreeBuilerUtil;
import com.yuejike.web.vo.CmsIndustryTreeVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/cms/industry")
@Api(tags = "行业信息")
public class CmsIndustryController extends BaseController {

    @Autowired
    ICmsIndustryService cmsIndustryService;

    /**
     * 行业多级联选列表
     */
    @ApiOperation("行业多级联选列表")
    @GetMapping("/tree")
    public AjaxResult tree() {
        List<CmsIndustry> cmsIndustries = cmsIndustryService.findAll();
        List<CmsIndustryTreeVo> cmsIndustryTreeVos = new IndustryTreeBuilerUtil(cmsIndustries).getTree();
        return AjaxResult.success((Serializable) cmsIndustryTreeVos);
    }
}
