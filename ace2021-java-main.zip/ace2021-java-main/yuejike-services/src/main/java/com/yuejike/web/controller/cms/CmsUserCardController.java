package com.yuejike.web.controller.cms;

import com.yuejike.common.utils.StringUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsUserCard;
import com.yuejike.cms.service.ICmsUserCardService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 名片Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/card")
@Api(tags = "名片",description = "名片")
public class CmsUserCardController extends BaseController {
    @Autowired
    private ICmsUserCardService cmsUserCardService;
    @Autowired
    private TokenService tokenService;

    /**
     * 查询名片列表
     */
    @ApiOperation("查询名片列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:card:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsUserCard> list(CmsUserCard cmsUserCard) {
        Page<CmsUserCard> page = cmsUserCardService.findCmsUserCardPage(cmsUserCard);
        return getDataTable(page);
    }

    /**
     * 导出名片列表
     */
    @ApiOperation("导出名片列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:card:export')")
    @Log(title = "名片", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsUserCard cmsUserCard) {
        List<CmsUserCard> list = cmsUserCardService.findCmsUserCardList(cmsUserCard);
        ExcelUtil<CmsUserCard> util = new ExcelUtil<>(CmsUserCard.class);
        return util.exportExcel(list, "card");
    }

    @ApiOperation("获取名片详细信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:card:query')")
    @GetMapping()
    public AjaxResult<CmsUserCard> getInfo() {
        CmsUserCard userCard = new CmsUserCard();
        try {
            LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
            CmsUserCard cmsUserCard = new CmsUserCard();
            cmsUserCard.setUserId(loginUser.getUser().getUserId());
            Page<CmsUserCard> cmsUserCardPage = cmsUserCardService.findCmsUserCardPage(cmsUserCard);
            if(cmsUserCardPage !=null){
                userCard = cmsUserCardPage.getContent().get(0);
            }
            return AjaxResult.success(userCard);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return AjaxResult.success(userCard);
    }

    /**
     * 新增名片
     */
    @ApiOperation("新增名片接口")
//    @PreAuthorize("@ss.hasPermi('cms:card:add')")
    @Log(title = "名片", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsUserCard cmsUserCard) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        CmsUserCard userCard = cmsUserCardService.findByUserId(loginUser.getUser().getUserId());
        if(userCard != null) {
            cmsUserCard.setCreateBy(userCard.getCreateBy());
            cmsUserCard.setCreateTime(userCard.getCreateTime());
            cmsUserCard.setUpdateBy(loginUser.getUsername());
            cmsUserCard.setUpdateTime(new Date());
            cmsUserCard.setCardId(userCard.getCardId());
            cmsUserCard.setDelFlag(userCard.getDelFlag());
            cmsUserCardService.save(cmsUserCard);
        }else {
            cmsUserCard.setCreateBy(loginUser.getUsername());
            cmsUserCard.setUserId(loginUser.getUser().getUserId());
            cmsUserCard.setCreateTime(new Date());
            // cmsUserCard.setName(loginUser.getUser().getNickName());
            cmsUserCard.setDelFlag("0");
            cmsUserCardService.save(cmsUserCard);
        }
        return AjaxResult.success();
    }

    /**
     * 修改名片
     */
    @ApiOperation("修改名片接口")
//    @PreAuthorize("@ss.hasPermi('cms:card:edit')")
    @Log(title = "名片", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsUserCard cmsUserCard) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());

        CmsUserCard userCard = cmsUserCardService.findByUserId(loginUser.getUser().getUserId());
        if(userCard != null) {
            cmsUserCard.setCreateBy(userCard.getCreateBy());
            cmsUserCard.setCreateTime(userCard.getCreateTime());
            cmsUserCard.setUpdateBy(loginUser.getUsername());
            cmsUserCard.setUpdateTime(new Date());
            cmsUserCard.setCardId(userCard.getCardId());
            cmsUserCard.setDelFlag(userCard.getDelFlag());
            cmsUserCardService.save(cmsUserCard);
        }else {
            cmsUserCard.setCreateBy(loginUser.getUsername());
            cmsUserCard.setUserId(loginUser.getUser().getUserId());
            cmsUserCard.setCreateTime(new Date());
            // cmsUserCard.setName(loginUser.getUser().getNickName());
            cmsUserCard.setDelFlag("0");
            cmsUserCardService.save(cmsUserCard);
        }
        return AjaxResult.success();
    }

    /**
     * 删除名片
     */
    @ApiOperation("删除名片接口")
    @PreAuthorize("@ss.hasPermi('cms:card:remove')")
    @Log(title = "名片", businessType = BusinessType.DELETE)
	@DeleteMapping("/{cardIds}")
    public AjaxResult remove(@PathVariable Long[] cardIds) {
        cmsUserCardService.deleteByIds(Arrays.asList(cardIds));
        return AjaxResult.success();
    }
}
