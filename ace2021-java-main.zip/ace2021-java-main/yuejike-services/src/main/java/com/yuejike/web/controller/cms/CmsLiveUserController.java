package com.yuejike.web.controller.cms;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsLiveUser;
import com.yuejike.cms.service.ICmsLiveUserService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 直播角色权限关联Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/live_user")
@Api(tags = "直播角色权限关联",description = "直播角色权限关联")
public class CmsLiveUserController extends BaseController {
    @Autowired
    private ICmsLiveUserService cmsLiveUserService;
    @Autowired
    private TokenService tokenService;

    /**
     * 查询直播角色权限关联列表
     */
    @ApiOperation("查询直播角色权限关联列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:user:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsLiveUser> list(CmsLiveUser cmsLiveUser) {
        Page<CmsLiveUser> page = cmsLiveUserService.findCmsLiveUserPage(cmsLiveUser);
        return getDataTable(page);
    }

    /**
     * 导出直播角色权限关联列表
     */
    @ApiOperation("导出直播角色权限关联列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:user:export')")
    @Log(title = "直播角色权限关联", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsLiveUser cmsLiveUser) {
        List<CmsLiveUser> list = cmsLiveUserService.findCmsLiveUserList(cmsLiveUser);
        ExcelUtil<CmsLiveUser> util = new ExcelUtil<>(CmsLiveUser.class);
        return util.exportExcel(list, "user");
    }

    /**
     * 获取直播角色权限关联详细信息
     */
    @ApiOperation("获取直播角色权限关联详细信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:user:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult<CmsLiveUser> getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(cmsLiveUserService.findById(id));
    }

    /**
     * 新增直播角色权限关联
     */
    @ApiOperation("新增直播角色权限关联接口")
//    @PreAuthorize("@ss.hasPermi('cms:user:add')")
    @Log(title = "直播角色权限关联", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsLiveUser cmsLiveUser) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsLiveUser.setCreateBy(loginUser.getUsername());
        cmsLiveUser.setCreateTime(new Date());
        cmsLiveUser.setDelFlag("0");
        cmsLiveUserService.save(cmsLiveUser);
        return AjaxResult.success();
    }

    /**
     * 修改直播角色权限关联
     */
    @ApiOperation("修改直播角色权限关联接口")
//    @PreAuthorize("@ss.hasPermi('cms:user:edit')")
    @Log(title = "直播角色权限关联", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsLiveUser cmsLiveUser) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsLiveUser.setUpdateBy(loginUser.getUsername());
        cmsLiveUser.setUpdateTime(new Date());
        cmsLiveUserService.save(cmsLiveUser);
        return AjaxResult.success();
    }

    /**
     * 删除直播角色权限关联
     */
    @ApiOperation("删除直播角色权限关联接口")
    @PreAuthorize("@ss.hasPermi('cms:user:remove')")
    @Log(title = "直播角色权限关联", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        cmsLiveUserService.deleteByIds(Arrays.asList(ids));
        return AjaxResult.success();
    }
}
