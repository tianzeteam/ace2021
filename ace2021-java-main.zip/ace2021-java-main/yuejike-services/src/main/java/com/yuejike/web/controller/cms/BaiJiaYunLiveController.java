package com.yuejike.web.controller.cms;

import com.yuejike.cms.domain.CmsLive;
import com.yuejike.cms.service.ICmsLiveService;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.web.util.SignUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author song
 * @date 2021年09月13日 13:46
 */
@RestController
@RequestMapping("/cms/baijiayun/live/")
@Api(tags = "百家云直播",description = "直播")
public class BaiJiaYunLiveController  extends BaseController {

    @Autowired
    private ICmsLiveService cmsLiveService;


    /**
     * 获取直播上下课状态
     * @return
     */
    // @ApiOperation("获取直播上下课状态")
    // @PostMapping(value = "/getClassStatus")
    // private AjaxResult getClassStatus(@RequestParam Map<String, Object> map){
    //     System.out.println("----进入接收直播上下课的方法中----");
    //     System.out.println("------"+map+"-------");
    //     CmsLive live = cmsLiveService.findByRoomId(map.get("room_id").toString());
    //     if(map.get("op").equals("start")){
    //         live.setProcess("1");
    //     }else if(map.get("op").equals("end")){
    //         live.setProcess("2");
    //     }
    //     cmsLiveService.save(live);
    //     return AjaxResult.success();
    // }


    public static void main(String[] args) {
        Date date = new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
        Map map = new HashMap();
        map.put("room_id","21091341992013");
        map.put("op","start");
        map.put("op_time","df.format(date)");
        map.put("qid","21091341992013");
        map.put("timestamp",date.getTime()/1000);
        String sign = SignUtil.getSign(map);
        map.put("sign",sign);

        System.out.println("当前时间"+df.format(date));
        System.out.println("时间戳"+date.getTime()/1000);
        System.out.println("=====sign====="+sign);

    }
}
