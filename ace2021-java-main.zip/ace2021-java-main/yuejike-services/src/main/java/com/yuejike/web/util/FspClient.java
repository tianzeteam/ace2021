package com.yuejike.web.util;

import com.alibaba.fastjson.JSONObject;
import com.iflytek.fsp.shield.java.sdk.constant.HttpConstant;
import com.iflytek.fsp.shield.java.sdk.constant.SdkConstant;
import com.iflytek.fsp.shield.java.sdk.enums.Method;
import com.iflytek.fsp.shield.java.sdk.enums.ParamPosition;
import com.iflytek.fsp.shield.java.sdk.http.ApiClient;
import com.iflytek.fsp.shield.java.sdk.http.BaseApp;
import com.iflytek.fsp.shield.java.sdk.model.ApiRequest;
import com.iflytek.fsp.shield.java.sdk.model.ApiResponse;
import com.iflytek.fsp.shield.java.sdk.model.MultipartFile;
import com.iflytek.fsp.shield.java.sdk.model.ApiSignStrategy;
import com.iflytek.fsp.shield.java.sdk.model.ResultInfo;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.MapResult;


/**
 * 安康码身份验证
 * @author kosku
 *
 */
public class FspClient extends BaseApp {

    public FspClient() {
        this.apiClient = new ApiClient();
        this.apiClient.init();

        // 管理平台应用查看处获取并修改
        this.appId = "1b26404bcd9b4bcfb9b889f91796d126";
        // 管理平台应用查看处获取并修改
        this.appSecret = "9EF6FF50540E3DBEB0902D0917C54FFF";

        // 核心层ip
//        this.host = "60.167.58.86";//dev外网环境
        this.host = "172.25.1.163";
        //核心层上下文
        this.contextPath ="";

        // 核心层暴露的http端口
        this.httpPort = 4989;

        // 核心层暴露的https端口
        this.httpsPort = 443;

        // sdk生成时选择的环境 RELEASE=线上  TEST=测试 PRE=预生产
        this.stage = "RELEASE";
        // 此参数暂时无用
        this.equipmentNo = "XXX";
        // 此参数暂时无用
        this.signStrategyUrl = "/getSignStrategy";
        // 此参数暂时无用
        this.tokenUrl = "/getTokenUrl";
        // 管理平台应用查看处获取并修改
        this.publicKey = "305C300D06092A864886F70D0101010500034B003048024100A91476320CF7DEA59E4D798DA5AFD02D07F4164BB00239050E81257F3F0B9B50A3DDC7B2CA3B5AE3A5C2E8B81F93BD376DFC2E8F26E62E2196ED861B3FF5528B0203010001";
        // 关闭云锁验证
        this.icloudlockEnabled = false;
    }


    /**
     * 验证身份信息
     */
    public ApiResponse CheckIdCard(String userName,String idcardNo) {
        ApiRequest apiRequest = new ApiRequest(HttpConstant.SCHEME_HTTP, Method.POST, "/prov-city-rest/check/checkHealthyByIdCardNo", SdkConstant.AUTH_TYPE_DEFAULT, "1");


        apiRequest.addParam("authToken", "", ParamPosition.QUERY, false);

        apiRequest.addParam("checkUsrIdCard", "340521199401201814", ParamPosition.QUERY, false);

        apiRequest.addParam("checkUsrName", "沙鹏", ParamPosition.QUERY, false);

        apiRequest.addParam("cityNo", "340200000000", ParamPosition.QUERY, false);

        apiRequest.addParam("dataSource", "", ParamPosition.QUERY, false);

        apiRequest.addParam("idcardNo", idcardNo, ParamPosition.QUERY, false);

        apiRequest.addParam("siteId", "608DDCE978654874905CAD78C8991204", ParamPosition.QUERY, false);

        apiRequest.addParam("userName", userName, ParamPosition.QUERY, false);

        return syncInvoke(apiRequest);
    }

    /**
     * 验证身份信息
     * 返回错误信息
     */
    public AjaxResult GetUserHealth(String userName, String idCardNo) {

        // 请求
        ApiResponse apiResponse;
        JSONObject jsonDataReal;

        // 验证身份证信息
        try{
            // send
            apiResponse = this.CheckIdCard(userName,idCardNo);

            // code err
            if(apiResponse.getStatusCode() != 200){
                return AjaxResult.error("安康码码色获取失败，请重试[01]");
            }

            // statusCode == 200
            JSONObject jsonObject = JSONObject.parseObject(new String(apiResponse.getBody()));

            // errCode 错误
            if(!jsonObject.get("errCode").equals("-1")){
                return AjaxResult.error("安康码码色获取失败，请重试[02]");
            }

            // 解析data 错误
            JSONObject jsonData = jsonObject.getJSONObject("data");
            if(!jsonData.getString("errCode").equals("-1")){

                // 如果未申请安康码
                if(jsonData.getString("errMsg").equals("该人员未申请安康码")){
                    return AjaxResult.error("您暂未申请安康码，暂时无法核验您的健康状态，请通过皖事通或支付宝申请安康码后重试或线下预约门票。");
                }

                // 其他错误
                return AjaxResult.error(jsonData.getString("errMsg"));
            }

            // 数据
            jsonDataReal = jsonData.getJSONObject("data");

        }catch (Exception e){
            return AjaxResult.error("安康码码色获取失败，请重试[03]");
        }

        // 健康状态
        if(!jsonDataReal.getString("healthLevel").equals("1")){
            return AjaxResult.error("您的健康码码色异常，请核实您的健康状况，可通过皖事通申诉转绿码后预约入场。");
        }

        return null;

    }

}
