package com.yuejike.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Pattern;
import java.io.Serializable;

@Data
@ApiModel("绑定微信手机或者更换手机信息")
public class BindWxMobileDTO implements Serializable{


    @ApiModelProperty(value = "手机号码加密数据")
    private String encryptedData;

    @ApiModelProperty(value = "微信用户openid")
    private String openId;

    @ApiModelProperty(value = "加密算法的初始向量")
    private String iv;

    @ApiModelProperty(value = "小程序用户昵称")
    private String nickName;

    @ApiModelProperty(value = "用户头像")
    private String avatar;
}
