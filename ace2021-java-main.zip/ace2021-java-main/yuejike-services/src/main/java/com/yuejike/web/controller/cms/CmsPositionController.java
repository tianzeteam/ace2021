package com.yuejike.web.controller.cms;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsPosition;
import com.yuejike.cms.service.ICmsPositionService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 位置信息管理Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/position")
@Api(tags = "位置信息管理",description = "位置信息管理")
public class CmsPositionController extends BaseController {
    @Autowired
    private ICmsPositionService cmsPositionService;
    @Autowired
    private TokenService tokenService;

    /**
     * 查询位置信息管理列表
     */
    @ApiOperation("查询位置信息管理列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:position:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsPosition> list(CmsPosition cmsPosition) {
        Page<CmsPosition> page = cmsPositionService.findCmsPositionPage(cmsPosition);
        return getDataTable(page);
    }

    /**
     * 导出位置信息管理列表
     */
    @ApiOperation("导出位置信息管理列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:position:export')")
    @Log(title = "位置信息管理", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsPosition cmsPosition) {
        List<CmsPosition> list = cmsPositionService.findCmsPositionList(cmsPosition);
        ExcelUtil<CmsPosition> util = new ExcelUtil<>(CmsPosition.class);
        return util.exportExcel(list, "position");
    }

    /**
     * 获取位置信息管理详细信息
     */
    @ApiOperation("获取位置信息管理详细信息接口")
    @PreAuthorize("@ss.hasPermi('cms:position:query')")
    @GetMapping(value = "/{positionId}")
    public AjaxResult<CmsPosition> getInfo(@PathVariable("positionId") Long positionId) {
        return AjaxResult.success(cmsPositionService.findById(positionId));
    }

    /**
     * 新增位置信息管理
     */
    @ApiOperation("新增位置信息管理接口")
    @PreAuthorize("@ss.hasPermi('cms:position:add')")
    @Log(title = "位置信息管理", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsPosition cmsPosition) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsPosition.setCreateBy(loginUser.getUsername());
        cmsPosition.setCreateTime(new Date());
        cmsPosition.setDelFlag("0");
        cmsPositionService.save(cmsPosition);
        return AjaxResult.success();
    }

    /**
     * 修改位置信息管理
     */
    @ApiOperation("修改位置信息管理接口")
    @PreAuthorize("@ss.hasPermi('cms:position:edit')")
    @Log(title = "位置信息管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsPosition cmsPosition) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsPosition.setUpdateBy(loginUser.getUsername());
        cmsPosition.setUpdateTime(new Date());
        cmsPositionService.save(cmsPosition);
        return AjaxResult.success();
    }

    /**
     * 删除位置信息管理
     */
    @ApiOperation("删除位置信息管理接口")
    @PreAuthorize("@ss.hasPermi('cms:position:remove')")
    @Log(title = "位置信息管理", businessType = BusinessType.DELETE)
	@DeleteMapping("/{positionIds}")
    public AjaxResult remove(@PathVariable Long[] positionIds) {
        cmsPositionService.deleteByIds(Arrays.asList(positionIds));
        return AjaxResult.success();
    }
}
