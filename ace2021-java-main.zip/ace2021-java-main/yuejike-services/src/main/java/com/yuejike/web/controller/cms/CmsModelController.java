package com.yuejike.web.controller.cms;

import com.yuejike.cms.domain.CmsContent;
import com.yuejike.cms.service.ICmsContentService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsModel;
import com.yuejike.cms.service.ICmsModelService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 模型Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/model")
@Api(tags = "模型",description = "模型")
public class CmsModelController extends BaseController {
    @Autowired
    private ICmsModelService cmsModelService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private ICmsContentService contentService;


    /**
     * 查询模型列表
     */
    @ApiOperation("查询模型列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:model:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsModel> list(CmsModel cmsModel) {
        Page<CmsModel> page = cmsModelService.findCmsModelPage(cmsModel);
        return getDataTable(page);
    }

    /**
     * 导出模型列表
     */
    @ApiOperation("导出模型列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:model:export')")
    @Log(title = "模型", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsModel cmsModel) {
        List<CmsModel> list = cmsModelService.findCmsModelList(cmsModel);
        ExcelUtil<CmsModel> util = new ExcelUtil<>(CmsModel.class);
        return util.exportExcel(list, "model");
    }

    /**
     * 获取模型详细信息
     */
    @ApiOperation("获取模型详细信息接口")
    @PreAuthorize("@ss.hasPermi('cms:model:query')")
    @GetMapping(value = "/{modelId}")
    public AjaxResult<CmsModel> getInfo(@PathVariable("modelId") Long modelId) {
        return AjaxResult.success(cmsModelService.findById(modelId));
    }

    /**
     * 新增模型
     */
    @ApiOperation("新增模型接口")
    @PreAuthorize("@ss.hasPermi('cms:model:add')")
    @Log(title = "模型", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsModel cmsModel) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsModel.setDelFlag("0");
        cmsModel.setCreateBy(loginUser.getUsername());
        cmsModel.setCreateTime(new Date());
        cmsModelService.save(cmsModel);
        return AjaxResult.success();
    }

    /**
     * 修改模型
     */
    @ApiOperation("修改模型接口")
    @PreAuthorize("@ss.hasPermi('cms:model:edit')")
    @Log(title = "模型", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsModel cmsModel) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsModel.setUpdateBy(loginUser.getUsername());
        cmsModel.setUpdateTime(new Date());
        cmsModelService.save(cmsModel);
        return AjaxResult.success();
    }

    /**
     * 删除模型
     */
    @ApiOperation("删除模型接口")
    @PreAuthorize("@ss.hasPermi('cms:model:remove')")
    @Log(title = "模型", businessType = BusinessType.DELETE)
	@DeleteMapping("/{modelIds}")
    public AjaxResult remove(@PathVariable Long[] modelIds) {
        for (Long modelId: modelIds) {
            List<CmsContent> contentList = contentService.findListByModelId(modelId);
            if(contentList.size() >0){
                return AjaxResult.warn("该编号为'"+ modelId+ "'的模型已被应用，不可删除！");
            }
        }
        cmsModelService.deleteByIds(Arrays.asList(modelIds));
        return AjaxResult.success();
    }
}
