package com.yuejike.web.controller.cms;

import com.yuejike.cms.domain.CmsCategory;
import com.yuejike.cms.domain.CmsContent;
import com.yuejike.cms.domain.CmsModel;
import com.yuejike.cms.service.ICmsCategoryService;
import com.yuejike.cms.service.ICmsContentService;
import com.yuejike.cms.service.ICmsModelService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsModelExtend;
import com.yuejike.cms.service.ICmsModelExtendService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 模型扩展信息Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/extend")
@Api(tags = "模型扩展信息",description = "模型扩展信息")
public class CmsModelExtendController extends BaseController {
    @Autowired
    private ICmsModelExtendService cmsModelExtendService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private ICmsModelService modelService;
    @Autowired
    private ICmsContentService contentService;
    @Autowired
    private ICmsCategoryService categoryService;

    /**
     * 查询模型扩展信息列表
     */
    @ApiOperation("查询模型扩展信息列表接口")
    @PreAuthorize("@ss.hasPermi('cms:extend:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsModelExtend> list(CmsModelExtend cmsModelExtend) {
        Page<CmsModelExtend> page = cmsModelExtendService.findCmsModelExtendPage(cmsModelExtend);
        return getDataTable(page);
    }

    /**
     * 导出模型扩展信息列表
     */
    @ApiOperation("导出模型扩展信息列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:extend:export')")
    @Log(title = "模型扩展信息", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsModelExtend cmsModelExtend) {
        List<CmsModelExtend> list = cmsModelExtendService.findCmsModelExtendList(cmsModelExtend);
        ExcelUtil<CmsModelExtend> util = new ExcelUtil<>(CmsModelExtend.class);
        return util.exportExcel(list, "extend");
    }

    /**
     * 获取模型扩展信息详细信息
     */
    @ApiOperation("获取模型扩展信息详细信息接口")
    @PreAuthorize("@ss.hasPermi('cms:extend:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult<CmsModelExtend> getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(cmsModelExtendService.findById(id));
    }

    /**
     * 新增模型扩展信息
     */
    @ApiOperation("新增模型扩展信息接口")
    @PreAuthorize("@ss.hasPermi('cms:extend:add')")
    @Log(title = "模型扩展信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsModelExtend cmsModelExtend) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsModelExtend.setDelFlag("0");
        cmsModelExtend.setCreateBy(loginUser.getUsername());
        cmsModelExtend.setCreateTime(new Date());
        cmsModelExtendService.save(cmsModelExtend);
        return AjaxResult.success();
    }

    /**
     * 修改模型扩展信息
     */
    @ApiOperation("修改模型扩展信息接口")
    @PreAuthorize("@ss.hasPermi('cms:extend:edit')")
    @Log(title = "模型扩展信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsModelExtend cmsModelExtend) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsModelExtend.setUpdateBy(loginUser.getUsername());
        cmsModelExtend.setUpdateTime(new Date());
        cmsModelExtendService.save(cmsModelExtend);
        return AjaxResult.success();
    }

    /**
     * 删除模型扩展信息
     */
    @ApiOperation("删除模型扩展信息接口")
    @PreAuthorize("@ss.hasPermi('cms:extend:remove')")
    @Log(title = "模型扩展信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        for (Long extendId:ids) {
            CmsModelExtend modelExtend = cmsModelExtendService.findById(extendId);
            CmsModel model =modelService.findById(modelExtend.getModelId());
            List<CmsContent> contentList = contentService.findListByModelId(model.getModelId());
            if(contentList.size() >0){
                return AjaxResult.warn("该'"+ model.getName()+ "'模型已被应用，不可删除");
            }
        }
        cmsModelExtendService.deleteByIds(Arrays.asList(ids));
        return AjaxResult.success();
    }
}
