package com.yuejike.web.controller.cms;

import com.yuejike.common.core.domain.MapResult;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsProvince;
import com.yuejike.cms.service.ICmsProvinceService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 省会字典Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-26
 */
@RestController
@RequestMapping("/cms/province")
@Api(tags = "A-B-B-省会字典接口",description = "省会字典接口")
public class CmsProvinceController extends BaseController {
    @Autowired
    private ICmsProvinceService cmsProvinceService;
    @Autowired
    private TokenService tokenService;

    /**
     * 查询省会字典列表
     */
//     @ApiOperation("查询省会字典列表接口")
// //    @PreAuthorize("@ss.hasPermi('cms:province:list')")
//     @GetMapping("/list")
//     public TableDataInfo<CmsProvince> list(CmsProvince cmsProvince) {
//         Page<CmsProvince> page = cmsProvinceService.findCmsProvincePage(cmsProvince);
//         return getDataTable(page);
//     }


    @ApiOperation("查询省会字典列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:province:list')")
    @GetMapping("/list")
    public MapResult list(CmsProvince cmsProvince) {
        List<CmsProvince> list = cmsProvinceService.findCmsProvinceList(cmsProvince);
        return MapResult.success("查询成功",list);
    }

    /**
     * 导出省会字典列表
     */
    @ApiOperation("导出省会字典列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:province:export')")
    @Log(title = "省会字典", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsProvince cmsProvince) {
        List<CmsProvince> list = cmsProvinceService.findCmsProvinceList(cmsProvince);
        ExcelUtil<CmsProvince> util = new ExcelUtil<>(CmsProvince.class);
        return util.exportExcel(list, "province");
    }

    /**
     * 获取省会字典详细信息
     */
    @ApiOperation("获取省会字典详细信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:province:query')")
    @GetMapping(value = "/{provinceId}")
    public AjaxResult<CmsProvince> getInfo(@PathVariable("provinceId") Long provinceId) {
        return AjaxResult.success(cmsProvinceService.findById(provinceId));
    }

    /**
     * 新增省会字典
     */
    @ApiOperation("新增省会字典接口")
    @PreAuthorize("@ss.hasPermi('cms:province:add')")
    @Log(title = "省会字典", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsProvince cmsProvince) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsProvince.setCreateBy(loginUser.getUsername());
        cmsProvince.setCreateTime(new Date());
        cmsProvince.setDelFlag("0");
        cmsProvinceService.save(cmsProvince);
        return AjaxResult.success();
    }

    /**
     * 修改省会字典
     */
    @ApiOperation("修改省会字典接口")
    @PreAuthorize("@ss.hasPermi('cms:province:edit')")
    @Log(title = "省会字典", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsProvince cmsProvince) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsProvince.setUpdateBy(loginUser.getUsername());
        cmsProvince.setUpdateTime(new Date());
        cmsProvinceService.save(cmsProvince);
        return AjaxResult.success();
    }

    /**
     * 删除省会字典
     */
    @ApiOperation("删除省会字典接口")
    @PreAuthorize("@ss.hasPermi('cms:province:remove')")
    @Log(title = "省会字典", businessType = BusinessType.DELETE)
	@DeleteMapping("/{provinceIds}")
    public AjaxResult remove(@PathVariable Long[] provinceIds) {
        cmsProvinceService.deleteByIds(Arrays.asList(provinceIds));
        return AjaxResult.success();
    }
}
