package com.yuejike.web.controller.cms;

import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.page.TableDataInfo;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.cms.domain.ExhibitionMaterials;
import com.yuejike.cms.service.ICmsExhibitionMaterialsService;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.framework.web.service.TokenService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

/**
 * @author JinZJ
 * @version 1.0
 * @Description: 展厅素材
 * @date 2021/11/17 11:05
 */
@RestController
@RequestMapping("/cms/3dmaterials")
@Api(tags = "3D展厅素材")
public class CmsExhibitionMaterialsController extends BaseController {

    @Autowired
    private ICmsExhibitionMaterialsService ICmsExhibitionMaterialsService;
    @Autowired
    private TokenService tokenService;

    @ApiOperation("条件分页查询素材")
    @PreAuthorize("@ss.hasPermi('cms:materials:list')")
    @GetMapping("/list")
    public TableDataInfo<ExhibitionMaterials> list(ExhibitionMaterials exhibitionMaterials){
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser != null && loginUser.getUser() != null
                && (loginUser.getUser().getUserType().equals(UserType.CZS.getCode()) || loginUser.getUser().getUserType().equals(UserType.CZS_JS.getCode()))){
            exhibitionMaterials.setUserId(loginUser.getUser().getUserId());
        }
        Page<ExhibitionMaterials> page = ICmsExhibitionMaterialsService.selectMaterialsList(exhibitionMaterials);
        return getDataTable(page);
    }

    @ApiOperation("新增素材接口")
    @Log(title = "素材管理", businessType = BusinessType.INSERT)
    @PreAuthorize("@ss.hasPermi('cms:materials:add')")
    @PostMapping
    public AjaxResult add(@Validated @RequestBody ExhibitionMaterials exhibitionMaterials) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        exhibitionMaterials.setCreateTime(new Date());
        exhibitionMaterials.setUserId(loginUser.getUser().getUserId());
        return ICmsExhibitionMaterialsService.insertMaterials(exhibitionMaterials) != null ? AjaxResult.success() : AjaxResult.error();
    }

    /**
     * 删除用户
     */
    @ApiOperation("删除素材接口")
    @Log(title = "素材管理", businessType = BusinessType.DELETE)
    @PreAuthorize("@ss.hasPermi('cms:materials:remove')")
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        ICmsExhibitionMaterialsService.deleteMaterialsByIds(ids);
        return AjaxResult.success();
    }

}
