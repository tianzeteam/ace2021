package com.yuejike.web.controller.cms;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsExpositionHall;
import com.yuejike.cms.service.ICmsExpositionHallService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 博览会和场馆关联Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/exposition_hall")
@Api(tags = "博览会和场馆关联",description = "博览会和场馆关联")
public class CmsExpositionHallController extends BaseController {
    @Autowired
    private ICmsExpositionHallService cmsExpositionHallService;
    @Autowired
    private TokenService tokenService;

    /**
     * 查询博览会和场馆关联列表
     */
    @ApiOperation("查询博览会和场馆关联列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:hall:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsExpositionHall> list(CmsExpositionHall cmsExpositionHall) {
        Page<CmsExpositionHall> page = cmsExpositionHallService.findCmsExpositionHallPage(cmsExpositionHall);
        return getDataTable(page);
    }

    /**
     * 导出博览会和场馆关联列表
     */
    @ApiOperation("导出博览会和场馆关联列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:hall:export')")
    @Log(title = "博览会和场馆关联", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsExpositionHall cmsExpositionHall) {
        List<CmsExpositionHall> list = cmsExpositionHallService.findCmsExpositionHallList(cmsExpositionHall);
        ExcelUtil<CmsExpositionHall> util = new ExcelUtil<>(CmsExpositionHall.class);
        return util.exportExcel(list, "hall");
    }

    /**
     * 获取博览会和场馆关联详细信息
     */
    @ApiOperation("获取博览会和场馆关联详细信息接口")
    @PreAuthorize("@ss.hasPermi('cms:hall:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult<CmsExpositionHall> getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(cmsExpositionHallService.findById(id));
    }

    /**
     * 新增博览会和场馆关联
     */
    @ApiOperation("新增博览会和场馆关联接口")
    @PreAuthorize("@ss.hasPermi('cms:hall:add')")
    @Log(title = "博览会和场馆关联", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsExpositionHall cmsExpositionHall) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsExpositionHall.setCreateBy(loginUser.getUsername());
        cmsExpositionHall.setCreateTime(new Date());
        cmsExpositionHall.setDelFlag("0");
        cmsExpositionHallService.save(cmsExpositionHall);
        return AjaxResult.success();
    }

    /**
     * 修改博览会和场馆关联
     */
    @ApiOperation("修改博览会和场馆关联接口")
    @PreAuthorize("@ss.hasPermi('cms:hall:edit')")
    @Log(title = "博览会和场馆关联", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsExpositionHall cmsExpositionHall) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsExpositionHall.setUpdateBy(loginUser.getUsername());
        cmsExpositionHall.setUpdateTime(new Date());
        cmsExpositionHallService.save(cmsExpositionHall);
        return AjaxResult.success();
    }

    /**
     * 删除博览会和场馆关联
     */
    @ApiOperation("删除博览会和场馆关联接口")
    @PreAuthorize("@ss.hasPermi('cms:hall:remove')")
    @Log(title = "博览会和场馆关联", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        cmsExpositionHallService.deleteByIds(Arrays.asList(ids));
        return AjaxResult.success();
    }
}
