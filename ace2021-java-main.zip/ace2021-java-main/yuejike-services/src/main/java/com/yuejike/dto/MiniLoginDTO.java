package com.yuejike.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Pattern;
import java.io.Serializable;

@Data
@ApiModel("小程序登录对象")
public class MiniLoginDTO implements Serializable{

    @ApiModelProperty(value = "小程序用户openid")
    private String openId;


}
