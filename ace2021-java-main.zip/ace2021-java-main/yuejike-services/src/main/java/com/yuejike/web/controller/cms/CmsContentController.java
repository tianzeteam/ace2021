package com.yuejike.web.controller.cms;

import com.yuejike.cms.domain.CmsContent;
import com.yuejike.cms.domain.CmsModelExtend;
import com.yuejike.cms.service.ICmsContentService;
import com.yuejike.cms.service.ICmsModelExtendService;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.annotation.Message;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.MapResult;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.page.TableDataInfo;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.common.enums.NoticeType;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.utils.sms.LuoSiMaoSmsUtils;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.system.service.ISysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * 文章Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/content")
@Api(tags = "文章",description = "文章")
public class CmsContentController extends BaseController {
    @Autowired
    private ICmsContentService cmsContentService;
    @Autowired
    private ICmsModelExtendService modelExtendService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private ISysUserService userService;

    /**
     * 根据栏目id获取模型扩展字段列表
     */
    @ApiOperation("根据栏目id获取模型扩展字段列表")
    @GetMapping("/getModelExtendList")
    public List<CmsModelExtend> getModelExtendList(Long categoryId) {
        List<CmsModelExtend> modelExtendList = modelExtendService.getModelExtendList(categoryId);
        return modelExtendList;
    }

    /**
     * 查询文章列表
     */
    @ApiOperation("查询文章列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:content:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsContent> listByPage(CmsContent cmsContent) {
        Page<CmsContent> page = cmsContentService.findCmsContentPage(cmsContent);
        return getDataTable(page);
    }

    @ApiOperation("不分页查询文章列表")
    @GetMapping("/ui/list")
    public MapResult list(CmsContent cmsContent) {
        List<CmsContent> list = cmsContentService.findCmsContentList(cmsContent);
        return MapResult.success("查询成功！",list);
    }


    /**
     * 导出文章列表
     */
    @ApiOperation("导出文章列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:content:export')")
    @Log(title = "文章", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsContent cmsContent) {
        List<CmsContent> list = cmsContentService.findCmsContentList(cmsContent);
        ExcelUtil<CmsContent> util = new ExcelUtil<>(CmsContent.class);
        return util.exportExcel(list, "content");
    }

    /**
     * 获取文章详细信息
     */
    @ApiOperation("获取文章详细信息接口")
    // @PreAuthorize("@ss.hasPermi('cms:content:query')")
    @GetMapping(value = "/{contentId}")
    public AjaxResult<CmsContent> getInfo(@PathVariable("contentId") Long contentId) {
        return AjaxResult.success(cmsContentService.findById(contentId));
    }

    /**
     * 新增文章
     */
    @ApiOperation("新增文章接口")
    // @PreAuthorize("@ss.hasPermi('cms:content:add')")
    @Log(title = "文章", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsContent cmsContent) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if (loginUser.getUser().getUserType().equals(UserType.ZBF.getCode()) || loginUser.getUser().getUserType().equals(UserType.ADMIN.getCode())) {
            cmsContent.setReviewStatus("1");
            cmsContent.setIsContribution("0");
        }else if(loginUser.getUser().getUserType().equals(UserType.MT.getCode())){
            cmsContent.setReviewStatus("0");
            cmsContent.setVisible("0");
            cmsContent.setSort(1);
            cmsContent.setIsContribution("1");
        }
        cmsContent.setCreateId(loginUser.getUser().getUserId());
        cmsContent.setDelFlag("0");
        cmsContent.setCreateBy(loginUser.getUsername());
        cmsContent.setCreateTime(new Date());
        cmsContentService.save(cmsContent);
        return AjaxResult.success();
    }

    /**
     * 修改文章
     */
    @ApiOperation("修改文章接口")
    @PreAuthorize("@ss.hasPermi('cms:content:edit')")
    @Log(title = "文章", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsContent cmsContent) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsContent.setUpdateBy(loginUser.getUsername());
        cmsContent.setUpdateTime(new Date());
        cmsContentService.save(cmsContent);
        return AjaxResult.success();
    }

    /**
     * 删除文章
     */
    @ApiOperation("删除文章接口")
    @PreAuthorize("@ss.hasPermi('cms:content:remove')")
    @Log(title = "文章", businessType = BusinessType.DELETE)
	@DeleteMapping("/{contentIds}")
    public AjaxResult remove(@PathVariable Long[] contentIds) {
        cmsContentService.deleteByIds(Arrays.asList(contentIds));
        return AjaxResult.success();
    }

    @ApiOperation("审核在线投稿接口")
    @Message(title = "投稿通知",noticeType = NoticeType.CONTRIBUTION)
    @PreAuthorize("@ss.hasPermi('cms:content:edit')")
    @Log(title = "文章", businessType = BusinessType.UPDATE)
    @PutMapping("/review")
    public AjaxResult reviewContent(@RequestBody CmsContent cmsContent) {
        AjaxResult ajaxResult = new AjaxResult();

        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsContent.setReviewId(loginUser.getUser().getUserId());
        cmsContent.setReviewTime(new Date());
        cmsContentService.save(cmsContent);
        if(cmsContent.getReviewStatus().equals("1") || cmsContent.getReviewStatus().equals("2")){
            SysUser user = userService.selectUserById(cmsContent.getCreateId());
            if(user != null && StringUtils.isNotEmpty(user.getPhonenumber())){
                LuoSiMaoSmsUtils.getInstance().sendApprovedContentMsg(user.getPhonenumber(), cmsContent.getTitle(),
                        cmsContent.getReviewStatus().equals("1"));
            }
        }
        ajaxResult.setCode(0);
        ajaxResult.setMsg("审核成功");
        ajaxResult.setData(cmsContent);
        return ajaxResult;
    }

    @ApiOperation("批量排序")
    @PreAuthorize("@ss.hasPermi('cms:content:resort')")
    @Log(title = "文章信息", businessType = BusinessType.UPDATE)
    @PutMapping("/resort")
    public AjaxResult resort(@RequestBody List<CmsContent> cmsContents) {
        cmsContentService.batchReSorted(cmsContents);
        return AjaxResult.success();
    }
}
