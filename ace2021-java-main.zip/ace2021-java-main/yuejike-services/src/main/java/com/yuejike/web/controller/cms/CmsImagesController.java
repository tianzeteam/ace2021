package com.yuejike.web.controller.cms;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsImages;
import com.yuejike.cms.service.ICmsImagesService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 图片关联Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/images")
@Api(tags = "图片关联",description = "图片关联")
public class CmsImagesController extends BaseController {
    @Autowired
    private ICmsImagesService cmsImagesService;
    @Autowired
    private TokenService tokenService;

    /**
     * 查询图片关联列表
     */
    @ApiOperation("查询图片关联列表接口")
//    @PreAuthorize("@ss.hasPermi('cms:images:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsImages> list(CmsImages cmsImages) {
        Page<CmsImages> page = cmsImagesService.findCmsImagesPage(cmsImages);
        return getDataTable(page);
    }

    /**
     * 导出图片关联列表
     */
    @ApiOperation("导出图片关联列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:images:export')")
    @Log(title = "图片关联", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsImages cmsImages) {
        List<CmsImages> list = cmsImagesService.findCmsImagesList(cmsImages);
        ExcelUtil<CmsImages> util = new ExcelUtil<>(CmsImages.class);
        return util.exportExcel(list, "images");
    }

    /**
     * 获取图片关联详细信息
     */
    @ApiOperation("获取图片关联详细信息接口")
    @PreAuthorize("@ss.hasPermi('cms:images:query')")
    @GetMapping(value = "/{imageId}")
    public AjaxResult<CmsImages> getInfo(@PathVariable("imageId") Long imageId) {
        return AjaxResult.success(cmsImagesService.findById(imageId));
    }

    /**
     * 新增图片关联
     */
    @ApiOperation("新增图片关联接口")
    @PreAuthorize("@ss.hasPermi('cms:images:add')")
    @Log(title = "图片关联", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsImages cmsImages) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsImages.setCreateBy(loginUser.getUsername());
        cmsImages.setCreateTime(new Date());
        cmsImages.setDelFlag("0");
        cmsImagesService.save(cmsImages);
        return AjaxResult.success();
    }

    /**
     * 修改图片关联
     */
    @ApiOperation("修改图片关联接口")
    @PreAuthorize("@ss.hasPermi('cms:images:edit')")
    @Log(title = "图片关联", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsImages cmsImages) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsImages.setUpdateBy(loginUser.getUsername());
        cmsImages.setUpdateTime(new Date());
        cmsImagesService.save(cmsImages);
        return AjaxResult.success();
    }

    /**
     * 删除图片关联
     */
    @ApiOperation("删除图片关联接口")
    @PreAuthorize("@ss.hasPermi('cms:images:remove')")
    @Log(title = "图片关联", businessType = BusinessType.DELETE)
	@DeleteMapping("/{imageIds}")
    public AjaxResult remove(@PathVariable Long[] imageIds) {
        cmsImagesService.deleteByIds(Arrays.asList(imageIds));
        return AjaxResult.success();
    }
}
