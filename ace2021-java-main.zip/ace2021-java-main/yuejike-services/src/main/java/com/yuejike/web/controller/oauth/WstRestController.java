package com.yuejike.web.controller.oauth;

import java.io.UnsupportedEncodingException;
import java.util.Optional;

import com.yuejike.common.utils.uuid.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.iflytek.wst.gateway.sdk.enums.HttpMethod;
import com.iflytek.wst.gateway.sdk.enums.ParamPosition;
import com.iflytek.wst.gateway.sdk.model.ApiRequest;
import com.iflytek.wst.gateway.sdk.model.ApiResponse;
import com.yuejike.common.constant.Constants;
import com.yuejike.common.core.domain.MapResult;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.utils.SecurityUtils;
import com.yuejike.common.utils.StringUtils;
import com.yuejike.framework.web.service.SysLoginService;
import com.yuejike.system.dao.SysUserDao;
import com.yuejike.web.util.WechatClient;
import com.yuejike.web.util.WstClient;

/**
 * 皖事通OAUTH
 * @author kosku
 *
 */
@RestController
@RequestMapping("/oauth")
public class WstRestController {
    
    @Autowired
    private SysUserDao userDao;
    
    @Autowired
    private SysLoginService loginService;

	@GetMapping("/testLogin")
	public MapResult testLogin() {
		String login3 = loginService.loginByUserName("ex");
		MapResult ajax = MapResult.success();
		ajax.put(Constants.TOKEN, login3);
		ajax.put("uuid", UUID.randomUUID().toString().replace("-",""));
		return ajax;
	}

    @GetMapping("/wstLogin")
    public MapResult wstLogin(@RequestParam String wstCode){
    	MapResult ajax = MapResult.success();
    	//判断皖事通用户是否存在
    	SysUser wstUser;
    	wstUser = userDao.findByOauthWst(wstCode);
    	if(ObjectUtils.isEmpty(wstUser)) {
    	   JSONObject wstJson = getWstJson(wstCode);
    	   if(ObjectUtils.isEmpty(wstJson)) {
    		   ajax.put(MapResult.CODE_TAG,500);
               ajax.put(MapResult.MSG_TAG,"统一认证错误");
    	   }else {
    		   String phone = wstJson.getString("perUserVo.bindPhone");
    		   String name = wstJson.getString("perUserVo.name");
    		   Optional<SysUser> findByPhonenumber = userDao.findByPhonenumber(phone);
    		   if(!ObjectUtils.isEmpty(findByPhonenumber)) {
    			   findByPhonenumber.get().setOauthWst(wstCode);
    			   wstUser = userDao.save(findByPhonenumber.get());
    		   }else {
    			   SysUser user = new SysUser();
    			   user.setUserName("wst_"+UUID.randomUUID().toString().replace("-",""));
    		       user.setNickName(name);
    		       user.setUserType("06");
    		       user.setPhonenumber(phone);
    		       user.setPassword(SecurityUtils.encryptPassword("123456@kbh2021"));
    		       user.setOauthWst(wstCode);
    		       user.setExpositionId(10L);
    		       wstUser = userDao.save(user);
    		   }
    	   }
    	}

		String loginU = loginService.loginByUserName(wstUser.getUserName());
		ajax.put(Constants.TOKEN, loginU);
		return ajax;
    }
    
    @GetMapping("/wxLogin")
    public MapResult wxLogin(@RequestParam String wxCode){
    	MapResult ajax = MapResult.success();
    	SysUser wstUser = null;
    	JSONObject wstJson = getWx(wxCode);
    	if(ObjectUtils.isEmpty(wstJson)) {
    		  ajax.put(MapResult.CODE_TAG,500);
              ajax.put(MapResult.MSG_TAG,"无法获取您的信息，请尝试重新授权");
              return ajax;
    	  }else {
    		   String name = wstJson.getString("nickname");
    		   Optional<SysUser> findByUserName = userDao.findByUserName(name);
    		   if(ObjectUtils.isEmpty(findByUserName)) {
    			   SysUser user = new SysUser();
    			   user.setUserName("wx_"+UUID.randomUUID().toString().replace("-",""));
    		       user.setNickName(name);
    		       user.setUserType("06");
    		       user.setPassword(SecurityUtils.encryptPassword("123456@kbh2021"));
    		       user.setOauthWechat(wxCode);
    		       user.setExpositionId(10L);
    		       wstUser = userDao.save(user);
    		   }else {
    			   wstUser = findByUserName.get();
    		   }
    	   }

		String loginU = loginService.loginByUserName(wstUser.getUserName());
        ajax.put(Constants.TOKEN, loginU);
        return ajax;
    }
    
    /**
     * 解析皖事通用户
     * @param wstCode
     * @return
     * @throws UnsupportedEncodingException 
     */
    private JSONObject getWstJson(String wstCode) {
    		ApiRequest request = new ApiRequest(HttpMethod.GET, "/user/getUserInfoByToken");
     	   	request.addParam("token", wstCode, ParamPosition.QUERY, true);
            request.addParam("serviceId", "1", ParamPosition.QUERY, true);
            request.addParam("roleCode", "", ParamPosition.QUERY, true);
            ApiResponse response = WstClient.getInstance().sendSyncRequest(request);
            byte[] body = response.getBody();
            String s = new String(body);
            JSONObject parseObject = JSONObject.parseObject(s);
            JSONObject parseObject2 = JSONObject.parseObject(parseObject.getString("data"));
            if(ObjectUtils.isEmpty(parseObject2) || StringUtils.isEmpty(parseObject2.getString("perUserVo.userId"))) {
            	return null;
            }
    	return parseObject2;
    }
    
    
    /**
     * 解析微信用户
     * @param wxCode
     * @return
     * @throws UnsupportedEncodingException 
     */
    private JSONObject getWx(String wxCode) {
    	String wxUser = ""; //class
	      try {
	          wxUser = WechatClient.getWechatUserByCode(wxCode);
	      }catch(Exception e) {
	      }
        JSONObject parseObject = JSONObject.parseObject(wxUser);
        if(StringUtils.isEmpty(parseObject.getString("nickname"))) {
        	return null;
        }
    	return parseObject;
    }
}
