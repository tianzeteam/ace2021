package com.yuejike.web.controller.monitor;

import com.yuejike.cms.domain.SysAccessRec;
import com.yuejike.cms.service.ISysAccessRecService;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.MapResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * @author JinZJ
 * @version 1.0
 * @Description: 访问记录
 * @date 2021/11/25 14:19
 */
@RestController
@RequestMapping("/monitor/access")
@Api(tags = "访问记录", description = "访问记录")
public class AccessRecordController {

    @Autowired
    private ISysAccessRecService sysAccessRecService;

    @ApiOperation("添加访问记录")
    @PostMapping("/addVisit")
    public AjaxResult addVisit(@RequestBody SysAccessRec sysAccessRec){
        System.out.println(sysAccessRec.toString());
        sysAccessRecService.addVisit(sysAccessRec.getPath());
        return AjaxResult.success();
    }

    @ApiOperation("访问量统计")
    @GetMapping("/statistics")
    public MapResult statistics(){
        Map<String, Object> result = new HashMap<>();
        result.put("base", sysAccessRecService.getBaseStatistics());
        return MapResult.success(result);
    }

}
