package com.yuejike.web.controller.cms;

import com.yuejike.cms.domain.CmsCategory;
import com.yuejike.cms.domain.CmsProductCategory;
import com.yuejike.cms.service.ICmsCategoryService;
import com.yuejike.cms.service.ICmsProductCategoryService;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.MapResult;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.page.TableDataInfo;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.model.TreeSelectModel;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 功能描述: <br>
 * 〈展品分类控制器〉
 * @Param:
 * @Return:
 * @Author: JinZJ
 * @Date: 2021/11/23 15:36
 */
@RestController
@RequestMapping("/cms/productCategory")
@Api(tags = "展品分类管理",description = "展品分类管理")
public class CmsProductCategoryController extends BaseController {
    @Autowired
    private ICmsProductCategoryService cmsProductCategoryService;
    @Autowired
    private TokenService tokenService;

    /**
     * 查询展品分类管理列表
     */
    @ApiOperation("查询展品分类列表接口")
    @PreAuthorize("@ss.hasPermi('cms:productCategory:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsCategory> list(CmsProductCategory cmsCategory) {
        Page<CmsProductCategory> page = cmsProductCategoryService.findCmsCategoryTreePage(cmsCategory);
        return getDataTable(page);
    }

    @ApiOperation("返回所有记录")
    @GetMapping("/listAll")
    public MapResult listAll(CmsProductCategory cmsCategory){
        List<CmsProductCategory> list = cmsProductCategoryService.findCmsCategoryList(cmsCategory);
        return MapResult.success("查询成功",list) ;
    }

    /**
     * 导出展品分类管理列表
     */
    @ApiOperation("导出展品分类列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:productCategory:export')")
    @Log(title = "展品分类管理", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsProductCategory cmsCategory) {
        List<CmsProductCategory> list = cmsProductCategoryService.findCmsCategoryList(cmsCategory);
        ExcelUtil<CmsProductCategory> util = new ExcelUtil<>(CmsProductCategory.class);
        return util.exportExcel(list, "category");
    }

    /**
     * 获取展品分类详细信息
     */
    @ApiOperation("获取展品分类详细信息接口")
    //@PreAuthorize("@ss.hasPermi('cms:productCategory:query')")
    @GetMapping(value = "/{categoryId}")
    public AjaxResult<CmsProductCategory> getInfo(@PathVariable("categoryId") Long categoryId) {
        return AjaxResult.success(cmsProductCategoryService.findById(categoryId));
    }

    /**
     * 新增展品分类
     */
    @ApiOperation("新增展品分类接口")
    @PreAuthorize("@ss.hasPermi('cms:productCategory:add')")
    @Log(title = "展品分类管理", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsProductCategory cmsCategory) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsCategory.setCreateBy(loginUser.getUsername());
        cmsCategory.setCreateTime(new Date());
        if(cmsCategory.getParentId() == null) cmsCategory.setParentId(0L);
        cmsProductCategoryService.save(cmsCategory);
        return AjaxResult.success();
    }

    /**
     * 获取展品分类层级结构树
     */
    @ApiOperation("获取展品分类层级结构树")
    @PostMapping(value = "/getTreeByPid")
    public List<Map<String, Object>> getTreeByPid() {
        List<Map<String, Object>> cmsCategorySelectByPid = cmsProductCategoryService.getCmsCategorySelectByPid();
        return cmsCategorySelectByPid;
    }

    /**
     * 修改展品分类管理
     */
    @ApiOperation("修改展品分类管理接口")
    @PreAuthorize("@ss.hasPermi('cms:productCategory:edit')")
    @Log(title = "展品分类管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsProductCategory cmsCategory) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsCategory.setUpdateBy(loginUser.getUsername());
        cmsCategory.setUpdateTime(new Date());
        cmsProductCategoryService.save(cmsCategory);
        return AjaxResult.success();
    }

    /**
     * 删除栏目管理
     */
    @ApiOperation("删除展品分类接口")
    @PreAuthorize("@ss.hasPermi('cms:productCategory:remove')")
    @Log(title = "展品分类管理", businessType = BusinessType.DELETE)
	@DeleteMapping("/{categoryIds}")
    public AjaxResult remove(@PathVariable Long[] categoryIds) {
        cmsProductCategoryService.deleteByIds(Arrays.asList(categoryIds));
        return AjaxResult.success();
    }

    @ApiOperation("获取分类下拉树列表接口")
    @GetMapping("/treeselect")
    public MapResult treeselect(CmsProductCategory cmsCategory){
        List<CmsProductCategory> categoryList = cmsProductCategoryService.findCmsCategoryList(cmsCategory);
        List<TreeSelectModel> treeSelectModels = cmsProductCategoryService.buildTreeSelect(categoryList);
        return MapResult.success(treeSelectModels);
    }

}
