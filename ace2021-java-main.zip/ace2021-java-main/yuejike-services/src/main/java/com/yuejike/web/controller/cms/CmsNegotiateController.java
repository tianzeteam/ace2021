package com.yuejike.web.controller.cms;

import com.yuejike.cms.domain.CmsProduct;
import com.yuejike.cms.service.ICmsProductService;
import com.yuejike.common.annotation.Message;
import com.yuejike.common.enums.NoticeType;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.StringUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yuejike.common.annotation.Log;
import com.yuejike.common.core.controller.BaseController;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.enums.BusinessType;
import com.yuejike.framework.web.service.TokenService;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.utils.ServletUtils;
import com.yuejike.cms.domain.CmsNegotiate;
import com.yuejike.cms.service.ICmsNegotiateService;
import com.yuejike.common.utils.poi.ExcelUtil;
import com.yuejike.common.core.page.TableDataInfo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 洽谈沟通Controller
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@RestController
@RequestMapping("/cms/negotiate")
@Api(tags = "C-洽谈沟通信息接口",description = "洽谈沟通")
public class CmsNegotiateController extends BaseController {
    @Autowired
    private ICmsNegotiateService cmsNegotiateService;
    @Autowired
    private TokenService tokenService;
    @Autowired
    private ICmsProductService productService;

    /**
     * 查询洽谈沟通列表
     */
    @ApiOperation("查询洽谈沟通列表接口")
//   @PreAuthorize("@ss.hasPermi('cms:negotiate:list')")
    @GetMapping("/list")
    public TableDataInfo<CmsNegotiate> list(CmsNegotiate cmsNegotiate) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser.getUser() != null) {
            if (loginUser.getUser().getUserType().equals(UserType.CZS.getCode()) || loginUser.getUser().getUserType().equals(UserType.CZS_JS.getCode())) {
                cmsNegotiate.setAcceptId(loginUser.getUser().getDeptId());
                if(loginUser.getUser().getDeptId() == null || loginUser.getUser().getDeptId().equals(0)){
                    TableDataInfo rspData = new TableDataInfo();
                    rspData.setCode(0);
                    rspData.setMsg("请认证后查询");
                    rspData.setRows(null);
                    rspData.setTotal(0);
                    return rspData;
                }
            }else if(loginUser.getUser().getUserType().equals(UserType.GZ.getCode()) || loginUser.getUser().getUserType().equals(UserType.ZYGZ.getCode()) ||
                    loginUser.getUser().getUserType().equals(UserType.MT.getCode()) || loginUser.getUser().getUserType().equals(UserType.HYDB.getCode())){
                cmsNegotiate.setSendId(loginUser.getUser().getUserId());
            }
            Page<CmsNegotiate> page = cmsNegotiateService.findCmsNegotiatePage(cmsNegotiate);
            return getDataTable(page);
        }else{
            TableDataInfo rspData = new TableDataInfo();
            rspData.setCode(500);
            rspData.setMsg("查询失败");
            rspData.setRows(null);
            rspData.setTotal(0);
            return rspData;
        }

    }

    /**
     * 导出洽谈沟通列表
     */
    @ApiOperation("导出洽谈沟通列表数据接口")
    @PreAuthorize("@ss.hasPermi('cms:negotiate:export')")
    @Log(title = "洽谈沟通", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(CmsNegotiate cmsNegotiate) {
        List<CmsNegotiate> list = cmsNegotiateService.findCmsNegotiateList(cmsNegotiate);
        ExcelUtil<CmsNegotiate> util = new ExcelUtil<>(CmsNegotiate.class);
        return util.exportExcel(list, "negotiate");
    }

    /**
     * 获取洽谈沟通详细信息
     */
    @ApiOperation("获取洽谈沟通详细信息接口")
//    @PreAuthorize("@ss.hasPermi('cms:negotiate:query')")
    @GetMapping(value = "/{negotiateId}")
    public AjaxResult<CmsNegotiate> getInfo(@PathVariable("negotiateId") Long negotiateId) {
        return AjaxResult.success(cmsNegotiateService.findById(negotiateId));
    }

    /**
     * 新增洽谈沟通
     */
    @ApiOperation("新增洽谈沟通接口")
//    @PreAuthorize("@ss.hasPermi('cms:negotiate:add')")
    @Log(title = "洽谈沟通", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CmsNegotiate cmsNegotiate) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        if(loginUser == null || loginUser.getUser() == null || loginUser.getUser().getUserType().equals(UserType.GZ.getCode())) {
            return AjaxResult.error("操作受限，无法发起洽谈");
        }
        CmsProduct product = productService.findById(cmsNegotiate.getProductId());
        if(product != null) {
            cmsNegotiate.setSendId(loginUser.getUser().getUserId());
            cmsNegotiate.setUserName(loginUser.getUser().getNickName());
            cmsNegotiate.setAcceptId(product.getUserId());
            cmsNegotiate.setExhibitorName(product.getExhibitorName());
            cmsNegotiate.setCreateBy(loginUser.getUsername());
            cmsNegotiate.setDelFlag("0");
            cmsNegotiate.setStatus("0");
            cmsNegotiate.setCreateTime(new Date());
            cmsNegotiateService.save(cmsNegotiate);
            return AjaxResult.success();
        }else{
            return AjaxResult.error("请选择正确的展品");
        }
    }

    /**
     * 修改洽谈沟通
     */
    @ApiOperation("修改洽谈沟通接口")
//    @PreAuthorize("@ss.hasPermi('cms:negotiate:edit')")
    @Log(title = "洽谈沟通", businessType = BusinessType.UPDATE)
    @Message(title = "洽谈回复通知",noticeType = NoticeType.NEGOTIATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CmsNegotiate cmsNegotiate) {
        LoginUser loginUser = tokenService.getLoginUser(ServletUtils.getRequest());
        cmsNegotiate.setUpdateBy(loginUser.getUsername());
        cmsNegotiate.setUpdateTime(new Date());
        CmsNegotiate negotiate = cmsNegotiateService.save(cmsNegotiate);
        AjaxResult ajaxResult = new AjaxResult();
        ajaxResult.setCode(0);
        ajaxResult.setMsg("修改成功");
        if(StringUtils.isNotBlank(cmsNegotiate.getReply())){
            ajaxResult.setData(negotiate);
        }
        return ajaxResult;
    }

    /**
     * 删除洽谈沟通
     */
    @ApiOperation("删除洽谈沟通接口")
//    @PreAuthorize("@ss.hasPermi('cms:negotiate:remove')")
    @Log(title = "洽谈沟通", businessType = BusinessType.DELETE)
	@DeleteMapping("/{negotiateIds}")
    public AjaxResult remove(@PathVariable Long[] negotiateIds) {
        cmsNegotiateService.deleteByIds(Arrays.asList(negotiateIds));
        return AjaxResult.success();
    }
}
