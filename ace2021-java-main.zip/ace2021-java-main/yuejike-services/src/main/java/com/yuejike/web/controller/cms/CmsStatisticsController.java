package com.yuejike.web.controller.cms;

import com.google.common.collect.Lists;
import com.yuejike.cms.domain.CmsBanner;
import com.yuejike.cms.domain.CmsClassification;
import com.yuejike.cms.domain.SysUserExhibitor;
import com.yuejike.cms.service.*;
import com.yuejike.common.core.domain.AjaxResult;
import com.yuejike.common.core.domain.MapResult;
import com.yuejike.system.service.ISysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.OrderedBidiMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.SimpleFormatter;
import java.util.stream.Collectors;

/**
 * 看板Controller
 */
@RestController
@RequestMapping("/cms/statistical")
@Api(tags = "看板",description = "看板")
public class CmsStatisticsController {

    @Autowired
    private ISysUserService userService;
    @Autowired
    private ICmsProductService cmsProductService;
    @Autowired
    private ISysUserExhibitorService sysUserExhibitorService;
    @Autowired
    private ICmsClassificationService classificationService;
    @Autowired
    private ISysAccessRecService sysAccessRecService;


    @ApiOperation("查询看板数据接口")
    @GetMapping("/list")
    public MapResult statistical(String time) throws ParseException{
        Map<String,Object> map = new HashMap<>();
        //参展企业数量
        CmsClassification classification = new CmsClassification();
        classification.setParentId(0L);
        List<CmsClassification> classificationList = classificationService.findCmsClassificationList(classification);
        Map<String,Object> userExhibitorMap = new HashMap<>();
        Map<String,Object> productMap = new HashMap<>();
        //展商总数量
        int allUserExhibitorCount =0;
        for (CmsClassification cmsClassification : classificationList) {
            int userExhibitorCount = 0;
            int productCount =0;
            if(classificationService.hasChildByMenuId(cmsClassification.getClassificationId())){
                List<Long> ids = new ArrayList<>();
                ids.add(cmsClassification.getClassificationId());
                //递归查询所选节点下的所有的子节点
                List<Long> classificationIdList = queryAllClassificationId(ids);
                classificationIdList.add(cmsClassification.getClassificationId());
                for (Long classificationId:classificationIdList) {
                   userExhibitorCount += sysUserExhibitorService.findByClassificationId(classificationId);
                   productCount += cmsProductService.findByClassificationId(classificationId);
                }
            }else{
                userExhibitorCount = sysUserExhibitorService.findByClassificationId(cmsClassification.getClassificationId());
                productCount = cmsProductService.findByClassificationId(cmsClassification.getClassificationId());
            }
            //展商总数量
            allUserExhibitorCount += userExhibitorCount;
            userExhibitorMap.put(cmsClassification.getName(),userExhibitorCount);
            productMap.put(cmsClassification.getName(),productCount);
            map.put("userExhibitor",userExhibitorMap);
            map.put("product",productMap);
            map.put("allUserExhibitorCount",allUserExhibitorCount);
        }
        map.put("allProductCount",cmsProductService.getAllCount());
        String statetime = getStatetime(time);
        //查询注册数量按day和用户类型统计
        List<Map<String,Object>> newExhibitorMap = new ArrayList<>();
        List<Map<String,Object>> exhibitorMap = userService.findByUserTypeAndCreateTime("02",statetime,time);
        Integer exhibitorCount =0;
        for (int i = 0; i < exhibitorMap.size(); i++) {
            //计算累计
            exhibitorCount +=Integer.valueOf(exhibitorMap.get(i).get("count").toString());
            Map<String,Object> newMap = new HashMap<>();
            newMap.put("count",exhibitorMap.get(i).get("count"));
            newMap.put("cumulativeCount",exhibitorCount);
            newMap.put("days",exhibitorMap.get(i).get("days"));
            newExhibitorMap.add(newMap);
        }
        //会议代表
        List<Map<String,Object>> newDelegateMap = new ArrayList<>();
        List<Map<String,Object>> delegateMap = userService.findByUserTypeAndCreateTime("03",statetime,time);
        Integer delegateCount =0;
        for (int i = 0; i < delegateMap.size(); i++) {
            //计算累计
            delegateCount +=Integer.valueOf(delegateMap.get(i).get("count").toString());
            Map<String,Object> newMap = new HashMap<>();
            newMap.put("count",delegateMap.get(i).get("count"));
            newMap.put("cumulativeCount",delegateCount);
            newMap.put("days",delegateMap.get(i).get("days"));
            newDelegateMap.add(newMap);
        }
        //媒体
        List<Map<String,Object>> newMediaMap = new ArrayList<>();
        List<Map<String,Object>> mediaMap = userService.findByUserTypeAndCreateTime("04",statetime,time);
        Integer mediaCount =0;
        for (int i = 0; i < mediaMap.size(); i++) {
            //计算累计
            mediaCount +=Integer.valueOf(mediaMap.get(i).get("count").toString());
            Map<String,Object> newMap = new HashMap<>();
            newMap.put("count",mediaMap.get(i).get("count"));
            newMap.put("cumulativeCount",mediaCount);
            newMap.put("days",mediaMap.get(i).get("days"));
            newMediaMap.add(newMap);
        }
        //专业观众
        List<Map<String,Object>> newAudienceMap = new ArrayList<>();
        List<Map<String,Object>> audienceMap = userService.findByUserTypeAndCreateTime("05",statetime,time);
        Integer audienceCount =0;
        for (int i = 0; i < audienceMap.size(); i++) {
            //计算累计
            audienceCount +=Integer.valueOf(audienceMap.get(i).get("count").toString());
            Map<String,Object> newMap = new HashMap<>();
            newMap.put("count",audienceMap.get(i).get("count"));
            newMap.put("cumulativeCount",audienceCount);
            newMap.put("days",audienceMap.get(i).get("days"));
            newAudienceMap.add(newMap);
        }
        //普通观众
        List<Map<String,Object>> newUserMap = new ArrayList<>();
        List<Map<String,Object>> userMap = userService.findByUserTypeAndCreateTime("06",statetime,time);
        Integer count =0;
        for (int i = 0; i < userMap.size(); i++) {
            //计算累计
            count +=Integer.valueOf(userMap.get(i).get("count").toString());
            Map<String,Object> newMap = new HashMap<>();
            newMap.put("count",userMap.get(i).get("count"));
            newMap.put("cumulativeCount",count);
            newMap.put("days",userMap.get(i).get("days"));
            newUserMap.add(newMap);
        }
        //注册用户总数量
        int userCount = userService.findUserCount();
        //线下参展数量
        int offlineCount = 0;
        map.put("allUserCount",userCount);
        map.put("offlineCount",offlineCount);
        map.put("exhibitorMap",newExhibitorMap);
        map.put("delegateMap",newDelegateMap);
        map.put("mediaMap",newMediaMap);
        map.put("audienceMap",newAudienceMap);
        map.put("userMap",newUserMap);
        map.put("pv_uv",sysAccessRecService.getBaseStatistics());
        System.out.println("========"+map+"==========");
        return MapResult.success("查询成功",map);
    }

    @ApiOperation("查询看板数据接口2021")
    @GetMapping("/listAce")
    public MapResult statistical2021(String time) throws ParseException{
        Map<String,Object> map = new HashMap<>();
        map.put("全局", sysAccessRecService.getWholeSituation());
        map.put("整体观展情况",sysAccessRecService.getOverallViewing());
        map.put("注册数量",sysAccessRecService.getRegistration());
        map.put("展商来源",sysAccessRecService.getExhibitorSource());
        map.put("观众来源",sysAccessRecService.getAudienceSource());
        map.put("热门展品",sysAccessRecService.getPopularProduct());
        map.put("热门展商",sysAccessRecService.getPopularExhibitors());
        map.put("展厅情况",sysAccessRecService.getExhibitionHallCount());
        map.put("观展与意向成交",sysAccessRecService.getIntendedTransaction());

        return MapResult.success("查询成功",map);
    }

    /**
     * 获取某个父节点下面的所有子节点
     * @param ids
     * @return
     */
    private List<Long> queryAllClassificationId(List<Long> ids){
        //根据父ID查询子节点列表
        List<CmsClassification> departments = classificationService.findByParentId(ids);
        if (CollectionUtils.isNotEmpty(departments)) {
            //拿到当前所有子节点ID
            List<Long> parentIds = departments.stream().map(item -> item.getClassificationId()).collect(Collectors.toList());
            return parentIds;
        } else {
            //如果没有下级节点那么我们就返回空集合，结束递归。
            return Lists.newArrayList();
        }
    }

    /**
     * 获取传入的日期的前7天
     * @return
     * @throws ParseException
     */
    public static String getStatetime(String time) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = sdf.parse(time);
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DATE, -7);
        Date monday = c.getTime();
        String preMonday = sdf.format(monday);
        return preMonday;
    }

    @ApiOperation("主办方查询待审核的统计数")
    @GetMapping("/pendingApproval")
    public MapResult pendingApprovalData() {
        return MapResult.success("查询成功",sysAccessRecService.pendingApprovalData());
    }


}
