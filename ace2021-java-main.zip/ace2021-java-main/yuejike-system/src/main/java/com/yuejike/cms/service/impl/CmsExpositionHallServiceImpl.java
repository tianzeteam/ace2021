package com.yuejike.cms.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.yuejike.common.utils.DateUtils;

import java.util.Date;
import org.apache.commons.lang3.StringUtils;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yuejike.cms.dao.CmsExpositionHallDao;
import com.yuejike.cms.domain.CmsExpositionHall;
import com.yuejike.cms.service.ICmsExpositionHallService;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/**
 * 博览会和场馆关联Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsExpositionHallServiceImpl implements ICmsExpositionHallService {

    @Autowired
    private CmsExpositionHallDao cmsExpositionHallDao;

    /**
     * 查询博览会和场馆关联
     *
     * @param id 博览会和场馆关联ID
     * @return 博览会和场馆关联
     */
    @Override
    public CmsExpositionHall findById(Long id) {
        return cmsExpositionHallDao.findById(id).get();
    }

    /**
     * 分页查询博览会和场馆关联列表
     *
     * @param req 博览会和场馆关联
     * @return 博览会和场馆关联
     */
    @Override
    public Page<CmsExpositionHall> findCmsExpositionHallPage(CmsExpositionHall req) {
        Specification<CmsExpositionHall> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsExpositionHall> page = cmsExpositionHallDao.findAll(example, pageable);
        return page;
    }

    /**
     * 分页查询博览会和场馆关联列表
     *
     * @param req 博览会和场馆关联
     * @return 博览会和场馆关联
     */
    @Override
    public List<CmsExpositionHall> findCmsExpositionHallList(CmsExpositionHall req) {
        Specification<CmsExpositionHall> example = formatQueryParams(req);
        List<CmsExpositionHall> list = cmsExpositionHallDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    private Specification<CmsExpositionHall> formatQueryParams(CmsExpositionHall req){
        Specification<CmsExpositionHall> example = new Specification<CmsExpositionHall>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsExpositionHall> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getId()){
                    Predicate pre = cb.equal(root.get("id").as(Long.class), req.getId());
                    list.add(pre);
                }
                if (null != req.getExpositionId()){
                    Predicate pre = cb.equal(root.get("expositionId").as(Long.class), req.getExpositionId());
                    list.add(pre);
                }
                if (null != req.getHallId()){
                    Predicate pre = cb.equal(root.get("hallId").as(Long.class), req.getHallId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())){
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）博览会和场馆关联
     *
     * @param cmsExpositionHall 博览会和场馆关联
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void save(CmsExpositionHall cmsExpositionHall) {
        cmsExpositionHall.setCreateTime(DateUtils.getNowDate());
        cmsExpositionHallDao.save(cmsExpositionHall);
    }


    /**
     * 批量删除博览会和场馆关联
     *
     * @param ids 需要删除的博览会和场馆关联ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> ids) {
        List<CmsExpositionHall> existBeans = cmsExpositionHallDao.findAllById(ids);
        if(!existBeans.isEmpty()){
            cmsExpositionHallDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除博览会和场馆关联信息
     *
     * @param id 博览会和场馆关联ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsExpositionHallById(Long id) {
         cmsExpositionHallDao.deleteById(id);
    }
}
