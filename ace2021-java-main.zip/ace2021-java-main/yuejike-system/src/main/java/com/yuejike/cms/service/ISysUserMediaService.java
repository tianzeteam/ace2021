package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.SysUserMedia;

/**
 * 媒体Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-27
 */
public interface ISysUserMediaService  {
    /**
     * 查询媒体
     *
     * @param userId 媒体ID
     * @return 媒体
     */
    SysUserMedia findById(Long userId);

    /**
     * 分页查询媒体列表
     *
     * @param req 媒体
     * @return 媒体集合
     */
    Page<SysUserMedia> findSysUserMediaPage(SysUserMedia req);

    /**
     * 查询媒体列表
     *
     * @param req 媒体
     * @return 媒体集合
     */
    List<SysUserMedia> findSysUserMediaList(SysUserMedia req);

    /**
     * 新增媒体
     *
     * @param sysUserMedia 媒体
     * @return 结果
     */
    void save(SysUserMedia sysUserMedia);

    /**
     * 批量删除媒体
     *
     * @param userIds 需要删除的媒体ID
     * @return 结果
     */
    void deleteByIds(List<Long> userIds);

    /**
     * 删除媒体信息
     *
     * @param userId 媒体ID
     * @return 结果
     */
    void deleteSysUserMediaById(Long userId);
}
