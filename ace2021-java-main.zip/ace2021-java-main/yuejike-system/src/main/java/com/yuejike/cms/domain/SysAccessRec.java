package com.yuejike.cms.domain;

import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

/**
 * @author JinZJ
 * @version 1.0
 * @Description: 前台访问记录
 * @date 2021/11/25 15:52
 */
@Entity
@Table(name = "sys_access_rec")
@Data
public class SysAccessRec extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long id;

    @Excel(name = "用户ID")
    @Column(name="user_id")
    @ApiModelProperty(value = "用户ID")
    private Long userId;

    @Excel(name = "路径")
    @Column(name="path")
    @ApiModelProperty(value = "路径")
    private String path;

    @Excel(name = "IP地址")
    @Column(name="ip_addr")
    @ApiModelProperty(value = "IP地址")
    private String ipAddr;

    @Excel(name = "省份")
    @Column(name="region_province")
    @ApiModelProperty(value = "省份")
    private String regionProvince;

    @Excel(name = "城市")
    @Column(name="region_city")
    @ApiModelProperty(value = "城市")
    private String regionCity;

    @Column(name="create_time")
    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @Column(name="page_type")
    @ApiModelProperty(value = "页面类型")
    private Integer pageType;

    @Column(name="source_id")
    @ApiModelProperty(value = "记录ID")
    private Long sourceId;

    @Column(name="multiple")
    @ApiModelProperty(value = "计数倍数")
    private Integer multiple;

}
