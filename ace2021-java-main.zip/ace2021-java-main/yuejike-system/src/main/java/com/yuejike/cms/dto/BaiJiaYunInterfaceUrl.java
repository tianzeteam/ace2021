package com.yuejike.cms.dto;

/**
 * @author song
 * @date 2021年09月12日 17:17
 */
public final class BaiJiaYunInterfaceUrl {
    /**
     * 个性域名
     */
//    public static final String private_domain="https://e49936904.at.baijiayun.com";
            //比克账号
    public static final String private_domain="https://e62532297.at.baijiayun.com";
    /**
     * 合作方用于更新partner_key的密钥（由开放平台提供给合作方）
     */
//    public static final String secret_key="f15e58ab809903e85f0767f71cb6549c";
    //比克账号
    public static final String secret_key="2a30805907fd64dfe73de47c5d7cc7bc";
    /**
     * 账号id
     */
//    public static final String partner_id="49936904";
            //比克账号
    public static final String partner_id="62532297";
    /**
     * 账户密钥
     */
//    public static final String partner_key="lzNWup2UwzsAE1+Xz+TCOue2TzTEF9M7kK+mx61jhHxG9K4lVJ0GH1ouzcLXJ738YIeBPcypK3VkmPtavUHm+GA9PtM8";
//比克账号
    public static final String partner_key="Axk/wnTBqydfZoPZD2aHnGQ72TxeJII5FpbIbrKgHdHXKsC3v0ys/PKRw8EOFr+cUEnoj2e2EnLtcyNyopJna278UQ1w";
    /**
     * 创建直播房间接口地址
     */
    public static final String createRoom ="/openapi/room/create";
    /**
     * 进入直播房间接口地址
     */
    public static final String enterRoom ="/web/room/enter";
    /**
     * 更新房间信息接口地址
     */
    public static final String updateRoom ="/openapi/room/update";
    /**
     * 删除房间接口地址
     */
    public static final String deleteRoom ="/openapi/room/delete";

    /**
     * 获取直播回放token
     */
    public static final String playbackToken = "/openapi/playback/getPlayerToken";

    /**
     * 获取直播推流地址
     */
    public static final String pushLiveUrl = "/openapi/room/getPushLiveUrl";
}