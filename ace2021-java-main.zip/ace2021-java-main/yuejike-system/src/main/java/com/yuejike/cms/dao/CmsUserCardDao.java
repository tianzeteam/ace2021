package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsUserCard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


/**
 * 名片Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Repository
public interface CmsUserCardDao extends JpaRepository<CmsUserCard, Long>, JpaSpecificationExecutor<CmsUserCard> {

    @Query(value = "select * from cms_user_card where del_flag = '0' and user_id =?1", nativeQuery = true)
    CmsUserCard findByUserId(Long id);
}
