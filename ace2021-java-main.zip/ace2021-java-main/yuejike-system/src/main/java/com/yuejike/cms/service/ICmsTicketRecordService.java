package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsTicketRecord;

/**
 * 门票预约记录Service接口
 *
 * @author tangdw
 * @since 1.0 2021-10-18
 */
public interface ICmsTicketRecordService  {
    /**
     * 查询门票预约记录
     *
     * @param userId 门票预约记录ID
     * @return 门票预约记录
     */
    CmsTicketRecord findById(Long userId);

    /**
     * 分页查询门票预约记录列表
     *
     * @param req 门票预约记录
     * @return 门票预约记录集合
     */
    Page<CmsTicketRecord> findCmsTicketRecordPage(CmsTicketRecord req);

    /**
     * 查询门票预约记录列表
     *
     * @param req 门票预约记录
     * @return 门票预约记录集合
     */
    List<CmsTicketRecord> findCmsTicketRecordList(CmsTicketRecord req);

    /**
     * 新增门票预约记录
     *
     * @param cmsTicketRecord 门票预约记录
     * @return 结果
     */
    void save(CmsTicketRecord cmsTicketRecord);

    /**
     * 批量删除门票预约记录
     *
     * @param userIds 需要删除的门票预约记录ID
     * @return 结果
     */
    void deleteByIds(List<Long> userIds);

    /**
     * 删除门票预约记录信息
     *
     * @param userId 门票预约记录ID
     * @return 结果
     */
    void deleteCmsTicketRecordById(Long userId);
}
