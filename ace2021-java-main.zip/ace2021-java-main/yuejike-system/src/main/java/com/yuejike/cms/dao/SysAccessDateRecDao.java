package com.yuejike.cms.dao;

import com.yuejike.cms.domain.SysAccessDateRec;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * @author JinZJ
 * @version 1.0
 * @Description:
 * @date 2021/12/3 14:29
 */
@Repository
public interface SysAccessDateRecDao extends JpaRepository<SysAccessDateRec, String>, JpaSpecificationExecutor<SysAccessDateRec> {

}
