package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsUserCardExchange;

/**
 * 名片关联Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsUserCardExchangeService  {
    /**
     * 查询名片关联
     *
     * @param id 名片关联ID
     * @return 名片关联
     */
    CmsUserCardExchange findById(Long id);

    /**
     * 分页查询名片关联列表
     *
     * @param req 名片关联
     * @return 名片关联集合
     */
    Page<CmsUserCardExchange> findCmsUserCardExchangePage(CmsUserCardExchange req);

    /**
     * 查询名片关联列表
     *
     * @param req 名片关联
     * @return 名片关联集合
     */
    List<CmsUserCardExchange> findCmsUserCardExchangeList(CmsUserCardExchange req);

    /**
     * 新增名片关联
     *
     * @param cmsUserCardExchange 名片关联
     * @return 结果
     */
    void save(CmsUserCardExchange cmsUserCardExchange);

    /**
     * 批量删除名片关联
     *
     * @param ids 需要删除的名片关联ID
     * @return 结果
     */
    void deleteByIds(List<Long> ids);

    /**
     * 删除名片关联信息
     *
     * @param id 名片关联ID
     * @return 结果
     */
    void deleteCmsUserCardExchangeById(Long id);

    int findCardExchange(Long accept, Long sendId);

    int updateAcceptById(Long id);
    int updateSendById(String status,Long id);

    int findCardExchangeByStatus(Long accept, Long sendId);

    void updateByStatus(Long accept, Long sendId);
}
