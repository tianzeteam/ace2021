package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import io.swagger.annotations.ApiModelProperty;

/**
 * 博览会对象 cms_exposition
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_exposition")
@Data
public class CmsExposition extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="exposition_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "展会ID")
    private Long expositionId;

    /** 展会英文名 */
    @Excel(name = "展会英文名")
    @Column(name="en_name")
    @ApiModelProperty(value = "展会英文名")
    private String enName;

    /** 展会中文名 */
    @Excel(name = "展会中文名")
    @Column(name="cn_name")
    @ApiModelProperty(value = "展会中文名")
    private String cnName;

    /** 活动举办开始时间 */
    @JsonFormat(pattern = "yyyy-MM-dd",timezone = "GMT+8")
    @Excel(name = "活动举办开始时间", width = 30, dateFormat = "yyyy-MM-dd")
    @Column(name="start_time")
    @ApiModelProperty(value = "活动举办开始时间")
    private Date startTime;

    /** 活动举办结束时间 */
    @JsonFormat(pattern = "yyyy-MM-dd",timezone = "GMT+8")
    @Excel(name = "活动举办结束时间", width = 30, dateFormat = "yyyy-MM-dd")
    @Column(name="end_time")
    @ApiModelProperty(value = "活动举办结束时间")
    private Date endTime;

    /** 所属行业 */
    @Excel(name = "所属行业")
    @Column(name="type")
    @ApiModelProperty(value = "所属行业")
    private String type;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "所属行业")
    private Date createTime;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "所属行业")
    private Date updateTime;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "所属行业")
    private String createBy;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "所属行业")
    private String updateBy;

    /** 删除标识 */
    @Column(name="del_flag")
    @ApiModelProperty(value = "所属行业")
    private String delFlag;

    /** 主办单位 */
    @Excel(name = "主办单位")
    @Column(name="organizer")
    @ApiModelProperty(value = "主办单位")
    private String organizer;

    /** 状态 */
    @Excel(name = "状态")
    @Column(name="status")
    @ApiModelProperty(value = "状态")
    private String status;

    @Excel(name = "博览会的场馆")
    @Column(name="hall_id")
    @ApiModelProperty(value = "场馆")
    private String hallId;



}
