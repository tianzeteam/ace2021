package com.yuejike.cms.dto;

import com.yuejike.common.core.domain.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Transient;
import java.math.BigInteger;

@Data
public class CmsProductCategoryDTO extends BaseEntity {

    /** id */
    @ApiModelProperty(value = "${comment}")
    private BigInteger categoryId;

    /** 展品分类中文名 */
    @ApiModelProperty(value = "展品分类中文名")
    private String cnName;

    /** 展品分类英文名 */
    @ApiModelProperty(value = "展品分类英文名")
    private String enName;

    @ApiModelProperty(value = "展品分类日文名")
    private String jaName;

    @ApiModelProperty(value = "展品分类韩文名")
    private String koName;

    /** 父id */
    @ApiModelProperty(value = "父id")
    private BigInteger parentId;

    /** 排序 */
    @ApiModelProperty(value = "排序")
    private Integer sort;

    @Transient
    @ApiModelProperty(value = "父级展品分类名称")
    private String parentName;
}
