package com.yuejike.cms.domain;

import com.yuejike.common.core.domain.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

/**
 * @author ：JinZj
 * @date ：Created in 2022/1/4 5:15 下午
 * @description：全站索引
 * @modified By：
 */
@Entity
@Table(name = "view_full_text")
@Data
public class FullText extends BaseEntity {

    @Id
    @Column(name = "id")
    @ApiModelProperty("全文搜索ID")
    private String id;

    @Column(name = "i_type")
    @ApiModelProperty("内容类型：1展商，2展品，3新闻，4论坛直播，5活动直播，6线下会议")
    private Integer iType;

    @Column(name = "real_id")
    @ApiModelProperty("真实ID，用于详情跳转")
    private Long realId;

    @Column(name = "i_name")
    @ApiModelProperty(value = "标题名称")
    private String iName;

    @Column(name = "i_name_en")
    @ApiModelProperty(value = "英文标题名称")
    private String iNameEn;

    @Column(name = "i_name_ja")
    @ApiModelProperty(value = "日文标题名称")
    private String iNameJa;

    @Column(name = "i_name_ko")
    @ApiModelProperty(value = "韩文标题名称")
    private String iNameKo;

    @Column(name = "cover_pic")
    @ApiModelProperty(value = "封面图片")
    private String coverPic;

    @Column(name = "classification_id")
    private Long classificationId;

    @ApiModelProperty(value = "展商特有字段：企业类型")
    @Transient
    private CmsClassification classification;

    @ApiModelProperty(value = "展品特有字段：访问用户数")
    @Transient
    private Long uv;

    @ApiModelProperty(value = "展品特有字段：收藏数")
    @Transient
    private Long bookmarkCount;

    @Column(name = "label_id")
    private String labelId;

    @ApiModelProperty(value = "展品特有字段：标签")
    @Transient
    private List<CmsLabel> labels;

    @Column(name = "live_process")
    @ApiModelProperty(value = "直播特有字段：直播进程状态（0：未开始 1：进行中 2：已结束 ）")
    private String liveProcess;

    @Column(name = "start_time")
    @ApiModelProperty(value = "线下会议特有字段：会议开始时间")
    private Date startTime;

    @Column(name = "empower")
    private String empower;

    @Column(name = "group_id")
    private String groupId;

}
