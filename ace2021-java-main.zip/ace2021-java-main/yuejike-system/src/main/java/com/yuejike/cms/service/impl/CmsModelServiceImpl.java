package com.yuejike.cms.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.yuejike.cms.dao.CmsModelExtendDao;
import com.yuejike.cms.domain.CmsModelExtend;
import com.yuejike.common.utils.DateUtils;

import java.util.Date;
import org.apache.commons.lang3.StringUtils;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yuejike.cms.dao.CmsModelDao;
import com.yuejike.cms.domain.CmsModel;
import com.yuejike.cms.service.ICmsModelService;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/**
 * 模型Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsModelServiceImpl implements ICmsModelService {

    @Autowired
    private CmsModelDao cmsModelDao;
    @Autowired
    private CmsModelExtendDao modelExtendDao;
    /**
     * 查询模型
     *
     * @param modelId 模型ID
     * @return 模型
     */
    @Override
    public CmsModel findById(Long modelId) {
        return cmsModelDao.findById(modelId).get();
    }

    /**
     * 分页查询模型列表
     *
     * @param req 模型
     * @return 模型
     */
    @Override
    public Page<CmsModel> findCmsModelPage(CmsModel req) {
        Specification<CmsModel> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsModel> page = cmsModelDao.findAll(example, pageable);
        return page;
    }

    /**
     * 分页查询模型列表
     *
     * @param req 模型
     * @return 模型
     */
    @Override
    public List<CmsModel> findCmsModelList(CmsModel req) {
        Specification<CmsModel> example = formatQueryParams(req);
        List<CmsModel> list = cmsModelDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    private Specification<CmsModel> formatQueryParams(CmsModel req){
        Specification<CmsModel> example = new Specification<CmsModel>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsModel> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getModelId()){
                    Predicate pre = cb.equal(root.get("modelId").as(Long.class), req.getModelId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getModelJson())){
                    Predicate pre = cb.equal(root.get("modelJson").as(String.class), req.getModelJson());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getName())){
                    Predicate pre = cb.like(root.get("name").as(String.class), "%" + req.getName()+ "%");
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())){
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getType())){
                    Predicate pre = cb.equal(root.get("type").as(String.class), req.getType());
                    list.add(pre);
                }
                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）模型
     *
     * @param cmsModel 模型
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void save(CmsModel cmsModel) {
        cmsModel.setCreateTime(DateUtils.getNowDate());
        cmsModelDao.save(cmsModel);
    }


    /**
     * 批量删除模型
     *
     * @param modelIds 需要删除的模型ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> modelIds) {
        List<CmsModel> existBeans = cmsModelDao.findAllById(modelIds);
        if(!existBeans.isEmpty()){
            //先删除扩展表中的数据
            for (CmsModel model:existBeans) {
                modelExtendDao.deleteByModelId(model.getModelId());
            }
            cmsModelDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除模型信息
     *
     * @param modelId 模型ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsModelById(Long modelId) {
        modelExtendDao.deleteByModelId(modelId);
        cmsModelDao.deleteById(modelId);
    }
}
