package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsIndustry;
import com.yuejike.cms.domain.SysUserExhibitorIndustry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CmsIndustryDao extends JpaRepository<CmsIndustry, Long>, JpaSpecificationExecutor<CmsIndustry> {

    @Query(value = "select * from cms_industry where (is_hided=0 or is_hided is null)", nativeQuery = true)
    @Override
    List<CmsIndustry> findAll();

    @Query(value = "select * from cms_industry where industry_id=?1", nativeQuery = true)
    CmsIndustry findByIndustryId(String industryId);
}
