package com.yuejike.cms.service.impl;

import java.math.BigDecimal;
import java.util.*;

import com.yuejike.cms.dao.SysUserExhibitorDao;
import com.yuejike.cms.domain.CmsProduct;
import com.yuejike.cms.service.ICmsProductService;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.enums.OrderStatus;
import com.yuejike.common.enums.OrderStatusQueryType;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.DateUtils;

import com.yuejike.common.utils.SecurityUtils;
import com.yuejike.common.utils.code.BusinessBizCode;
import org.apache.commons.lang3.StringUtils;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yuejike.cms.dao.CmsOrderDao;
import com.yuejike.cms.domain.CmsOrder;
import com.yuejike.cms.service.ICmsOrderService;

import javax.persistence.criteria.*;

/**
 * 订单Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsOrderServiceImpl implements ICmsOrderService {

    @Autowired
    private CmsOrderDao cmsOrderDao;
    @Autowired
    private ICmsProductService cmsProductService;
    @Autowired
    private SysUserExhibitorDao sysUserExhibitorDao;

    /**
     * 查询订单
     *
     * @param orderId 订单ID
     * @return 订单
     */
    @Override
    public CmsOrder findById(Long orderId) {
        return cmsOrderDao.findById(orderId).get();
    }

    /**
     * 分页查询订单列表
     *
     * @param req 订单
     * @return 订单
     */
    @Override
    public Page<CmsOrder> findCmsOrderPage(CmsOrder req) {
        Specification<CmsOrder> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsOrder> page = cmsOrderDao.findAll(example, pageable);
        page.getContent().forEach(order -> {
            CmsProduct product = cmsProductService.findById(order.getProductId());
            order.setProduct(product);
        });
        return page;
    }

    /**
     * 分页查询订单列表
     *
     * @param req 订单
     * @return 订单
     */
    @Override
    public List<CmsOrder> findCmsOrderList(CmsOrder req) {
        Specification<CmsOrder> example = formatQueryParams(req);
        List<CmsOrder> list = cmsOrderDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    private Specification<CmsOrder> formatQueryParams(CmsOrder req){
        Specification<CmsOrder> example = new Specification<CmsOrder>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsOrder> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getOrderId()){
                    Predicate pre = cb.equal(root.get("orderId").as(Long.class), req.getOrderId());
                    list.add(pre);
                }
                if (null != req.getProductId()){
                    Predicate pre = cb.equal(root.get("productId").as(Long.class), req.getProductId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getRemark())){
                    Predicate pre = cb.equal(root.get("remark").as(String.class), req.getRemark());
                    list.add(pre);
                }
                if (null != req.getQuantity()){
                    Predicate pre = cb.equal(root.get("quantity").as(Long.class), req.getQuantity());
                    list.add(pre);
                }
                if (null != req.getIntendedPrice()){
                    Predicate pre = cb.equal(root.get("intendedPrice").as(BigDecimal.class), req.getIntendedPrice());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())){
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if(null != req.getUserId() && null != req.getBuyerId()){
                    list.add(cb.or(cb.equal(root.get("userId").as(Long.class), req.getUserId()),cb.equal(root.get("buyerId").as(Long.class), req.getBuyerId())));
                }else {
                    if (null != req.getUserId()){
                        Predicate pre = cb.equal(root.get("userId").as(Long.class), req.getUserId());
                        list.add(pre);
                    }
                    if (null != req.getBuyerId()){
                        Predicate pre = cb.equal(root.get("buyerId").as(Long.class), req.getBuyerId());
                        list.add(pre);
                    }
                }
                if (StringUtils.isNotBlank(req.getProductName())){
                    Predicate pre = cb.like(root.get("productName").as(String.class), "%" + req.getProductName()+ "%");
                    list.add(pre);
                }
                if (null != req.getProductPrice()){
                    Predicate pre = cb.equal(root.get("productPrice").as(BigDecimal.class), req.getProductPrice());
                    list.add(pre);
                }
                if (null != req.getDealAmounts()){
                    Predicate pre = cb.equal(root.get("dealAmounts").as(BigDecimal.class), req.getDealAmounts());
                    list.add(pre);
                }

                if (null != req.getUserName()){
                    Predicate pre = cb.like(root.get("userName").as(String.class), "%" + req.getUserName()+ "%");
                    list.add(pre);
                }
                if (null != req.getExhibitorName()){
                    Predicate pre = cb.like(root.get("exhibitorName").as(String.class), "%" + req.getExhibitorName()+ "%");
                    list.add(pre);
                }
                if (null != req.getOrderStatus()){
                    if (req.getOrderStatus().equals(OrderStatusQueryType.XUNPAN.getCode())){
                        //当穿10进来表示查询所有询盘数据
                        List<Long> statusList = new ArrayList<>();
                        statusList.add(OrderStatus.NORMAL.getCode());
                        statusList.add(OrderStatus.INVALID.getCode());
                        statusList.add(OrderStatus.EFFECTIVE.getCode());
                        CriteriaBuilder.In<Long> in = cb.in(root.get("orderStatus"));
                        statusList.forEach(in::value);
                        list.add(in);
                    }else if(req.getOrderStatus().equals(OrderStatusQueryType.ORDER.getCode())){
                        //当穿20进来表示查询所有订单数据
                        List<Long> statusList = new ArrayList<>();
                        statusList.add(OrderStatus.VOIDEO.getCode());
                        statusList.add(OrderStatus.EFFECTIVE.getCode());
                        statusList.add(OrderStatus.PROCESSED.getCode());
                        CriteriaBuilder.In<Long> in = cb.in(root.get("orderStatus"));
                        statusList.forEach(in::value);
                        list.add(in);
                    }else {
                        Predicate pre = cb.equal(root.get("orderStatus").as(Long.class), req.getOrderStatus());
                        list.add(pre);
                    }
                }
                //判断渠道数据权限
                LoginUser loginUser = SecurityUtils.getLoginUserNoThrow();
                boolean isChannel = (loginUser != null && loginUser.getUser() != null
                        && loginUser.getUser().getRoles() != null && loginUser.getUser().getRoles()
                        .stream().filter(item -> item.getRoleKey().startsWith("channel")).count()>0);
                if(isChannel){
                    Subquery subQuery = query.subquery(String.class);
                    Root from = subQuery.from(SysUser.class);
                    //创建子查询条件对象('where'后的语句对象)
                    Predicate predicate1 = cb.conjunction();
                    predicate1 = cb.and(predicate1,cb.equal(from.get("channelId"), loginUser.getUser().getUserId()));
                    //完成子查询
                    subQuery.select(from.get("deptId")).where(predicate1);

                    //过滤购买用户ID为渠道下面的展商的
                    Subquery subQuery2 = query.subquery(String.class);
                    Root from2 = subQuery2.from(SysUser.class);
                    //创建子查询条件对象('where'后的语句对象)
                    Predicate predicate2 = cb.conjunction();
                    predicate2 = cb.and(predicate2,cb.equal(from2.get("channelId"), loginUser.getUser().getUserId()));
                    //完成子查询
                    subQuery2.select(from2.get("userId")).where(predicate2);

                    list.add(cb.or(cb.in(root.get("userId")).value(subQuery), cb.in(root.get("buyerId")).value(subQuery2)));
                }
                //主办方按展区过滤数据权限
                if(loginUser != null && loginUser.getUser() != null && loginUser.getUser().getUserType().equals(UserType.ZBF_JS.getCode())){
                    List<Long> planIds = new ArrayList<>();
                    if(loginUser.getUser().getRoles() != null){
                        loginUser.getUser().getRoles().forEach(role -> {
                            if(com.yuejike.common.utils.StringUtils.isNotEmpty(role.getPlanIds())) {
                                Arrays.stream(role.getPlanIds().split(",")).forEach(it -> {
                                    if(!planIds.contains(Long.valueOf(it))){
                                        planIds.add(Long.valueOf(it));
                                    }
                                });
                            }
                        });
                    }
                    CriteriaBuilder.In<Long> in = cb.in(root.get("userId"));
                    List<Long> tmpUsers = null;
                    if(planIds.size()>0){
                        tmpUsers = sysUserExhibitorDao.getExhibitorDeptIdByPlanIds(planIds);
                    }
                    if(tmpUsers != null && tmpUsers.size()>0){
                        tmpUsers.forEach(user -> in.value(user));
                    }else{
                        in.value(0L);
                    }
                    Predicate deptPre = cb.conjunction();
                    deptPre = cb.and(deptPre, in);
                    list.add(deptPre);
                }

                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）订单
     *
     * @param cmsOrder 订单
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public CmsOrder save(CmsOrder cmsOrder) {
        // cmsOrder.setCreateTime(DateUtils.getNowDate());
        CmsOrder order = cmsOrderDao.save(cmsOrder);
        return order;
    }


    /**
     * 批量删除订单
     *
     * @param orderIds 需要删除的订单ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> orderIds) {
        List<CmsOrder> existBeans = cmsOrderDao.findAllById(orderIds);
        if(!existBeans.isEmpty()){
            cmsOrderDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除订单信息
     *
     * @param orderId 订单ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsOrderById(Long orderId) {
         cmsOrderDao.deleteById(orderId);
    }

    /**
     * 修改订单状态
     * @param
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int updateOrderStatus(CmsOrder cmsOrder) {
        CmsOrder cmsOrderOne = cmsOrderDao.findById(cmsOrder.getOrderId()).get();
        cmsOrderOne.setOrderStatus(cmsOrder.getOrderStatus());
        cmsOrderOne.setUpdateBy(cmsOrder.getUpdateBy());
        cmsOrderOne.setUpdateTime(cmsOrder.getUpdateTime());
        cmsOrderDao.save(cmsOrderOne);
        return BusinessBizCode.OPTION_SUCCESS.getCode();
    }

}
