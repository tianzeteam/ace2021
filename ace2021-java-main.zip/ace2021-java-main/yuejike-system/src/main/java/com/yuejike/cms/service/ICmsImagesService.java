package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsImages;

/**
 * 图片关联Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsImagesService  {
    /**
     * 查询图片关联
     *
     * @param imageId 图片关联ID
     * @return 图片关联
     */
    CmsImages findById(Long imageId);

    /**
     * 分页查询图片关联列表
     *
     * @param req 图片关联
     * @return 图片关联集合
     */
    Page<CmsImages> findCmsImagesPage(CmsImages req);

    /**
     * 查询图片关联列表
     *
     * @param req 图片关联
     * @return 图片关联集合
     */
    List<CmsImages> findCmsImagesList(CmsImages req);

    /**
     * 新增图片关联
     *
     * @param cmsImages 图片关联
     * @return 结果
     */
    void save(CmsImages cmsImages);

    /**
     * 批量删除图片关联
     *
     * @param imageIds 需要删除的图片关联ID
     * @return 结果
     */
    void deleteByIds(List<Long> imageIds);

    /**
     * 删除图片关联信息
     *
     * @param imageId 图片关联ID
     * @return 结果
     */
    void deleteCmsImagesById(Long imageId);
}
