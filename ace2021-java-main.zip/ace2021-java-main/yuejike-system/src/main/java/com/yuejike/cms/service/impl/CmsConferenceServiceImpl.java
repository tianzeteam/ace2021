package com.yuejike.cms.service.impl;

import com.yuejike.cms.dao.CmsConferenceDao;
import com.yuejike.cms.dao.SysUserExhibitorDao;
import com.yuejike.cms.domain.CmsClassification;
import com.yuejike.cms.domain.CmsConference;
import com.yuejike.cms.service.ICmsConferenceService;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.SecurityUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.*;
import java.util.*;

/**
 * 线下会议Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsConferenceServiceImpl implements ICmsConferenceService {

    @Autowired
    private CmsConferenceDao cmsConferenceDao;
    @Autowired
    private SysUserExhibitorDao sysUserExhibitorDao;


    /**
     * 查询线下会议
     *
     * @param conferenceId 线下会议ID
     * @return 线下会议
     */
    @Override
    public CmsConference findById(Long conferenceId) {
        return cmsConferenceDao.findById(conferenceId).get();
    }

    /**
     * 分页查询线下会议列表
     *
     * @param req 线下会议
     * @return 线下会议
     */
    @Override
    public Page<CmsConference> findCmsConferencePage(CmsConference req) {
        Specification<CmsConference> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsConference> page = cmsConferenceDao.findAll(example, pageable);
        return page;
    }

    /**
     * 分页查询线下会议列表
     *
     * @param req 线下会议
     * @return 线下会议
     */
    @Override
    public List<CmsConference> findCmsConferenceList(CmsConference req) {
        Specification<CmsConference> example = formatQueryParams(req);
        List<CmsConference> list = cmsConferenceDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    private Specification<CmsConference> formatQueryParams(CmsConference req){
        Specification<CmsConference> example = new Specification<CmsConference>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsConference> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getConferenceId()){
                    Predicate pre = cb.equal(root.get("conferenceId").as(Long.class), req.getConferenceId());
                    list.add(pre);
                }
                if (null != req.getExhibitorId()){
                    Predicate pre = cb.equal(root.get("exhibitorId").as(Long.class), req.getExhibitorId());
                    list.add(pre);
                }
                if (null != req.getCreateId()){
                    Predicate pre = cb.equal(root.get("createId").as(Long.class), req.getCreateId());
                    list.add(pre);
                }
                if (null != req.getExpositionId()){
                    Predicate pre = cb.equal(root.get("expositionId").as(Long.class), req.getExpositionId());
                    list.add(pre);
                }
                //模糊查询
                if (StringUtils.isNotBlank(req.getTitle())){
                    Predicate pre = cb.like(root.get("title").as(String.class), "%"+req.getTitle()+"%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getContent())){
                    Predicate pre = cb.equal(root.get("content").as(String.class), req.getContent());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getSource())){
                    Predicate pre = cb.equal(root.get("source").as(String.class), req.getSource());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getImgUrl())){
                    Predicate pre = cb.equal(root.get("imgUrl").as(String.class), req.getImgUrl());
                    list.add(pre);
                }
                if (null != req.getStartTime()){
                    Predicate pre = cb.equal(root.get("startTime").as(Date.class), req.getStartTime());
                    list.add(pre);
                }
                if (null != req.getEndTime()){
                    Predicate pre = cb.equal(root.get("endTime").as(Date.class), req.getEndTime());
                    list.add(pre);
                }
                if (null != req.getPushTime()){
                    Predicate pre = cb.equal(root.get("pushTime").as(Date.class), req.getPushTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getOrganizer())){
                    Predicate pre = cb.equal(root.get("organizer").as(String.class), req.getOrganizer());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getHostAddress())){
                    Predicate pre = cb.equal(root.get("hostAddress").as(String.class), req.getHostAddress());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getType())){
                    Predicate pre = cb.equal(root.get("type").as(String.class), req.getType());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getStatus())){
                    Predicate pre = cb.equal(root.get("status").as(String.class), req.getStatus());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())){
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (null != req.getReviewerId()){
                    Predicate pre = cb.equal(root.get("reviewerId").as(Long.class), req.getReviewerId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getRejectReason())){
                    Predicate pre = cb.equal(root.get("rejectReason").as(String.class), req.getRejectReason());
                    list.add(pre);
                }
                //判断渠道数据权限
                LoginUser loginUser = SecurityUtils.getLoginUserNoThrow();
                boolean isChannel = (loginUser != null && loginUser.getUser() != null
                        && loginUser.getUser().getRoles() != null && loginUser.getUser().getRoles()
                        .stream().filter(item -> item.getRoleKey().startsWith("channel")).count()>0);
                if(isChannel){
                    Subquery subQuery = query.subquery(String.class);
                    Root from = subQuery.from(SysUser.class);
                    //创建子查询条件对象('where'后的语句对象)
                    Predicate predicate1 = cb.conjunction();
                    predicate1 = cb.and(predicate1,cb.equal(from.get("channelId"), loginUser.getUser().getUserId()));
                    //完成子查询
                    subQuery.select(from.get("deptId")).where(predicate1);
                    //把子查询结果拼接到原查询语句后面---这里是dept_id in的写法
                    //过滤渠道用户数据权限
                    Predicate deptPre = cb.conjunction();
                    deptPre = cb.and(deptPre, cb.in(root.get("deptId")).value(subQuery));
                    list.add(deptPre);
                }
                //主办方按展区过滤数据权限
                if(loginUser != null && loginUser.getUser() != null && loginUser.getUser().getUserType().equals(UserType.ZBF_JS.getCode())){
                    List<Long> planIds = new ArrayList<>();
                    if(loginUser.getUser().getRoles() != null){
                        loginUser.getUser().getRoles().forEach(role -> {
                            if(com.yuejike.common.utils.StringUtils.isNotEmpty(role.getPlanIds())) {
                                Arrays.stream(role.getPlanIds().split(",")).forEach(it -> {
                                    if(!planIds.contains(Long.valueOf(it))){
                                        planIds.add(Long.valueOf(it));
                                    }
                                });
                            }
                        });
                    }
                    CriteriaBuilder.In<Long> in = cb.in(root.get("deptId"));
                    List<Long> tmpUsers = null;
                    if(planIds.size()>0){
                        tmpUsers = sysUserExhibitorDao.getExhibitorDeptIdByPlanIds(planIds);
                    }
                    if(tmpUsers != null && tmpUsers.size()>0){
                        tmpUsers.forEach(user -> in.value(user));
                    }else{
                        in.value(0L);
                    }
                    Predicate deptPre = cb.conjunction();
                    deptPre = cb.and(deptPre, in);
                    list.add(deptPre);
                }

                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）线下会议
     *
     * @param cmsConference 线下会议
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void save(CmsConference cmsConference) {
        cmsConferenceDao.save(cmsConference);
    }


    /**
     * 批量删除线下会议
     *
     * @param conferenceIds 需要删除的线下会议ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> conferenceIds) {
        List<CmsConference> existBeans = cmsConferenceDao.findAllById(conferenceIds);
        if(!existBeans.isEmpty()){
            cmsConferenceDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除线下会议信息
     *
     * @param conferenceId 线下会议ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsConferenceById(Long conferenceId) {
         cmsConferenceDao.deleteById(conferenceId);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void batchAudit(Long[] conferenceIds, CmsConference cmsConference) {
        List<CmsConference> cmsConferences = cmsConferenceDao.findAllById(Arrays.asList(conferenceIds));
        for(CmsConference cmsConferenceTmp : cmsConferences) {
            cmsConferenceTmp.setReviewerId(cmsConference.getReviewerId());
            cmsConferenceTmp.setExpositionId(cmsConference.getExpositionId());
            cmsConferenceTmp.setReviewerName(cmsConference.getReviewerName());
            cmsConferenceTmp.setUpdateBy(cmsConference.getUpdateBy());
            cmsConferenceTmp.setUpdateTime(cmsConference.getUpdateTime());
            cmsConferenceTmp.setStatus(cmsConference.getStatus());
            cmsConferenceTmp.setRejectReason(cmsConference.getRejectReason());

        }
        cmsConferenceDao.saveAll(cmsConferences);
    }
}
