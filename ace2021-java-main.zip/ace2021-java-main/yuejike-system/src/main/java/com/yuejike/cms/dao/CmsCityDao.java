package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsCity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;


/**
 * 城市字典Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-26
 */
@Repository
public interface CmsCityDao extends JpaRepository<CmsCity, Long>, JpaSpecificationExecutor<CmsCity> {



}
