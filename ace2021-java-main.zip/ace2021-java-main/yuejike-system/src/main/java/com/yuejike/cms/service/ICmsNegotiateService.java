package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsNegotiate;

/**
 * 洽谈沟通Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsNegotiateService  {
    /**
     * 查询洽谈沟通
     *
     * @param negotiateId 洽谈沟通ID
     * @return 洽谈沟通
     */
    CmsNegotiate findById(Long negotiateId);

    /**
     * 分页查询洽谈沟通列表
     *
     * @param req 洽谈沟通
     * @return 洽谈沟通集合
     */
    Page<CmsNegotiate> findCmsNegotiatePage(CmsNegotiate req);

    /**
     * 查询洽谈沟通列表
     *
     * @param req 洽谈沟通
     * @return 洽谈沟通集合
     */
    List<CmsNegotiate> findCmsNegotiateList(CmsNegotiate req);

    /**
     * 新增洽谈沟通
     *
     * @param cmsNegotiate 洽谈沟通
     * @return 结果
     */
    CmsNegotiate save(CmsNegotiate cmsNegotiate);

    /**
     * 批量删除洽谈沟通
     *
     * @param negotiateIds 需要删除的洽谈沟通ID
     * @return 结果
     */
    void deleteByIds(List<Long> negotiateIds);

    /**
     * 删除洽谈沟通信息
     *
     * @param negotiateId 洽谈沟通ID
     * @return 结果
     */
    void deleteCmsNegotiateById(Long negotiateId);
}
