package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsOrder;

/**
 * 订单Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsOrderService  {
    /**
     * 查询订单
     *
     * @param orderId 订单ID
     * @return 订单
     */
    CmsOrder findById(Long orderId);

    /**
     * 分页查询订单列表
     *
     * @param req 订单
     * @return 订单集合
     */
    Page<CmsOrder> findCmsOrderPage(CmsOrder req);

    /**
     * 查询订单列表
     *
     * @param req 订单
     * @return 订单集合
     */
    List<CmsOrder> findCmsOrderList(CmsOrder req);

    /**
     * 新增订单
     *
     * @param cmsOrder 订单
     * @return 结果
     */
    CmsOrder save(CmsOrder cmsOrder);

    /**
     * 批量删除订单
     *
     * @param orderIds 需要删除的订单ID
     * @return 结果
     */
    void deleteByIds(List<Long> orderIds);

    /**
     * 删除订单信息
     *
     * @param orderId 订单ID
     * @return 结果
     */
    void deleteCmsOrderById(Long orderId);
    /**
     * 修改订单状态
     * @param cmsOrder
     * @return
     */
    int updateOrderStatus(CmsOrder cmsOrder);
}
