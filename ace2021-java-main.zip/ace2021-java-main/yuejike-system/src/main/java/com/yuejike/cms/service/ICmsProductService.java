package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsProduct;

/**
 * 展品信息Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsProductService  {
    /**
     * 查询展品信息
     *
     * @param productId 展品信息ID
     * @return 展品信息
     */
    CmsProduct findById(Long productId);

    /**
     * 分页查询展品信息列表
     *
     * @param req 展品信息
     * @return 展品信息集合
     */
    Page<CmsProduct> findCmsProductPage(CmsProduct req);

    /**
     * 查询展品信息列表
     *
     * @param req 展品信息
     * @return 展品信息集合
     */
    List<CmsProduct> findCmsProductList(CmsProduct req);

    /**
     * 新增展品信息
     *
     * @param cmsProduct 展品信息
     * @return 结果
     */
    void save(CmsProduct cmsProduct);

    /**
     * 批量删除展品信息
     *
     * @param productIds 需要删除的展品信息ID
     * @return 结果
     */
    void deleteByIds(List<Long> productIds);

    /**
     * 删除展品信息信息
     *
     * @param productId 展品信息ID
     * @return 结果
     */
    void deleteCmsProductById(Long productId);

    /**
     * 修改场馆状态
     * @param cmsProduct
     * @return
     */
    int updateAuditStatus(CmsProduct cmsProduct);

    /**
     * 修改场馆状态
     * @param cmsProduct
     * @return
     */
    int updateVisibleStatus(CmsProduct cmsProduct);

    int findByClassificationId(Long classificationId);

    void batchReSorted(List<CmsProduct> cmsProducts);

    int batchRecommend(Long[] productIds, String type);

    Long getAllCount();
}
