package com.yuejike.cms.domain;


import java.util.Date;

import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import javax.persistence.*;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 会议报名对象 cms_enroll
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_enroll")
@Data
public class CmsEnroll extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="enroll_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long enrollId;

    /** 报名用户id */
    @Excel(name = "报名用户id")
    @Column(name="user_id")
    @ApiModelProperty(value = "报名用户id")
    private Long userId;

    /** 会议id */
    @Excel(name = "会议id")
    @Column(name="conference_id")
    @ApiModelProperty(value = "会议id")
    private Long conferenceId;

    /** 审核状态(0:待审核1:已通过2:已拒绝) */
    @Excel(name = "审核状态(0:待审核1:已通过2:已拒绝)")
    @Column(name="status")
    @ApiModelProperty(value = "审核状态(0:待审核1:已通过2:已拒绝)")
    private String status;

    /** 删除标识(0:正常1:删除) */
    @Column(name="del_flag")
    @ApiModelProperty(value = "审核状态(0:待审核1:已通过2:已拒绝)")
    private String delFlag;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "审核状态(0:待审核1:已通过2:已拒绝)")
    private String createBy;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "审核状态(0:待审核1:已通过2:已拒绝)")
    private Date createTime;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "审核状态(0:待审核1:已通过2:已拒绝)")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "审核状态(0:待审核1:已通过2:已拒绝)")
    private Date updateTime;

    /** 审核拒绝原因 */
    @Excel(name = "审核拒绝原因")
    @Column(name="reject_reason")
    @ApiModelProperty(value = "审核拒绝原因")
    private String rejectReason;

    /** 审核人id */
    @Excel(name = "审核人id")
    @Column(name="reviewer_id")
    @ApiModelProperty(value = "审核人id")
    private Long reviewerId;

    /** 审核人id */
    @Excel(name = "直播id")
    @Column(name="live_id")
    @ApiModelProperty(value = "直播id")
    private Long liveId;

    /** 姓名 */
    @Excel(name = "姓名")
    @Column(name="name")
    @ApiModelProperty(value = "姓名")
    private String name;

    /** 证件类型(0：身份证1：港澳通行证2：护照) */
    @Excel(name = "证件类型(0：身份证1：港澳通行证2：护照)")
    @Column(name="card_type")
    @ApiModelProperty(value = "证件类型(0：身份证1：港澳通行证2：护照)")
    private String cardType;

    /** 姓名 */
    @Excel(name = "证件号码")
    @Column(name="card_number")
    @ApiModelProperty(value = "证件号码")
    private String cardNumber;

    /** 姓名 */
    @Excel(name = "联系电话")
    @Column(name="phone_number")
    @ApiModelProperty(value = "联系电话")
    private String phoneNumber;

    /** 单位名称 */
    @Excel(name = "单位名称")
    @Column(name="company_nam")
    @ApiModelProperty(value = "单位名称")
    private String companyNam;

    /**  头像地址
     */
    @Excel(name = "头像地址")
    @Column(name="avatar")
    @ApiModelProperty(value = "头像地址")
    private String avatar;

    /** 单位名称 */
    @Excel(name = "类型(0：直播 1：线下会议)")
    @Column(name="type")
    @ApiModelProperty(value = "类型(0：直播 1：线下会议)")
    private String type;

    /** 审核人名字 */
    @Excel(name = "审核人名字")
    @Column(name="reviewer_name")
    @ApiModelProperty(value = "审核人名字")
    private String reviewerName;

    /** 单位名称 */
    @Excel(name = "会议名称")
    @Column(name="conference_name")
    @ApiModelProperty(value = "会议名称")
    private String conferenceName;

    /** 单位名称 */
    @Excel(name = "展商名称")
    @Column(name="exhibitor_name")
    @ApiModelProperty(value = "展商名称")
    private String exhibitorName;

    /** 展商id */
    @Excel(name = "展商id")
    @Column(name="exhibitor_id")
    @ApiModelProperty(value = "展商id")
    private Long exhibitorId;

    @Transient
    private Date startTime;

    @Transient
    private Date endTime;

    @Transient
    private CmsConference conference;

    @Transient
    private CmsLive live;
}

