package com.yuejike.cms.service.impl;

import com.yuejike.cms.dao.CmsLabelDao;
import com.yuejike.cms.domain.CmsLabel;
import com.yuejike.cms.service.ICmsLabelService;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import com.yuejike.common.utils.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.*;

/**
 * 标签Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsLabelServiceImpl implements ICmsLabelService {

    @Autowired
    private CmsLabelDao cmsLabelDao;

    /**
     * 查询标签
     *
     * @param labelId 标签ID
     * @return 标签
     */
    @Override
    public CmsLabel findById(Long labelId) {
        return cmsLabelDao.findById(labelId).get();
    }

    /**
     * 分页查询标签列表
     *
     * @param req 标签
     * @return 标签
     */
    @Override
    public Page<CmsLabel> findCmsLabelPage(CmsLabel req) {
        Specification<CmsLabel> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsLabel> page = cmsLabelDao.findAll(example, pageable);
        return page;
    }

    /**
     * 分页查询标签列表
     *
     * @param req 标签
     * @return 标签
     */
    @Override
    public List<CmsLabel> findCmsLabelList(CmsLabel req) {
        Specification<CmsLabel> example = formatQueryParams(req);
        List<CmsLabel> list = cmsLabelDao.findAll(example, Sort.by(Sort.Direction.DESC, "createTime"));
        return list;
    }

    private Specification<CmsLabel> formatQueryParams(CmsLabel req) {
        Specification<CmsLabel> example = new Specification<CmsLabel>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsLabel> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getLabelId()) {
                    Predicate pre = cb.equal(root.get("labelId").as(Long.class), req.getLabelId());
                    list.add(pre);
                }
                if (null != req.getExpositionId()) {
                    Predicate pre = cb.equal(root.get("expositionId").as(Long.class), req.getExpositionId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getLabelName())) {
                    Predicate pre = cb.like(root.get("labelName").as(String.class), "%" + req.getLabelName() + "%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getImgUrl())) {
                    Predicate pre = cb.equal(root.get("imgUrl").as(String.class), req.getImgUrl());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getType())) {
                    Predicate pre = cb.equal(root.get("type").as(String.class), req.getType());
                    list.add(pre);
                }
                if (null != req.getUserId()) {
                    Predicate pre = cb.equal(root.get("userId").as(Long.class), req.getUserId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())) {
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (null != req.getCreateTime()) {
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()) {
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())) {
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())) {
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getVisible())) {
                    Predicate pre = cb.equal(root.get("visible").as(String.class), req.getVisible());
                    list.add(pre);
                }
                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 批量查询标签
     *
     * @param labelIds
     * @return
     */
    private Specification<CmsLabel> formatQueryByIds(Collections labelIds) {
        if (null == labelIds) {
            throw new NullPointerException("labelIds 不能为 null");
        }
        Specification<CmsLabel> example = new Specification<CmsLabel>() {
            private static final long serialVersionUID = 1L;
            @Override
            public Predicate toPredicate(Root<CmsLabel> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                Predicate pre = root.get("labelId").in(labelIds);
                return cb.and(pre);
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）标签
     *
     * @param cmsLabel 标签
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void save(CmsLabel cmsLabel) {
        cmsLabel.setCreateTime(DateUtils.getNowDate());
        cmsLabelDao.save(cmsLabel);
    }


    /**
     * 批量删除标签
     *
     * @param labelIds 需要删除的标签ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> labelIds) {
        List<CmsLabel> existBeans = cmsLabelDao.findAllById(labelIds);
        if (!existBeans.isEmpty()) {
            cmsLabelDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除标签信息
     *
     * @param labelId 标签ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsLabelById(Long labelId) {
        cmsLabelDao.deleteById(labelId);
    }
}
