package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsModelExtend;

/**
 * 模型扩展信息Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsModelExtendService  {
    /**
     * 查询模型扩展信息
     *
     * @param id 模型扩展信息ID
     * @return 模型扩展信息
     */
    CmsModelExtend findById(Long id);

    /**
     * 分页查询模型扩展信息列表
     *
     * @param req 模型扩展信息
     * @return 模型扩展信息集合
     */
    Page<CmsModelExtend> findCmsModelExtendPage(CmsModelExtend req);

    /**
     * 根据栏目id获取模型扩展字段列表
     *
     * @param categoryId 栏目ID
     * @return
     */
    List<CmsModelExtend> getModelExtendList(Long categoryId);
    /**
     * 查询模型扩展信息列表
     *
     * @param req 模型扩展信息
     * @return 模型扩展信息集合
     */
    List<CmsModelExtend> findCmsModelExtendList(CmsModelExtend req);

    /**
     * 新增模型扩展信息
     *
     * @param cmsModelExtend 模型扩展信息
     * @return 结果
     */
    void save(CmsModelExtend cmsModelExtend);

    /**
     * 批量删除模型扩展信息
     *
     * @param ids 需要删除的模型扩展信息ID
     * @return 结果
     */
    void deleteByIds(List<Long> ids);

    /**
     * 删除模型扩展信息信息
     *
     * @param id 模型扩展信息ID
     * @return 结果
     */
    void deleteCmsModelExtendById(Long id);

    int deleteByModelId(Long modelId);
}
