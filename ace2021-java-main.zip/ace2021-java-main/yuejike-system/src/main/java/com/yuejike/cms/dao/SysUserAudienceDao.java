package com.yuejike.cms.dao;

import com.yuejike.cms.domain.SysUserAudience;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;


/**
 * 专业观众信息Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-26
 */
@Repository
public interface SysUserAudienceDao extends JpaRepository<SysUserAudience, Long>, JpaSpecificationExecutor<SysUserAudience> {



}
