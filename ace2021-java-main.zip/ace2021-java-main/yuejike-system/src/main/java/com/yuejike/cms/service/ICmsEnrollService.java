package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsEnroll;
import org.springframework.data.repository.query.Param;

/**
 * 会议报名Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsEnrollService  {
    /**
     * 查询会议报名
     *
     * @param enrollId 会议报名ID
     * @return 会议报名
     */
    CmsEnroll findById(Long enrollId);

    /**
     * 分页查询会议报名列表
     *
     * @param req 会议报名
     * @return 会议报名集合
     */
    Page<CmsEnroll> findCmsEnrollPage(CmsEnroll req);

    /**
     * 查询会议报名列表
     *
     * @param req 会议报名
     * @return 会议报名集合
     */
    List<CmsEnroll> findCmsEnrollList(CmsEnroll req);

    /**
     * 新增会议报名
     *
     * @param cmsEnroll 会议报名
     * @return 结果
     */
    void save(CmsEnroll cmsEnroll);

    /**
     * 批量删除会议报名
     *
     * @param enrollIds 需要删除的会议报名ID
     * @return 结果
     */
    void deleteByIds(List<Long> enrollIds);

    /**
     * 删除会议报名信息
     *
     * @param enrollId 会议报名ID
     * @return 结果
     */
    void deleteCmsEnrollById(Long enrollId);

    List<CmsEnroll> findByLiveId(Long liveId);

    CmsEnroll findByLiveIdAndUserId(Long liveId,Long userId);

    int updateByConferenceId(Long conferenceId);

    int updateByLiveId(Long liveId);

}
