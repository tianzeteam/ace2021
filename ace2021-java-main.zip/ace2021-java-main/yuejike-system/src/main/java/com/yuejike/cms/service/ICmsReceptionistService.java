package com.yuejike.cms.service;

import com.yuejike.cms.domain.Receptionist;
import org.springframework.data.domain.Page;

/**
 * @author JinZJ
 * @version 1.0
 * @Description:
 * @date 2021/11/17 17:12
 */
public interface ICmsReceptionistService {
    Page<Receptionist> selectReceptionistList(Receptionist req);

    Receptionist save(Receptionist receptionist);

    void deleteReceptionistByIds(Long[] ids);
}
