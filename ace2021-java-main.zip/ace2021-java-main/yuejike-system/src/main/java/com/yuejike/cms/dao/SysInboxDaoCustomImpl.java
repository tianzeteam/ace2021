package com.yuejike.cms.dao;

import com.yuejike.cms.dao.SysInboxDaoCustom;
import com.yuejike.cms.domain.SysInbox;
import com.yuejike.cms.dto.SysInboxDTO;
import com.yuejike.common.utils.bean.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.query.internal.NativeQueryImpl;
import org.hibernate.transform.Transformers;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Transactional(readOnly = true)
@Service
public class SysInboxDaoCustomImpl implements SysInboxDaoCustom {
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Page<SysInbox> findInboxPage(SysInbox req, Pageable pageable) {
        ArrayList<Object> params = new ArrayList<>();
        StringBuilder sql = new StringBuilder();
        sql.append("FROM sys_inbox i ");
        sql.append("LEFT JOIN sys_user u ON (u.user_id=i.send_id) ");

        buildWhere(sql,req,params);
        Query totalQuery = entityManager.createNativeQuery("select count(*) " + sql.toString());

        List<?> resultList = totalQuery.getResultList();
        if (resultList.isEmpty()) {
            return Page.empty();
        }
        BigInteger total = (BigInteger) resultList.get(0);
        Query contentQuery = entityManager.createNativeQuery("select i.inbox_id inboxId ,u.nick_name sendName,i.accept_id acceptId,i.send_id sendId,i.notice_id noticeId,i.create_by createBy,i.create_time createTime,i.status status,i.del_flag delFlag " + sql.toString());

        contentQuery.unwrap(NativeQueryImpl.class).setResultTransformer(Transformers.aliasToBean(SysInboxDTO.class));
        contentQuery.setFirstResult(pageable.getPageNumber() * pageable.getPageSize());
        contentQuery.setMaxResults(pageable.getPageSize());
        List<SysInboxDTO> result = contentQuery.getResultList();
        List<SysInbox> collect = result.stream().map(s -> {
            SysInbox sysInbox = new SysInbox();
            BeanUtils.copyProperties(s, sysInbox);
            sysInbox.setInboxId(s.getInboxId().longValue());
            sysInbox.setSendId(s.getSendId().longValue());
            sysInbox.setAcceptId(s.getAcceptId().longValue());
            sysInbox.setDelFlag(s.getDelFlag().toString());
            // sysInbox.setIsPush(s.getIsPush().toString());
            sysInbox.setStatus(s.getStatus().toString());
            sysInbox.setNoticeId(s.getNoticeId().longValue());
            // sysInbox.setType(s.getType().toString());
            return sysInbox;
        }).collect(Collectors.toList());
        return new PageImpl<>(collect, pageable, total.intValue());
    }

    private void buildWhere(StringBuilder sql, SysInbox req, List<Object> params) {
        sql.append("  where i.del_flag = '0'  ");
        // if (StringUtils.isNotBlank(req.getTitle())) {
        //     sql.append("   AND i.title like ? ");
        //     params.add("%" + req.getTitle() + "%");
        // }
        if(null != req.getAcceptId()){
            sql.append("   AND i.accept_id = ? ");
            params.add(req.getAcceptId());
        }
        if (StringUtils.isNotBlank(req.getStatus())) {
            sql.append("   AND i.status = ? ");
            params.add(req.getStatus());
        }
        if (null != req.getNoticeId()) {
            sql.append("   AND i.notice_id = ? ");
            params.add(req.getNoticeId());
        }
        // if (StringUtils.isNotBlank(req.getContent())) {
        //     sql.append("   AND i.content like ? ");
        //     params.add("%" + req.getContent() + "%");
        // }
        sql.append(req.getParams().getOrDefault("dataScope", ""));
    }
}
