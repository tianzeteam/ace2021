package com.yuejike.cms.dto;

import com.yuejike.common.annotation.Excel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Column;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 参展商信息对象 sys_user_exhibitor
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Data
public class SysUserExhibitorDTO {

    private static final long serialVersionUID = 1L;

    /** id */
    @ApiModelProperty(value = "展商ID")
    private Long userId;

    /** 参展商中文名称 */
    @ApiModelProperty(value = "参展商中文名称")
    private String name;

    /** 参展商英文名称 */
    @ApiModelProperty(value = "参展商中参展商英文名称文名称")
    private String enName;

    @ApiModelProperty(value = "参展商中参展商日文名称文名称")
    private String jaName;

    @ApiModelProperty(value = "参展商中参展商韩文名称文名称")
    private String koName;

    /**
     * 2022年2月新增简称
     */
    @ApiModelProperty(value = "参展商简称")
    private String shortName;

    @ApiModelProperty(value = "参展商英文简称")
    private String enShortName;

    @ApiModelProperty(value = "参展商日文简称")
    private String jaShortName;

    @ApiModelProperty(value = "参展商韩文简称")
    private String koShortName;

    /** 联系人 */
    @ApiModelProperty(value = "联系人")
    private String contacts;

    /** 联系人部门/岗位 */
    @ApiModelProperty(value = "联系人部门/岗位")
    private String contactsDept;

    /** 电话 */
    @ApiModelProperty(value = "电话")
    private String phone;

    /** 参展商logo */
    @ApiModelProperty(value = "参展商logo")
    private String logo;

    /** 营业执照 */
    @ApiModelProperty(value = "营业执照")
    private String licenseUrl;

    /** 邮箱 */
    @ApiModelProperty(value = "邮箱")
    private String email;

    /** 公司简介_中文 */
    @ApiModelProperty(value = "公司简介_中文")
    private String cnProfile;

    /** 公司简介_中文 */
    @ApiModelProperty(value = "公司简介_中文")
    private String enProfile;

    @ApiModelProperty(value = "公司简介_日文")
    private String jaProfile;

    @ApiModelProperty(value = "公司简介_韩文")
    private String koProfile;

   /** 创建人 */
   @ApiModelProperty(value = "创建人")
   private String createBy;

   /** 创建时间 */
   @ApiModelProperty(value = "创建时间")
   private Date createTime;

   /** 更新人 */
   @ApiModelProperty(value = "更新人")
   private String updateBy;

   /** 更新时间 */
   @ApiModelProperty(value = "更新时间")
   private Date updateTime;

    /** 参展商地址 */
    @ApiModelProperty(value = "参展商地址")
    private String address;

    /** 排序 */
    @ApiModelProperty(value = "排序")
    private Integer sort;

    /** 删除标识 */
//    @ApiModelProperty(value = "排序")
//    private String delFlag;

    /** 是否显示（0：显示1：隐藏） */
   @ApiModelProperty(value = "是否显示")
   private String visible;

    /** 官网地址 */
    @ApiModelProperty(value = "官网地址")
    private String website;

    /** 企业规模 */
    @ApiModelProperty(value = "企业规模")
    private String scale;

    /** 注册资金 */
    @ApiModelProperty(value = "注册资金")
    private BigDecimal capital;

    /** 企业分类 */
    @ApiModelProperty(value = "企业分类")
    private Long classificationId;

    /** 主营产品 */
    @ApiModelProperty(value = "主营产品")
    private String mainProducts;

    /** 企业属性 */
    @ApiModelProperty(value = "企业属性")
    private String attribute;

    /** 参展年数 */
    @ApiModelProperty(value = "参展年数")
    private Long joinYears;

    /** 场馆id */
    @ApiModelProperty(value = "场馆id")
    private Long hallId;

    /** 参展商所在国家 */
    @ApiModelProperty(value = "参展商所在国家")
    private Long countryId;

    /** 参展商省份 */
    @ApiModelProperty(value = "参展商所在省份")
    private String province;

    @ApiModelProperty(value = "参展商所在省份ID")
    private Long provinceId;

    /** 参展商所在城市 */
    @ApiModelProperty(value = "参展商所在城市")
    private String city;

    @ApiModelProperty(value = "参展商所在城市ID")
    private Long cityId;

    /** 企业视频 */
    @ApiModelProperty(value = "企业视频")
    private String videoUrl;

    /** 展商精彩视频地址 */
    @ApiModelProperty(value = "展商精彩视频地址")
    private String excellentVideoUrl;

    /** 展商精彩审核人id */
    @ApiModelProperty(value = "展商精彩审核人id")
    private Long excellectVideoReviewerId;

    /** 展商精彩视频审核状态(0:待审核1：已通过2：已拒绝) */
    @ApiModelProperty(value = "展商精彩视频审核状态(0:待审核1：已通过2：已拒绝)")
    private String excellentVideoStatus;

    /** 展商精彩审核拒绝原因 */
    @ApiModelProperty(value = "展商精彩审核拒绝原因")
    private String excellentVideoRejectReason;

    private Date excellentVideoReviewTime;
    /** 展商标签id */
    @ApiModelProperty(value = "展商标签id")
    private String labelId;

    /** 社会统一代码 */
    @ApiModelProperty(value = "社会统一代码")
    private String socialCode;

    /** 展会编号 */
    @ApiModelProperty(value = "展会编号")
    private String exhibitionNumber;

    /** 图集 */
    @ApiModelProperty(value = "图集")
    private String imgUrl;

    /** banner **/
    @ApiModelProperty(value = "banner：多张用逗号分隔")
    private String bannerUrl;

    /** 展商精彩视频封面 */
    @ApiModelProperty(value = "展商精彩视频封面")
    private String excellentVideoCover;

    /** 展商精彩视频名称 */
    @ApiModelProperty(value = "展商精彩视频名称")
    private String excellentVideoName;

    /** 展商精彩视频分类 */
    @ApiModelProperty(value = "展商精彩视频分类")
    private Long excellentVideoClassificationId;

    /** 3D访问量 */
    private Integer historyViews;

    /** 3D审核状态 **/
    private String status;

    /** 3D排序 **/
    private Integer vSort;

    private String reviewStatus;

    private String targetMarket;

    private String basicinfoReviewStatus;

    private String updateObj;

    private Long basicinfoReviewId;

    private Date basicinfoReviewTime;

    private String basicinfoReviewRejectReason;

    /** 仅线上 **/
    @ApiModelProperty(value = "仅线上：0-全部，1-仅线上")
    private String onlineOnly;

    @ApiModelProperty(value = "参展年份，例如：2022,2023,2025")
    private String joinYearsArr;

    @ApiModelProperty(value = "报名状态，0未报名，1已报名")
    private String signUpStatus;

    @ApiModelProperty(value = "是否推荐：0-未推荐，1-推荐")
    private String recommend;

    @ApiModelProperty(value = "是否是超级品牌：0-不是，1-是")
    private String superBrand;

}

