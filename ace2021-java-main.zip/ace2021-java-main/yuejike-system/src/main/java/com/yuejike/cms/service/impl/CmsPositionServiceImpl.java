package com.yuejike.cms.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.yuejike.common.utils.DateUtils;

import java.util.Date;
import org.apache.commons.lang3.StringUtils;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yuejike.cms.dao.CmsPositionDao;
import com.yuejike.cms.domain.CmsPosition;
import com.yuejike.cms.service.ICmsPositionService;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/**
 * 位置信息管理Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsPositionServiceImpl implements ICmsPositionService {

    @Autowired
    private CmsPositionDao cmsPositionDao;

    /**
     * 查询位置信息管理
     *
     * @param positionId 位置信息管理ID
     * @return 位置信息管理
     */
    @Override
    public CmsPosition findById(Long positionId) {
        return cmsPositionDao.findById(positionId).get();
    }

    /**
     * 分页查询位置信息管理列表
     *
     * @param req 位置信息管理
     * @return 位置信息管理
     */
    @Override
    public Page<CmsPosition> findCmsPositionPage(CmsPosition req) {
        Specification<CmsPosition> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsPosition> page = cmsPositionDao.findAll(example, pageable);
        return page;
    }

    /**
     * 分页查询位置信息管理列表
     *
     * @param req 位置信息管理
     * @return 位置信息管理
     */
    @Override
    public List<CmsPosition> findCmsPositionList(CmsPosition req) {
        Specification<CmsPosition> example = formatQueryParams(req);
        List<CmsPosition> list = cmsPositionDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    private Specification<CmsPosition> formatQueryParams(CmsPosition req){
        Specification<CmsPosition> example = new Specification<CmsPosition>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsPosition> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getPositionId()){
                    Predicate pre = cb.equal(root.get("positionId").as(Long.class), req.getPositionId());
                    list.add(pre);
                }
                if (null != req.getExpositionId()){
                    Predicate pre = cb.equal(root.get("expositionId").as(Long.class), req.getExpositionId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getPositionTitle())){
                    Predicate pre = cb.equal(root.get("positionTitle").as(String.class), req.getPositionTitle());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getStatus())){
                    Predicate pre = cb.equal(root.get("status").as(String.class), req.getStatus());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())){
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getRemark())){
                    Predicate pre = cb.equal(root.get("remark").as(String.class), req.getRemark());
                    list.add(pre);
                }
                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）位置信息管理
     *
     * @param cmsPosition 位置信息管理
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void save(CmsPosition cmsPosition) {
        cmsPosition.setCreateTime(DateUtils.getNowDate());
        cmsPositionDao.save(cmsPosition);
    }


    /**
     * 批量删除位置信息管理
     *
     * @param positionIds 需要删除的位置信息管理ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> positionIds) {
        List<CmsPosition> existBeans = cmsPositionDao.findAllById(positionIds);
        if(!existBeans.isEmpty()){
            cmsPositionDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除位置信息管理信息
     *
     * @param positionId 位置信息管理ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsPositionById(Long positionId) {
         cmsPositionDao.deleteById(positionId);
    }
}
