package com.yuejike.cms.dao;

import com.yuejike.cms.domain.SysInbox;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;


/**
 * 站内信Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Repository
public interface SysInboxDao extends JpaRepository<SysInbox, Long>, JpaSpecificationExecutor<SysInbox> {



}
