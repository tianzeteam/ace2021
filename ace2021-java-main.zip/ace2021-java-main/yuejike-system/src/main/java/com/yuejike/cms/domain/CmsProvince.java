package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 省会字典对象 cms_province
 *
 * @author tangdw
 * @since 1.0 2021-08-26
 */
@Entity
@Table(name = "cms_province")
@Data
@JsonIgnoreProperties(value = {"hibernateLazyInitializer"})
public class CmsProvince extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** 省会id */
    @Id
    @Column(name="province_id")
    @ApiModelProperty(value = "${comment}")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long provinceId;

    /** 省会名称 */
    @Excel(name = "省会名称")
    @Column(name="province_name")
    @ApiModelProperty(value = "省会名称")
    private String provinceName;

    /** 所属国家id */
    @Excel(name = "所属国家id")
    @Column(name="country_id")
    @ApiModelProperty(value = "所属国家id")
    private Long countryId;

    /** 删除标识 */
    @Column(name="del_flag")
    @ApiModelProperty(value = "所属国家id")
    private String delFlag;

    /** 创建者 */
    @Column(name="create_by")
    @ApiModelProperty(value = "所属国家id")
    private String createBy;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "所属国家id")
    private Date createTime;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "所属国家id")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "所属国家id")
    private Date updateTime;


}
