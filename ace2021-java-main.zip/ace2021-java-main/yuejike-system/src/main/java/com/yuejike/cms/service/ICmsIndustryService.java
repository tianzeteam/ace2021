package com.yuejike.cms.service;

import com.yuejike.cms.domain.CmsIndustry;
import com.yuejike.cms.domain.CmsLiveUser;

import java.util.List;

public interface ICmsIndustryService {

    /**
     * 获取所有
     */
    List<CmsIndustry> findAll();

    /**
     * 通过industry id 获取
     */
    CmsIndustry findByIndustryId(String industryId);

}
