package com.yuejike.cms.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.cms.domain.CmsCountry;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import com.yuejike.common.core.domain.entity.SysUser;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

/**
 * 媒体对象 sys_user_media
 *
 * @author tangdw
 * @since 1.0 2021-08-27
 */
@Data
public class SysUserMediaDTO {

    private static final long serialVersionUID = 1L;

    /** 用户id */
    @ApiModelProperty(value = "媒体id")
    private Long userId;

    /** 删除标识 */
   @ApiModelProperty(value = "删除标识")
   private String delFlag;

   /** 创建人id */
   @ApiModelProperty(value = "创建人")
   private String createBy;

   /** 创建时间 */
   @ApiModelProperty(value = "创建时间")
   private Date createTime;

   /** 更新人id */
   @ApiModelProperty(value = "修改人")
   private String updateBy;

   /** 更新时间 */
   @ApiModelProperty(value = "修改时间")
   private Date updateTime;

    /** 公司名称 */
    @ApiModelProperty(value = "公司名称")
    private String companyName;

    /** 记者所属国家 */
    @ApiModelProperty(value = "记者所属国家")
    private Long userCountryId;

    /** 证件类型 */
    @ApiModelProperty(value = "证件类型，0身份证，1港澳通行证，2护照")
    private String credentialsType;

    /** 证件号码 */
    @ApiModelProperty(value = "证件号码")
    private String credentialsNumber;

    /** 身份证扫描图片 */
    @ApiModelProperty(value = "身份证扫描图片")
    private String idCardPicture;

    /** 媒体所属国家 */
    @ApiModelProperty(value = "媒体所属国家")
    private Long companyCountryId;

    /** 中文名 */
    @ApiModelProperty(value = "中文名")
    private String chineseName;

    /** 中文姓 */
    @ApiModelProperty(value = "中文姓")
    private String chineseSurname;

    /** 拼音名 */
    @ApiModelProperty(value = "拼音名")
    private String pinyinName;

    /** 拼音姓 */
    @ApiModelProperty(value = "拼音姓")
    private String pinyinSurname;

    /** 英文名 */
    @ApiModelProperty(value = "英文名")
    private String englishName;

    /** 英文姓 */
    @ApiModelProperty(value = "英文姓")
    private String englishSurname;

    /** 英文中间名 */
    @ApiModelProperty(value = "英文中间名")
    private String englishCenterName;

    /** 性别(0:男1:女) */
    @ApiModelProperty(value = "性别(0:男1:女)")
    private String sex;

    /** 生日 */
    @ApiModelProperty(value = "生日")
    @JsonFormat(pattern = "yyyy-MM-dd",timezone = "GMT+8")
    private Date borth;

    /** 记者类型(0:文字1:摄影2:电视3:广播4:其他) */
    @ApiModelProperty(value = "记者类型(0:文字1:摄影2:电视3:广播4:其他)")
    private String reporterType;

    /** 手机号 */
    @ApiModelProperty(value = "手机号")
    private String phoneNumber;

    /** 邮箱 */
    @ApiModelProperty(value = "邮箱")
    private String email;

    /** 媒体执照图片 */
    @ApiModelProperty(value = "媒体执照图片")
    private String companyLicensePicture;

    /** 记者证图片 */
    @ApiModelProperty(value = "记者证图片")
    private String pressCardPicture;

    private String reviewStatus;
}
