package com.yuejike.cms.dao;

import com.yuejike.cms.domain.SysUserExhibitor;
import com.yuejike.common.core.domain.entity.SysUser;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;


/**
 * 参展商信息Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Repository
public interface SysUserExhibitorDao extends JpaRepository<SysUserExhibitor, Long>, JpaSpecificationExecutor<SysUserExhibitor> {

    @Query(value = "select * from sys_user_exhibitor where if(?1 !='',name = ?1,1=1) and if(?2!='',social_code =?2,1=1)",nativeQuery = true)
    SysUserExhibitor findByExhibitor(String name,String socialCode);

    @Query(value = "select * from sys_user_exhibitor where user_id=?1",nativeQuery = true)
    SysUserExhibitor findByUserId(Long userId);

    @Query(value = "SELECT count(*) from sys_user_exhibitor e left join sys_user u on u.user_id = e.user_id  where u.review_status='1' and e.classification_id=?1",nativeQuery = true)
    int findByClassificationId(Long classificationId);

    @Query(value = "SELECT U.user_id as userId, U.dept_id as deptId FROM sys_user U INNER JOIN sys_user_exhibitor EX ON EX.user_id = U.user_id \n" +
            "\tLEFT JOIN cms_classification CL ON CL.classification_id=EX.classification_id\n" +
            "\tLEFT JOIN cms_classification CL2 ON CL2.classification_id = CL.parent_id\n" +
            "\tLEFT JOIN cms_hall_plan PL ON (CL.parent_id=0 AND PL.classification_id=CL.classification_id) \n" +
            "\t\tOR (CL.parent_id <> 0 AND PL.classification_id=CL2.classification_id)\n" +
            "WHERE U.user_type='02' and PL.plan_id in (?1)", nativeQuery = true)
    List<Long> getExhibitorUserIdByPlanIds(List<Long> planIds);

    @Query(value = "SELECT U.dept_id FROM sys_user U INNER JOIN sys_user_exhibitor EX ON EX.user_id = U.user_id \n" +
            "\tLEFT JOIN cms_classification CL ON CL.classification_id=EX.classification_id\n" +
            "\tLEFT JOIN cms_classification CL2 ON CL2.classification_id = CL.parent_id\n" +
            "\tLEFT JOIN cms_hall_plan PL ON (CL.parent_id=0 AND PL.classification_id=CL.classification_id) \n" +
            "\t\tOR (CL.parent_id <> 0 AND PL.classification_id=CL2.classification_id)\n" +
            "WHERE U.user_type='02' and PL.plan_id in (?1)", nativeQuery = true)
    List<Long> getExhibitorDeptIdByPlanIds(List<Long> planIds);

    @Transactional
    @Modifying
    @Query(value = "update sys_user_exhibitor set recommend =?2 where user_id in (?1)",nativeQuery = true)
    int batchRecommend(List<Long> userIds, String type);

    @Transactional
    @Modifying
    @Query(value = "UPDATE sys_user_exhibitor A LEFT JOIN (\n" +
            "select T.user_id, ( @i \\:= @i + 1 ) AS idx FROM (SELECT T.user_id, SUM(T.pv) as pv FROM (\n" +
            "SELECT source_id AS user_id, COUNT(1) AS pv FROM sys_access_rec WHERE page_type = 1 AND source_id IS NOT NULL AND source_id > 0 GROUP BY source_id\n" +
            "UNION ALL\n" +
            "SELECT D.user_id, COUNT(1) AS pv FROM sys_access_rec A INNER JOIN cms_product B ON A.page_type = 2 AND A.source_id IS NOT NULL AND A.source_id > 0 AND B.product_id = A.source_id\n" +
            "INNER JOIN sys_dept C ON C.dept_id = B.user_id INNER JOIN (select a.* from sys_user a \n" +
            "\twhere user_id = (select min(user_id) from sys_user where dept_id = a.dept_id)) D ON D.dept_id = C.dept_id GROUP BY D.user_id\n" +
            ") T INNER join sys_user u ON u.user_id=T.user_id AND u.review_status='1' GROUP BY T.user_id LIMIT 50) T," +
            "( SELECT @i \\:= 0 ) AS i ORDER BY pv DESC) B ON B.user_id = A.user_id SET A.hot_ranking = B.idx", nativeQuery = true)
    int calculateHotRanking();

    @Transactional
    @Modifying
    @Query(value = "UPDATE sys_user_exhibitor A LEFT JOIN (\n" +
            "select T.user_id, ( @i \\:= @i + 1 ) AS idx FROM (\n" +
            "SELECT D.user_id, COUNT(1) AS pv FROM sys_access_rec A INNER JOIN cms_product B ON A.page_type = 3 AND A.source_id IS NOT NULL AND A.source_id > 0 AND B.product_id = A.source_id\n" +
            "INNER JOIN sys_dept C ON C.dept_id = B.user_id INNER JOIN (select a.* from sys_user a \n" +
            "\twhere a.user_id = (select min(user_id) from sys_user where dept_id = a.dept_id) AND a.review_status='1') D ON D.dept_id = C.dept_id\n" +
            "\t GROUP BY D.user_id LIMIT 30 \n" +
            ") T,( SELECT @i \\:= 0 ) AS i ORDER BY pv DESC) B ON B.user_id = A.user_id SET A.sales_ranking = B.idx", nativeQuery = true)
    int calculateSalesRanking();

    @Transactional
    @Modifying
    @Query(value = "UPDATE sys_user_exhibitor A LEFT JOIN (\n" +
            "select T.user_id, ( @i \\:= @i + 1 ) AS idx FROM (\n" +
            "SELECT D.dept_id, D.user_id, (COUNT(1) / E.product_count) AS aCount \n" +
            "FROM cms_favorites A INNER JOIN cms_product B ON A.business_type = '0' AND A.business_id IS NOT NULL AND A.business_id > 0 \n" +
            "\tAND B.product_id = A.business_id INNER JOIN sys_dept C ON C.dept_id = B.user_id INNER JOIN (select a.* from sys_user a \n" +
            "\twhere a.user_id = (select min(user_id) from sys_user where dept_id = a.dept_id) AND a.review_status='1') D ON D.dept_id = C.dept_id \n" +
            "\tLEFT JOIN (SELECT user_id, COUNT(1) AS product_count FROM cms_product WHERE del_flag='0' AND `status`='1' GROUP BY user_id) E\n" +
            "\tON E.user_id = D.dept_id where E.product_count > 0 GROUP BY D.dept_id, D.user_id LIMIT 30\n" +
            ") T,( SELECT @i \\:= 0 ) AS i ORDER BY aCount DESC) B ON B.user_id = A.user_id SET A.interesting_ranking = B.idx", nativeQuery = true)
    int calculateInterestingRanking();

    @Transactional
    @Modifying
    @Query(value = "UPDATE sys_user_exhibitor A LEFT JOIN (\n" +
            "select T.user_id, ( @i \\:= @i + 1 ) AS idx FROM (\n" +
            "SELECT B.user_id, COUNT(1) as aCount FROM cms_user_card_exchange A INNER JOIN sys_user_exhibitor B ON B.user_id = A.accept_id OR B.user_id = A.send_id\n" +
            "INNER JOIN sys_user u ON u.user_id=B.user_id AND u.review_status='1' GROUP BY B.user_id LIMIT 30\n" +
            ") T,( SELECT @i \\:= 0 ) AS i ORDER BY aCount DESC) B ON B.user_id = A.user_id SET A.trust_ranking = B.idx", nativeQuery = true)
    int calculateTrustRanking();

    @Query(value = "SELECT * FROM sys_user_exhibitor where v3d_status='审核通过' AND user_id<?1 order by user_id DESC LIMIT 1", nativeQuery = true)
    SysUserExhibitor getPreExhibitor(Long curUserId);

    @Query(value = "SELECT * FROM sys_user_exhibitor where v3d_status='审核通过' AND user_id>?1 order by user_id LIMIT 1", nativeQuery = true)
    SysUserExhibitor getNextExhibitor(Long curUserId);
}
