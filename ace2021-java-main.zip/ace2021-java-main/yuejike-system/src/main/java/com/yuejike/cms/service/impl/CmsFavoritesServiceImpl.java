package com.yuejike.cms.service.impl;

import java.util.*;

import com.yuejike.cms.dao.CmsProductDao;
import com.yuejike.cms.domain.CmsLive;
import com.yuejike.cms.domain.CmsProduct;
import com.yuejike.cms.domain.SysUserExhibitor;
import com.yuejike.cms.service.ICmsLiveService;
import com.yuejike.cms.service.ICmsProductService;
import com.yuejike.cms.service.ISysUserExhibitorService;
import com.yuejike.common.utils.DateUtils;

import org.apache.commons.lang3.StringUtils;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yuejike.cms.dao.CmsFavoritesDao;
import com.yuejike.cms.domain.CmsFavorites;
import com.yuejike.cms.service.ICmsFavoritesService;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/**
 * 收藏Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsFavoritesServiceImpl implements ICmsFavoritesService {

    @Autowired
    private CmsFavoritesDao cmsFavoritesDao;
    @Autowired
    private CmsProductDao productDao;

    @Autowired
    private ISysUserExhibitorService userExhibitorService;
    @Autowired
    private ICmsLiveService liveService;
    /**
     * 查询收藏
     *
     * @param favoritesId 收藏ID
     * @return 收藏
     */
    @Override
    public CmsFavorites findById(Long favoritesId) {
        return cmsFavoritesDao.findById(favoritesId).orElse(null);
    }

    /**
     * 分页查询收藏列表
     *
     * @param req 收藏
     * @return 收藏
     */
    @Override
    public Page<CmsFavorites> findCmsFavoritesPage(CmsFavorites req) {
        Specification<CmsFavorites> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsFavorites> page = cmsFavoritesDao.findAll(example, pageable);
        page.getContent().forEach(favorites -> {
            if(favorites.getBusinessType().equals("0")){
                CmsProduct cmsProduct = productDao.findById(favorites.getBusinessId()).orElse(null);
                favorites.setProduct(cmsProduct);
            }else if(favorites.getBusinessType().equals("1")){
                SysUserExhibitor userExhibitor = userExhibitorService.findById(favorites.getBusinessId());
                favorites.setUserExhibitor(userExhibitor);
            }else if(favorites.getBusinessType().equals("2")){
                CmsLive live =liveService.findById(favorites.getBusinessId());
                favorites.setLive(live);
            }
        });
        return page;
    }

    /**
     * 分页查询收藏列表
     *
     * @param req 收藏
     * @return 收藏
     */
    @Override
    public List<CmsFavorites> findCmsFavoritesList(CmsFavorites req) {
        Specification<CmsFavorites> example = formatQueryParams(req);
        List<CmsFavorites> list = cmsFavoritesDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    private Specification<CmsFavorites> formatQueryParams(CmsFavorites req){
        Specification<CmsFavorites> example = new Specification<CmsFavorites>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsFavorites> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getFavoritesId()){
                    Predicate pre = cb.equal(root.get("favoritesId").as(Long.class), req.getFavoritesId());
                    list.add(pre);
                }
                if (null != req.getUserId()){
                    Predicate pre = cb.equal(root.get("userId").as(Long.class), req.getUserId());
                    list.add(pre);
                }
                if (null != req.getBusinessId()){
                    Predicate pre = cb.equal(root.get("businessId").as(Long.class), req.getBusinessId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())){
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getBusinessName())){
                    Predicate pre = cb.like(root.get("businessName").as(String.class), "%" + req.getBusinessName()+ "%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getBusinessType())){
                    Predicate pre = cb.equal(root.get("businessType").as(String.class), req.getBusinessType());
                    list.add(pre);
                }
                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）收藏
     *
     * @param cmsFavorites 收藏
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public CmsFavorites save(CmsFavorites cmsFavorites) {
        cmsFavorites.setCreateTime(DateUtils.getNowDate());
        CmsFavorites favorites = cmsFavoritesDao.save(cmsFavorites);
        return favorites;
    }


    /**
     * 批量删除收藏
     *
     * @param favoritesIds 需要删除的收藏ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> favoritesIds) {
        List<CmsFavorites> existBeans = cmsFavoritesDao.findAllById(favoritesIds);
        if(!existBeans.isEmpty()){
            cmsFavoritesDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除收藏信息
     *
     * @param favoritesId 收藏ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsFavoritesById(Long favoritesId) {
         cmsFavoritesDao.deleteById(favoritesId);
    }

    @Override
    public CmsFavorites findByUserIdAndBusinessTypeAndBusinessId(Long userId, String businessType, Long businessId) {
        return cmsFavoritesDao.findByUserIdAndBusinessTypeAndBusinessId(userId, businessType, businessId);
    }

    @Override
    public Long getFavoritesCountByProductId(Long productId) {
        return cmsFavoritesDao.getFavoritesCountByProductId(productId);
    }

    @Override
    public List<Map<String, Long>> getFavoritesCountByProductId(Long[] productIds) {
        return cmsFavoritesDao.getFavoritesCountByProductId(productIds);
    }
}
