package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsCity;

/**
 * 城市字典Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-26
 */
public interface ICmsCityService  {
    /**
     * 查询城市字典
     *
     * @param cityId 城市字典ID
     * @return 城市字典
     */
    CmsCity findById(Long cityId);

    /**
     * 分页查询城市字典列表
     *
     * @param req 城市字典
     * @return 城市字典集合
     */
    Page<CmsCity> findCmsCityPage(CmsCity req);

    /**
     * 查询城市字典列表
     *
     * @param req 城市字典
     * @return 城市字典集合
     */
    List<CmsCity> findCmsCityList(CmsCity req);

    /**
     * 新增城市字典
     *
     * @param cmsCity 城市字典
     * @return 结果
     */
    void save(CmsCity cmsCity);

    /**
     * 批量删除城市字典
     *
     * @param cityIds 需要删除的城市字典ID
     * @return 结果
     */
    void deleteByIds(List<Long> cityIds);

    /**
     * 删除城市字典信息
     *
     * @param cityId 城市字典ID
     * @return 结果
     */
    void deleteCmsCityById(Long cityId);
}
