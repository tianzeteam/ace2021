package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsPosition;

/**
 * 位置信息管理Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsPositionService  {
    /**
     * 查询位置信息管理
     *
     * @param positionId 位置信息管理ID
     * @return 位置信息管理
     */
    CmsPosition findById(Long positionId);

    /**
     * 分页查询位置信息管理列表
     *
     * @param req 位置信息管理
     * @return 位置信息管理集合
     */
    Page<CmsPosition> findCmsPositionPage(CmsPosition req);

    /**
     * 查询位置信息管理列表
     *
     * @param req 位置信息管理
     * @return 位置信息管理集合
     */
    List<CmsPosition> findCmsPositionList(CmsPosition req);

    /**
     * 新增位置信息管理
     *
     * @param cmsPosition 位置信息管理
     * @return 结果
     */
    void save(CmsPosition cmsPosition);

    /**
     * 批量删除位置信息管理
     *
     * @param positionIds 需要删除的位置信息管理ID
     * @return 结果
     */
    void deleteByIds(List<Long> positionIds);

    /**
     * 删除位置信息管理信息
     *
     * @param positionId 位置信息管理ID
     * @return 结果
     */
    void deleteCmsPositionById(Long positionId);
}
