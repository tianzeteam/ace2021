package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsProvince;

/**
 * 省会字典Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-26
 */
public interface ICmsProvinceService  {
    /**
     * 查询省会字典
     *
     * @param provinceId 省会字典ID
     * @return 省会字典
     */
    CmsProvince findById(Long provinceId);

    /**
     * 分页查询省会字典列表
     *
     * @param req 省会字典
     * @return 省会字典集合
     */
    Page<CmsProvince> findCmsProvincePage(CmsProvince req);

    /**
     * 查询省会字典列表
     *
     * @param req 省会字典
     * @return 省会字典集合
     */
    List<CmsProvince> findCmsProvinceList(CmsProvince req);

    /**
     * 新增省会字典
     *
     * @param cmsProvince 省会字典
     * @return 结果
     */
    void save(CmsProvince cmsProvince);

    /**
     * 批量删除省会字典
     *
     * @param provinceIds 需要删除的省会字典ID
     * @return 结果
     */
    void deleteByIds(List<Long> provinceIds);

    /**
     * 删除省会字典信息
     *
     * @param provinceId 省会字典ID
     * @return 结果
     */
    void deleteCmsProvinceById(Long provinceId);
}
