package com.yuejike.cms.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.yuejike.common.utils.DateUtils;

import java.util.Date;
import org.apache.commons.lang3.StringUtils;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yuejike.cms.dao.CmsCityDao;
import com.yuejike.cms.domain.CmsCity;
import com.yuejike.cms.service.ICmsCityService;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/**
 * 城市字典Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-26
 */
@Transactional(readOnly = true)
@Service
public class CmsCityServiceImpl implements ICmsCityService {

    @Autowired
    private CmsCityDao cmsCityDao;

    /**
     * 查询城市字典
     *
     * @param cityId 城市字典ID
     * @return 城市字典
     */
    @Override
    public CmsCity findById(Long cityId) {
        return cmsCityDao.findById(cityId).get();
    }

    /**
     * 分页查询城市字典列表
     *
     * @param req 城市字典
     * @return 城市字典
     */
    @Override
    public Page<CmsCity> findCmsCityPage(CmsCity req) {
        Specification<CmsCity> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsCity> page = cmsCityDao.findAll(example, pageable);
        return page;
    }

    /**
     * 分页查询城市字典列表
     *
     * @param req 城市字典
     * @return 城市字典
     */
    @Override
    public List<CmsCity> findCmsCityList(CmsCity req) {
        Specification<CmsCity> example = formatQueryParams(req);
        List<CmsCity> list = cmsCityDao.findAll(example, Sort.by(Sort.Direction.ASC,"cityId"));
        return list;
    }

    private Specification<CmsCity> formatQueryParams(CmsCity req){
        Specification<CmsCity> example = new Specification<CmsCity>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsCity> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getCityId()){
                    Predicate pre = cb.equal(root.get("cityId").as(Long.class), req.getCityId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCityName())){
                    Predicate pre = cb.like(root.get("cityName").as(String.class), "%" + req.getCityName()+ "%");
                    list.add(pre);
                }
                if (null != req.getProvinceId()){
                    Predicate pre = cb.equal(root.get("provinceId").as(Long.class), req.getProvinceId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())){
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）城市字典
     *
     * @param cmsCity 城市字典
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void save(CmsCity cmsCity) {
        cmsCity.setCreateTime(DateUtils.getNowDate());
        cmsCityDao.save(cmsCity);
    }


    /**
     * 批量删除城市字典
     *
     * @param cityIds 需要删除的城市字典ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> cityIds) {
        List<CmsCity> existBeans = cmsCityDao.findAllById(cityIds);
        if(!existBeans.isEmpty()){
            cmsCityDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除城市字典信息
     *
     * @param cityId 城市字典ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsCityById(Long cityId) {
         cmsCityDao.deleteById(cityId);
    }
}
