package com.yuejike.cms.service;

import java.util.List;
import java.util.Map;

import com.yuejike.cms.domain.CmsModelExtend;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsContent;

/**
 * 文章Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsContentService  {

    /**
     * 查询文章
     *
     * @param contentId 文章ID
     * @return 文章
     */
    CmsContent findById(Long contentId);

    /**
     * 分页查询文章列表
     *
     * @param req 文章
     * @return 文章集合
     */
    Page<CmsContent> findCmsContentPage(CmsContent req);

    /**
     * 查询文章列表
     *
     * @param req 文章
     * @return 文章集合
     */
    List<CmsContent> findCmsContentList(CmsContent req);

    /**
     * 新增文章
     *
     * @param cmsContent 文章
     * @return 结果
     */
    void save(CmsContent cmsContent);

    /**
     * 批量删除文章
     *
     * @param contentIds 需要删除的文章ID
     * @return 结果
     */
    void deleteByIds(List<Long> contentIds);

    /**
     * 删除文章信息
     *
     * @param contentId 文章ID
     * @return 结果
     */
    void deleteCmsContentById(Long contentId);

    List<CmsContent> findListByModelId(Long modelId);

    void batchReSorted(List<CmsContent> cmsContents);
}
