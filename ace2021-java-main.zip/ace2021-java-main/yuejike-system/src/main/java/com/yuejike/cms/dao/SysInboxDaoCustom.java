package com.yuejike.cms.dao;

import com.yuejike.cms.domain.SysInbox;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

@Repository
public interface SysInboxDaoCustom {
    Page<SysInbox> findInboxPage(SysInbox inbox, Pageable pageable);
}
