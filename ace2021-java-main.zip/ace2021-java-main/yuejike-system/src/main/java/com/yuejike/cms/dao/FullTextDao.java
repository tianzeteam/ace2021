package com.yuejike.cms.dao;

import com.yuejike.cms.domain.FullText;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * @author ：JinZj
 * @date ：Created in 2022/1/4 5:25 下午
 * @description：全文索引数据访问
 * @modified By：
 */
@Repository
public interface FullTextDao extends JpaRepository<FullText, String>, JpaSpecificationExecutor<FullText> {
}
