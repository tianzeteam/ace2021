package com.yuejike.cms.domain;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author JinZJ
 * @version 1.0
 * @Description:
 * @date 2021/12/3 13:57
 */
@Entity
@Table(name = "sys_access_date_rec")
@Data
public class SysAccessDateRec {

    @Id
    @Column(name="statistical_date")
    @ApiModelProperty(value = "${comment}")
    private String statisticalDate;

    @Column(name="counter_Offline")
    @ApiModelProperty(value = "线下访问人数")
    private Integer counterOffline;

    @Column(name="counter_online")
    @ApiModelProperty(value = "线上访问人数")
    private Integer counterOnline;

}
