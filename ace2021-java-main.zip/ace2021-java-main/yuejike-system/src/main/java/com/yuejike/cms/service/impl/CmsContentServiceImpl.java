package com.yuejike.cms.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.yuejike.cms.dao.CmsContentDao;
import com.yuejike.cms.domain.CmsContent;
import com.yuejike.cms.service.ICmsContentService;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * 文章Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsContentServiceImpl implements ICmsContentService {

    @Autowired
    private CmsContentDao cmsContentDao;

    /**
     * 查询文章
     *
     * @param categoryId 栏目ID
     * @return
     */


    /**
     * 查询文章
     *
     * @param contentId 文章ID
     * @return 文章
     */
    @Override
    public CmsContent findById(Long contentId) {
        return cmsContentDao.findById(contentId).get();
    }

    /**
     * 分页查询文章列表
     *
     * @param req 文章
     * @return 文章
     */
    @Override
    public Page<CmsContent> findCmsContentPage(CmsContent req) {
        Specification<CmsContent> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("sort"),
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsContent> page = cmsContentDao.findAll(example, pageable);
        return page;
    }

    /**
     * 分页查询文章列表
     *
     * @param req 文章
     * @return 文章
     */
    @Override
    public List<CmsContent> findCmsContentList(CmsContent req) {
        Specification<CmsContent> example = formatQueryParams(req);
        List<CmsContent> list = cmsContentDao.findAll(example, Sort.by( Sort.Direction.DESC, "sort","createTime"));
        return list;
    }

    private Specification<CmsContent> formatQueryParams(CmsContent req) {
        Specification<CmsContent> example = new Specification<CmsContent>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsContent> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getContentId()) {
                    Predicate pre = cb.equal(root.get("contentId").as(Long.class), req.getContentId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getTitle())) {
                    Predicate pre = cb.like(root.get("title").as(String.class), "%"+req.getTitle()+"%");
                    list.add(pre);
                }
                if (null != req.getCategoryId()) {
                    Predicate pre = cb.equal(root.get("categoryId").as(Long.class), req.getCategoryId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getLink())) {
                    Predicate pre = cb.equal(root.get("link").as(String.class), req.getLink());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDetails())) {
                    Predicate pre = cb.equal(root.get("details").as(String.class), req.getDetails());
                    list.add(pre);
                }
                //是否是投稿
                if (StringUtils.isNotBlank(req.getIsContribution())) {
                    Predicate pre = cb.equal(root.get("isContribution").as(String.class), req.getIsContribution());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getKeyword())) {
                    Predicate pre = cb.equal(root.get("keyword").as(String.class), req.getKeyword());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getImgUrl())) {
                    Predicate pre = cb.equal(root.get("imgUrl").as(String.class), req.getImgUrl());
                    list.add(pre);
                }
                if (null != req.getSort()) {
                    Predicate pre = cb.equal(root.get("sort").as(Integer.class), req.getSort());
                    list.add(pre);
                }
                if (null != req.getPushTime()) {
                    Predicate pre = cb.equal(root.get("pushTime").as(Date.class), req.getPushTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getSource())) {
                    Predicate pre = cb.equal(root.get("source").as(String.class), req.getSource());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getAuthor())) {
                    Predicate pre = cb.like(root.get("author").as(String.class),"%"+ req.getAuthor()+"%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getVisible())) {
                    Predicate pre = cb.equal(root.get("visible").as(String.class), req.getVisible());
                    list.add(pre);
                }
                if (null != req.getCreateTime()) {
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()) {
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())) {
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())) {
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())) {
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getReviewStatus())) {
                    Predicate pre = cb.equal(root.get("reviewStatus").as(String.class), req.getReviewStatus());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getModelExtendData())) {
                    String str = req.getModelExtendData();
                    if (str.contains("[") && str.contains("]")) {
                        //是数组形式
                        List<String> strings = JSONArray.parseArray(str, String.class);
                        strings.forEach(s -> {
                            if (s.contains("{") && s.contains("}")) {
                                //转json object
                                JSONObject jsonObject = JSONObject.parseObject(s);
                                // 2021-09-08 日期格式要这样的
                                String target = jsonObject.getString("DateTimeRange");
                                //芜湖市情
                                String systematics =jsonObject.getString("systematics");
                                if(StringUtils.isNotBlank(target)){
                                    Predicate pre = cb.like(root.get("modelExtendData").as(String.class), "%" + "\"DateTimeRange\":[\"" + target + "%");
                                    list.add(pre);
                                }
                                if(StringUtils.isNotBlank(systematics)){
                                    Predicate systematicsPre = cb.like(root.get("modelExtendData").as(String.class), "%" + "\"systematics\":\"" + systematics + "%");
                                    list.add(systematicsPre);
                                }

                            }
                        });
                    }
//                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
//                    list.add(pre);
                }
                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）文章
     *
     * @param cmsContent 文章
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void save(CmsContent cmsContent) {
        // cmsContent.setCreateTime(DateUtils.getNowDate());
        cmsContentDao.save(cmsContent);
    }


    /**
     * 批量删除文章
     *
     * @param contentIds 需要删除的文章ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> contentIds) {
        List<CmsContent> existBeans = cmsContentDao.findAllById(contentIds);
        if (!existBeans.isEmpty()) {
            cmsContentDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除文章信息
     *
     * @param contentId 文章ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsContentById(Long contentId) {
        cmsContentDao.deleteById(contentId);
    }

    @Override
    public List<CmsContent> findListByModelId(Long modelId) {
        return cmsContentDao.findListByModelId(modelId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void batchReSorted(List<CmsContent> cmsContents) {
        cmsContentDao.saveAll(cmsContents);
    }
}
