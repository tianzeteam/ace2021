package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsProductCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author JinZJ
 * @version 1.0
 * @Description: 展品分类Dao接口
 * @date 2021/11/23 15:37
 */
@Repository
public interface CmsProductCategoryDao extends JpaRepository<CmsProductCategory, Long>, JpaSpecificationExecutor<CmsProductCategory> {

    @Query(value = "SELECT count(*) FROM `cms_product_category` WHERE parent_id =?;   ", nativeQuery = true)
    Integer hasChildByMenuId(Long menuId);

    @Query(value = "select * from cms_product_category where parent_id in (?1)",nativeQuery = true)
    List<CmsProductCategory> findByParentId(List<Long> categoryIds);

}
