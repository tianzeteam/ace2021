package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsHallPlan;

/**
 * 展区规划Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsHallPlanService  {
    /**
     * 查询展区规划
     *
     * @param planId 展区规划ID
     * @return 展区规划
     */
    CmsHallPlan findById(Long planId);

    /**
     * 分页查询展区规划列表
     *
     * @param req 展区规划
     * @return 展区规划集合
     */
    Page<CmsHallPlan> findCmsHallPlanPage(CmsHallPlan req);

    /**
     * 查询展区规划列表
     *
     * @param req 展区规划
     * @return 展区规划集合
     */
    List<CmsHallPlan> findCmsHallPlanList(CmsHallPlan req);

    /**
     * 新增展区规划
     *
     * @param cmsHallPlan 展区规划
     * @return 结果
     */
    void save(CmsHallPlan cmsHallPlan);

    /**
     * 批量删除展区规划
     *
     * @param planIds 需要删除的展区规划ID
     * @return 结果
     */
    void deleteByIds(List<Long> planIds);

    /**
     * 删除展区规划信息
     *
     * @param planId 展区规划ID
     * @return 结果
     */
    void deleteCmsHallPlanById(Long planId);
}
