package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 洽谈沟通对象 cms_negotiate
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_negotiate")
@Data
public class CmsNegotiate extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="negotiate_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long negotiateId;

    /** 展品id */
    @Excel(name = "展品id")
    @Column(name="product_id")
    @ApiModelProperty(value = "展品id")
    private Long productId;

    /** 联系人 */
    @Excel(name = "联系人")
    @Column(name="contacts")
    @ApiModelProperty(value = "联系人")
    private String contacts;

    /** 电话 */
    @Excel(name = "电话")
    @Column(name="phone")
    @ApiModelProperty(value = "电话")
    private String phone;

    /** 备注内容 */
    @Excel(name = "备注内容")
    @Column(name="remark")
    @ApiModelProperty(value = "备注内容")
    private String remark;

    /** 发起人id */
    @Excel(name = "客户id（观众、媒体、专业观众、会议代表）")
    @Column(name="send_id")
    @ApiModelProperty(value = "客户id（观众、媒体、专业观众、会议代表）")
    private Long sendId;

    /** 接收人id */
    @Excel(name = "展商id")
    @Column(name="accept_id")
    @ApiModelProperty(value = "展商id")
    private Long acceptId;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "创建人")
    private String createBy;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "接收人id")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "接收人id")
    private Date updateTime;

    /** 状态（0：未读1：已读） */
    @Excel(name = "状态", readConverterExp = "0=：未读1：已读")
    @Column(name="status")
    @ApiModelProperty(value = "状态")
    private String status;

    /** 删除标识(0:正常1:删除) */
    @Column(name="del_flag")
    @ApiModelProperty(value = "状态")
    private String delFlag;

    /** 删除标识(0:正常1:删除) */
    @Column(name="reply")
    @ApiModelProperty(value = "恰谈回复")
    private String reply;

    /** 删除标识(0:正常1:删除) */
    @Column(name="start_time")
    @ApiModelProperty(value = "预约开始时间")
    private Long startTime;

    @Column(name="end_time")
    @ApiModelProperty(value = "预约结束时间")
    private Long endTime;

    @Column(name="reservation_time")
    @ApiModelProperty(value = "预约时间")
    private Date reservationTime;

    /** 删除标识(0:正常1:删除) */
//        @Column(name="del_flag")
    @ApiModelProperty(value = "用户名")
    @Transient
    private String userName;

    /** 删除标识(0:正常1:删除) */
//        @Column(name="del_flag")
    @ApiModelProperty(value = "展品名称")
    @Transient
    private String productName;

    /** 删除标识(0:正常1:删除) */
//        @Column(name="del_flag")
    @ApiModelProperty(value = "展商名称")
    @Transient
    private String exhibitorName;

    @Transient
    private CmsProduct product;
}
