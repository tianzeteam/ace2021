package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 城市字典对象 cms_city
 *
 * @author tangdw
 * @since 1.0 2021-08-26
 */
@Entity
@Table(name = "cms_city")
@Data
@JsonIgnoreProperties(value = {"hibernateLazyInitializer"})
public class CmsCity extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** 城市id */
    @Id
    @Column(name="city_id")
    @ApiModelProperty(value = "${comment}")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cityId;

    /** 城市名 */
    @Excel(name = "城市名")
    @Column(name="city_name")
    @ApiModelProperty(value = "城市名")
    private String cityName;

    /** 省会id */
    @Excel(name = "省会id")
    @Column(name="province_id")
    @ApiModelProperty(value = "省会id")
    private Long provinceId;

    /** 删除标识 */
    @Column(name="del_flag")
    @ApiModelProperty(value = "省会id")
    private String delFlag;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "省会id")
    private String createBy;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "省会id")
    private Date createTime;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "省会id")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "省会id")
    private Date updateTime;


}
