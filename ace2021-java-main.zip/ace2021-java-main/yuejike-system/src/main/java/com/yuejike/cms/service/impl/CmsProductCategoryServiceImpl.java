package com.yuejike.cms.service.impl;

import com.yuejike.cms.dao.CmsProductCategoryDao;
import com.yuejike.cms.domain.CmsClassification;
import com.yuejike.cms.domain.CmsProductCategory;
import com.yuejike.cms.dto.CmsProductCategoryDTO;
import com.yuejike.cms.service.ICmsProductCategoryService;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import com.yuejike.common.utils.DateUtils;
import com.yuejike.common.utils.bean.BeanUtils;
import com.yuejike.model.TreeSelectModel;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.query.internal.NativeQueryImpl;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author JinZJ
 * @version 1.0
 * @Description: 展品分类业务处理层
 * @date 2021/11/23 15:39
 */
@Transactional(readOnly = true)
@Service
public class CmsProductCategoryServiceImpl implements ICmsProductCategoryService {

    @Autowired
    private CmsProductCategoryDao cmsProductCategoryDao;


    @Override
    public CmsProductCategory findById(Long categoryId) {
        return cmsProductCategoryDao.findById(categoryId).orElse(null);
    }

    @Override
    public Page<CmsProductCategory> findCmsCategoryPage(CmsProductCategory req) {
        Specification<CmsProductCategory> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsProductCategory> page = cmsProductCategoryDao.findAll(example, pageable);
        return page;
    }

    @Override
    public Page<CmsProductCategory> findCmsCategoryTreePage(CmsProductCategory req) {
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        List<CmsProductCategory> categoryTrees = new ArrayList<>();
        List<CmsProductCategory> allCategory = findCmsCategorgFullList(req);
        for (CmsProductCategory cmsCategory : allCategory) {
            List<CmsProductCategory> children = new ArrayList<>();
            if (cmsCategory!=null && (cmsCategory.getParentId() == null || cmsCategory.getParentId() == 0L)) {
                categoryTrees.add(cmsCategory);
                getTableTreeByAllCategory(children,allCategory,cmsCategory.getCategoryId());
                if(children.size()>0){
                    cmsCategory.setChildren(children);
                }
            }
        }
        Page<CmsProductCategory> cmsCategories = new PageImpl<>(categoryTrees,pageable,categoryTrees.size());
        return cmsCategories;
    }

    @PersistenceContext
    private EntityManager entityManager;

    public List<CmsProductCategory> findCmsCategorgFullList(CmsProductCategory cmsCategory) {
        StringBuffer sql = new StringBuffer();
        List<Object> params = new ArrayList<>();
        sql.append(" select cc.category_id categoryId, cc.cn_name cnName, cc.en_name enName,cc.ja_name jaName, cc.ko_name koName, ");
        sql.append(" cc.parent_id parentId, cc.sort sort, cc.create_time createTime, cc.create_by createBy, ");
        sql.append(" ccp.cn_name parentName from cms_product_category cc ");
        sql.append(" left join cms_product_category ccp on cc.parent_id = ccp.category_id ");
        sql.append(" where 1 = 1 ");
        if (cmsCategory.getCategoryId()!=null) {
            sql.append(" AND cc.category_id = ? ");
            params.add("%" + cmsCategory.getCategoryId() + "%");
        }
        if (StringUtils.isNotBlank(cmsCategory.getCnName())) {
            sql.append(" AND cc.cn_name = ? ");
            params.add(cmsCategory.getCnName());
        }
        if (StringUtils.isNotBlank(cmsCategory.getEnName())) {
            sql.append(" AND cc.en_name = ? ");
            params.add(cmsCategory.getEnName());
        }
        if (cmsCategory.getParentId() != null) {
            sql.append(" AND cc.parent_id = ? ");
            params.add(cmsCategory.getParentId());
        }
        if (cmsCategory.getSort() != null) {
            sql.append(" AND cc.sort = ? ");
            params.add(cmsCategory.getSort());
        }
        sql.append(" order by cc.update_time, cc.create_time ");
        Query contentQuery = entityManager.createNativeQuery(sql.toString());
        for (int i = 0; i < params.size(); i++) {
            contentQuery.setParameter(i + 1, params.get(i));
        }
        contentQuery.unwrap(NativeQueryImpl.class).setResultTransformer(Transformers.aliasToBean(CmsProductCategoryDTO.class));
        List<CmsProductCategoryDTO> results = contentQuery.getResultList();
        List<CmsProductCategory> collect = results.stream().map(m -> newCmsCategory(m)).collect(Collectors.toList());
        return collect;
    }

    private CmsProductCategory newCmsCategory(CmsProductCategoryDTO c){
        CmsProductCategory cmsCategory = new CmsProductCategory();
        BeanUtils.copyProperties(c, cmsCategory);
        if(c.getCategoryId()!=null)cmsCategory.setCategoryId(c.getCategoryId().longValue());
        cmsCategory.setCnName(c.getCnName());
        cmsCategory.setEnName(c.getEnName());
        cmsCategory.setJaName(c.getJaName());
        cmsCategory.setKoName(c.getKoName());
        if(c.getParentId()!=null)cmsCategory.setParentId(c.getParentId().longValue());
        cmsCategory.setSort(c.getSort());
        cmsCategory.setParentName(c.getParentName());
        return cmsCategory;
    }

    private void getTableTreeByAllCategory(List<CmsProductCategory> result,List<CmsProductCategory> allCategory,Long id){
        for (CmsProductCategory cmsCategory : allCategory) {
            List<CmsProductCategory> children = new ArrayList<>();
            if (cmsCategory.getParentId()!= null && cmsCategory.getParentId().longValue() == id.longValue()) {
                result.add(cmsCategory);
                getTableTreeByAllCategory(children,allCategory,cmsCategory.getCategoryId());
                if(children.size()>0){
                    cmsCategory.setChildren(children);
                }
            }
        }
    }

    @Override
    public List<CmsProductCategory> findCmsCategoryList(CmsProductCategory req) {
        Specification<CmsProductCategory> example = formatQueryParams(req);
        List<CmsProductCategory> list = cmsProductCategoryDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    @Override
    public List<Map<String, Object>> getCmsCategorySelectByPid() {
        List<Map<String,Object>> result = new ArrayList<>();
        try {
            List<CmsProductCategory> allCategory = cmsProductCategoryDao.findAll();

            for (CmsProductCategory cmsCategory : allCategory) {
                List<Map<String,Object>> children = new ArrayList<>();
                if (cmsCategory!=null && (cmsCategory.getParentId() == null || cmsCategory.getParentId() == 0L)) {
                    Map<String, Object> map = new HashMap<>();
                    map.put("value", cmsCategory.getCategoryId());
                    map.put("id", cmsCategory.getCategoryId());
                    map.put("label", cmsCategory.getCnName());
                    getTreeByAllCategory(children,allCategory,cmsCategory.getCategoryId());
                    if(children.size()>0){
                        map.put("children", children);
                    }
                    result.add(map);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    private void getTreeByAllCategory(List<Map<String,Object>> result,List<CmsProductCategory> allCategory,Long id){
        for (CmsProductCategory cmsCategory : allCategory) {
            List<Map<String,Object>> children = new ArrayList<>();
            if (cmsCategory.getParentId()!= null && cmsCategory.getParentId().longValue() == id.longValue()) {
                Map<String, Object> map = new HashMap<>();
                map.put("value", cmsCategory.getCategoryId());
                map.put("id", cmsCategory.getCategoryId());
                map.put("label", cmsCategory.getCnName());
                getTreeByAllCategory(children,allCategory,cmsCategory.getCategoryId());
                if(children.size()>0){
                    map.put("children", children);
                }
                result.add(map);
            }
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void save(CmsProductCategory cmsCategory) {
        cmsCategory.setCreateTime(DateUtils.getNowDate());
        cmsProductCategoryDao.save(cmsCategory);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> categoryIds) {
        List<CmsProductCategory> existBeans = cmsProductCategoryDao.findAllById(categoryIds);
        if(!existBeans.isEmpty()){
            cmsProductCategoryDao.deleteAll(existBeans);
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsCategoryById(Long categoryId) {
        cmsProductCategoryDao.deleteById(categoryId);
    }

    @Override
    public boolean hasChildByMenuId(Long categoryId) {
        int result = cmsProductCategoryDao.hasChildByMenuId(categoryId);
        return result> 0 ? true : false;
    }

    @Override
    public List<CmsProductCategory> findByParentId(List<Long> categoryIds) {
        return cmsProductCategoryDao.findByParentId(categoryIds);
    }

    @Override
    public List<CmsProductCategory> buildTree(List<CmsProductCategory> productCategories) {
        List<CmsProductCategory> returnList = new ArrayList<>();
        List<Long> tempList = new ArrayList<>();
        for (CmsProductCategory dept : productCategories) {
            tempList.add(dept.getCategoryId());
        }
        for (Iterator<CmsProductCategory> iterator = productCategories.iterator(); iterator.hasNext(); ) {
            CmsProductCategory next = iterator.next();
            // 如果是顶级节点, 遍历该父节点的所有子节点
            if (!tempList.contains(next.getParentId())) {
                recursionFn(productCategories, next);
                returnList.add(next);
            }
        }
        if (returnList.isEmpty()) {
            returnList = productCategories;
        }
        return returnList;
    }

    /**
     * 递归列表
     */
    private void recursionFn(List<CmsProductCategory> list, CmsProductCategory t) {
        // 得到子节点列表
        List<CmsProductCategory> childList = getChildList(list, t);
        t.setChildren(childList);
        for (CmsProductCategory tChild : childList) {
            if (hasChild(list, tChild)) {
                recursionFn(list, tChild);
            }
        }
    }

    /**
     * 得到子节点列表
     */
    private List<CmsProductCategory> getChildList(List<CmsProductCategory> list, CmsProductCategory t) {
        List<CmsProductCategory> tlist = new ArrayList<>();
        Iterator<CmsProductCategory> it = list.iterator();
        while (it.hasNext()) {
            CmsProductCategory n = it.next();
            if (com.yuejike.common.utils.StringUtils.isNotNull(n.getParentId()) && n.getParentId().longValue() == t.getCategoryId().longValue()) {
                tlist.add(n);
            }
        }
        return tlist;
    }

    /**
     * 判断是否有子节点
     */
    private boolean hasChild(List<CmsProductCategory> list, CmsProductCategory t) {
        return getChildList(list, t).size() > 0 ? true : false;
    }

    @Override
    public List<TreeSelectModel> buildTreeSelect(List<CmsProductCategory> productCategories) {
        List<CmsProductCategory> deptTrees = buildTree(productCategories);
        return deptTrees.stream().map(TreeSelectModel::new).collect(Collectors.toList());
    }

    private Specification<CmsProductCategory> formatQueryParams(CmsProductCategory req){
        Specification<CmsProductCategory> example = new Specification<CmsProductCategory>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsProductCategory> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getCategoryId()){
                    Predicate pre = cb.equal(root.get("categoryId").as(Long.class), req.getCategoryId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCnName())){
                    Predicate pre = cb.like(root.get("cnName").as(String.class), "%" + req.getCnName()+ "%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getEnName())){
                    Predicate pre = cb.like(root.get("enName").as(String.class), "%" + req.getEnName()+ "%");
                    list.add(pre);
                }
                if (null != req.getParentId()){
                    Predicate pre = cb.equal(root.get("parentId").as(Long.class), req.getParentId());
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

}
