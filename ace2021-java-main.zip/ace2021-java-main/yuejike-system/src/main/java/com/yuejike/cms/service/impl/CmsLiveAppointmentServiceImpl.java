package com.yuejike.cms.service.impl;

import com.yuejike.cms.dao.CmsLiveAppointmentDao;
import com.yuejike.cms.domain.CmsLiveAppointment;
import com.yuejike.cms.service.ICmsLiveAppointmentService;
import com.yuejike.common.utils.sms.LuoSiMaoSmsUtils;
import com.yuejike.common.utils.sms.RetMsg;
import com.yuejike.system.dao.SysUserDao;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 直播预约Service业务层处理
 *
 * @author cian
 * @since 1.0 2021-11-11
 */
@Transactional(readOnly = true)
@Service("scheduler_appointment_task")
public class CmsLiveAppointmentServiceImpl implements ICmsLiveAppointmentService {

    @Autowired
    private CmsLiveAppointmentDao cmsLiveAppointmentDao;

    @Autowired
    private SysUserDao sysUserDao;

    /**
     * 保存（新增/修改）直播预约
     *
     * @param cmsLive 直播
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public CmsLiveAppointment save(CmsLiveAppointment cmsLive) {
        CmsLiveAppointment live = cmsLiveAppointmentDao.save(cmsLive);
        return live;
    }

    /**
     * 预约直播短信通知
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void scheduler_live_notice() {
        long now_time=System.currentTimeMillis();

        long example_start_time = now_time+60*60*1000;
        Date example_start_date = new Date(example_start_time);
        long example_end_time = now_time+(60+10)*60*1000;
        Date example_end_date = new Date(example_end_time);
        CmsLiveAppointment req = new CmsLiveAppointment();
        req.setStatus("0");
        List<CmsLiveAppointment>  appointments = findCmsLiveList(req,example_start_date,example_end_date);
        List<String> phoneNumbers=new ArrayList<String>() ;
        for (CmsLiveAppointment  cmsLiveAppointment : appointments) {
            long user_id = cmsLiveAppointment.getUserId();
            String live_name = cmsLiveAppointment.getName();
            String mobile = cmsLiveAppointment.getMobile();
            phoneNumbers.add(mobile);
            cmsLiveAppointment.setStatus("1");
        }
        cmsLiveAppointmentDao.saveAll(appointments);
        if (!CollectionUtils.isEmpty(phoneNumbers)){
             RetMsg retMsg = LuoSiMaoSmsUtils.getInstance().sendLiveSubscribeMsg(phoneNumbers.toArray(new String[phoneNumbers.size()]),
                "");
        }
    }

    /**
     * 分页查询直播预约列表
     *
     * @param req 直播
     * @return 直播
     */
    @Override
    public List<CmsLiveAppointment> findCmsLiveList(CmsLiveAppointment req,Date example_start_date,Date example_end_date) {
        Specification<CmsLiveAppointment> example = formatQueryParams(req,example_start_date,example_end_date);
        List<CmsLiveAppointment> list = cmsLiveAppointmentDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    private Specification<CmsLiveAppointment> formatQueryParams(CmsLiveAppointment req,Date example_start_date,Date example_end_date){
        Specification<CmsLiveAppointment> example = new Specification<CmsLiveAppointment>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsLiveAppointment> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getLiveId()){
                    Predicate pre = cb.equal(root.get("liveId").as(Long.class), req.getLiveId());
                    list.add(pre);
                }

                if (StringUtils.isNotBlank(req.getName())){
                    Predicate pre = cb.like(root.get("name").as(String.class), "%" + req.getName()+ "%");
                    list.add(pre);
                }
                if (null != example_start_date){
                    Predicate pre = cb.between(root.get("startTime").as(Date.class), example_start_date,example_end_date);
                    list.add(pre);
                }

                if (StringUtils.isNotBlank(req.getType())){
                    Predicate pre = cb.equal(root.get("type").as(String.class), req.getType());
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }

                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }

                if (StringUtils.isNotBlank(req.getStatus())){

                    Predicate pre = cb.equal(root.get("status").as(String.class), req.getStatus());
                    list.add(pre);
                }


                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }




}
