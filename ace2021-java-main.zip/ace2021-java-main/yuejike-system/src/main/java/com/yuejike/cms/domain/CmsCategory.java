package com.yuejike.cms.domain;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 栏目管理对象 cms_category
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_category")
@Data
public class CmsCategory extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="category_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long categoryId;

    /** 栏目中文名 */
    @Excel(name = "栏目中文名")
    @Column(name="cn_name")
    @ApiModelProperty(value = "栏目中文名")
    private String cnName;

    /** 栏目英文名 */
    @Excel(name = "栏目英文名")
    @Column(name="en_name")
    @ApiModelProperty(value = "栏目英文名")
    private String enName;

    @Excel(name = "栏目日文名称")
    @Column(name="ja_name")
    @ApiModelProperty(value = "栏目日文名称")
    private String jaName;

    @Excel(name = "栏目韩文名称")
    @Column(name="ko_name")
    @ApiModelProperty(value = "栏目韩文名称")
    private String koName;

    /** 缩略图 */
    @Excel(name = "缩略图")
    @Column(name="img_url")
    @ApiModelProperty(value = "缩略图")
    private String imgUrl;

    /** 描述 */
    @Excel(name = "描述")
    @Column(name="descrip")
    @ApiModelProperty(value = "描述")
    private String descrip;

    /** 关键字 */
    @Excel(name = "关键字")
    @Column(name="keyword")
    @ApiModelProperty(value = "关键字")
    private String keyword;

    /** 链接 */
    @Excel(name = "链接")
    @Column(name="link")
    @ApiModelProperty(value = "链接")
    private String link;

    /** 父id */
    @Excel(name = "父id")
    @Column(name="parent_id")
    @ApiModelProperty(value = "父id")
    private Long parentId;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "父id")
    private Date createTime;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "父id")
    private Date updateTime;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "父id")
    private String createBy;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "父id")
    private String updateBy;

    /** 删除标识 */
    @Column(name="del_flag")
    @ApiModelProperty(value = "父id")
    private String delFlag;

    /** 模型id */
    @Excel(name = "模型id")
    @Column(name="model_id")
    @ApiModelProperty(value = "模型id")
    private Long modelId;

    /** 排序 */
    @Excel(name = "排序")
    @Column(name="sort")
    @ApiModelProperty(value = "排序")
    private Integer sort;

    /** 是否外链（0:否1:是）*/
    @Excel(name = "是否外链")
    @Column(name="is_link")
    @ApiModelProperty(value = "是否外链")
    private String isLink;

    @Excel(name = "状态")
    @Column(name="visible")
    @ApiModelProperty(value = "状态")
    private String visible;

    @Excel(name = "博览会id")
    @Column(name="exposition_id")
    @ApiModelProperty(value = "博览会id")
    private Long expositionId;

    @Transient
    @ApiModelProperty(value = "子集")
    private List<CmsCategory> children;

    @Transient
    @ApiModelProperty(value = "父级栏目名称")
    private String parentName;

    @Transient
    @ApiModelProperty(value = "模型名称")
    private String modelName;




}
