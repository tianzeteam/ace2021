package com.yuejike.cms.service;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsCategory;

/**
 * 栏目管理Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsCategoryService  {
    /**
     * 查询栏目管理
     *
     * @param categoryId 栏目管理ID
     * @return 栏目管理
     */
    CmsCategory findById(Long categoryId);

    /**
     * 分页查询栏目管理列表
     *
     * @param req 栏目管理
     * @return 栏目管理集合
     */
    Page<CmsCategory> findCmsCategoryPage(CmsCategory req);


    /**
     * 分页查询栏目管理列表（table-tree展示）
     *
     * @param req 栏目管理
     * @return 栏目管理
     */
    Page<CmsCategory> findCmsCategoryTreePage(CmsCategory req);
    /**
     * 查询栏目管理列表
     *
     * @param req 栏目管理
     * @return 栏目管理集合
     */
    List<CmsCategory> findCmsCategoryList(CmsCategory req);

    /**
     * 获取栏目层级结构树
     *
     * @return 栏目管理集合
     */
    List<Map<String,Object>> getCmsCategorySelectByPid();

    /**
     * 新增栏目管理
     *
     * @param cmsCategory 栏目管理
     * @return 结果
     */
    void save(CmsCategory cmsCategory);

    /**
     * 批量删除栏目管理
     *
     * @param categoryIds 需要删除的栏目管理ID
     * @return 结果
     */
    void deleteByIds(List<Long> categoryIds);

    /**
     * 删除栏目管理信息
     *
     * @param categoryId 栏目管理ID
     * @return 结果
     */
    void deleteCmsCategoryById(Long categoryId);
}
