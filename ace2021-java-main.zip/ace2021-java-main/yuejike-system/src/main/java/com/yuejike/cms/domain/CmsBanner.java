package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 轮播图对象 cms_banner
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_banner")
@Data
public class CmsBanner extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="banner_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "banner")
    private Long bannerId;

    /** 名称 */
    @Excel(name = "名称")
    @Column(name="name")
    @ApiModelProperty(value = "名称")
    private String name;

    /** 位置id */
    @Excel(name = "位置id")
    @Column(name="position_id")
    @ApiModelProperty(value = "位置id")
    private Long positionId;

    /** 图片地址 */
    @Excel(name = "图片地址")
    @Column(name="img_url")
    @ApiModelProperty(value = "图片地址")
    private String imgUrl;

    /** 备注 */
    @Excel(name = "备注")
    @Column(name="remark")
    @ApiModelProperty(value = "备注")
    private String remark;

    /** 排序 */
    @Excel(name = "排序")
    @Column(name="sort")
    @ApiModelProperty(value = "排序")
    private Integer sort;

    /** 显示状态（0：显示1：隐藏） */
    @Excel(name = "显示状态", readConverterExp = "0=：显示1：隐藏")
    @Column(name="status")
    @ApiModelProperty(value = "显示状态")
    private String status;

    /** 删除标识（0：正常1：删除） */
    @Column(name="del_flag")
    @ApiModelProperty(value = "显示状态")
    private String delFlag;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "显示状态")
    private String createBy;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "显示状态")
    private Date createTime;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "显示状态")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "显示状态")
    private Date updateTime;

    /** 跳转链接 */
    @Excel(name = "跳转链接")
    @Column(name="link")
    @ApiModelProperty(value = "跳转链接")
    private String link;

    /** id */
    @Excel(name = "展会id")
    @Column(name="exposition_id")
    @ApiModelProperty(value = "展会id")
    private Long expositionId;
}
