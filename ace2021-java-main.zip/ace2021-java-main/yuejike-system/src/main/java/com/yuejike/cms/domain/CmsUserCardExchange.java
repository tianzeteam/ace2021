package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import com.yuejike.common.core.domain.entity.SysUser;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 名片关联对象 cms_user_card_exchange
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_user_card_exchange")
@Data
public class CmsUserCardExchange extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long id;

    /** 接收名片人id */
    @Excel(name = "展商id")
    @Column(name="accept_id")
    @ApiModelProperty(value = "展商id")
    private Long acceptId;

    /** 发送名片人id */
    @Excel(name = "观众id")
    @Column(name="send_id")
    @ApiModelProperty(value = "观众id")
    private Long sendId;

    /** 名片id */
    @Excel(name = "名片id")
    @Column(name="card_id")
    @ApiModelProperty(value = "名片id")
    private Long cardId;

//    /** 名片姓名 */
//    @Excel(name = "名片姓名")
//    @Column(name="card_name")
//    @ApiModelProperty(value = "名片姓名")
//    private String cardName;
//
//    /** 名片电话 */
//    @Excel(name = "名片电话")
//    @Column(name="card_phone")
//    @ApiModelProperty(value = "名片电话")
//    private String cardPhone;

    /** 展商删除标识(0:正常1:删除) */
    @Column(name="accept_del_flag")
    @ApiModelProperty(value = "展商删除标识(0:正常1:删除)")
    private String acceptDelFlag;

    /** 用户删除标识(0:正常1:删除) */
    @Column(name="send_del_flag")
    @ApiModelProperty(value = "用户删除标识(0:正常1:删除)")
    private String sendDelFlag;

    /** 创建人id */
    @Column(name="create_by")
    @ApiModelProperty(value = "名片电话")
    private String createBy;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "名片电话")
    private Date createTime;

    /** 更新人id */
    @Column(name="update_by")
    @ApiModelProperty(value = "名片电话")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "名片电话")
    private Date updateTime;

//    /** 职位 */
//    @Excel(name = "职位")
//    @Column(name="position")
//    @ApiModelProperty(value = "职位")
//    private String position;
//
//    /** 公司名称 */
//    @Excel(name = "公司名称")
//    @Column(name="company_name")
//    @ApiModelProperty(value = "公司名称")
//    private String companyName;

    /** 接收人地址 */
    @Column(name="accept_address")
    @ApiModelProperty(value = "展商地址")
    private String acceptAddress;

    /** 发送人地址 */
    @Column(name="send_address")
    @ApiModelProperty(value = "观众地址")
    private String sendAddress;

    /** 接收人姓名 */
    @Column(name="accept_name")
    @ApiModelProperty(value = "展商姓名")
    private String acceptName;

    /** 接收人电话 */
    @Column(name="accept_phone")
    @ApiModelProperty(value = "展商电话")
    private String acceptPhone;

    /** 发送人姓名 */
    @Column(name="send_name")
    @ApiModelProperty(value = "观众姓名")
    private String sendName;

    /** 发送人电话 */
    @Column(name="send_phone")
    @ApiModelProperty(value = "观众电话")
    private String sendPhone;

    /** 接收人职位 */
    @Column(name="accept_position")
    @ApiModelProperty(value = "展商职位")
    private String acceptPosition;

    /** 发送人电话 */
    @Column(name="send_position")
    @ApiModelProperty(value = "观众职位")
    private String sendPosition;

    /** 接收人邮箱 */
    @Column(name="accept_email")
    @ApiModelProperty(value = "展商邮箱")
    private String acceptEmail;

    /** 发送人公司 */
    @Column(name="send_company_name")
    @ApiModelProperty(value = "观众公司")
    private String sendCompanyName;

    /** 发送人邮箱 */
    @Column(name="send_email")
    @ApiModelProperty(value = "观众邮箱")
    private String sendEmail;

    /** 接收人公司 */
    @Column(name="accept_company_name")
    @ApiModelProperty(value = "展商公司")
    private String acceptCompanyName;

    @Transient
    private Date startTime;

    @Transient
    private Date endTime;

    @OneToOne
    @JoinColumn(name = "accept_id",insertable = false,updatable = false)
    private SysUser acceptUser;

    @OneToOne
    @JoinColumn(name = "send_id",insertable = false,updatable = false)
    private SysUser sendUser;


}
