package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsLiveUser;

/**
 * 直播角色权限关联Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsLiveUserService  {
    /**
     * 查询直播角色权限关联
     *
     * @param id 直播角色权限关联ID
     * @return 直播角色权限关联
     */
    CmsLiveUser findById(Long id);

    /**
     * 分页查询直播角色权限关联列表
     *
     * @param req 直播角色权限关联
     * @return 直播角色权限关联集合
     */
    Page<CmsLiveUser> findCmsLiveUserPage(CmsLiveUser req);

    /**
     * 查询直播角色权限关联列表
     *
     * @param req 直播角色权限关联
     * @return 直播角色权限关联集合
     */
    List<CmsLiveUser> findCmsLiveUserList(CmsLiveUser req);

    /**
     * 新增直播角色权限关联
     *
     * @param cmsLiveUser 直播角色权限关联
     * @return 结果
     */
    void save(CmsLiveUser cmsLiveUser);

    /**
     * 批量删除直播角色权限关联
     *
     * @param ids 需要删除的直播角色权限关联ID
     * @return 结果
     */
    void deleteByIds(List<Long> ids);

    /**
     * 删除直播角色权限关联信息
     *
     * @param id 直播角色权限关联ID
     * @return 结果
     */
    void deleteCmsLiveUserById(Long id);
}
