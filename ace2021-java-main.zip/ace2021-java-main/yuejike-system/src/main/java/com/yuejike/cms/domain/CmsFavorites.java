package com.yuejike.cms.domain;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 收藏对象 cms_favorites
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_favorites")
@Data
public class CmsFavorites extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="favorites_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "主键id")
    private Long favoritesId;

    /** 收藏人id */
    @Excel(name = "收藏人id")
    @Column(name="user_id")
    @ApiModelProperty(value = "收藏人id")
    private Long userId;

    /** 业务id */
    @Excel(name = "业务id")
    @Column(name="business_id")
    @ApiModelProperty(value = "业务id")
    private Long businessId;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "业务id")
    private String createBy;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "业务id")
    private Date createTime;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "业务id")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "业务id")
    private Date updateTime;

    /** 删除标识 */
    @Column(name="del_flag")
    @ApiModelProperty(value = "业务id")
    private String delFlag;

    /** 业务名称 */
    @Excel(name = "业务名称")
    @Column(name="business_name")
    @ApiModelProperty(value = "业务名称")
    private String businessName;

    /** 业务类型(0:展品1：展商2：直播) */
    @Excel(name = "业务类型(0:展品1：展商2：直播)")
    @Column(name="business_type")
    @ApiModelProperty(value = "业务类型(0:展品1：展商2：直播)")
    private String businessType;

    @Transient
    private CmsProduct product;

    @Transient
    private SysUserExhibitor userExhibitor;

    @Transient
    private CmsLive live;


}
