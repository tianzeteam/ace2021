package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.SysUserDelegate;

/**
 * 会议代Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-27
 */
public interface ISysUserDelegateService  {
    /**
     * 查询会议代
     *
     * @param userId 会议代ID
     * @return 会议代
     */
    SysUserDelegate findById(Long userId);

    /**
     * 分页查询会议代列表
     *
     * @param req 会议代
     * @return 会议代集合
     */
    Page<SysUserDelegate> findSysUserDelegatePage(SysUserDelegate req);

    /**
     * 查询会议代列表
     *
     * @param req 会议代
     * @return 会议代集合
     */
    List<SysUserDelegate> findSysUserDelegateList(SysUserDelegate req);

    /**
     * 新增会议代
     *
     * @param sysUserDelegate 会议代
     * @return 结果
     */
    void save(SysUserDelegate sysUserDelegate);

    /**
     * 批量删除会议代
     *
     * @param userIds 需要删除的会议代ID
     * @return 结果
     */
    void deleteByIds(List<Long> userIds);

    /**
     * 删除会议代信息
     *
     * @param userId 会议代ID
     * @return 结果
     */
    void deleteSysUserDelegateById(Long userId);
}
