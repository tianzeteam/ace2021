package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsProduct;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


/**
 * 展品信息Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Repository
public interface CmsProductDao extends JpaRepository<CmsProduct, Long>, JpaSpecificationExecutor<CmsProduct> {
	
	/**
	 * 根据展商查展品
	 * @param uid
	 * @return
	 */
	@Query(value = " select product_id,cover_url,name,detail from cms_product where user_id =?1 and status = 1", nativeQuery = true)
	List<Map<String, Object>> findByUserId(Long uid);

	@Query(value = "select count(*) from cms_product where status='1' and visible ='0' and classification_id =?1",nativeQuery = true)
	int findByClassificationId(Long classificationId);

	@Query(value = "select sort from cms_product order by sort desc limit 1", nativeQuery = true)
	Integer getMaxSortNo();

	@Transactional
	@Modifying
	@Query(value = "update cms_product set recommend =?2 where product_id in (?1)",nativeQuery = true)
	int batchRecommend(List<Long> productIds, String type);

	@Query(value = "SELECT product_id FROM cms_product where recommend = ?1 ORDER BY RAND() LIMIT ?2",nativeQuery = true)
	List<Long> getRandProductIds(String recommend, Integer size);

}
