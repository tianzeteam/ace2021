package com.yuejike.cms.dao;

import com.yuejike.cms.domain.Receptionist;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * @author JinZJ
 * @version 1.0
 * @Description:
 * @date 2021/11/17 17:18
 */
@Repository
public interface ReceptionistDao extends JpaRepository<Receptionist, Long>, JpaSpecificationExecutor<Receptionist> {
}
