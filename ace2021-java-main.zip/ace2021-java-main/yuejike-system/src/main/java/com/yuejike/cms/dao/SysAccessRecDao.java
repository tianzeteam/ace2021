package com.yuejike.cms.dao;

import com.yuejike.cms.domain.SysAccessRec;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * @author JinZJ
 * @version 1.0
 * @Description:
 * @date 2021/11/25 15:55
 */
@Repository
public interface SysAccessRecDao extends JpaRepository<SysAccessRec, Long>, JpaSpecificationExecutor<SysAccessRec> {

    @Query(value = "SELECT COUNT(1) FROM sys_access_rec WHERE DATEDIFF(create_time,NOW())=0", nativeQuery = true)
    Long getPv();

    @Query(value = " SELECT COUNT(1) FROM (SELECT DISTINCT ip_addr, user_id FROM sys_access_rec WHERE DATEDIFF(create_time,NOW())=0) a ", nativeQuery = true)
    Long getUv();

    @Query(value = "SELECT COUNT(1) FROM sys_access_rec WHERE path LIKE '/#/CloudHall?type=product%'", nativeQuery = true)
    Long getProductPv();

    @Query(value = "SELECT COUNT(1) FROM (SELECT DISTINCT ip_addr, user_id FROM sys_access_rec " +
            "WHERE page_type=2 and source_id=?1) a", nativeQuery = true)
    Long getProductUv(Long productId);

    @Query(value = "SELECT source_id as productId, count(1) as aCount FROM (SELECT DISTINCT source_id, ip_addr, user_id FROM sys_access_rec " +
            "WHERE page_type=2 and source_id in (?1)) a group by source_id", nativeQuery = true)
    List<Map<String, Long>> getProductUv(Long[] productIds);

    @Query(value = "SELECT COUNT(1) FROM sys_access_rec WHERE path LIKE '/#/CloudHall?type=store%'", nativeQuery = true)
    Long getExhibitorPv();

    /**全局**/
    @Query(value = "SELECT (SELECT sum(multiple) FROM sys_access_rec) AS '云展访问数量'\n" +
            ", (SELECT sum(counter_Offline) FROM sys_access_date_rec) AS '观展人数'", nativeQuery = true)
    Map getWholeSituation();

    @Query(value = "SELECT (SELECT COUNT(*) FROM sys_access_rec WHERE page_type = 3) AS '线上购买次数'\n" +
            ",(SELECT sum(counter_online+counter_Offline) FROM sys_access_date_rec) AS '累计人数'\n" +
            ", (SELECT counter_online+counter_Offline FROM sys_access_date_rec WHERE statistical_date = DATE_FORMAT(NOW(),'%Y-%m-%d')) AS '今日观展'\n" +
            ", (SELECT COUNT(1) FROM sys_access_rec WHERE create_time >= DATE_ADD(NOW(),INTERVAL -30 MINUTE)) AS '当前在线'", nativeQuery = true)
    Map getOverallViewing();

    /**
     * 功能描述: <br>
     * 〈获取注册数量〉
     * @Param: []
     * @Return: java.util.Map
     * @Author: JinZJ
     * @Date: 2021/12/3 12:12
     */
    @Query(value = "SELECT COUNT(IF(A.user_type IN ('02','08') AND B.user_id IS NOT NULL,1,NULL)) AS '展商'\n" +
            ", COUNT(IF(A.user_type = '04' AND C.user_id IS NOT NULL,1,NULL)) '媒体' \n" +
            ", COUNT(IF(A.user_type = '03' AND D.user_id IS NOT NULL,1,NULL)) '嘉宾'\n" +
            ", COUNT(IF(A.user_type = '05' AND E.user_id IS NOT NULL,1,NULL)) '专业观众'\n" +
            ", COUNT(IF(A.user_type = '06',1,NULL)) '普通观众'\n" +
            "FROM sys_user A LEFT JOIN sys_user_exhibitor B ON B.user_id=A.user_id AND IFNULL(B.del_flag,0)='0'\n" +
            "LEFT JOIN sys_user_media C ON C.user_id=A.user_id AND IFNULL(C.del_flag,0)='0'\n" +
            "LEFT JOIN sys_user_delegate D ON D.user_id=A.user_id AND IFNULL(D.del_flag,0)='0'\n" +
            "LEFT JOIN sys_user_audience E ON E.user_id=A.user_id AND IFNULL(E.del_flag,0)='0'\n" +
            "WHERE A.del_flag='0' AND A.`status`='0' AND (A.user_type = '06' OR A.review_status='1')", nativeQuery = true)
    Map getRegistration();

    /**
     * 功能描述: <br>
     * 〈获取展商来源〉
     * @Param: []
     * @Return: java.util.List<java.util.Map>
     * @Author: JinZJ
     * @Date: 2021/12/3 16:39
     */
    @Query(value = "SELECT IFNULL(A.city, A.province) AS '地区', A.aCount AS '数量' FROM (SELECT A.province, A.city,COUNT(1) AS aCount \n" +
            "FROM sys_user_exhibitor A INNER JOIN sys_user B ON B.user_id = A.user_id \n" +
            "WHERE IFNULL(A.del_flag,0)='0' AND B.del_flag='0' AND B.`status`='0' AND B.review_status='1'\n" +
            "AND A.province IS NOT NULL AND A.province<>'' AND A.country_id = 1 GROUP BY A.province, A.city) A\n" +
            "UNION ALL\n" +
            "SELECT '海外' AS '地区', COUNT(1) AS '数量' FROM sys_user_exhibitor A INNER JOIN sys_user B ON B.user_id = A.user_id \n" +
            "WHERE IFNULL(A.del_flag,0)='0' AND B.del_flag='0' AND B.`status`='0' AND B.review_status='1'\n" +
            "AND A.province IS NOT NULL AND A.province<>'' AND A.country_id <> 1", nativeQuery = true)
    List<Map> getExhibitorSource();

    /**
     * 功能描述: <br>
     * 〈获取观众来源〉
     * @Param: []
     * @Return: java.util.List<java.util.Map>
     * @Author: JinZJ
     * @Date: 2021/12/3 16:47
     */
    @Query(value = "SELECT IFNULL(region_city, region_province) AS '出发地', '芜湖' AS '目的地' FROM (\n" +
            "\tSELECT region_province, region_city, MAX(create_time) AS create_time FROM sys_access_rec GROUP BY region_province, region_city\n" +
            ") A  WHERE region_province IS NOT NULL AND region_province <> '' ORDER BY create_time DESC LIMIT 15", nativeQuery = true)
    List<Map> getAudienceSource();

    /**
     * 功能描述: <br>
     * 〈获取热门展商〉
     * @Param: []
     * @Return: java.util.List<java.util.Map>
     * @Author: JinZJ
     * @Date: 2021/12/3 16:59
     */
    @Query(value = "SELECT name AS '名称', pv AS '数量' FROM sys_user_exhibitor ORDER BY pv DESC LIMIT 6", nativeQuery = true)
    List<Map> getPopularExhibitors();

    /**
     * 功能描述: <br>
     * 〈获取热门展品〉
     * @Param: []
     * @Return: java.util.List<java.util.Map>
     * @Author: JinZJ
     * @Date: 2021/12/3 17:08
     */
    @Query(value = "SELECT name AS '名称', pv AS '数量' FROM cms_product ORDER BY pv DESC LIMIT 6", nativeQuery = true)
    List<Map> getPopularProduct();

    /**
     * 功能描述: <br>
     * 〈获取展厅情况〉
     * @Param: []
     * @Return: java.util.List<java.util.Map>
     * @Author: JinZJ 
     * @Date: 2021/12/3 17:30
     */
    @Query(value = "SELECT classification_name AS '名称', COUNT(1) AS '数量' FROM (SELECT CASE B.parent_id WHEN 0 \n" +
            "\tTHEN B.classification_id ELSE C.classification_id END AS classification_id, \n" +
            "\tCASE B.parent_id WHEN 0 THEN B.name ELSE C.name END AS classification_name\n" +
            "FROM sys_user_exhibitor A \n" +
            "\tINNER JOIN sys_user D ON D.user_id=A.user_id AND D.del_flag = '0' AND D.`status`='0' AND D.review_status='1'\n" +
            "\tLEFT JOIN cms_classification B ON B.classification_id=A.classification_id\n" +
            "\tLEFT JOIN cms_classification C ON C.classification_id=B.parent_id) A\n" +
            "GROUP BY classification_id, classification_name", nativeQuery = true)
    List<Map> getExhibitionHallCount();

    @Query(value = "select count(1) from sys_access_rec where (?2 is null or ?2=user_id) and ?1=ip_addr " +
            "and DATE(create_time)=curdate()", nativeQuery = true)
    Long visitCount(String ipAddr, Long userId);


    @Query(value = "SELECT A.strWeek AS '星期', IFNULL(b.acount,0) AS '访问量', IFNULL(C.acount,0) AS 意向成交 \n" +
            "FROM (SELECT 1 AS aWeek, '一' AS strWeek UNION SELECT 2 AS aWeek, '二' AS strWeek \n" +
            "UNION SELECT 3 AS aWeek, '三' AS strWeek UNION SELECT 4 AS aWeek, '四' AS strWeek \n" +
            "UNION SELECT 5 AS aWeek, '五' AS strWeek UNION SELECT 6 AS aWeek, '六' AS strWeek \n" +
            "UNION SELECT 7 AS aWeek, '日' AS strWeek ) A LEFT JOIN (\n" +
            "\tSELECT DAYOFWEEK(create_time)-1 AS aweek, COUNT(multiple) AS acount FROM sys_access_rec\n" +
            "\tGROUP BY DAYOFWEEK(create_time)-1\n" +
            ") B ON B.aweek=A.aWeek\n" +
            "LEFT JOIN (\n" +
            "\tSELECT DAYOFWEEK(create_time)-1 AS aweek, COUNT(1) AS acount FROM cms_order WHERE order_status=2 AND del_flag='0'\n" +
            "\tGROUP BY DAYOFWEEK(create_time)-1\n" +
            ") C ON C.aweek=A.aWeek", nativeQuery = true)
    List<Map> getIntendedTransaction();

    @Query(value = "select \n" +
            "(SELECT count(1) FROM sys_user_exhibitor A INNER JOIN sys_user B ON B.user_id=A.user_id AND B.del_flag='0' and B.review_status='0') as type1, \n" +
            "(SELECT count(1) FROM sys_user_exhibitor A INNER JOIN sys_user B ON B.user_id=A.user_id AND B.del_flag='0' and B.review_status='1' \n" +
            "\tAND A.excellent_video_status='0') as type2,\n" +
            "(SELECT COUNT(1) FROM v3d_businessman_exhibition where `status`='待审核') as type3, \n" +
            "(SELECT COUNT(1) FROM cms_product where `status`='0' and del_flag='0') as type4, \n" +
            "(SELECT COUNT(1) FROM sys_user_audience A INNER JOIN sys_user B ON B.user_id=A.user_id and B.del_flag='0' AND B.review_status='0') as type5, \n" +
            "(SELECT COUNT(1) FROM sys_user_delegate A inner JOIN sys_user B ON B.user_id=A.user_id AND B.del_flag='0' and B.review_status='0') as type6, \n" +
            "(SELECT COUNT(1) FROM sys_user_media A INNER JOIN sys_user B ON B.user_id=A.user_id AND B.dept_id='0' and B.review_status='0') as type7,\n" +
            "(SELECT count(1) FROM sys_user_exhibitor A INNER JOIN sys_user B ON B.user_id=A.user_id AND B.del_flag='0' and B.review_status='1' \n" +
            "\tAND A.basicinfo_review_status='0') as type8 ", nativeQuery = true)
    Map<String, Long> pendingApprovalData();
}
