package com.yuejike.cms.dto;

import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Transient;
import java.math.BigInteger;
import java.util.Date;
@Data
public class CmsNegotiateDTO extends BaseEntity{

        //private static final long serialVersionUID = 1L;

        /** id */
//        @Id
//        @Column(name="negotiate_id")
//        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @ApiModelProperty(value = "${comment}")
        @Transient
        private BigInteger negotiateId;

        /** 展品id */
//        @Excel(name = "展品id")
//        @Column(name="product_id")
        @ApiModelProperty(value = "展品id")
        @Transient
        private BigInteger productId;

        /** 联系人 */
//        @Excel(name = "联系人")
//        @Column(name="contacts")
        @ApiModelProperty(value = "联系人")
        @Transient
        private String contacts;

        /** 电话 */
//        @Excel(name = "电话")
//        @Column(name="phone")
        @ApiModelProperty(value = "电话")
        @Transient
        private String phone;

        /** 备注内容 */
//        @Excel(name = "备注内容")
//        @Column(name="remark")
        @ApiModelProperty(value = "备注内容")
        @Transient
        private String remark;

        /** 发起人id */
//        @Excel(name = "发起人id")
//        @Column(name="send_id")
        @ApiModelProperty(value = "发起人id")
        @Transient
        private BigInteger sendId;

        /** 接收人id */
//        @Excel(name = "接收人id")
//        @Column(name="accept_id")
        @ApiModelProperty(value = "接收人id")
        @Transient
        private BigInteger acceptId;

        /** 创建人 */
//        @Column(name="create_by")
        @ApiModelProperty(value = "创建人")
        @Transient
        private String createBy;

        /** 创建时间 */
//        @Column(name="create_time")
        @ApiModelProperty(value = "创建时间")
        @Transient
        private Date createTime;

        /** 更新人 */
//        @Column(name="update_by")
        @ApiModelProperty(value = "修改人")
        @Transient
        private String updateBy;

        /** 更新时间 */
//        @Column(name="update_time")
        @ApiModelProperty(value = "修改时间")
        @Transient
        private Date updateTime;

        /** 状态（0：未读1：已读） */
//        @Excel(name = "状态", readConverterExp = "0=：未读1：已读")
//        @Column(name="status")
        @ApiModelProperty(value = "状态")
        @Transient
        private Character status;

        /** 删除标识(0:正常1:删除) */
//        @Column(name="del_flag")
    @ApiModelProperty(value = "状态")
    @Transient
    private Character delFlag;

    /** 删除标识(0:正常1:删除) */
//        @Column(name="del_flag")
    @ApiModelProperty(value = "用户名")
    @Transient
    private String userName;

    /** 删除标识(0:正常1:删除) */
//        @Column(name="del_flag")
    @ApiModelProperty(value = "展品名称")
    @Transient
    private String productName;

    /** 删除标识(0:正常1:删除) */
//        @Column(name="del_flag")
    @ApiModelProperty(value = "展商名称")
    @Transient
    private String exhibitorName;

    /** 删除标识(0:正常1:删除) */
    @Column(name="reply")
    @Transient
    @ApiModelProperty(value = "恰谈回复")
    private String reply;

    /** 删除标识(0:正常1:删除) */
    @Column(name="start_time")
    @Transient
    @ApiModelProperty(value = "预约开始时间")
    private Integer startTime;

    @Column(name="end_time")
    @Transient
    @ApiModelProperty(value = "预约结束时间")
    private Integer endTime;

    @Column(name="reservation_time")
    @Transient
    @ApiModelProperty(value = "预约时间")
    private Date reservationTime;


    }


