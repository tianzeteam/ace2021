package com.yuejike.cms.service.impl;

import java.util.*;
import java.util.stream.Collectors;

import com.yuejike.common.core.domain.TreeSelect;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.DateUtils;

import com.yuejike.common.utils.SecurityUtils;
import com.yuejike.model.TreeSelectModel;
import org.apache.commons.lang3.StringUtils;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yuejike.cms.dao.CmsClassificationDao;
import com.yuejike.cms.domain.CmsClassification;
import com.yuejike.cms.service.ICmsClassificationService;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/**
 * 分类Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsClassificationServiceImpl implements ICmsClassificationService {

    @Autowired
    private CmsClassificationDao cmsClassificationDao;

    @Override
    public List<CmsClassification> selectClassList(CmsClassification classification) {
        Specification<CmsClassification> example = formatQueryParams(classification);
        List<CmsClassification> list = cmsClassificationDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    /**
     * 查询分类
     *
     * @param classificationId 分类ID
     * @return 分类
     */
    @Override
    public CmsClassification findById(Long classificationId) {
        return cmsClassificationDao.findById(classificationId).get();
    }

    /**
     * 分页查询分类列表
     *
     * @param req 分类
     * @return 分类
     */
    @Override
    public Page<CmsClassification> findCmsClassificationPage(CmsClassification req) {
        Specification<CmsClassification> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsClassification> page = cmsClassificationDao.findAll(example, pageable);
        return page;
    }

    /**
     * 分页查询分类列表
     *
     * @param req 分类
     * @return 分类
     */
    @Override
    public List<CmsClassification> findCmsClassificationList(CmsClassification req) {
        Specification<CmsClassification> example = formatQueryParams(req);
        List<CmsClassification> list = cmsClassificationDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    private Specification<CmsClassification> formatQueryParams(CmsClassification req){
        Specification<CmsClassification> example = new Specification<CmsClassification>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsClassification> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getClassificationId()){
                    Predicate pre = cb.equal(root.get("classificationId").as(Long.class), req.getClassificationId());
                    list.add(pre);
                }
                if (null != req.getExpositionId()){
                    Predicate pre = cb.equal(root.get("expositionId").as(Long.class), req.getExpositionId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getName())){
                    Predicate pre = cb.like(root.get("name").as(String.class), "%" + req.getName()+ "%");
                    list.add(pre);
                }
                if (null != req.getParentId()){
                    Predicate pre = cb.equal(root.get("parentId").as(Long.class), req.getParentId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())){
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getVisible())){
                    Predicate pre = cb.equal(root.get("visible").as(String.class), req.getVisible());
                    list.add(pre);
                }
                //主办方按展区过滤数据权限
                LoginUser loginUser = SecurityUtils.getLoginUserNoThrow();
                if(loginUser != null && loginUser.getUser() != null && loginUser.getUser().getUserType().equals(UserType.ZBF_JS.getCode())){
                    List<Long> planIds = new ArrayList<>();
                    if(loginUser.getUser().getRoles() != null){
                        loginUser.getUser().getRoles().forEach(role -> {
                            if(StringUtils.isNotEmpty(role.getPlanIds())) {
                                Arrays.stream(role.getPlanIds().split(",")).forEach(it -> {
                                    if(!planIds.contains(Long.valueOf(it))){
                                        planIds.add(Long.valueOf(it));
                                    }
                                });
                            }
                        });
                        if(planIds.size()>0){
                            List<Long> classificationIds = cmsClassificationDao.getClassificationIdByPlanIds(planIds);
                            if(classificationIds.size()>0){
                                CriteriaBuilder.In<Long> in = cb.in(root.get("classificationId"));
                                CriteriaBuilder.In<Long> inParent = cb.in(root.get("parentId"));
                                classificationIds.forEach(it -> {
                                    in.value(Long.valueOf(it));
                                    inParent.value(Long.valueOf(it));
                                });
                                list.add(cb.or(in, inParent));
                            }
                        }

                    }
                }

                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）分类
     *
     * @param cmsClassification 分类
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void save(CmsClassification cmsClassification) {
        cmsClassification.setCreateTime(DateUtils.getNowDate());
        cmsClassificationDao.save(cmsClassification);
    }


    /**
     * 批量删除分类
     *
     * @param classificationIds 需要删除的分类ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> classificationIds) {
        List<CmsClassification> existBeans = cmsClassificationDao.findAllById(classificationIds);
        if(!existBeans.isEmpty()){
            cmsClassificationDao.deleteAll(existBeans);
        }
    }

    /**
     * 是否存在子节点
     * @param classificationId
     * @return
     */
    @Override
    public boolean hasChildByMenuId(Long classificationId) {
        int result = cmsClassificationDao.hasChildByMenuId(classificationId);
        return result> 0 ? true : false;
    }

    /**
     * 删除分类信息
     *
     * @param classificationId 分类ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsClassificationById(Long classificationId) {
         cmsClassificationDao.deleteById(classificationId);
    }

    /**
     * 构建前端所需要下拉树结构
     *
     * @param classifications 分类列表
     * @return 下拉树结构列表
     */
    @Override
    public List<TreeSelectModel> buildTreeSelect(List<CmsClassification> classifications) {
        List<CmsClassification> deptTrees = buildTree(classifications);
        return deptTrees.stream().map(TreeSelectModel::new).collect(Collectors.toList());
    }

    @Override
    public List<CmsClassification> findByParentId(List<Long> classificationId) {
        return cmsClassificationDao.findByParentId(classificationId);
    }

    @Override
    public List<CmsClassification> buildTree(List<CmsClassification> classifications) {
        List<CmsClassification> returnList = new ArrayList<>();
        List<Long> tempList = new ArrayList<>();
        for (CmsClassification dept : classifications) {
            tempList.add(dept.getClassificationId());
        }
        for (Iterator<CmsClassification> iterator = classifications.iterator(); iterator.hasNext(); ) {
            CmsClassification next = iterator.next();
            // 如果是顶级节点, 遍历该父节点的所有子节点
            if (!tempList.contains(next.getParentId())) {
                recursionFn(classifications, next);
                returnList.add(next);
            }
        }
        if (returnList.isEmpty()) {
            returnList = classifications;
        }
        return returnList;
    }

    /**
     * 递归列表
     */
    private void recursionFn(List<CmsClassification> list, CmsClassification t) {
        // 得到子节点列表
        List<CmsClassification> childList = getChildList(list, t);
        t.setChildren(childList);
        for (CmsClassification tChild : childList) {
            if (hasChild(list, tChild)) {
                recursionFn(list, tChild);
            }
        }
    }

    /**
     * 得到子节点列表
     */
    private List<CmsClassification> getChildList(List<CmsClassification> list, CmsClassification t) {
        List<CmsClassification> tlist = new ArrayList<>();
        Iterator<CmsClassification> it = list.iterator();
        while (it.hasNext()) {
            CmsClassification n = it.next();
            if (com.yuejike.common.utils.StringUtils.isNotNull(n.getParentId()) && n.getParentId().longValue() == t.getClassificationId().longValue()) {
                tlist.add(n);
            }
        }
        return tlist;
    }

    /**
     * 判断是否有子节点
     */
    private boolean hasChild(List<CmsClassification> list, CmsClassification t) {
        return getChildList(list, t).size() > 0 ? true : false;
    }
}
