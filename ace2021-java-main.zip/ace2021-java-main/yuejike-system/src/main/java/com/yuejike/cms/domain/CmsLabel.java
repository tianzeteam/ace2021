package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 标签对象 cms_label
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_label")
@Data
public class CmsLabel extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="label_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long labelId;

    /** 标签名称 */
    @Excel(name = "标签中文名称")
    @Column(name="label_name")
    @ApiModelProperty(value = "标签中文名称")
    private String labelName;

    /** 标签名称 */
    @Excel(name = "标签英文名称")
    @Column(name="label_en_name")
    @ApiModelProperty(value = "标签英文名称")
    private String labelEnName;

    @Excel(name = "标签日文名称")
    @Column(name="label_ja_name")
    @ApiModelProperty(value = "标签日文名称")
    private String labelJaName;

    @Excel(name = "标签韩文名称")
    @Column(name="label_ko_name")
    @ApiModelProperty(value = "标签韩文名称")
    private String labelKoName;

    /** 标签图标 */
    @Excel(name = "标签图标")
    @Column(name="img_url")
    @ApiModelProperty(value = "标签图标")
    private String imgUrl;

    /** 标签类型(0:展品标签1:展商标签) */
    @Excel(name = "标签类型(0:展品标签1:展商标签)")
    @Column(name="type")
    @ApiModelProperty(value = "标签类型(0:展品标签1:展商标签)")
    private String type;

    /** 创建人id */
    @Excel(name = "创建人id")
    @Column(name="user_id")
    @ApiModelProperty(value = "创建人id")
    private Long userId;

    /** 删除标识（0：正常 1：删除） */
    @Column(name="del_flag")
    @ApiModelProperty(value = "创建人id")
    private String delFlag;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "创建人id")
    private Date createTime;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "创建人id")
    private Date updateTime;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "创建人id")
    private String createBy;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "创建人id")
    private String updateBy;

    /** 是否启用(0:启用1:禁用) */
    @Excel(name = "是否启用(0:启用1:禁用)")
    @Column(name="visible")
    @ApiModelProperty(value = "是否启用(0:启用1:禁用)")
    private String visible;

    @Excel(name = "博览会id")
    @Column(name="exposition_id")
    @ApiModelProperty(value = "博览会id")
    private Long expositionId;
}
