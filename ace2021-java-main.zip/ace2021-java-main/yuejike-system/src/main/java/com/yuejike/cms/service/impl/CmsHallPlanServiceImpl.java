package com.yuejike.cms.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.yuejike.common.utils.DateUtils;

import java.util.Date;
import org.apache.commons.lang3.StringUtils;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yuejike.cms.dao.CmsHallPlanDao;
import com.yuejike.cms.domain.CmsHallPlan;
import com.yuejike.cms.service.ICmsHallPlanService;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/**
 * 展区规划Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsHallPlanServiceImpl implements ICmsHallPlanService {

    @Autowired
    private CmsHallPlanDao cmsHallPlanDao;

    /**
     * 查询展区规划
     *
     * @param planId 展区规划ID
     * @return 展区规划
     */
    @Override
    public CmsHallPlan findById(Long planId) {
        return cmsHallPlanDao.findById(planId).get();
    }

    /**
     * 分页查询展区规划列表
     *
     * @param req 展区规划
     * @return 展区规划
     */
    @Override
    public Page<CmsHallPlan> findCmsHallPlanPage(CmsHallPlan req) {
        Specification<CmsHallPlan> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsHallPlan> page = cmsHallPlanDao.findAll(example, pageable);
        return page;
    }

    /**
     * 分页查询展区规划列表
     *
     * @param req 展区规划
     * @return 展区规划
     */
    @Override
    public List<CmsHallPlan> findCmsHallPlanList(CmsHallPlan req) {
        Specification<CmsHallPlan> example = formatQueryParams(req);
        List<CmsHallPlan> list = cmsHallPlanDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    private Specification<CmsHallPlan> formatQueryParams(CmsHallPlan req){
        Specification<CmsHallPlan> example = new Specification<CmsHallPlan>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsHallPlan> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getPlanId()){
                    Predicate pre = cb.equal(root.get("planId").as(Long.class), req.getPlanId());
                    list.add(pre);
                }
                if (null != req.getExpositionId()){
                    Predicate pre = cb.equal(root.get("expositionId").as(Long.class), req.getExpositionId());
                    list.add(pre);
                }
                if (null != req.getClassificationId()){
                    Predicate pre = cb.equal(root.get("classificationId").as(Long.class), req.getClassificationId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getImgUrl())){
                    Predicate pre = cb.equal(root.get("imgUrl").as(String.class), req.getImgUrl());
                    list.add(pre);
                }
                if (null != req.getSort()){
                    Predicate pre = cb.equal(root.get("sort").as(Integer.class), req.getSort());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getVisible())){
                    Predicate pre = cb.equal(root.get("visible").as(String.class), req.getVisible());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())){
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）展区规划
     *
     * @param cmsHallPlan 展区规划
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void save(CmsHallPlan cmsHallPlan) {
        cmsHallPlan.setCreateTime(DateUtils.getNowDate());
        cmsHallPlanDao.save(cmsHallPlan);
    }


    /**
     * 批量删除展区规划
     *
     * @param planIds 需要删除的展区规划ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> planIds) {
        List<CmsHallPlan> existBeans = cmsHallPlanDao.findAllById(planIds);
        if(!existBeans.isEmpty()){
            cmsHallPlanDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除展区规划信息
     *
     * @param planId 展区规划ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsHallPlanById(Long planId) {
         cmsHallPlanDao.deleteById(planId);
    }
}
