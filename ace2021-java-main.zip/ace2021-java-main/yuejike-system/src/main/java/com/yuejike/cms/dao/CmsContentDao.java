package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsContent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * 文章Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Repository
public interface CmsContentDao extends JpaRepository<CmsContent, Long>, JpaSpecificationExecutor<CmsContent> {


 @Query(value = "SELECT DISTINCT cc.* from cms_content cc\n" +
         " left join cms_category ca on ca.category_id =cc.category_id\n" +
         " left join cms_model m on m.model_id = ca.model_id\n" +
         " left join cms_model_extend me on me.model_id = m.model_id\n" +
         " where me.model_id=?1",nativeQuery = true)
 List<CmsContent> findListByModelId(Long modelId);

}
