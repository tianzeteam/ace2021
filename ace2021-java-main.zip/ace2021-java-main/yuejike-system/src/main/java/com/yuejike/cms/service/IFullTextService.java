package com.yuejike.cms.service;

import com.yuejike.cms.domain.FullText;
import org.springframework.data.domain.Page;

/**
 * @author ：JinZj
 * @date ：Created in 2022/1/4 5:28 下午
 * @description：全文索引服务
 * @modified By：
 */
public interface IFullTextService {

    Page<FullText> search(String keyWord, String empower, String groupId);

}
