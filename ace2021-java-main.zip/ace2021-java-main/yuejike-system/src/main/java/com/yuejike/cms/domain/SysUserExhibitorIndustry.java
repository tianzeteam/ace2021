package com.yuejike.cms.domain;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.yuejike.common.core.domain.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Entity
@Table(name = "sys_user_exhibitor_industry")
@Data
public class SysUserExhibitorIndustry extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name="industry_map")
    private String industryMap;

    // 数据转换
    @Transient
    private List<String> industryData;
    public List<String> getIndustryData() {
        return new ArrayList<>(Arrays.asList(this.industryMap.split(",")));
    }

    @ManyToOne(fetch= FetchType.LAZY)
    @JoinColumn(name="user_id", foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT))
    @JsonBackReference
    private SysUserExhibitor exhibitor;

}
