package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsTicketRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;


/**
 * 门票预约记录Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-10-18
 */
@Repository
public interface CmsTicketRecordDao extends JpaRepository<CmsTicketRecord, Long>, JpaSpecificationExecutor<CmsTicketRecord> {



}
