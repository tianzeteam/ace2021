package com.yuejike.cms.service;

public interface ISysUserExhibitorIndustryService {
}
