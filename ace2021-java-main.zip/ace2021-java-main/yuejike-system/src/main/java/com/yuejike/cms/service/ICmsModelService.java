package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsModel;

/**
 * 模型Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsModelService  {
    /**
     * 查询模型
     *
     * @param modelId 模型ID
     * @return 模型
     */
    CmsModel findById(Long modelId);

    /**
     * 分页查询模型列表
     *
     * @param req 模型
     * @return 模型集合
     */
    Page<CmsModel> findCmsModelPage(CmsModel req);

    /**
     * 查询模型列表
     *
     * @param req 模型
     * @return 模型集合
     */
    List<CmsModel> findCmsModelList(CmsModel req);

    /**
     * 新增模型
     *
     * @param cmsModel 模型
     * @return 结果
     */
    void save(CmsModel cmsModel);

    /**
     * 批量删除模型
     *
     * @param modelIds 需要删除的模型ID
     * @return 结果
     */
    void deleteByIds(List<Long> modelIds);

    /**
     * 删除模型信息
     *
     * @param modelId 模型ID
     * @return 结果
     */
    void deleteCmsModelById(Long modelId);
}
