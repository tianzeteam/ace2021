package com.yuejike.cms.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 分类对象 cms_classification
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_classification")
@Data
public class CmsClassification extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** 分类id */
    @Id
    @Column(name="classification_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long classificationId;

    /** 分类名称 */
    @Excel(name = "分类名称")
    @Column(name="name")
    @ApiModelProperty(value = "分类名称")
    private String name;

    @Excel(name = "分类英文名称")
    @Column(name="en_name")
    @ApiModelProperty(value = "分类英文名称")
    private String enName;

    @Excel(name = "分类日文名称")
    @Column(name="ja_name")
    @ApiModelProperty(value = "分类日文名称")
    private String jaName;

    @Excel(name = "分类韩文名称")
    @Column(name="ko_name")
    @ApiModelProperty(value = "分类韩文名称")
    private String koName;

    /** 父id */
    @Excel(name = "父id")
    @Column(name="parent_id")
    @ApiModelProperty(value = "父id")
    private Long parentId;

    /** 删除标识（0：正常1：删除） */
    @Column(name="del_flag")
    @ApiModelProperty(value = "父id")
    private String delFlag;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "父id")
    private String createBy;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "父id")
    private Date createTime;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "父id")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "父id")
    private Date updateTime;

    /** 是否显示(0:显示1:隐藏) */
    @Excel(name = "是否显示(0:显示1:隐藏)")
    @Column(name="visible")
    @ApiModelProperty(value = "是否显示(0:显示1:隐藏)")
    private String visible;

    @Excel(name = "博览会id")
    @Column(name="exposition_id")
    @ApiModelProperty(value = "博览会id")
    private Long expositionId;
    /**
     * 子集合
     */
    @ApiModelProperty(value = "子分类集合")
    @Transient
    private List<CmsClassification> children = new ArrayList<>();
}
