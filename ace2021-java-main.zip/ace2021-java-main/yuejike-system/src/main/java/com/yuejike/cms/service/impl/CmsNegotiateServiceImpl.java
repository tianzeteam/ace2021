package com.yuejike.cms.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.yuejike.cms.dao.CmsNegotiateDaoCustom;
import com.yuejike.cms.dao.CmsProductDao;
import com.yuejike.cms.domain.CmsProduct;
import com.yuejike.cms.service.ICmsProductService;
import com.yuejike.common.utils.DateUtils;

import java.util.Date;
import org.apache.commons.lang3.StringUtils;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yuejike.cms.dao.CmsNegotiateDao;
import com.yuejike.cms.domain.CmsNegotiate;
import com.yuejike.cms.service.ICmsNegotiateService;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/**
 * 洽谈沟通Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsNegotiateServiceImpl implements ICmsNegotiateService {

    @Autowired
    private CmsNegotiateDao cmsNegotiateDao;
    @Autowired
    private CmsNegotiateDaoCustom cmsNegotiateDaoCustom;
    @Autowired
    private ICmsProductService cmsProductService;

    /**
     * 查询洽谈沟通
     *
     * @param negotiateId 洽谈沟通ID
     * @return 洽谈沟通
     */
    @Override
    public CmsNegotiate findById(Long negotiateId) {
        return cmsNegotiateDao.findById(negotiateId).get();
    }

    /**
     * 分页查询洽谈沟通列表
     *
     * @param req 洽谈沟通
     * @return 洽谈沟通
     */
    @Override
    public Page<CmsNegotiate> findCmsNegotiatePage(CmsNegotiate req) {
//        Specification<CmsNegotiate> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
      //  Page<CmsNegotiate> page = cmsNegotiateDao.findAll(example, pageable);
        Page<CmsNegotiate> page = cmsNegotiateDaoCustom.findNegotiatePage(req,pageable);
        page.getContent().forEach(cmsNegotiate -> {
            CmsProduct product = cmsProductService.findById(cmsNegotiate.getProductId());
            cmsNegotiate.setProduct(product);
        });
        return page;
    }

    /**
     * 分页查询洽谈沟通列表
     *
     * @param req 洽谈沟通
     * @return 洽谈沟通
     */
    @Override
    public List<CmsNegotiate> findCmsNegotiateList(CmsNegotiate req) {
        Specification<CmsNegotiate> example = formatQueryParams(req);
        List<CmsNegotiate> list = cmsNegotiateDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    private Specification<CmsNegotiate> formatQueryParams(CmsNegotiate req){
        Specification<CmsNegotiate> example = new Specification<CmsNegotiate>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsNegotiate> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getNegotiateId()){
                    Predicate pre = cb.equal(root.get("negotiateId").as(Long.class), req.getNegotiateId());
                    list.add(pre);
                }
                if (null != req.getProductId()){
                    Predicate pre = cb.equal(root.get("productId").as(Long.class), req.getProductId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getContacts())){
                    Predicate pre = cb.equal(root.get("contacts").as(String.class), req.getContacts());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getPhone())){
                    Predicate pre = cb.equal(root.get("phone").as(String.class), req.getPhone());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getRemark())){
                    Predicate pre = cb.equal(root.get("remark").as(String.class), req.getRemark());
                    list.add(pre);
                }
                if (null != req.getSendId()){
                    Predicate pre = cb.equal(root.get("sendId").as(Long.class), req.getSendId());
                    list.add(pre);
                }
                if (null != req.getAcceptId()){
                    Predicate pre = cb.equal(root.get("acceptId").as(Long.class), req.getAcceptId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getStatus())){
                    Predicate pre = cb.equal(root.get("status").as(String.class), req.getStatus());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())){
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）洽谈沟通
     *
     * @param cmsNegotiate 洽谈沟通
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public CmsNegotiate save(CmsNegotiate cmsNegotiate) {
        // cmsNegotiate.setCreateTime(DateUtils.getNowDate());
        CmsNegotiate negotiate = cmsNegotiateDao.save(cmsNegotiate);
        return negotiate;
    }


    /**
     * 批量删除洽谈沟通
     *
     * @param negotiateIds 需要删除的洽谈沟通ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> negotiateIds) {
        List<CmsNegotiate> existBeans = cmsNegotiateDao.findAllById(negotiateIds);
        if(!existBeans.isEmpty()){
            cmsNegotiateDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除洽谈沟通信息
     *
     * @param negotiateId 洽谈沟通ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsNegotiateById(Long negotiateId) {
         cmsNegotiateDao.deleteById(negotiateId);
    }
}
