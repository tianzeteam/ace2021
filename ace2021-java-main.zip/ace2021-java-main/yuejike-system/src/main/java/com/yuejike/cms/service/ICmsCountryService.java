package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsCountry;

/**
 * 国家字典Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-26
 */
public interface ICmsCountryService  {
    /**
     * 查询国家字典
     *
     * @param countryId 国家字典ID
     * @return 国家字典
     */
    CmsCountry findById(Long countryId);

    /**
     * 分页查询国家字典列表
     *
     * @param req 国家字典
     * @return 国家字典集合
     */
    Page<CmsCountry> findCmsCountryPage(CmsCountry req);

    /**
     * 查询国家字典列表
     *
     * @param req 国家字典
     * @return 国家字典集合
     */
    List<CmsCountry> findCmsCountryList(CmsCountry req);

    /**
     * 新增国家字典
     *
     * @param cmsCountry 国家字典
     * @return 结果
     */
    void save(CmsCountry cmsCountry);

    /**
     * 批量删除国家字典
     *
     * @param countryIds 需要删除的国家字典ID
     * @return 结果
     */
    void deleteByIds(List<Long> countryIds);

    /**
     * 删除国家字典信息
     *
     * @param countryId 国家字典ID
     * @return 结果
     */
    void deleteCmsCountryById(Long countryId);
}
