package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.SysUserGroup;

/**
 * 标签分组Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ISysUserGroupService  {
    /**
     * 查询标签分组
     *
     * @param groupId 标签分组ID
     * @return 标签分组
     */
    SysUserGroup findById(Long groupId);
    /**
     * 分页查询标签分组列表
     *
     * @param req 标签分组
     * @return 标签分组集合
     */
    Page<SysUserGroup> findSysUserGroupPage(SysUserGroup req);

    /**
     * 查询标签分组列表
     *
     * @param req 标签分组
     * @return 标签分组集合
     */
    List<SysUserGroup> findSysUserGroupList(SysUserGroup req);

    /**
     * 新增标签分组
     *
     * @param sysUserGroup 标签分组
     * @return 结果
     */
    void save(SysUserGroup sysUserGroup);

    /**
     * 批量删除标签分组
     *
     * @param groupIds 需要删除的标签分组ID
     * @return 结果
     */
    void deleteByIds(List<Long> groupIds);

    /**
     * 删除标签分组信息
     *
     * @param groupId 标签分组ID
     * @return 结果
     */
    void deleteSysUserGroupById(Long groupId);

    List<SysUserGroup> findByGroupIdIn(List<Long> groupIds);

    SysUserGroup findByName(String name);
}
