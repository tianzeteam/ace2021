package com.yuejike.cms.domain;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.v3d.constant.TypeConstant;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * 参展商信息对象 sys_user_exhibitor
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "sys_user_exhibitor")
@Data
public class SysUserExhibitor extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**
     * id
     */
    @Id
    @Column(name = "user_id")
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "展商ID")
    private Long userId;

    @ApiModelProperty(value = "参展商id列表")
    @Transient
    private List<Long> userIds;

    /**
     * 参展商中文名称
     */
    @Excel(name = "参展商中文名称")
    @Column(name = "name")
    @ApiModelProperty(value = "参展商中文名称")
    private String name;
    
    @ApiModelProperty(value = "历史总浏览量")
	@Column(name="v3d_history_views")
	private Integer historyViews;
    
    @ApiModelProperty(value = "展商状态")
    @Column(name="v3d_status")
	private String status = TypeConstant.NOTDECORATE;


    @ApiModelProperty(value = "v3d排序")
    @Column(name="v3d_sort")
    private Integer vSort;
    /**
     * 参展商英文名称
     */
    @Excel(name = "参展商英文名称")
    @Column(name = "en_name")
    @ApiModelProperty(value = "参展商中参展商英文名称文名称")
    private String enName;

    @Excel(name = "参展商日文名称")
    @Column(name="ja_name")
    @ApiModelProperty(value = "参展商日文名称")
    private String jaName;

    @Excel(name = "参展商韩文名称")
    @Column(name="ko_name")
    @ApiModelProperty(value = "参展商韩文名称")
    private String koName;

    /**
     * 2022年2月新增简称
     */
    @Excel(name = "参展商简称")
    @Column(name="short_name")
    @ApiModelProperty(value = "参展商简称")
    private String shortName;

    @Excel(name = "参展商英文简称")
    @Column(name="en_short_name")
    @ApiModelProperty(value = "参展商英文简称")
    private String enShortName;

    @Excel(name = "参展商日文简称")
    @Column(name="ja_short_name")
    @ApiModelProperty(value = "参展商日文简称")
    private String jaShortName;

    @Excel(name = "参展商韩文简称")
    @Column(name="ko_short_name")
    @ApiModelProperty(value = "参展商韩文简称")
    private String koShortName;

    /**
     * 联系人
     */
    @Excel(name = "联系人")
    @Column(name = "contacts")
    @ApiModelProperty(value = "联系人")
    private String contacts;

    /**
     * 联系人部门/岗位
     */
    @Excel(name = "联系人部门/岗位")
    @Column(name = "contacts_dept")
    @ApiModelProperty(value = "联系人部门/岗位")
    private String contactsDept;

    /**
     * 电话
     */
    @Excel(name = "电话")
    @Column(name = "phone")
    @ApiModelProperty(value = "电话")
    private String phone;

    /**
     * 参展商logo
     */
    @Excel(name = "参展商logo")
    @Column(name = "logo")
    @ApiModelProperty(value = "参展商logo")
    private String logo;

    /**
     * 营业执照
     */
    @Excel(name = "营业执照")
    @Column(name = "license_url")
    @ApiModelProperty(value = "营业执照")
    private String licenseUrl;

    /**
     * 邮箱
     */
    @Excel(name = "邮箱")
    @Column(name = "email")
    @ApiModelProperty(value = "邮箱")
    private String email;

    /**
     * 公司简介_中文
     */
    @Excel(name = "公司简介_中文")
    @Column(name = "cn_profile")
    @ApiModelProperty(value = "公司简介_中文")
    private String cnProfile;

    /**
     * 公司简介_中文
     */
    @Excel(name = "公司简介_中文")
    @Column(name = "en_profile")
    @ApiModelProperty(value = "公司简介_中文")
    private String enProfile;

    @Excel(name = "公司简介_日文")
    @Column(name = "ja_profile")
    @ApiModelProperty(value = "公司简介_日文")
    private String jaProfile;

    @Excel(name = "公司简介_韩文")
    @Column(name = "ko_profile")
    @ApiModelProperty(value = "公司简介_韩文")
    private String koProfile;

    /**
     * 创建人
     */
    @Column(name = "create_by")
    @ApiModelProperty(value = "公司简介")
    private String createBy;

    /**
     * 创建时间
     */
    @Column(name = "create_time")
    @ApiModelProperty(value = "公司简介")
    private Date createTime;

    /**
     * 更新人
     */
    @Column(name = "update_by")
    @ApiModelProperty(value = "公司简介")
    private String updateBy;

    /**
     * 更新时间
     */
    @Column(name = "update_time")
    @ApiModelProperty(value = "公司简介")
    private Date updateTime;

    /**
     * 参展商地址
     */
    @Excel(name = "参展商地址")
    @Column(name = "address")
    @ApiModelProperty(value = "参展商地址")
    private String address;

    /**
     * 排序
     */
    @Excel(name = "排序")
    @Column(name = "sort")
    @ApiModelProperty(value = "排序")
    private Integer sort;

    /**
     * 删除标识
     */
    @Column(name = "del_flag")
    @ApiModelProperty(value = "排序")
    private String delFlag;

    /**
     * 是否显示（0：显示1：隐藏）
     */
    @Excel(name = "是否显示", readConverterExp = "0=：显示1：隐藏")
    @Column(name = "visible")
    @ApiModelProperty(value = "是否显示")
    private String visible;

    /**
     * 官网地址
     */
    @Excel(name = "官网地址")
    @Column(name = "website")
    @ApiModelProperty(value = "官网地址")
    private String website;

    /**
     * 企业规模
     */
    @Excel(name = "企业规模")
    @Column(name = "scale")
    @ApiModelProperty(value = "企业规模")
    private String scale;

    /**
     * 注册资金
     */
    @Excel(name = "注册资金")
    @Column(name = "capital")
    @ApiModelProperty(value = "注册资金")
    private BigDecimal capital;
    
//    @ApiModelProperty(value = "展商状态")
//    @Column(name = "v3d_status")
//	private String status = TypeConstant.NOTDECORATE;

    /**
     * 企业分类
     */
    @Excel(name = "企业分类")
    @Column(name = "classification_id")
    @ApiModelProperty(value = "企业分类")
    private Long classificationId;

    /**
     * 主营产品
     */
    @Excel(name = "主营产品")
    @Column(name = "main_products")
    @ApiModelProperty(value = "主营产品")
    private String mainProducts;

    /**
     * 企业属性
     */
    @Excel(name = "企业属性")
    @Column(name = "attribute")
    @ApiModelProperty(value = "企业属性")
    private String attribute;

    /**
     * 参展年数
     */
    @Excel(name = "参展年数")
    @Column(name = "join_years")
    @ApiModelProperty(value = "参展年数")
    private Long joinYears;

    @Excel(name = "参展年份")
    @Column(name = "join_years_arr")
    @ApiModelProperty(value = "参展年份，例如：2022,2023,2025")
    private String joinYearsArr;

    /**
     * 场馆id
     */
    @Excel(name = "场馆id")
    @Column(name = "hall_id")
    @ApiModelProperty(value = "场馆id")
    private Long hallId;

    /**
     * 参展商所在国家
     */
    @Excel(name = "参展商所在国家")
    @Column(name = "country_id")
    @ApiModelProperty(value = "参展商所在国家")
    private Long countryId;

    /**
     * 参展商所在省份
     */
    @Excel(name = "参展商所在省份")
    @Column(name = "province")
    @ApiModelProperty(value = "参展商所在省份")
    private String province;

    @Column(name = "province_id")
    @ApiModelProperty(value = "参展商所在省份ID")
    private Long provinceId;

    /**
     * 参展商所在城市
     */
    @Excel(name = "参展商所在城市")
    @Column(name = "city")
    @ApiModelProperty(value = "参展商所在城市")
    private String city;

    @Column(name = "city_id")
    @ApiModelProperty(value = "参展商所在城市ID")
    private Long cityId;

    /**
     * 企业视频
     */
    @Excel(name = "企业视频")
    @Column(name = "video_url")
    @ApiModelProperty(value = "企业视频")
    private String videoUrl;


    /**
     * 展商精彩视频地址
     */
    @Excel(name = "展商精彩视频地址")
    @Column(name = "excellent_video_url")
    @ApiModelProperty(value = "展商精彩视频地址")
    private String excellentVideoUrl;

    /**
     * 展商精彩审核人id
     */
    @Excel(name = "展商精彩审核人id")
    @Column(name = "excellect_video_reviewer_id")
    @ApiModelProperty(value = "展商精彩审核人id")
    private Long excellectVideoReviewerId;

    /**
     * 展商精彩视频审核状态(0:待审核1：已通过2：已拒绝)
     */
    @Excel(name = "展商精彩视频审核状态(0:待审核1：已通过2：已拒绝)")
    @Column(name = "excellent_video_status")
    @ApiModelProperty(value = "展商精彩视频审核状态(0:待审核1：已通过2：已拒绝)")
    private String excellentVideoStatus;

    /**
     * 展商精彩审核拒绝原因
     */
    @Excel(name = "展商精彩审核拒绝原因")
    @Column(name = "excellent_video_reject_reason")
    @ApiModelProperty(value = "展商精彩审核拒绝原因")
    private String excellentVideoRejectReason;

    /**
     * 展商精彩视频封面
     */
    @Excel(name = "展商精彩视频封面")
    @Column(name = "excellent_video_cover")
    @ApiModelProperty(value = "展商精彩视频封面")
    private String excellentVideoCover;

    /**
     * 展商精彩视频名称
     */
    @Excel(name = "展商精彩视频名称")
    @Column(name = "excellent_video_name")
    @ApiModelProperty(value = "展商精彩视频名称")
    private String excellentVideoName;

    /**
     * 展商精彩视频分类
     */
    @Excel(name = "展商精彩视频分类")
    @Column(name = "excellent_video_classification_id")
    @ApiModelProperty(value = "展商精彩视频分类")
    private Long excellentVideoClassificationId;

    /**
     * 展商精彩视频审核时间
     */
    @Excel(name = "展商精彩视频审核时间")
    @Column(name = "excellent_video_review_time")
    @ApiModelProperty(value = "展商精彩视频审核时间")
    private Date excellentVideoReviewTime;

    /**
     * 展商标签id
     */
    @Excel(name = "展商标签id")
    @Column(name = "label_id")
    @ApiModelProperty(value = "展商标签id")
    private String labelId;

    /**
     * 社会统一代码
     */
    @Excel(name = "社会统一代码")
    @Column(name = "social_code")
    @ApiModelProperty(value = "社会统一代码")
    private String socialCode;

    /**
     * 展会编号
     */
    @Excel(name = "展会编号")
    @Column(name = "exhibition_number")
    @ApiModelProperty(value = "展会编号")
    private String exhibitionNumber;

    /**
     * 图集
     */
    @Excel(name = "图集")
    @Column(name = "img_url")
    @ApiModelProperty(value = "图集")
    private String imgUrl;

    /**
     * banner
     */
    @Excel(name = "banner")
    @Column(name = "banner_url")
    @ApiModelProperty(value = "banner：多张用逗号分隔")
    private String bannerUrl;

    @Excel(name = "目标市场(所属地区)")
    @Column(name = "target_market")
    @ApiModelProperty(value = "目标市场(所属地区)")
    private String targetMarket;
    
    
    @ApiModelProperty(value = "首字母")
	private String initials;

    @OneToOne
    @JoinColumn(name = "user_id", insertable = false, updatable = false)
    private SysUser user;

    @OneToOne
    @JoinColumn(name = "classification_id", insertable = false, updatable = false)
    private CmsClassification classification;

    @OneToOne
    @JoinColumn(name = "excellent_video_classification_id", insertable = false, updatable = false)
    private CmsClassification excellentClassification;

    @Transient
    private String reviewStatus;

    // 国家
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "country_id", referencedColumnName = "country_id", insertable = false, updatable = false, foreignKey = @ForeignKey(name = "none", value = ConstraintMode.NO_CONSTRAINT))
    private CmsCountry country;

    /**
     * 展商标签列表
     */
    @Transient
    private List<CmsLabel> LabelList;


    /**
     * 展品列表
     */
    @Transient
    private List<CmsProduct> productList;

    // 展商分类
    @Transient
    private List<Long> classificationIds;

    // 展商精彩分类
    @Transient
    private List<Long> excellentVideoClassificationIds;

    //是否查询精彩视频（0：否1：是）
    @Transient
    private String isExcellentVideo;

   @Column(name = "basicinfo_review_status")
   @ApiModelProperty(value = "基本信息审核状态")
   private String basicinfoReviewStatus;

   @Column(name = "update_obj")
   @ApiModelProperty(value = "修改的对象信息")
   private String updateObj;

   @Column(name = "basicinfo_review_id")
   @ApiModelProperty(value = "审核人id")
   private Long basicinfoReviewId;

   @Column(name = "basicinfo_review_time")
   @ApiModelProperty(value = "审核时间")
   private Date basicinfoReviewTime;

   @Column(name = "basicinfo_review_reject_reason")
   @ApiModelProperty(value = "审核拒绝原因")
   private String basicinfoReviewRejectReason;

    //是否收藏
    @Transient
    private CmsFavorites favorites;

    @ApiModelProperty(value = "访问量")
    @Column(name="pv")
    private Integer pv;

    @Column(name = "online_only")
    @ApiModelProperty(value = "仅线上：0-全部，1-仅线上")
    private String onlineOnly;

    @Transient
    private String signUpStatus;

    @Column(name = "recommend")
    @ApiModelProperty(value = "是否推荐：0-未推荐，1-推荐")
    private String recommend;

    @Column(name = "hot_ranking")
    private Long hotRanking;

    @Column(name = "sales_ranking")
    private Long salesRanking;

    @Column(name = "interesting_ranking")
    private Long interestingRanking;

    @Column(name = "trust_ranking")
    private Long trustRanking;

    /** 商品数量 **/
    @Transient
    @ApiModelProperty(value = "商品数量")
    private Integer productCount;

    /** 3d私有链接 **/
    @ApiModelProperty(value = "3d私有链接")
    @Column(name="v3d_private_link")
    private String v3dPrivateLink;

    // 关联行业
    @OneToMany(mappedBy = "exhibitor", cascade = CascadeType.ALL, orphanRemoval=true, fetch = FetchType.EAGER)
    @JsonManagedReference
    private List<SysUserExhibitorIndustry> industries = new ArrayList<>();

    // 行业数据转换
    @Transient
    private List<Object> industriesData;
    public List<Object> getIndustriesData() {
        List<Object> rootArr = new ArrayList<>();
        for (SysUserExhibitorIndustry sysUserExhibitorIndustry: this.industries) {
            rootArr.add(sysUserExhibitorIndustry.getIndustryData());
        }
        return rootArr;
    }

}

