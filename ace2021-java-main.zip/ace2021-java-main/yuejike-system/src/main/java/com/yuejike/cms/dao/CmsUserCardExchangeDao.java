package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsUserCardExchange;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * 名片关联Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Repository
public interface CmsUserCardExchangeDao extends JpaRepository<CmsUserCardExchange, Long>, JpaSpecificationExecutor<CmsUserCardExchange> {

    @Query(value = "SELECT COUNT(*) FROM cms_user_card_exchange WHERE accept_id =?1  AND send_id=?2",nativeQuery = true)
    int findCardExchange(Long accept, Long sendId);

    @Transactional
    @Modifying
    @Query(value = "update cms_user_card_exchange set accept_del_flag='1' where id =?1",nativeQuery = true)
    int updateAcceptById(Long id);

    @Transactional
    @Modifying
    @Query(value = "update cms_user_card_exchange set send_del_flag=?1 where id =?2",nativeQuery = true)
    int updateSendById(String status,Long id);


    @Query(value = "SELECT COUNT(*) FROM cms_user_card_exchange WHERE accept_id =?1  AND send_id=?2 AND accept_del_flag !='0' or send_del_flag !='0'",nativeQuery = true)
    int findCardExchangeByStatus(Long accept, Long sendId);

    @Transactional
    @Modifying
    @Query(value = "update cms_user_card_exchange set send_del_flag='0',accept_del_flag ='0' WHERE accept_id =?1  AND send_id=?2",nativeQuery = true)
    void updateByStatus(Long accept, Long sendId);

}
