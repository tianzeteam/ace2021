package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsEnroll;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


/**
 * 会议报名Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Repository
public interface CmsEnrollDao extends JpaRepository<CmsEnroll, Long>, JpaSpecificationExecutor<CmsEnroll> {

    // 根据liveId查询已报名人
    @Query(value = "select * from cms_enroll where live_id=?1 and (status='1' or status='0')",nativeQuery = true)
    List<CmsEnroll> findByLiveId(Long liveId);

    @Query(value = "select * from cms_enroll where live_id=?1 and user_id=?2",nativeQuery = true)
    CmsEnroll findByLiveIdAndUserId(Long liveId,Long userId);

    @Transactional
    @Modifying
    @Query(value = "update cms_enroll set del_flag='1' where conference_id=?1",nativeQuery = true)
    int updateByConferenceId(Long conferenceId);

    @Transactional
    @Modifying
    @Query(value = "update cms_enroll set del_flag='1' where live_id=?1",nativeQuery = true)
    int updateByLiveId(Long liveId);
}
