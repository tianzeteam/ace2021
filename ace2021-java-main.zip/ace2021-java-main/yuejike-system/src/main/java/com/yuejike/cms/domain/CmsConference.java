package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 线下会议对象 cms_conference
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_conference")
@Data
public class CmsConference extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="conference_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long conferenceId;

    /** 标题 */
    @Excel(name = "标题")
    @Column(name="title")
    @ApiModelProperty(value = "标题")
    private String title;

    /** 会议内容 */
    @Excel(name = "会议内容")
    @Column(name="content")
    @ApiModelProperty(value = "会议内容")
    private String content;

    /** 来源 */
    @Excel(name = "来源")
    @Column(name="source")
    @ApiModelProperty(value = "来源")
    private String source;

    /** 封面图 */
    @Excel(name = "封面图")
    @Column(name="img_url")
    @ApiModelProperty(value = "封面图")
    private String imgUrl;

    /** 会议开始时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @Excel(name = "会议开始时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    @Column(name="start_time")
    @ApiModelProperty(value = "会议开始时间")
    private Date startTime;

    /** 会议结束时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @Excel(name = "会议结束时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    @Column(name="end_time")
    @ApiModelProperty(value = "会议结束时间")
    private Date endTime;

    /** 发布时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @Excel(name = "发布时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    @Column(name="push_time")
    @ApiModelProperty(value = "发布时间")
    private Date pushTime;

    /** 举办单位 */
    @Excel(name = "举办单位")
    @Column(name="organizer")
    @ApiModelProperty(value = "举办单位")
    private String organizer;

    /** 举办地址 */
    @Excel(name = "举办地址")
    @Column(name="host_address")
    @ApiModelProperty(value = "举办地址")
    private String hostAddress;

    /** 类型(0:主办方会议1:参展商会议) */
    @Excel(name = "类型(0:主办方会议1:参展商会议)")
    @Column(name="type")
    @ApiModelProperty(value = "类型(0:主办方会议1:参展商会议)")
    private String type;

    /** 审核状态(0:待审核1:已通过2:已拒绝) */
    @Excel(name = "审核状态(0:待审核1:已通过2:已拒绝)")
    @Column(name="status")
    @ApiModelProperty(value = "审核状态(0:待审核1:已通过2:已拒绝)")
    private String status;

    /** 删除标识(0:正常1:删除) */
    @Column(name="del_flag")
    @ApiModelProperty(value = "审核状态(0:待审核1:已通过2:已拒绝)")
    private String delFlag;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "审核状态(0:待审核1:已通过2:已拒绝)")
    private String createBy;

    /** 创建时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    @Column(name="create_time")
    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    /** 更新时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    @Column(name="update_time")
    @ApiModelProperty(value = "创建时间")
    private Date updateTime;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "创建时间")
    private String updateBy;

    /** 审核人id */
    @Excel(name = "审核人id")
    @Column(name="reviewer_id")
    @ApiModelProperty(value = "审核人id")
    private Long reviewerId;

    /** 拒绝原因 */
    @Excel(name = "拒绝原因")
    @Column(name="reject_reason")
    @ApiModelProperty(value = "拒绝原因")
    private String rejectReason;

    @Excel(name = "博览会id")
    @Column(name="exposition_id")
    @ApiModelProperty(value = "博览会id")
    private Long expositionId;

    @Excel(name = "最大报名人数")
    @Column(name="max_number")
    @ApiModelProperty(value = "最大报名人数")
    private Integer maxNumber;

    @Excel(name = "审核人名字")
    @Column(name="reviewer_name")
    @ApiModelProperty(value = "审核人名字")
    private String reviewerName;

    @Excel(name = "创建人id")
    @Column(name="create_id")
    @ApiModelProperty(value = "创建人id")
    private Long createId;

    @Excel(name = "展商英文名字")
    @Column(name="exhibitor_en_name")
    @ApiModelProperty(value = "展商英文名字")
    private String exhibitorEnName;

    @Excel(name = "展商中文名字")
    @Column(name="exhibitor_cn_name")
    @ApiModelProperty(value = "展商中文名字")
    private String exhibitorCnName;

    @Excel(name = "展商id")
    @Column(name="exhibitor_id")
    @ApiModelProperty(value = "展商id")
    private Long exhibitorId;

    /** 展商部门id */
    @Excel(name = "展商部门id")
    @Column(name="dept_id")
    @ApiModelProperty(value = "展商部门id")
    private Long deptId;
}
