package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsLiveUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;


/**
 * 直播角色权限关联Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Repository
public interface CmsLiveUserDao extends JpaRepository<CmsLiveUser, Long>, JpaSpecificationExecutor<CmsLiveUser> {



}
