package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import com.yuejike.common.core.domain.entity.SysUser;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 媒体对象 sys_user_media
 *
 * @author tangdw
 * @since 1.0 2021-08-27
 */
@Entity
@Table(name = "sys_user_media")
@Data
public class SysUserMedia extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** 用户id */
    @Id
    @Column(name="user_id")
    @ApiModelProperty(value = "媒体ID")
    private Long userId;

    /** 删除标识 */
    @Column(name="del_flag")
    @ApiModelProperty(value = "删除标识")
    private String delFlag;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "创建人")
    private String createBy;

    /** 创建时间 */
    @Excel(name = "提交时间")
    @Column(name="create_time")
    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @Excel(name = "用户名称")
    @Transient
    private String userName;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "修改人")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "修改时间")
    private Date updateTime;

    /** 公司名称 */
    @Excel(name = "公司名称")
    @Column(name="company_name")
    @ApiModelProperty(value = "公司名称")
    private String companyName;

    /** 记者所属国家 */
//    @Excel(name = "记者所属国家")
    @Column(name="user_country_id")
    @ApiModelProperty(value = "记者所属国家")
    private Long userCountryId;

    @Excel(name = "记者所属国家")
    @Transient
    private String userCountryName;

    @Excel(name = "媒体所属国家")
    @Transient
    private String companyCountryName;

    /** 证件类型 */
    @Excel(name = "证件类型")
    @Column(name="credentials_type")
    @ApiModelProperty(value = "证件类型")
    private String credentialsType;

    /** 证件号码 */
    @Excel(name = "证件号码")
    @Column(name="credentials_number")
    @ApiModelProperty(value = "证件号码")
    private String credentialsNumber;

    /** 身份证扫描图片 */
//    @Excel(name = "身份证扫描图片")
    @Column(name="id_card_picture")
    @ApiModelProperty(value = "身份证扫描图片")
    private String idCardPicture;

    /** 媒体所属国家 */
//    @Excel(name = "媒体所属国家")
    @Column(name="company_country_id")
    @ApiModelProperty(value = "媒体所属国家")
    private Long companyCountryId;

    /** 中文名 */
    @Excel(name = "中文名")
    @Column(name="chinese_name")
    @ApiModelProperty(value = "中文名")
    private String chineseName;

    /** 中文姓 */
    @Excel(name = "中文姓")
    @Column(name="chinese_surname")
    @ApiModelProperty(value = "中文姓")
    private String chineseSurname;

    /** 拼音名 */
    @Excel(name = "拼音名")
    @Column(name="pinyin_name")
    @ApiModelProperty(value = "拼音名")
    private String pinyinName;

    /** 拼音姓 */
    @Excel(name = "拼音姓")
    @Column(name="pinyin_surname")
    @ApiModelProperty(value = "拼音姓")
    private String pinyinSurname;

    /** 英文名 */
    @Excel(name = "英文名")
    @Column(name="english_name")
    @ApiModelProperty(value = "英文名")
    private String englishName;

    /** 英文姓 */
    @Excel(name = "英文姓")
    @Column(name="english_surname")
    @ApiModelProperty(value = "英文姓")
    private String englishSurname;

    /** 英文中间名 */
    @Excel(name = "英文中间名")
    @Column(name="english_center_name")
    @ApiModelProperty(value = "英文中间名")
    private String englishCenterName;

    /** 性别(0:男1:女) */
    @Excel(name = "性别")
    @Column(name="sex")
    @ApiModelProperty(value = "性别(0:男1:女)")
    private String sex;

    /** 生日 */
    @JsonFormat(pattern = "yyyy-MM-dd",timezone = "GMT+8")
    @Excel(name = "生日", width = 30, dateFormat = "yyyy-MM-dd")
    @Column(name="borth")
    @ApiModelProperty(value = "生日")
    private Date borth;

    /** 记者类型(0:文字1:摄影2:电视3:广播4:其他) */
    @Excel(name = "记者类型")
    @Column(name="reporter_type")
    @ApiModelProperty(value = "记者类型(0:文字1:摄影2:电视3:广播4:其他)")
    private String reporterType;

    /** 手机号 */
    @Excel(name = "手机号")
    @Column(name="phone_number")
    @ApiModelProperty(value = "手机号")
    private String phoneNumber;

    /** 邮箱 */
    @Excel(name = "邮箱")
    @Column(name="email")
    @ApiModelProperty(value = "邮箱")
    private String email;

    /** 媒体执照图片 */
//    @Excel(name = "媒体执照图片")
    @Column(name="company_license_picture")
    @ApiModelProperty(value = "媒体执照图片")
    private String companyLicensePicture;

    /** 记者证图片 */
//    @Excel(name = "记者证图片")
    @Column(name="press_card_picture")
    @ApiModelProperty(value = "记者证图片")
    private String pressCardPicture;

    @OneToOne
    @JoinColumn(name = "user_id",insertable = false,updatable = false)
    private SysUser user;

    @Excel(name = "审核状态")
    @Transient
    private String reviewStatus;

    // 国家
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "company_country_id",referencedColumnName = "country_id",insertable = false,updatable = false)
    private CmsCountry companyCountry;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_country_id",referencedColumnName = "country_id",insertable = false,updatable = false)
    private CmsCountry userCountry;

}
