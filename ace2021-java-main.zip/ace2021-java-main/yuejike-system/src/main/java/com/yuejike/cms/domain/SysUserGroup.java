package com.yuejike.cms.domain;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 标签分组对象 sys_user_group
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "sys_user_group")
@Data
public class SysUserGroup extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="group_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long groupId;

    /** 分组名称 */
    @Excel(name = "分组名称")
    @Column(name="name")
    @ApiModelProperty(value = "分组名称")
    private String name;

    /** 删除标识（0：正常 1：删除） */
    @Column(name="del_flag")
    @ApiModelProperty(value = "分组名称")
    private String delFlag;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "分组名称")
    private Date createTime;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "分组名称")
    private Date updateTime;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "分组名称")
    private String createBy;

    /** 创建人id */
    @Column(name="create_id")
    @ApiModelProperty(value = "创建人id")
    private Long createId;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "分组名称")
    private String updateBy;

    @Transient
    private List<Long> userIds;

    @Transient
    private List<Long> groupIds;
}
