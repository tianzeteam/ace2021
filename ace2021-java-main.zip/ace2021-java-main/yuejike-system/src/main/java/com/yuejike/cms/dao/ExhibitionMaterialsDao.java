package com.yuejike.cms.dao;

import com.yuejike.cms.domain.ExhibitionMaterials;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * @author JinZJ
 * @version 1.0
 * @Description:
 * @date 2021/11/17 11:29
 */
@Repository
public interface ExhibitionMaterialsDao extends JpaRepository<ExhibitionMaterials, Long>, JpaSpecificationExecutor<ExhibitionMaterials> {

}
