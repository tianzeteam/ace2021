package com.yuejike.cms.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.yuejike.common.utils.DateUtils;

import java.util.Date;
import org.apache.commons.lang3.StringUtils;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yuejike.cms.dao.CmsCountryDao;
import com.yuejike.cms.domain.CmsCountry;
import com.yuejike.cms.service.ICmsCountryService;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/**
 * 国家字典Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-26
 */
@Transactional(readOnly = true)
@Service
public class CmsCountryServiceImpl implements ICmsCountryService {

    @Autowired
    private CmsCountryDao cmsCountryDao;

    /**
     * 查询国家字典
     *
     * @param countryId 国家字典ID
     * @return 国家字典
     */
    @Override
    public CmsCountry findById(Long countryId) {
        return cmsCountryDao.findById(countryId).get();
    }

    /**
     * 分页查询国家字典列表
     *
     * @param req 国家字典
     * @return 国家字典
     */
    @Override
    public Page<CmsCountry> findCmsCountryPage(CmsCountry req) {
        Specification<CmsCountry> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsCountry> page = cmsCountryDao.findAll(example, pageable);
        return page;
    }

    /**
     * 分页查询国家字典列表
     *
     * @param req 国家字典
     * @return 国家字典
     */
    @Override
    public List<CmsCountry> findCmsCountryList(CmsCountry req) {
        Specification<CmsCountry> example = formatQueryParams(req);
        List<CmsCountry> list = cmsCountryDao.findAll(example, Sort.by(Sort.Direction.ASC,"countryId"));
        return list;
    }

    private Specification<CmsCountry> formatQueryParams(CmsCountry req){
        Specification<CmsCountry> example = new Specification<CmsCountry>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsCountry> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getCountryId()){
                    Predicate pre = cb.equal(root.get("countryId").as(Long.class), req.getCountryId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCountryName())){
                    Predicate pre = cb.like(root.get("countryName").as(String.class), "%" + req.getCountryName()+ "%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())){
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）国家字典
     *
     * @param cmsCountry 国家字典
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void save(CmsCountry cmsCountry) {
        cmsCountry.setCreateTime(DateUtils.getNowDate());
        cmsCountryDao.save(cmsCountry);
    }


    /**
     * 批量删除国家字典
     *
     * @param countryIds 需要删除的国家字典ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> countryIds) {
        List<CmsCountry> existBeans = cmsCountryDao.findAllById(countryIds);
        if(!existBeans.isEmpty()){
            cmsCountryDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除国家字典信息
     *
     * @param countryId 国家字典ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsCountryById(Long countryId) {
         cmsCountryDao.deleteById(countryId);
    }
}
