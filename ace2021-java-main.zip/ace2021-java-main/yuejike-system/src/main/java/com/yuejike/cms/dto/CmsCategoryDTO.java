package com.yuejike.cms.dto;

import com.yuejike.cms.domain.CmsCategory;
import com.yuejike.common.core.domain.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Transient;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

@Data
public class CmsCategoryDTO extends BaseEntity {

    /** id */
    @ApiModelProperty(value = "${comment}")
    private BigInteger categoryId;

    /** 栏目中文名 */
    @ApiModelProperty(value = "栏目中文名")
    private String cnName;

    /** 栏目英文名 */
    @ApiModelProperty(value = "栏目英文名")
    private String enName;

    @ApiModelProperty(value = "栏目日文名")
    private String jaName;

    @ApiModelProperty(value = "栏目韩文名")
    private String koName;

    /** 缩略图 */
    @ApiModelProperty(value = "缩略图")
    private String imgUrl;

    /** 描述 */
    @ApiModelProperty(value = "描述")
    private String descrip;

    /** 关键字 */
    @ApiModelProperty(value = "关键字")
    private String keyword;

    /** 链接 */
    @ApiModelProperty(value = "链接")
    private String link;

    /** 父id */
    @ApiModelProperty(value = "父id")
    private BigInteger parentId;

    private BigInteger expositionId;

//    /** 创建时间 */
//    @ApiModelProperty(value = "父id")
//    private Date createTime;
//
//    /** 更新时间 */
//    @ApiModelProperty(value = "父id")
//    private Date updateTime;
//
//    /** 创建人 */
//    @ApiModelProperty(value = "父id")
//    private String createBy;
//
//    /** 更新人 */
//    @ApiModelProperty(value = "父id")
//    private String updateBy;

//    /** 删除标识 */
//    @ApiModelProperty(value = "父id")
//    private Character delFlag;

    /** 模型id */
    @ApiModelProperty(value = "模型id")
    private BigInteger modelId;

    /** 排序 */
    @ApiModelProperty(value = "排序")
    private Integer sort;

    /** 是否是外链(0:否1：是) */
    @ApiModelProperty(value = "是否是外链(0:否1：是)")
    private Character isLink;
    //显示状态
    private Character visible;

    @Transient
    @ApiModelProperty(value = "父级栏目名称")
    private String parentName;

    @Transient
    @ApiModelProperty(value = "模型名称")
    private String modelName;
}
