package com.yuejike.cms.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.yuejike.common.utils.DateUtils;

import java.util.Date;
import org.apache.commons.lang3.StringUtils;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yuejike.cms.dao.CmsLiveUserDao;
import com.yuejike.cms.domain.CmsLiveUser;
import com.yuejike.cms.service.ICmsLiveUserService;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/**
 * 直播角色权限关联Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsLiveUserServiceImpl implements ICmsLiveUserService {

    @Autowired
    private CmsLiveUserDao cmsLiveUserDao;

    /**
     * 查询直播角色权限关联
     *
     * @param id 直播角色权限关联ID
     * @return 直播角色权限关联
     */
    @Override
    public CmsLiveUser findById(Long id) {
        return cmsLiveUserDao.findById(id).get();
    }

    /**
     * 分页查询直播角色权限关联列表
     *
     * @param req 直播角色权限关联
     * @return 直播角色权限关联
     */
    @Override
    public Page<CmsLiveUser> findCmsLiveUserPage(CmsLiveUser req) {
        Specification<CmsLiveUser> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsLiveUser> page = cmsLiveUserDao.findAll(example, pageable);
        return page;
    }

    /**
     * 分页查询直播角色权限关联列表
     *
     * @param req 直播角色权限关联
     * @return 直播角色权限关联
     */
    @Override
    public List<CmsLiveUser> findCmsLiveUserList(CmsLiveUser req) {
        Specification<CmsLiveUser> example = formatQueryParams(req);
        List<CmsLiveUser> list = cmsLiveUserDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    private Specification<CmsLiveUser> formatQueryParams(CmsLiveUser req){
        Specification<CmsLiveUser> example = new Specification<CmsLiveUser>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsLiveUser> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getId()){
                    Predicate pre = cb.equal(root.get("id").as(Long.class), req.getId());
                    list.add(pre);
                }
                if (null != req.getLiveId()){
                    Predicate pre = cb.equal(root.get("liveId").as(Long.class), req.getLiveId());
                    list.add(pre);
                }
                if (null != req.getUserId()){
                    Predicate pre = cb.equal(root.get("userId").as(Long.class), req.getUserId());
                    list.add(pre);
                }

                if (StringUtils.isNotBlank(req.getDelFlag())){
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）直播角色权限关联
     *
     * @param cmsLiveUser 直播角色权限关联
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void save(CmsLiveUser cmsLiveUser) {
        cmsLiveUser.setCreateTime(DateUtils.getNowDate());
        cmsLiveUserDao.save(cmsLiveUser);
    }


    /**
     * 批量删除直播角色权限关联
     *
     * @param ids 需要删除的直播角色权限关联ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> ids) {
        List<CmsLiveUser> existBeans = cmsLiveUserDao.findAllById(ids);
        if(!existBeans.isEmpty()){
            cmsLiveUserDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除直播角色权限关联信息
     *
     * @param id 直播角色权限关联ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsLiveUserById(Long id) {
         cmsLiveUserDao.deleteById(id);
    }
}
