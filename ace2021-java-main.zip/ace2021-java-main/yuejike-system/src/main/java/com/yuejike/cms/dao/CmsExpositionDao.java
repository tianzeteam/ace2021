package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsExposition;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;

/**
 * 博览会Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Repository
public interface CmsExpositionDao extends JpaRepository<CmsExposition, Long>, JpaSpecificationExecutor<CmsExposition> {
    @Transactional
    @Modifying
    @Query(value = "update cms_exposition set status ='1'",nativeQuery = true)
    void updateAllStatus();

}
