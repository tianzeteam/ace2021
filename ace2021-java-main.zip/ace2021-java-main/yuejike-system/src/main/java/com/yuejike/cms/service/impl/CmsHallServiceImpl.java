package com.yuejike.cms.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.yuejike.common.utils.DateUtils;

import java.util.Date;

import com.yuejike.common.utils.code.BusinessBizCode;
import org.apache.commons.lang3.StringUtils;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yuejike.cms.dao.CmsHallDao;
import com.yuejike.cms.domain.CmsHall;
import com.yuejike.cms.service.ICmsHallService;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/**
 * 场馆信息Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsHallServiceImpl implements ICmsHallService {

    @Autowired
    private CmsHallDao cmsHallDao;

    /**
     * 查询场馆信息
     *
     * @param hallId 场馆信息ID
     * @return 场馆信息
     */
    @Override
    public CmsHall findById(Long hallId) {
        return cmsHallDao.findById(hallId).get();
    }

    /**
     * 分页查询场馆信息列表
     *
     * @param req 场馆信息
     * @return 场馆信息
     */
    @Override
    public Page<CmsHall> findCmsHallPage(CmsHall req) {
        Specification<CmsHall> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsHall> page = cmsHallDao.findAll(example, pageable);
        return page;
    }

    /**
     * 分页查询场馆信息列表
     *
     * @param req 场馆信息
     * @return 场馆信息
     */
    @Override
    public List<CmsHall> findCmsHallList(CmsHall req) {
        Specification<CmsHall> example = formatQueryParams(req);
        List<CmsHall> list = cmsHallDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    private Specification<CmsHall> formatQueryParams(CmsHall req){
        Specification<CmsHall> example = new Specification<CmsHall>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsHall> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getHallId()){
                    Predicate pre = cb.equal(root.get("hallId").as(Long.class), req.getHallId());
                    list.add(pre);
                }
                if (null != req.getHallIds() && req.getHallIds().size() >0){
                    Predicate pre = root.get("hallId").in(req.getHallIds());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getName())){
                    Predicate pre = cb.like(root.get("name").as(String.class), "%" + req.getName()+ "%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getAddress())){
                    Predicate pre = cb.equal(root.get("address").as(String.class), req.getAddress());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getArea())){
                    Predicate pre = cb.equal(root.get("area").as(String.class), req.getArea());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCity())){
                    Predicate pre = cb.equal(root.get("city").as(String.class), req.getCity());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getIntroduce())){
                    Predicate pre = cb.equal(root.get("introduce").as(String.class), req.getIntroduce());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getHallNo())){
                    Predicate pre = cb.equal(root.get("hallNo").as(String.class), req.getHallNo());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getBoothNo())){
                    Predicate pre = cb.equal(root.get("boothNo").as(String.class), req.getBoothNo());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())){
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getStatus())){
                    Predicate pre = cb.equal(root.get("status").as(String.class), req.getStatus());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getImgUrl())){
                    Predicate pre = cb.equal(root.get("imgUrl").as(String.class), req.getImgUrl());
                    list.add(pre);
                }
                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）场馆信息
     *
     * @param cmsHall 场馆信息
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public CmsHall save(CmsHall cmsHall) {
        // cmsHall.setCreateTime(DateUtils.getNowDate());
        CmsHall hall = cmsHallDao.save(cmsHall);
        return hall;
    }


    /**
     * 批量删除场馆信息
     *
     * @param hallIds 需要删除的场馆信息ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> hallIds) {
        List<CmsHall> existBeans = cmsHallDao.findAllById(hallIds);
        if(!existBeans.isEmpty()){
            cmsHallDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除场馆信息信息
     *
     * @param hallId 场馆信息ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsHallById(Long hallId) {
         cmsHallDao.deleteById(hallId);
    }

    /**
     * 修改场馆状态
     * @param cmsHall
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public int updateHallStatus(CmsHall cmsHall) {
        CmsHall cmsHallLm = cmsHallDao.findById(cmsHall.getHallId()).get();
        cmsHallLm.setStatus(cmsHall.getStatus());
        cmsHallLm.setUpdateBy(cmsHall.getUpdateBy());
        cmsHallLm.setUpdateTime(new Date());
        cmsHallDao.save(cmsHallLm);
        return BusinessBizCode.OPTION_SUCCESS.getCode();
    }
}
