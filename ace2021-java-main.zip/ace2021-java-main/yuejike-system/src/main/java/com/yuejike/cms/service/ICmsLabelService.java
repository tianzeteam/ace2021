package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsLabel;

/**
 * 标签Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsLabelService  {
    /**
     * 查询标签
     *
     * @param labelId 标签ID
     * @return 标签
     */
    CmsLabel findById(Long labelId);

    /**
     * 分页查询标签列表
     *
     * @param req 标签
     * @return 标签集合
     */
    Page<CmsLabel> findCmsLabelPage(CmsLabel req);

    /**
     * 查询标签列表
     *
     * @param req 标签
     * @return 标签集合
     */
    List<CmsLabel> findCmsLabelList(CmsLabel req);

    /**
     * 新增标签
     *
     * @param cmsLabel 标签
     * @return 结果
     */
    void save(CmsLabel cmsLabel);

    /**
     * 批量删除标签
     *
     * @param labelIds 需要删除的标签ID
     * @return 结果
     */
    void deleteByIds(List<Long> labelIds);

    /**
     * 删除标签信息
     *
     * @param labelId 标签ID
     * @return 结果
     */
    void deleteCmsLabelById(Long labelId);
}
