package com.yuejike.cms.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.yuejike.common.utils.DateUtils;

import java.util.Date;
import org.apache.commons.lang3.StringUtils;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yuejike.cms.dao.CmsExpositionDao;
import com.yuejike.cms.domain.CmsExposition;
import com.yuejike.cms.service.ICmsExpositionService;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/**
 * 博览会Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsExpositionServiceImpl implements ICmsExpositionService {

    @Autowired
    private CmsExpositionDao cmsExpositionDao;

    /**
     * 查询博览会
     *
     * @param expositionId 博览会ID
     * @return 博览会
     */
    @Override
    public CmsExposition findById(Long expositionId) {
        return cmsExpositionDao.findById(expositionId).get();
    }

    /**
     * 分页查询博览会列表
     *
     * @param req 博览会
     * @return 博览会
     */
    @Override
    public Page<CmsExposition> findCmsExpositionPage(CmsExposition req) {
        Specification<CmsExposition> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsExposition> page = cmsExpositionDao.findAll(example, pageable);
        return page;
    }

    /**
     * 分页查询博览会列表
     *
     * @param req 博览会
     * @return 博览会
     */
    @Override
    public List<CmsExposition> findCmsExpositionList(CmsExposition req) {
        Specification<CmsExposition> example = formatQueryParams(req);
        List<CmsExposition> list = cmsExpositionDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    private Specification<CmsExposition> formatQueryParams(CmsExposition req){
        Specification<CmsExposition> example = new Specification<CmsExposition>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsExposition> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getExpositionId()){
                    Predicate pre = cb.equal(root.get("expositionId").as(Long.class), req.getExpositionId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getEnName())){
                    Predicate pre = cb.like(root.get("enName").as(String.class), "%" + req.getEnName()+ "%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCnName())){
                    Predicate pre = cb.like(root.get("cnName").as(String.class), "%" + req.getCnName()+ "%");
                    list.add(pre);
                }
                if (null != req.getStartTime()){
                    Predicate pre = cb.equal(root.get("startTime").as(Date.class), req.getStartTime());
                    list.add(pre);
                }
                if (null != req.getEndTime()){
                    Predicate pre = cb.equal(root.get("endTime").as(Date.class), req.getEndTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getType())){
                    Predicate pre = cb.equal(root.get("type").as(String.class), req.getType());
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())){
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getOrganizer())){
                    Predicate pre = cb.equal(root.get("organizer").as(String.class), req.getOrganizer());
                    list.add(pre);
                }
                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）博览会
     *
     * @param cmsExposition 博览会
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void save(CmsExposition cmsExposition) {
        // cmsExposition.setCreateTime(DateUtils.getNowDate());
        cmsExpositionDao.updateAllStatus();
        cmsExposition.setStatus("0");
        cmsExpositionDao.save(cmsExposition);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void update(CmsExposition cmsExposition) {
        cmsExpositionDao.save(cmsExposition);
    }


    /**
     * 批量删除博览会
     *
     * @param expositionIds 需要删除的博览会ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> expositionIds) {
        List<CmsExposition> existBeans = cmsExpositionDao.findAllById(expositionIds);
        if(!existBeans.isEmpty()){
            cmsExpositionDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除博览会信息
     *
     * @param expositionId 博览会ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsExpositionById(Long expositionId) {
         cmsExpositionDao.deleteById(expositionId);
    }
}
