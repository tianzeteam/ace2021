package com.yuejike.cms.domain;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 模型对象 cms_model
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_model")
@Data
@JsonIgnoreProperties(value = {"hibernateLazyInitializer"})
public class CmsModel extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="model_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long modelId;

    /** 扩展json数据对象 */
    @Excel(name = "扩展json数据对象")
    @Column(name="model_json")
    @ApiModelProperty(value = "扩展json数据对象")
    private String modelJson;

    /** 名称 */
    @Excel(name = "名称")
    @Column(name="name")
    @ApiModelProperty(value = "名称")
    private String name;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "名称")
    private Date createTime;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "名称")
    private Date updateTime;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "名称")
    private String createBy;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "名称")
    private String updateBy;

    /** 删除标识 */
    @Column(name="del_flag")
    @ApiModelProperty(value = "名称")
    private String delFlag;

    /** 模型类型（0:列表 1：内容  2：链接） */
    @Excel(name = "模型类型", readConverterExp = "0=:列表,1=：内容,2=：链接")
    @Column(name="type")
    @ApiModelProperty(value = "模型类型")
    private String type;

}
