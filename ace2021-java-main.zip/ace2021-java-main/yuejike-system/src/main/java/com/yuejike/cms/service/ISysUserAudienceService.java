package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.SysUserAudience;

/**
 * 专业观众信息Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-26
 */
public interface ISysUserAudienceService  {
    /**
     * 查询专业观众信息
     *
     * @param userId 专业观众信息ID
     * @return 专业观众信息
     */
    SysUserAudience findById(Long userId);

    /**
     * 分页查询专业观众信息列表
     *
     * @param req 专业观众信息
     * @return 专业观众信息集合
     */
    Page<SysUserAudience> findSysUserAudiencePage(SysUserAudience req);

    /**
     * 查询专业观众信息列表
     *
     * @param req 专业观众信息
     * @return 专业观众信息集合
     */
    List<SysUserAudience> findSysUserAudienceList(SysUserAudience req);

    /**
     * 新增专业观众信息
     *
     * @param sysUserAudience 专业观众信息
     * @return 结果
     */
    void save(SysUserAudience sysUserAudience);

    /**
     * 批量删除专业观众信息
     *
     * @param userIds 需要删除的专业观众信息ID
     * @return 结果
     */
    void deleteByIds(List<Long> userIds);

    /**
     * 删除专业观众信息信息
     *
     * @param userId 专业观众信息ID
     * @return 结果
     */
    void deleteSysUserAudienceById(Long userId);
}
