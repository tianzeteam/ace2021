package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsFavorites;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;


/**
 * 收藏Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Repository
public interface CmsFavoritesDao extends JpaRepository<CmsFavorites, Long>, JpaSpecificationExecutor<CmsFavorites> {


    @Query(value = "select * from cms_favorites where user_id=?1 and business_type=?2 and business_id=?3 LIMIT 1",nativeQuery = true)
    CmsFavorites findByUserIdAndBusinessTypeAndBusinessId(Long userId,String businessType,Long businessId);

    @Query(value = "select count(1) from cms_favorites where business_type='0' and business_id=?1", nativeQuery = true)
    Long getFavoritesCountByProductId(Long productId);

    @Query(value = "select business_id as productId, count(1) as aCount from cms_favorites where business_type='0' " +
            "and business_id in (?1) group by business_id", nativeQuery = true)
    List<Map<String, Long>> getFavoritesCountByProductId(Long[] productIds);

}
