package com.yuejike.cms.domain;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 订单对象 cms_order
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_order")
@Data
public class CmsOrder extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="order_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long orderId;

    /** 展品id */
    @Excel(name = "展品id")
    @Column(name="product_id")
    @ApiModelProperty(value = "展品id")
    private Long productId;

    /** 买家id */
    @Excel(name = "买家id")
    @Column(name="buyer_id")
    @ApiModelProperty(value = "买家id")
    private Long buyerId;

    /** 订单备注 */
    @Excel(name = "订单备注")
    @Column(name="remark")
    @ApiModelProperty(value = "订单备注")
    private String remark;

    /** 订购数量 */
    @Excel(name = "订购数量")
    @Column(name="quantity")
    @ApiModelProperty(value = "订购数量")
    private Long quantity;

    /** 意向价格 */
    @Excel(name = "意向价格")
    @Column(name="intended_price")
    @ApiModelProperty(value = "意向价格")
    private BigDecimal intendedPrice;

    /** 删除标识 */
    @Column(name="del_flag")
    @ApiModelProperty(value = "意向价格")
    private String delFlag;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "意向价格")
    private String createBy;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "意向价格")
    private Date createTime;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "意向价格")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "意向价格")
    private Date updateTime;

    /** 展商id */
    @Excel(name = "展商id")
    @Column(name="user_id")
    @ApiModelProperty(value = "展商id")
    private Long userId;

    /** 展品名称 */
    @Excel(name = "展品名称")
    @Column(name="product_name")
    @ApiModelProperty(value = "展品名称")
    private String productName;

    /** 展品品价格 */
    @Excel(name = "展品品价格")
    @Column(name="product_price")
    @ApiModelProperty(value = "展品品价格")
    private BigDecimal productPrice;

    /** 最终交易金额 */
    @Excel(name = "最终交易金额")
    @Column(name="deal_amounts")
    @ApiModelProperty(value = "最终交易金额")
    private BigDecimal dealAmounts;

    /** 用户名 */
    @Excel(name = "用户名")
    @Column(name="user_name")
    @ApiModelProperty(value = "用户名")
    private String userName;

    /** 手机号 */
    @Excel(name = "手机号")
    @Column(name="phone_number")
    @ApiModelProperty(value = "手机号")
    private String phoneNumber;

    /** 电子邮件 */
    @Excel(name = "电子邮件")
    @Column(name="email")
    @ApiModelProperty(value = "电子邮件")
    private String email;

    /** 订单状态（0 待处理  1 成交  2 已作废） */
    @Excel(name = "订单状态（0 待处理  1 成交  2 已作废）")
    @Column(name="order_status")
    @ApiModelProperty(value = "订单状态（0 待处理  1 成交  2 已作废）")
    private Long orderStatus;

    /** 展商名字 */
    @Excel(name = "展商名字")
    @Column(name="exhibitor_name")
    @ApiModelProperty(value = "展商名字")
    private String exhibitorName;

    /** 展商回复 */
    @Excel(name = "展商回复")
    @Column(name="reply")
    @ApiModelProperty(value = "展商回复")
    private String reply;

    @Transient
    private CmsProduct product;


}
