package com.yuejike.cms.service;

import java.util.List;

import com.yuejike.cms.domain.SysInbox;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.SysUserExhibitor;
import org.springframework.data.domain.Pageable;

/**
 * 参展商信息Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ISysUserExhibitorService  {
    /**
     * 查询参展商信息
     *
     * @param userId 参展商信息ID
     * @return 参展商信息
     */
    SysUserExhibitor findById(Long userId);

    /**
     * 分页查询参展商信息列表
     *
     * @param req 参展商信息
     * @return 参展商信息集合
     */
    Page<SysUserExhibitor> findSysUserExhibitorPage(SysUserExhibitor req);

    /**
     * cms分页查询参展商信息列表
     *
     * @param req 参展商信息
     * @return 参展商信息集合
     */
    Page<SysUserExhibitor> cmsFindSysUserExhibitorPage(SysUserExhibitor req);

    /**
     * 查询参展商信息列表
     *
     * @param req 参展商信息
     * @return 参展商信息集合
     */
    List<SysUserExhibitor> findSysUserExhibitorList(SysUserExhibitor req);

    /**
     * 新增参展商信息
     *
     * @param sysUserExhibitor 参展商信息
     * @return 结果
     */
    void save(SysUserExhibitor sysUserExhibitor,int type);

    /**
     * 批量删除参展商信息
     *
     * @param userIds 需要删除的参展商信息ID
     * @return 结果
     */
    void deleteByIds(List<Long> userIds);

    /**
     * 删除参展商信息信息
     *
     * @param userId 参展商信息ID
     * @return 结果
     */
    void deleteSysUserExhibitorById(Long userId);

    /**
     *校验参展商是否唯一
     * @param exhibitor
     * @return
     */
    String checkExhibitorUnique(SysUserExhibitor exhibitor);


    SysUserExhibitor findByUserId(Long userId);

    int findByClassificationId(Long classificationId);

    /**刷新参展年份**/
    void refreshJoinYears(Long userId);

    int batchRecommend(Long[] userIds, String type);

    boolean canRecommend(Long[] userIds);

    void calculateRanking();
}
