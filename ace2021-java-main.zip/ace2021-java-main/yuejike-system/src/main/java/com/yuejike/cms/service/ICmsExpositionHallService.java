package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsExpositionHall;

/**
 * 博览会和场馆关联Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsExpositionHallService  {
    /**
     * 查询博览会和场馆关联
     *
     * @param id 博览会和场馆关联ID
     * @return 博览会和场馆关联
     */
    CmsExpositionHall findById(Long id);

    /**
     * 分页查询博览会和场馆关联列表
     *
     * @param req 博览会和场馆关联
     * @return 博览会和场馆关联集合
     */
    Page<CmsExpositionHall> findCmsExpositionHallPage(CmsExpositionHall req);

    /**
     * 查询博览会和场馆关联列表
     *
     * @param req 博览会和场馆关联
     * @return 博览会和场馆关联集合
     */
    List<CmsExpositionHall> findCmsExpositionHallList(CmsExpositionHall req);

    /**
     * 新增博览会和场馆关联
     *
     * @param cmsExpositionHall 博览会和场馆关联
     * @return 结果
     */
    void save(CmsExpositionHall cmsExpositionHall);

    /**
     * 批量删除博览会和场馆关联
     *
     * @param ids 需要删除的博览会和场馆关联ID
     * @return 结果
     */
    void deleteByIds(List<Long> ids);

    /**
     * 删除博览会和场馆关联信息
     *
     * @param id 博览会和场馆关联ID
     * @return 结果
     */
    void deleteCmsExpositionHallById(Long id);
}
