package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsLive;

/**
 * 直播Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsLiveService  {
    /**
     * 查询直播
     *
     * @param liveId 直播ID
     * @return 直播
     */
    CmsLive findById(Long liveId);

    /**
     * 分页查询直播列表
     *
     * @param req 直播
     * @return 直播集合
     */
    Page<CmsLive> findCmsLivePage(CmsLive req);

    /**
     * 查询直播列表
     *
     * @param req 直播
     * @return 直播集合
     */
    List<CmsLive> findCmsLiveList(CmsLive req);

    /**
     * 新增直播
     *
     * @param cmsLive 直播
     * @return 结果
     */
    CmsLive save(CmsLive cmsLive);

    /**
     * 批量删除直播
     *
     * @param liveIds 需要删除的直播ID
     * @return 结果
     */
    void deleteByIds(List<Long> liveIds);

    /**
     * 删除直播信息
     *
     * @param liveId 直播ID
     * @return 结果
     */
    void deleteCmsLiveById(Long liveId);

    CmsLive findByRoomId(String roomId);

    void review(Long[] liveIds, CmsLive cmsLive);
}
