package com.yuejike.cms.service;

import com.yuejike.cms.domain.CmsProductCategory;
import com.yuejike.model.TreeSelectModel;
import org.springframework.data.domain.Page;

import java.util.List;
import java.util.Map;

/**
 * @author JinZJ
 * @version 1.0
 * @Description:
 * @date 2021/11/23 15:39
 */
public interface ICmsProductCategoryService {

    /**
     * 查询展品分类
     *
     * @param categoryId 展品分类ID
     * @return 展品分类信息
     */
    CmsProductCategory findById(Long categoryId);

    /**
     * 分页查询展品分类列表
     *
     * @param req 展品分类
     * @return 展品分类集合
     */
    Page<CmsProductCategory> findCmsCategoryPage(CmsProductCategory req);


    /**
     * 分页查询展品分类列表（table-tree展示）
     *
     * @param req 展品分类
     * @return 展品分类
     */
    Page<CmsProductCategory> findCmsCategoryTreePage(CmsProductCategory req);
    /**
     * 查询展品分类管理列表
     *
     * @param req 展品分类
     * @return 展品分类集合
     */
    List<CmsProductCategory> findCmsCategoryList(CmsProductCategory req);

    /**
     * 获取展品分类层级结构树
     *
     * @return 展品分类集合
     */
    List<Map<String,Object>> getCmsCategorySelectByPid();

    /**
     * 新增展品分类
     *
     * @param cmsCategory 展品分类
     * @return 结果
     */
    void save(CmsProductCategory cmsCategory);

    /**
     * 批量删除展品分类
     *
     * @param categoryIds 需要删除的展品分类ID
     * @return 结果
     */
    void deleteByIds(List<Long> categoryIds);

    /**
     * 删除展品分类信息
     *
     * @param categoryId 展品分类ID
     * @return 结果
     */
    void deleteCmsCategoryById(Long categoryId);

    boolean hasChildByMenuId(Long categoryId);

    List<CmsProductCategory> findByParentId(List<Long> categoryIds);

    List<CmsProductCategory> buildTree(List<CmsProductCategory> productCategories);

    List<TreeSelectModel> buildTreeSelect(List<CmsProductCategory> productCategories);

}
