package com.yuejike.cms.service.impl;

import com.yuejike.cms.dao.CmsEnrollDao;
import com.yuejike.cms.dao.CmsLiveDao;
import com.yuejike.cms.dao.SysUserExhibitorDao;
import com.yuejike.cms.domain.CmsEnroll;
import com.yuejike.cms.domain.CmsLive;
import com.yuejike.cms.service.ICmsLiveService;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.SecurityUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.*;
import java.util.*;

/**
 * 直播Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsLiveServiceImpl implements ICmsLiveService {

    @Autowired
    private CmsLiveDao cmsLiveDao;
    @Autowired
    private CmsEnrollDao cmsEnrollDao;
    @Autowired
    private SysUserExhibitorDao sysUserExhibitorDao;
    /**
     * 查询直播
     *
     * @param liveId 直播ID
     * @return 直播
     */
    @Override
    public CmsLive findById(Long liveId) {
        return cmsLiveDao.findById(liveId).orElse(null);
    }

    /**
     * 分页查询直播列表
     *
     * @param req 直播
     * @return 直播
     */
    @Override
    public Page<CmsLive> findCmsLivePage(CmsLive req) {
        Specification<CmsLive> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("sort"),
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsLive> page = cmsLiveDao.findAll(example, pageable);
        page.getContent().forEach(live->{
            //查询每个直播已报名并且通过审核的人数
            List<CmsEnroll> enrollList =cmsEnrollDao.findByLiveId(live.getLiveId());
            live.setEnrollNumber(enrollList.size());
            // SysUser loginUser = SecurityUtils.getLoginUser().getUser();
            // //添加报名是否成功的状态
            // if(null !=loginUser){
            //     CmsEnroll enroll = cmsEnrollDao.findByLiveIdAndUserId(live.getLiveId(),loginUser.getUserId());
            //     if(null != enroll && enroll.getStatus().equals("1")){
            //         live.setEnrollStatus("1");
            //     }else {
            //         live.setEnrollStatus("0");
            //     }
            // }else{
            //     live.setEnrollStatus("0");
            // }
        });
        return page;
    }

    /**
     * 分页查询直播列表
     *
     * @param req 直播
     * @return 直播
     */
    @Override
    public List<CmsLive> findCmsLiveList(CmsLive req) {
        Specification<CmsLive> example = formatQueryParams(req);
        List<CmsLive> list = cmsLiveDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    private Specification<CmsLive> formatQueryParams(CmsLive req){
        Specification<CmsLive> example = new Specification<CmsLive>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsLive> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getLiveId()){
                    Predicate pre = cb.equal(root.get("liveId").as(Long.class), req.getLiveId());
                    list.add(pre);
                }
                if (null != req.getExpositionId()){
                    Predicate pre = cb.equal(root.get("expositionId").as(Long.class), req.getExpositionId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getName())){
                    Predicate pre = cb.like(root.get("name").as(String.class), "%" + req.getName()+ "%");
                    list.add(pre);
                }
                if (null != req.getStartTime()){
                    Predicate pre = cb.equal(root.get("startTime").as(Date.class), req.getStartTime());
                    list.add(pre);
                }
                if (null != req.getEndTime()){
                    Predicate pre = cb.equal(root.get("endTime").as(Date.class), req.getEndTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getType())){
                    Predicate pre = cb.equal(root.get("type").as(String.class), req.getType());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getIntroduce())){
                    Predicate pre = cb.equal(root.get("introduce").as(String.class), req.getIntroduce());
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateType())){
                    Predicate pre = cb.equal(root.get("createType").as(String.class), req.getCreateType());
                    list.add(pre);
                }
                if (null != req.getCreateId()){
                    // if(StringUtils.isNotBlank(req.getCreateType()) && req.getCreateType().equals("1")){
                    //     Join<CmsLive, SysUserExhibitor> exhibitorJoin = root.join("userExhibitor",JoinType.LEFT);
                    // }else{
                        Predicate pre = cb.equal(root.get("createId").as(Long.class), req.getCreateId());
                        list.add(pre);
                    // }
                }
                if (null != req.getDeptId()){
                    Predicate pre = cb.equal(root.get("deptId").as(Long.class), req.getDeptId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())){
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (null != req.getReviewerId()){
                    Predicate pre = cb.equal(root.get("reviewerId").as(Long.class), req.getReviewerId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getStatus())){
                    Predicate pre = cb.equal(root.get("status").as(String.class), req.getStatus());
                    list.add(pre);
                }
                if(StringUtils.isNotBlank(req.getEmpower()) && StringUtils.isNotBlank(req.getGroupId())){
                    String[] userType = req.getEmpower().split(",");
                    List<Predicate> predicate1 =new ArrayList<>();
                    for (String s : userType) {
                        Predicate pre = cb.like(root.get("empower").as(String.class),"%"+ s +"%") ;
                        predicate1.add(pre);
                    }
                    //分组查询
                    String[] groupIds = req.getGroupId().split(",");
                    for (String s:groupIds){
                        Predicate pre = cb.like(root.get("groupId").as(String.class),"%"+ s +"%");
                        predicate1.add(pre);
                    }
                    //添加userType or groupId条件
                    Predicate predicateOr = cb.or(predicate1.toArray(new Predicate[predicate1.size()]));

                    predicateOr = cb.and(predicateOr);
                    list.add(predicateOr);

                }else if(StringUtils.isNotBlank(req.getEmpower())){
                    String[] userType = req.getEmpower().split(",");
                    List<Predicate> predicate1 =new ArrayList<>();
                    for (String s : userType) {
                        Predicate pre = cb.like(root.get("empower").as(String.class),"%"+ s +"%") ;
                        predicate1.add(pre);
                    }
                    //添加or条件
                    Predicate predicateOr = cb.or(predicate1.toArray(new Predicate[predicate1.size()]));
                    predicateOr = cb.and(predicateOr);
                    list.add(predicateOr);

                }else if (StringUtils.isNotBlank(req.getGroupId())){
                    // Predicate pre = cb.like(root.get("groupId").as(String.class),"%"+ req.getGroupId()+"%");
                    // list.add(pre);
                    String[] groupIds = req.getGroupId().split(",");
                    List<Predicate> predicate3 =new ArrayList<>();
                    for (String s:groupIds){
                        Predicate pre = cb.like(root.get("groupId").as(String.class),"%"+ s +"%");
                        predicate3.add(pre);
                    }
                    //添加or条件
                    Predicate predicateOrGroupId = cb.or(predicate3.toArray(new Predicate[predicate3.size()]));
                    predicateOrGroupId = cb.and(predicateOrGroupId);
                    list.add(predicateOrGroupId);
                }
                if (StringUtils.isNotBlank(req.getVideoId())){
                    Predicate pre = cb.equal(root.get("videoId").as(String.class), req.getVideoId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getRoomId())){
                    Predicate pre = cb.equal(root.get("roomId").as(String.class), req.getRoomId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpfileName())){
                    Predicate pre = cb.like(root.get("upfileName").as(String.class), "%" + req.getUpfileName()+ "%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getTheme())){
                    Predicate pre = cb.equal(root.get("theme").as(String.class), req.getTheme());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getProcess())){
                    Predicate pre = cb.equal(root.get("process").as(String.class), req.getProcess());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCoverPicture())){
                    Predicate pre = cb.equal(root.get("coverPicture").as(String.class), req.getCoverPicture());
                    list.add(pre);
                }
                if (null != req.getSort()){
                    Predicate pre = cb.equal(root.get("sort").as(Integer.class), req.getSort());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getLiveUrl())){
                    Predicate pre = cb.equal(root.get("liveUrl").as(String.class), req.getLiveUrl());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getLiveForm())){
                    Predicate pre = cb.equal(root.get("liveForm").as(String.class), req.getLiveForm());
                    list.add(pre);
                }
                //uiList需要显示在线直播和外部链接直播
                if(StringUtils.isNotBlank(req.getIsUiList()) && req.getIsUiList().equals("1")){
                    List<String> strings = new ArrayList<>();
                    strings.add("0");
                    strings.add("1");
                    List<Predicate> predicate1 =new ArrayList<>();
                    for (String s : strings) {
                        Predicate pre = cb.equal(root.get("liveForm").as(String.class),s ) ;
                        predicate1.add(pre);
                    }
                    //添加or条件
                    Predicate predicateOr = cb.or(predicate1.toArray(new Predicate[predicate1.size()]));
                    predicateOr = cb.and(predicateOr);
                    list.add(predicateOr);
                }
                //判断渠道数据权限
                LoginUser loginUser = SecurityUtils.getLoginUserNoThrow();
                boolean isChannel = (loginUser != null && loginUser.getUser() != null
                        && loginUser.getUser().getRoles() != null && loginUser.getUser().getRoles()
                        .stream().filter(item -> item.getRoleKey().startsWith("channel")).count()>0);
                if(isChannel){
                    Subquery subQuery = query.subquery(String.class);
                    Root from = subQuery.from(SysUser.class);
                    //创建子查询条件对象('where'后的语句对象)
                    Predicate predicate1 = cb.conjunction();
                    predicate1 = cb.and(predicate1,cb.equal(from.get("channelId"), loginUser.getUser().getUserId()));
                    //完成子查询
                    subQuery.select(from.get("deptId")).where(predicate1);
                    //把子查询结果拼接到原查询语句后面---这里是dept_id in的写法
                    //过滤渠道用户数据权限
                    Predicate deptPre = cb.conjunction();
                    deptPre = cb.and(deptPre, cb.in(root.get("deptId")).value(subQuery));
                    list.add(deptPre);
                }
                //主办方按展区过滤数据权限
                if(loginUser != null && loginUser.getUser() != null && loginUser.getUser().getUserType().equals(UserType.ZBF_JS.getCode())){
                    List<Long> planIds = new ArrayList<>();
                    if(loginUser.getUser().getRoles() != null){
                        loginUser.getUser().getRoles().forEach(role -> {
                            if(com.yuejike.common.utils.StringUtils.isNotEmpty(role.getPlanIds())) {
                                Arrays.stream(role.getPlanIds().split(",")).forEach(it -> {
                                    if(!planIds.contains(Long.valueOf(it))){
                                        planIds.add(Long.valueOf(it));
                                    }
                                });
                            }
                        });
                    }
                    CriteriaBuilder.In<Long> in = cb.in(root.get("deptId"));
                    List<Long> tmpUsers = null;
                    if(planIds.size()>0){
                        tmpUsers = sysUserExhibitorDao.getExhibitorDeptIdByPlanIds(planIds);
                    }
                    if(tmpUsers != null && tmpUsers.size()>0){
                        tmpUsers.forEach(user -> in.value(user));
                    }else{
                        in.value(0L);
                    }
                    Predicate deptPre = cb.conjunction();
                    deptPre = cb.and(deptPre, in);
                    list.add(deptPre);
                }

                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）直播
     *
     * @param cmsLive 直播
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public CmsLive save(CmsLive cmsLive) {
        // cmsLive.setCreateTime(DateUtils.getNowDate());
        CmsLive live = cmsLiveDao.save(cmsLive);
        return live;
    }


    /**
     * 批量删除直播
     *
     * @param liveIds 需要删除的直播ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> liveIds) {
        List<CmsLive> existBeans = cmsLiveDao.findAllById(liveIds);
        if(!existBeans.isEmpty()){
            cmsLiveDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除直播信息
     *
     * @param liveId 直播ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsLiveById(Long liveId) {
         cmsLiveDao.deleteById(liveId);
    }

    @Override
    public CmsLive findByRoomId(String roomId) {
        return cmsLiveDao.findByRoomId(roomId);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void review(Long[] liveIds, CmsLive cmsLive) {
        List<CmsLive> cmsLives = cmsLiveDao.findAllById(Arrays.asList(liveIds));
        for(CmsLive cmsLiveTmp: cmsLives){
            cmsLiveTmp.setReviewerId(cmsLive.getReviewerId());
            cmsLiveTmp.setReviewRejectReason(cmsLive.getReviewRejectReason());
            cmsLiveTmp.setReviewTime(cmsLive.getReviewTime());
            cmsLiveTmp.setStatus(cmsLive.getStatus());
        }
        cmsLiveDao.saveAll(cmsLives);
    }
}
