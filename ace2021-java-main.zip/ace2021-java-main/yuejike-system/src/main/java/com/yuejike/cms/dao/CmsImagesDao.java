package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsImages;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;


/**
 * 图片关联Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Repository
public interface CmsImagesDao extends JpaRepository<CmsImages, Long>, JpaSpecificationExecutor<CmsImages> {



}
