package com.yuejike.cms.service.impl;

import java.util.*;
import java.util.stream.Collectors;

import com.yuejike.cms.dto.CmsCategoryDTO;
import com.yuejike.common.utils.DateUtils;

import com.yuejike.common.utils.bean.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import org.hibernate.query.internal.NativeQueryImpl;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yuejike.cms.dao.CmsCategoryDao;
import com.yuejike.cms.domain.CmsCategory;
import com.yuejike.cms.service.ICmsCategoryService;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/**
 * 栏目管理Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsCategoryServiceImpl implements ICmsCategoryService {

    @Autowired
    private CmsCategoryDao cmsCategoryDao;

    /**
     * 查询栏目管理
     *
     * @param categoryId 栏目管理ID
     * @return 栏目管理
     */
    @Override
    public CmsCategory findById(Long categoryId) {
        return cmsCategoryDao.findById(categoryId).get();
    }

    /**
     * 分页查询栏目管理列表
     *
     * @param req 栏目管理
     * @return 栏目管理
     */
    @Override
    public Page<CmsCategory> findCmsCategoryPage(CmsCategory req) {
        Specification<CmsCategory> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsCategory> page = cmsCategoryDao.findAll(example, pageable);
        return page;
    }


    /**
     * 分页查询栏目管理列表（table-tree展示）
     *
     * @param req 栏目管理
     * @return 栏目管理
     */
    @Override
    public Page<CmsCategory> findCmsCategoryTreePage(CmsCategory req) {
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        List<CmsCategory> categoryTrees = new ArrayList<>();
        List<CmsCategory> allCategory = findCmsCategorgFullList(req);
        for (CmsCategory cmsCategory : allCategory) {
            List<CmsCategory> children = new ArrayList<>();
            if (cmsCategory!=null && (cmsCategory.getParentId() == null || cmsCategory.getParentId() == 0L)) {
                categoryTrees.add(cmsCategory);
                getTableTreeByAllCategory(children,allCategory,cmsCategory.getCategoryId());
                if(children.size()>0){
                    cmsCategory.setChildren(children);
                }
            }
        }
        // Page<CmsCategory> cmsCategories = new PageImpl<>(categoryTrees,pageable,allCategory.size());
        Page<CmsCategory> cmsCategories = new PageImpl<>(categoryTrees,pageable,categoryTrees.size());
        return cmsCategories;
    }

    @PersistenceContext
    private EntityManager entityManager;

    public List<CmsCategory> findCmsCategorgFullList(CmsCategory cmsCategory) {
        StringBuffer sql = new StringBuffer();
        List<Object> params = new ArrayList<>();
        sql.append(" select cc.category_id categoryId, cc.cn_name cnName, cc.en_name enName,cc.ja_name jaName, cc.ko_name koName, cc.img_url imgUrl, cc.descrip descrip, cc.keyword keyword, ");
        sql.append(" cc.link link, cc.parent_id parentId, cc.model_id modelId, cc.sort sort, cc.is_link isLink,cc.visible visible,cc.create_time createTime, ");
        sql.append(" ccp.cn_name parentName,cm.name modelName,");
        sql.append(" cc.exposition_id as expositionId from cms_category cc ");
        sql.append(" left join cms_category ccp on cc.parent_id = ccp.category_id ");
        sql.append(" left join cms_model cm on cc.model_id = cm.model_id ");
        sql.append(" where cc.del_flag = '0' or cc.del_flag is null ");
        if (cmsCategory.getCategoryId()!=null) {
            sql.append(" AND cc.category_id = ? ");
            params.add("%" + cmsCategory.getCategoryId() + "%");
        }
        if (cmsCategory.getExpositionId()!=null) {
            sql.append(" AND cc.exposition_id = ? ");
            params.add(cmsCategory.getExpositionId());
        }
        if (StringUtils.isNotBlank(cmsCategory.getCnName())) {
            sql.append(" AND cc.cn_name = ? ");
            params.add(cmsCategory.getCnName());
        }
        if (StringUtils.isNotBlank(cmsCategory.getEnName())) {
            sql.append(" AND cc.en_name = ? ");
            params.add(cmsCategory.getEnName());
        }
        if (StringUtils.isNotBlank(cmsCategory.getImgUrl())) {
            sql.append(" AND cc.img_url = ? ");
            params.add(cmsCategory.getImgUrl());
        }
        if (StringUtils.isNotBlank(cmsCategory.getDescrip())) {
            sql.append(" AND cc.descrip = ? ");
            params.add(cmsCategory.getDescrip());
        }
        if (StringUtils.isNotBlank(cmsCategory.getKeyword())) {
            sql.append(" AND cc.keyword = ? ");
            params.add(cmsCategory.getKeyword());
        }
        if (StringUtils.isNotBlank(cmsCategory.getLink())) {
            sql.append(" AND cc.link = ? ");
            params.add(cmsCategory.getLink());
        }
        if (cmsCategory.getParentId() != null) {
            sql.append(" AND cc.parent_id = ? ");
            params.add(cmsCategory.getParentId());
        }
        if (cmsCategory.getModelId() != null) {
            sql.append(" AND cc.model_id = ? ");
            params.add(cmsCategory.getModelId());
        }
        if (cmsCategory.getSort() != null) {
            sql.append(" AND cc.sort = ? ");
            params.add(cmsCategory.getSort());
        }
        if (StringUtils.isNotBlank(cmsCategory.getIsLink())) {
            sql.append(" AND cc.is_link = ? ");
            params.add(cmsCategory.getIsLink());
        }
        if (StringUtils.isNotBlank(cmsCategory.getVisible())) {
            sql.append(" AND cc.visible = ? ");
            params.add(cmsCategory.getVisible());
        }
        sql.append(" order by cc.update_time, cc.create_time ");
        Query contentQuery = entityManager.createNativeQuery(sql.toString());
        for (int i = 0; i < params.size(); i++) {
            contentQuery.setParameter(i + 1, params.get(i));
        }
        contentQuery.unwrap(NativeQueryImpl.class).setResultTransformer(Transformers.aliasToBean(CmsCategoryDTO.class));
        List<CmsCategoryDTO> results = contentQuery.getResultList();
        List<CmsCategory> collect = results.stream().map(m -> newCmsCategory(m)).collect(Collectors.toList());
        return collect;
    }


    private CmsCategory newCmsCategory(CmsCategoryDTO c){
        CmsCategory cmsCategory = new CmsCategory();
        BeanUtils.copyProperties(c, cmsCategory);
        if(c.getCategoryId()!=null)cmsCategory.setCategoryId(c.getCategoryId().longValue());
        cmsCategory.setCnName(c.getCnName());
        cmsCategory.setEnName(c.getEnName());
        cmsCategory.setJaName(c.getJaName());
        cmsCategory.setKoName(c.getKoName());
        cmsCategory.setImgUrl(c.getImgUrl());
        cmsCategory.setDescrip(c.getDescrip());
        cmsCategory.setKeyword(c.getKeyword());
        cmsCategory.setLink(c.getLink());
        if(c.getParentId()!=null)cmsCategory.setParentId(c.getParentId().longValue());
        if(c.getModelId()!=null)cmsCategory.setModelId(c.getModelId().longValue());
        if(c.getExpositionId()!=null)cmsCategory.setExpositionId(c.getExpositionId().longValue());
        cmsCategory.setSort(c.getSort());
        if(c.getIsLink()!=null)cmsCategory.setIsLink(c.getIsLink().toString());
        if(c.getVisible()!=null)cmsCategory.setVisible(c.getVisible().toString());
        cmsCategory.setParentName(c.getParentName());
        cmsCategory.setModelName(c.getModelName());
        return cmsCategory;
    }

    private void getTableTreeByAllCategory(List<CmsCategory> result,List<CmsCategory> allCategory,Long id){
        for (CmsCategory cmsCategory : allCategory) {
            List<CmsCategory> children = new ArrayList<>();
            if (cmsCategory.getParentId()!= null && cmsCategory.getParentId().longValue() == id.longValue()) {
                result.add(cmsCategory);
                getTableTreeByAllCategory(children,allCategory,cmsCategory.getCategoryId());
                if(children.size()>0){
                    cmsCategory.setChildren(children);
                }
            }
        }
    }


    /**
     * 分页查询栏目管理列表
     *
     * @param req 栏目管理
     * @return 栏目管理
     */
    @Override
    public List<CmsCategory> findCmsCategoryList(CmsCategory req) {
        Specification<CmsCategory> example = formatQueryParams(req);
        List<CmsCategory> list = cmsCategoryDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    private Specification<CmsCategory> formatQueryParams(CmsCategory req){
        Specification<CmsCategory> example = new Specification<CmsCategory>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsCategory> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getCategoryId()){
                    Predicate pre = cb.equal(root.get("categoryId").as(Long.class), req.getCategoryId());
                    list.add(pre);
                }
                if (null != req.getExpositionId()){
                    Predicate pre = cb.equal(root.get("expositionId").as(Long.class), req.getExpositionId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCnName())){
                    Predicate pre = cb.like(root.get("cnName").as(String.class), "%" + req.getCnName()+ "%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getEnName())){
                    Predicate pre = cb.like(root.get("enName").as(String.class), "%" + req.getEnName()+ "%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getImgUrl())){
                    Predicate pre = cb.equal(root.get("imgUrl").as(String.class), req.getImgUrl());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDescrip())){
                    Predicate pre = cb.equal(root.get("descrip").as(String.class), req.getDescrip());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getKeyword())){
                    Predicate pre = cb.equal(root.get("keyword").as(String.class), req.getKeyword());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getLink())){
                    Predicate pre = cb.equal(root.get("link").as(String.class), req.getLink());
                    list.add(pre);
                }
                if (null != req.getParentId()){
                    Predicate pre = cb.equal(root.get("parentId").as(Long.class), req.getParentId());
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())){
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (null != req.getModelId()){
                    Predicate pre = cb.equal(root.get("modelId").as(Long.class), req.getModelId());
                    list.add(pre);
                }
                if (null != req.getSort()){
                    Predicate pre = cb.equal(root.get("sort").as(Integer.class), req.getSort());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getIsLink())){
                    Predicate pre = cb.equal(root.get("isLink").as(String.class), req.getIsLink());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getVisible())){
                    Predicate pre = cb.equal(root.get("visible").as(String.class), req.getVisible());
                    list.add(pre);
                }
                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 获取栏目层级结构树
     *
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public List<Map<String,Object>> getCmsCategorySelectByPid() {
        List<Map<String,Object>> result = new ArrayList<>();
        try {
            List<CmsCategory> allCategory = cmsCategoryDao.findAll();

            for (CmsCategory cmsCategory : allCategory) {
                List<Map<String,Object>> children = new ArrayList<>();
                if (cmsCategory!=null && (cmsCategory.getParentId() == null || cmsCategory.getParentId() == 0L)) {
                    Map<String, Object> map = new HashMap<>();
                    map.put("value", cmsCategory.getCategoryId());
                    map.put("id", cmsCategory.getCategoryId());
                    map.put("label", cmsCategory.getCnName());
                    map.put("modelId", cmsCategory.getModelId());
                    getTreeByAllCategory(children,allCategory,cmsCategory.getCategoryId());
                    if(children.size()>0){
                        map.put("children", children);
                    }
                    result.add(map);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    private void getTreeByAllCategory(List<Map<String,Object>> result,List<CmsCategory> allCategory,Long id){
        for (CmsCategory cmsCategory : allCategory) {
            List<Map<String,Object>> children = new ArrayList<>();
            if (cmsCategory.getParentId()!= null && cmsCategory.getParentId().longValue() == id.longValue()) {
                Map<String, Object> map = new HashMap<>();
                map.put("value", cmsCategory.getCategoryId());
                map.put("id", cmsCategory.getCategoryId());
                map.put("label", cmsCategory.getCnName());
                map.put("modelId", cmsCategory.getModelId());
                getTreeByAllCategory(children,allCategory,cmsCategory.getCategoryId());
                if(children.size()>0){
                    map.put("children", children);
                }
                result.add(map);
            }
        }
    }

    /**
     * 保存（新增/修改）栏目管理
     *
     * @param cmsCategory 栏目管理
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void save(CmsCategory cmsCategory) {
        cmsCategory.setCreateTime(DateUtils.getNowDate());
        cmsCategoryDao.save(cmsCategory);
    }


    /**
     * 批量删除栏目管理
     *
     * @param categoryIds 需要删除的栏目管理ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> categoryIds) {
        List<CmsCategory> existBeans = cmsCategoryDao.findAllById(categoryIds);
        if(!existBeans.isEmpty()){
            cmsCategoryDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除栏目管理信息
     *
     * @param categoryId 栏目管理ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsCategoryById(Long categoryId) {
         cmsCategoryDao.deleteById(categoryId);
    }
}
