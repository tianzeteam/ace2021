package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsExposition;

/**
 * 博览会Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsExpositionService  {
    /**
     * 查询博览会
     *
     * @param expositionId 博览会ID
     * @return 博览会
     */
    CmsExposition findById(Long expositionId);

    /**
     * 分页查询博览会列表
     *
     * @param req 博览会
     * @return 博览会集合
     */
    Page<CmsExposition> findCmsExpositionPage(CmsExposition req);

    /**
     * 查询博览会列表
     *
     * @param req 博览会
     * @return 博览会集合
     */
    List<CmsExposition> findCmsExpositionList(CmsExposition req);

    /**
     * 新增博览会
     *
     * @param cmsExposition 博览会
     * @return 结果
     */
    void save(CmsExposition cmsExposition);

    void update(CmsExposition cmsExposition);

    /**
     * 批量删除博览会
     *
     * @param expositionIds 需要删除的博览会ID
     * @return 结果
     */
    void deleteByIds(List<Long> expositionIds);

    /**
     * 删除博览会信息
     *
     * @param expositionId 博览会ID
     * @return 结果
     */
    void deleteCmsExpositionById(Long expositionId);
}
