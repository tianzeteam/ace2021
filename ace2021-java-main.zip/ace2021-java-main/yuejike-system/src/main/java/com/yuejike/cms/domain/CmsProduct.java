package com.yuejike.cms.domain;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import com.yuejike.common.core.domain.entity.SysDept;
import com.yuejike.common.core.domain.entity.SysUser;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 展品信息对象 cms_product
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_product")
@Data
public class CmsProduct extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="product_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long productId;

    /** 展商id */
    @Excel(name = "展商id")
    @Column(name="user_id")
    @ApiModelProperty(value = "展商id")
    private Long userId;

    /** 展品名称 */
    @Excel(name = "展品名称")
    @Column(name="name")
    @ApiModelProperty(value = "展品名称")
    private String name;

    @Excel(name = "展品英文名")
    @Column(name="en_name")
    @ApiModelProperty(value = "展品英文名")
    private String enName;

    @Excel(name = "展品日文名称")
    @Column(name="ja_name")
    @ApiModelProperty(value = "展品日文名称")
    private String jaName;

    @Excel(name = "展品韩文名称")
    @Column(name="ko_name")
    @ApiModelProperty(value = "展品韩文名称")
    private String koName;

    /** 分类id */
    @Excel(name = "分类id")
    @Column(name="classification_id")
    @ApiModelProperty(value = "分类id")
    private Long classificationId;

    @Excel(name = "展品分类id")
    @Column(name="category_id")
    @ApiModelProperty(value = "展品分类id")
    private Long categoryId;

    /** 展品简介 */
    @Excel(name = "展品简介")
    @Column(name="detail")
    @ApiModelProperty(value = "展品简介")
    private String detail;

    @Excel(name = "展品英文简介")
    @Column(name="en_detail")
    @ApiModelProperty(value = "展品英文简介")
    private String enDetail;

    @Excel(name = "展品日文简介")
    @Column(name="ja_detail")
    @ApiModelProperty(value = "展品日文简介")
    private String jaDetail;

    @Excel(name = "展品韩文简介")
    @Column(name="ko_detail")
    @ApiModelProperty(value = "展品韩文简介")
    private String koDetail;

    /** 审核人id */
    @Excel(name = "审核人id")
    @Column(name="reviewer_id")
    @ApiModelProperty(value = "审核人id")
    private Long reviewerId;

    /** 审核状态（0：待审核1：已通过2：已拒绝） */
    @Excel(name = "审核状态", readConverterExp = "0=：待审核1：已通过2：已拒绝")
    @Column(name="status")
    @ApiModelProperty(value = "审核状态")
    private String status;

    /** 最低价 */
    @Excel(name = "最低价")
    @Column(name="min_price")
    @ApiModelProperty(value = "最低价")
    private BigDecimal minPrice;

    /** 最高价 */
    @Excel(name = "最高价")
    @Column(name="max_price")
    @ApiModelProperty(value = "最高价")
    private BigDecimal maxPrice;

    /** 发货地址 */
    @Excel(name = "发货地址")
    @Column(name="ship_address")
    @ApiModelProperty(value = "发货地址")
    private String shipAddress;

    /** 最少起订量 */
    @Excel(name = "最少起订量")
    @Column(name="min_order")
    @ApiModelProperty(value = "最少起订量")
    private Long minOrder;

    /** 最高订单数 */
    @Excel(name = "最高订单数")
    @Column(name="max_order")
    @ApiModelProperty(value = "最高订单数")
    private Long maxOrder;

    /** 展品型号 */
    @Excel(name = "展品型号")
    @Column(name="model")
    @ApiModelProperty(value = "展品型号")
    private String model;

    /** 展品颜色 */
    @Excel(name = "展品颜色")
    @Column(name="color")
    @ApiModelProperty(value = "展品颜色")
    private String color;

    /** 展品材质 */
    @Excel(name = "展品材质")
    @Column(name="material")
    @ApiModelProperty(value = "展品材质")
    private String material;

    /** 展品大小 */
    @Excel(name = "展品大小")
    @Column(name="size")
    @ApiModelProperty(value = "展品大小")
    private String size;

    /** 特征 */
    @Excel(name = "特征")
    @Column(name="features")
    @ApiModelProperty(value = "特征")
    private String features;

    /** 排序 */
    @Excel(name = "排序")
    @Column(name="sort")
    @ApiModelProperty(value = "排序")
    private Integer sort;

    /** 删除标识 */
    @Column(name="del_flag")
    @ApiModelProperty(value = "排序")
    private String delFlag;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "排序")
    private String createBy;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "排序")
    private Date createTime;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "排序")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "排序")
    private Date updateTime;

    /** 是否可见（0：正常1：隐藏） */
    @Excel(name = "是否可见", readConverterExp = "0=：正常1：隐藏")
    @Column(name="visible")
    @ApiModelProperty(value = "是否可见")
    private String visible;

    /** 展品视频地址 */
    @Excel(name = "展品视频地址")
    @Column(name="video_url")
    @ApiModelProperty(value = "展品视频地址")
    private String videoUrl;

    /** 展品标签id */
    @Excel(name = "展品标签id")
    @Column(name="label_id")
    @ApiModelProperty(value = "展品标签id")
    private String labelId;

    /**
     * 展品属性
     */
    @Excel(name = "展品属性")
    @Column(name="attribute")
    @ApiModelProperty(value = "展品属性")
    private String attribute;

    /**
     * 图片
     */
    @Excel(name = "图片")
    @Column(name="img_url")
    @ApiModelProperty(value = "图片")
    private String imgUrl;

    /**
     * 封面图片
     */
    @Excel(name = "封面图片")
    @Column(name="cover_url")
    @ApiModelProperty(value = "封面图片")
    private String coverUrl;

    /**
     * 国家id
     */
    @Excel(name = "国家id")
    @Column(name="country_id")
    @ApiModelProperty(value = "国家id")
    private String countryId;

    /**
     * 市id
     */
    @Excel(name = "市id")
    @Column(name="city_id")
    @ApiModelProperty(value = "市id")
    private String cityId;

    /**
     * 省id
     */
    @Excel(name = "省id")
    @Column(name="province_id")
    @ApiModelProperty(value = "省id")
    private String provinceId;

    /**
     * 展商名字
     */
    @Excel(name = "展商名字")
    @Column(name="exhibitor_name")
    @ApiModelProperty(value = "展商名字")
    private String exhibitorName;

    /**
     * 展品规格属性
     */
    @Excel(name = "展品规格属性")
    @Column(name="product_spec")
    @ApiModelProperty(value = "展品规格属性")
    private String productSpec;

    /**
     * 审核建议
     */
    @Excel(name = "审核建议")
    @Column(name="audit_advice")
    @ApiModelProperty(value = "审核建议")
    private String auditAdvice;

    /**
     * 购买链接
     */
    @Excel(name = "购买链接")
    @Column(name="buy_url")
    @ApiModelProperty(value = "购买链接")
    private String buyUrl;

    /**
     * 展品标签列表
     */
    @Transient
    private List<CmsLabel> LabelList;


    /**
     * 展商信息
     */
    @Transient
    private SysUserExhibitor sysUserExhibitor;

    //是否收藏
    @Transient
    private CmsFavorites favorites;

    @Transient
    private List<Long> classificationIds;

    @Transient
    private List<Long> categoryIds;

    @OneToOne
    @JoinColumn(name = "user_id",insertable = false,updatable = false)
    private SysDept dept;

    @Column(name="qrcode")
    @ApiModelProperty(value = "展品二维码")
    private String qrcode;

    @Column(name="recommend")
    @ApiModelProperty(value = "推荐")
    private String recommend;

    @Transient
    private Long uv;

    @Transient
    private Long bookmarkCount;

    @ApiModelProperty(value = "访问量")
    @Column(name="pv")
    private Integer pv;

    @Transient
    private Boolean isUi;//是否是前端查询

}
