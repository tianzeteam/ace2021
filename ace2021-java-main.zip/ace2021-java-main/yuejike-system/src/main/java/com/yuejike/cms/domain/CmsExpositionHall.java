package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 博览会和场馆关联对象 cms_exposition_hall
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_exposition_hall")
@Data
public class CmsExpositionHall extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /**  */
    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long id;

    /** 博览会id */
    @Excel(name = "博览会id")
    @Column(name="exposition_id")
    @ApiModelProperty(value = "博览会id")
    private Long expositionId;

    /** 场馆id */
    @Excel(name = "场馆id")
    @Column(name="hall_id")
    @ApiModelProperty(value = "场馆id")
    private Long hallId;

    /** 删除标识 */
    @Column(name="del_flag")
    @ApiModelProperty(value = "场馆id")
    private String delFlag;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "场馆id")
    private Date createTime;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "场馆id")
    private Date updateTime;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "场馆id")
    private String createBy;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "场馆id")
    private String updateBy;


}
