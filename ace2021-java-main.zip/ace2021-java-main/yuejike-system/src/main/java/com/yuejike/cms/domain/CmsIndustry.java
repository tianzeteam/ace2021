package com.yuejike.cms.domain;

import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "cms_industry")
@Data
public class CmsIndustry extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "id")
    private Long id;

    /** industry_id 行业编码 */
    @Excel(name = "行业编码")
    @Column(name="industry_id")
    @ApiModelProperty(value = "行业编码")
    private String industryId;

    /** 行业名称 */
    @Excel(name = "name")
    @Column(name="name")
    @ApiModelProperty(value = "行业名称")
    private String name;

    /** 上级行业名称 */
    @Excel(name = "parent_id")
    @Column(name="parent_id")
    @ApiModelProperty(value = "上级行业名称")
    private String parentId;

    /** 分类级别 */
    @Excel(name = "level_type")
    @Column(name="level_type")
    @ApiModelProperty(value = "分类级别")
    private Integer levelType;

    /** 分类描述 */
    @Excel(name = "description")
    @Column(name="description")
    @ApiModelProperty(value = "分类描述")
    private String description;

    /** 是否隐藏不可见 */
    @Excel(name = "is_hided")
    @Column(name="is_hided")
    @ApiModelProperty(value = "是否隐藏不可见")
    private Integer isHided;

}
