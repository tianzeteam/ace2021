package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsIndustry;
import com.yuejike.cms.domain.SysUserExhibitorIndustry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface SysUserExhibitorIndustryDao extends JpaRepository<SysUserExhibitorIndustry, Long>, JpaSpecificationExecutor<CmsIndustry> {
}
