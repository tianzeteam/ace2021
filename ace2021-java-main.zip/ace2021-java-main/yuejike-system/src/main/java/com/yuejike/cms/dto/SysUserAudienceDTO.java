package com.yuejike.cms.dto;

import com.yuejike.cms.domain.CmsCity;
import com.yuejike.cms.domain.CmsCountry;
import com.yuejike.cms.domain.CmsProvince;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import com.yuejike.common.core.domain.entity.SysUser;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

/**
 * 专业观众信息对象 sys_user_audience
 *
 * @author tangdw
 * @since 1.0 2021-08-26
 */
@Data
public class SysUserAudienceDTO {

    private static final long serialVersionUID = 1L;

    /** 用户id */
    @ApiModelProperty(value = "专业观众ID")
    private Long userId;

   /** 删除标识 */
   @ApiModelProperty(value = "删除标识")
   private String delFlag;

   /** 创建人 */
   @ApiModelProperty(value = "创建人")
   private String createBy;

   /** 创建时间 */
   @ApiModelProperty(value = "创建时间")
   private Date createTime;

   /** 更新人 */
   @ApiModelProperty(value = "修改人")
   private String updateBy;

   /** 更新时间 */
   @ApiModelProperty(value = "修改时间")
   private Date updateTime;

    /** 公司名称 */
    @ApiModelProperty(value = "公司名称")
    private String companyName;

    /** 统一信用代码 */
    @ApiModelProperty(value = "统一信用代码")
    private String intent;

    /** 城市id */
    @ApiModelProperty(value = "城市id")
    private Long cityId;

    /** 国家id */
    @ApiModelProperty(value = "国家id")
    private Long countryId;

    /** 省份id */
    @ApiModelProperty(value = "省份id")
    private Long provinceId;

    @ApiModelProperty(value = "审核认证状态")
    private String reviewStatus;



}
