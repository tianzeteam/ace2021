package com.yuejike.cms.service.impl;

import com.yuejike.cms.dao.CmsLabelDao;
import com.yuejike.cms.dao.CmsProductDao;
import com.yuejike.cms.dao.SysUserExhibitorDao;
import com.yuejike.cms.domain.CmsLabel;
import com.yuejike.cms.domain.CmsProduct;
import com.yuejike.cms.domain.SysUserAudience;
import com.yuejike.cms.domain.SysUserExhibitor;
import com.yuejike.cms.service.ICmsProductService;
import com.yuejike.common.core.domain.entity.SysDept;
import com.yuejike.common.core.domain.entity.SysUser;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.DateUtils;
import com.yuejike.common.utils.SecurityUtils;
import com.yuejike.common.utils.code.BusinessBizCode;
import com.yuejike.system.service.ISysUserService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.*;
import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.util.*;

/**
 * 展品信息Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsProductServiceImpl implements ICmsProductService {

    @Autowired
    private CmsProductDao cmsProductDao;
    @Autowired
    private CmsLabelDao cmsLabelDao;
    @Autowired
    private SysUserExhibitorDao sysUserExhibitorDao;

    /**
     * 查询展品信息
     *
     * @param productId 展品信息ID
     * @return 展品信息
     */
    @Override
    public CmsProduct findById(Long productId) {
        CmsProduct cmsProduct = cmsProductDao.findById(productId).orElse(null);
        if (null != cmsProduct) {
            setLabelList(cmsProduct);
        }
        return cmsProduct;
    }

    /**
     * 分页查询展品信息列表
     *
     * @param req 展品信息
     * @return 展品信息
     */
    @Override
    public Page<CmsProduct> findCmsProductPage(CmsProduct req) {
        Specification<CmsProduct> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        // Sort sort = new Sort(Sort.Direction.ASC,Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("sort")).and(new Sort(Sort.Direction.DESC,Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime")));
        Pageable pageable = null;
        if (StringUtils.isNotBlank(req.getRecommend())) {
            pageable = PageRequest.of(pageDomain.getPageNo(),
                    Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                    // sort
                    Sort.unsorted()
            );

        }else{
            pageable = PageRequest.of(pageDomain.getPageNo(),
                    Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                    // sort
                    Sort.Direction.DESC,
                    Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("sort"),
                    Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime")
            );
        }
        Page<CmsProduct> page = cmsProductDao.findAll(example, pageable);
        page.getContent().forEach(cmsProduct -> {
            setLabelList(cmsProduct);
        });
        return page;
    }


    /**
     * 查询标签
     *
     * @param cmsProduct
     */
    private void setLabelList(CmsProduct cmsProduct) {
        String labelIds = cmsProduct.getLabelId();
        if (StringUtils.isNotBlank(labelIds)) {
            String[] labelIdArray = labelIds.trim().split(",");
            List<Long> idList = new ArrayList<>();
            for (String s : labelIdArray) {
                if (StringUtils.isNotBlank(s) && s.matches("^[0-9]*$")) {
                    idList.add(Long.valueOf(s));
                }
            }
            Specification<CmsLabel> example2 = this.formatQueryLabelByIds(idList);
            cmsProduct.setLabelList(cmsLabelDao.findAll(example2));
        }
    }

    /**
     * 批量查询标签
     */
    private Specification<CmsLabel> formatQueryLabelByIds(List<Long> labelIds) {
        if (null == labelIds) {
            throw new NullPointerException("labelIds 不能为 null");
        }
        Specification<CmsLabel> example2 = new Specification<CmsLabel>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsLabel> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                Predicate pre = root.get("labelId").in(labelIds);
                return cb.and(pre);
            }
        };
        return example2;
    }

    /**
     * 分页查询展品信息列表
     *
     * @param req 展品信息
     * @return 展品信息
     */
    @Override
    public List<CmsProduct> findCmsProductList(CmsProduct req) {
        Specification<CmsProduct> example = formatQueryParams(req);
        List<CmsProduct> list = cmsProductDao.findAll(example, Sort.by(Sort.Direction.DESC, "createTime"));
        return list;
    }

    private Specification<CmsProduct> formatQueryParams(CmsProduct req) {
        Specification<CmsProduct> example = new Specification<CmsProduct>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsProduct> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if(null != req.getIsUi() && req.getIsUi()) {
                    Subquery<SysUser> subQuery = query.subquery(SysUser.class);
                    Root<SysUser> root2 = subQuery.from(SysUser.class);
                    subQuery.select(root2.<SysUser> get("deptId"));
                    subQuery.where(cb.equal(root2.<String> get("reviewStatus"), "1"));
                    list.add(cb.in(root.get("userId")).value(subQuery));
                }
                if (null != req.getProductId()) {
                    Predicate pre = cb.equal(root.get("productId").as(Long.class), req.getProductId());
                    list.add(pre);
                }
                if (null != req.getUserId()) {
                    Predicate pre = cb.equal(root.get("userId").as(Long.class), req.getUserId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getName())) {
                    Predicate pre = cb.like(root.get("name").as(String.class), "%" + req.getName() + "%");
                    list.add(pre);
                }
                if (null != req.getClassificationId()) {
                    //查询当前节点下的子节点
                    if(null != req.getClassificationIds() && req.getClassificationIds().size() >0){
                        List<Predicate> predicates= new ArrayList<>();
                        for (Long cc:req.getClassificationIds()){
                            Predicate pre = cb.equal(root.get("classificationId").as(Long.class),cc);
                            predicates.add(pre);
                        }
                        //添加or条件
                        Predicate predicateOr = cb.or(predicates.toArray(new Predicate[predicates.size()]));
                        predicateOr = cb.and(predicateOr);
                        list.add(predicateOr);
                    }else{//无子节点
                        Predicate pre = cb.equal(root.get("classificationId").as(Long.class), req.getClassificationId());
                        list.add(pre);
                    }
                }
                if (null != req.getCategoryId()) {
                    if(null != req.getCategoryIds() && req.getCategoryIds().size() > 0) {
                        List<Predicate> predicates= new ArrayList<>();
                        for (Long cc:req.getCategoryIds()){
                            Predicate pre = cb.equal(root.get("categoryId").as(Long.class),cc);
                            predicates.add(pre);
                        }
                        //添加or条件
                        Predicate predicateOr = cb.or(predicates.toArray(new Predicate[predicates.size()]));
                        predicateOr = cb.and(predicateOr);
                        list.add(predicateOr);
                    }else{
                        Predicate pre = cb.equal(root.get("categoryId").as(Long.class), req.getCategoryId());
                        list.add(pre);
                    }
                }else if(null != req.getCategoryIds() && req.getCategoryIds().size() > 0) {
                    List<Predicate> predicates= new ArrayList<>();
                    for (Long cc:req.getCategoryIds()){
                        Predicate pre = cb.equal(root.get("categoryId").as(Long.class),cc);
                        predicates.add(pre);
                    }
                    //添加or条件
                    Predicate predicateOr = cb.or(predicates.toArray(new Predicate[predicates.size()]));
                    predicateOr = cb.and(predicateOr);
                    list.add(predicateOr);
                }
                if (StringUtils.isNotBlank(req.getDetail())) {
                    Predicate pre = cb.equal(root.get("detail").as(String.class), req.getDetail());
                    list.add(pre);
                }
                if (null != req.getReviewerId()) {
                    Predicate pre = cb.equal(root.get("reviewerId").as(Long.class), req.getReviewerId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getStatus())) {
                    Predicate pre = cb.equal(root.get("status").as(String.class), req.getStatus());
                    list.add(pre);
                }
                if (null != req.getMinPrice()) {
                    Predicate pre = cb.equal(root.get("minPrice").as(BigDecimal.class), req.getMinPrice());
                    list.add(pre);
                }
                if (null != req.getMaxPrice()) {
                    Predicate pre = cb.equal(root.get("maxPrice").as(BigDecimal.class), req.getMaxPrice());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getShipAddress())) {
                    Predicate pre = cb.equal(root.get("shipAddress").as(String.class), req.getShipAddress());
                    list.add(pre);
                }
                if (null != req.getMinOrder()) {
                    Predicate pre = cb.equal(root.get("minOrder").as(Long.class), req.getMinOrder());
                    list.add(pre);
                }
                if (null != req.getMaxOrder()) {
                    Predicate pre = cb.equal(root.get("maxOrder").as(Long.class), req.getMaxOrder());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getModel())) {
                    Predicate pre = cb.like(root.get("model").as(String.class), "%"+req.getModel()+"%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getColor())) {
                    Predicate pre = cb.like(root.get("color").as(String.class), "%"+req.getColor()+"%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getMaterial())) {
                    Predicate pre = cb.equal(root.get("material").as(String.class), req.getMaterial());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getSize())) {
                    Predicate pre = cb.equal(root.get("size").as(String.class), req.getSize());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getFeatures())) {
                    Predicate pre = cb.equal(root.get("features").as(String.class), req.getFeatures());
                    list.add(pre);
                }
                if (null != req.getSort()) {
                    Predicate pre = cb.equal(root.get("sort").as(Integer.class), req.getSort());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())) {
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())) {
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (null != req.getCreateTime()) {
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())) {
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()) {
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getVisible())) {
                    Predicate pre = cb.equal(root.get("visible").as(String.class), req.getVisible());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getVideoUrl())) {
                    Predicate pre = cb.equal(root.get("videoUrl").as(String.class), req.getVideoUrl());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getLabelId())) {
                    // Predicate pre = cb.equal(root.get("labelId").as(String.class), req.getLabelId());
                    // list.add(pre);
                    String[] labelIds = req.getLabelId().split(",");
                    List<Predicate> predicate1 =new ArrayList<>();
                    for (String s:labelIds){
                        Predicate pre = cb.like(root.get("labelId").as(String.class),"%"+ s +"%");
                        predicate1.add(pre);
                    }
                    //添加or条件
                    Predicate predicateOr = cb.or(predicate1.toArray(new Predicate[predicate1.size()]));
                    predicateOr = cb.and(predicateOr);
                    list.add(predicateOr);
                }
                if (StringUtils.isNotBlank(req.getExhibitorName())) {
                    Predicate pre = cb.like(root.get("exhibitorName").as(String.class), "%"+req.getExhibitorName()+"%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getProductSpec())) {
                    Predicate pre = cb.equal(root.get("productSpec").as(String.class), req.getProductSpec());
                    list.add(pre);
                }
                //判断渠道数据权限
                LoginUser loginUser = SecurityUtils.getLoginUserNoThrow();
                boolean isChannel = (loginUser != null && loginUser.getUser() != null
                        && loginUser.getUser().getRoles() != null && loginUser.getUser().getRoles()
                        .stream().filter(item -> item.getRoleKey().startsWith("channel")).count()>0);
                if(isChannel){
                    Subquery subQuery = query.subquery(String.class);
                    Root from = subQuery.from(SysUser.class);
                    //创建子查询条件对象('where'后的语句对象)
                    Predicate predicate1 = cb.conjunction();
                    predicate1 = cb.and(predicate1,cb.equal(from.get("channelId"), loginUser.getUser().getUserId()));
                    //完成子查询
                    subQuery.select(from.get("deptId")).where(predicate1);
                    //把子查询结果拼接到原查询语句后面---这里是dept_id in的写法
                    //过滤渠道用户数据权限
                    Predicate deptPre = cb.conjunction();
                    deptPre = cb.and(deptPre, cb.in(root.get("userId")).value(subQuery));
                    list.add(deptPre);
                }
                //主办方按展区过滤数据权限
                if(loginUser != null && loginUser.getUser() != null && loginUser.getUser().getUserType().equals(UserType.ZBF_JS.getCode())){
                    List<Long> planIds = new ArrayList<>();
                    if(loginUser.getUser().getRoles() != null){
                        loginUser.getUser().getRoles().forEach(role -> {
                            if(com.yuejike.common.utils.StringUtils.isNotEmpty(role.getPlanIds())) {
                                Arrays.stream(role.getPlanIds().split(",")).forEach(it -> {
                                    if(!planIds.contains(Long.valueOf(it))){
                                        planIds.add(Long.valueOf(it));
                                    }
                                });
                            }
                        });
                    }
                    CriteriaBuilder.In<Long> in = cb.in(root.get("userId"));
                    List<Long> tmpUsers = null;
                    if(planIds.size()>0){
                        tmpUsers = sysUserExhibitorDao.getExhibitorDeptIdByPlanIds(planIds);
                    }
                    if(tmpUsers != null && tmpUsers.size()>0){
                        tmpUsers.forEach(user -> in.value(user));
                    }else{
                        in.value(0L);
                    }
                    Predicate deptPre = cb.conjunction();
                    deptPre = cb.and(deptPre, in);
                    list.add(deptPre);
                }
                //判断是否推荐
                if (StringUtils.isNotBlank(req.getRecommend())) {
                    Predicate pre = cb.equal(root.get("recommend").as(String.class), req.getRecommend());
                    list.add(pre);

                    PageDomain pageDomain = TableSupport.buildPageRequest();
                    List<Long> productIds = cmsProductDao.getRandProductIds(req.getRecommend(),
                            Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE));
                    if(productIds != null && productIds.size()>0){
                        CriteriaBuilder.In<Long> in = cb.in(root.get("productId"));
                        productIds.forEach(it -> in.value(it));
                        list.add(cb.and(in));
                    }

                }

                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）展品信息
     *
     * @param cmsProduct 展品信息
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void save(CmsProduct cmsProduct) {
        if(cmsProduct.getProductId() == null){
            cmsProduct.setCreateTime(DateUtils.getNowDate());
//            // 默认排序值最大
//            Integer curSortNo = cmsProductDao.getMaxSortNo();
//            cmsProduct.setSort(curSortNo==null?0:curSortNo+1);
            cmsProduct.setSort(0);
            cmsProduct.setRecommend("0");
        }
        cmsProductDao.save(cmsProduct);
    }


    /**
     * 批量删除展品信息
     *
     * @param productIds 需要删除的展品信息ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> productIds) {
        List<CmsProduct> existBeans = cmsProductDao.findAllById(productIds);
        if (!existBeans.isEmpty()) {
            cmsProductDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除展品信息信息
     *
     * @param productId 展品信息ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsProductById(Long productId) {
        cmsProductDao.deleteById(productId);
    }


    /**
     * 场馆审核
     *
     * @param cmsProduct
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public int updateAuditStatus(CmsProduct cmsProduct) {
        CmsProduct cmsProduct2 = cmsProductDao.findById(cmsProduct.getProductId()).get();
        cmsProduct2.setStatus(cmsProduct.getStatus());
        cmsProduct2.setSort(cmsProduct.getSort());
        cmsProduct2.setUpdateBy(cmsProduct.getUpdateBy());
        cmsProduct2.setUpdateTime(new Date());
        cmsProduct2.setAuditAdvice(cmsProduct.getAuditAdvice());
        cmsProductDao.save(cmsProduct2);
        return BusinessBizCode.OPTION_SUCCESS.getCode();
    }

    /**
     * 上下架状态状态修改
     *
     * @param cmsProduct
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public int updateVisibleStatus(CmsProduct cmsProduct) {
        CmsProduct cmsProduct2 = cmsProductDao.findById(cmsProduct.getProductId()).get();
        cmsProduct2.setVisible(cmsProduct.getVisible());
//        cmsProduct2.setSort(cmsProduct.getSort());
        cmsProduct2.setUpdateBy(cmsProduct.getUpdateBy());
        cmsProduct2.setUpdateTime(new Date());
        cmsProductDao.save(cmsProduct2);
        return BusinessBizCode.OPTION_SUCCESS.getCode();
    }

    @Override
    public int findByClassificationId(Long classificationId) {
        return cmsProductDao.findByClassificationId(classificationId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void batchReSorted(List<CmsProduct> cmsProducts) {
        cmsProducts.forEach(cmsProduct -> {
            CmsProduct cmsProduct2 = cmsProductDao.findById(cmsProduct.getProductId()).get();
            cmsProduct.setPv(cmsProduct2.getPv());
        });
        cmsProductDao.saveAll(cmsProducts);
    }

    @Override
    @Transactional(readOnly = false)
    public int batchRecommend(Long[] productIds, String type) {
        return cmsProductDao.batchRecommend(Arrays.asList(productIds), type);
    }

    public Long getAllCount(){
        Specification<CmsProduct> example = new Specification<CmsProduct>() {

            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsProduct> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder cb) {
                return cb.equal(root.get("status").as(String.class), "1");
            }

        };
        return cmsProductDao.count(example);
    }
}
