package com.yuejike.cms.domain;

import com.yuejike.common.core.domain.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.sql.Timestamp;

/**
 * @author JinZJ
 * @version 1.0
 * @Description: 3D形象
 * @date 2021/11/17 17:07
 */
@Entity
@Table(name = "v3d_receptionist")
@Setter
@Getter
public class Receptionist extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "id")
    private Long id;

    @NotNull(message = "形象名称不能为空")
    @ApiModelProperty(value = "形象名称")
    @Column(name = "name")
    private String name;

    @NotNull(message = "形象路径不能为空")
    @ApiModelProperty(value = "形象路径")
    @Column(name = "path")
    private String path;

    @CreationTimestamp
    @Column(name = "create_time", updatable = false)
    @ApiModelProperty(value = "创建时间", hidden = true)
    private Timestamp createTime;

    @Column(name = "create_by", updatable = false)
    @ApiModelProperty(value = "创建人", hidden = true)
    private String createBy;

}
