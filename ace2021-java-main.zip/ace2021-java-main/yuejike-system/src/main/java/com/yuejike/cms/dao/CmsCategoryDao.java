package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * 栏目管理Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Repository
public interface CmsCategoryDao extends JpaRepository<CmsCategory, Long>, JpaSpecificationExecutor<CmsCategory> {

    @Query(value = "select cc.*,ccp.cn_name parentName,cm.name modelName from cms_category cc \n" +
            "left join cms_category ccp on cc.parent_id = ccp.category_id\n" +
            "left join cms_model cm on cc.model_id = cm.model_id\n" +
            "where cc.del_flag = '0' or cc.del_flag is null\n" +
            "and cc.category_id = :#{#cmsCategory.categoryId}\n" +
            "and cc.cn_name = :#{#cmsCategory.cnName}\n" +
            "and cc.en_name = :#{#cmsCategory.enName}\n" +
            "and cc.img_url = :#{#cmsCategory.imgUrl}\n" +
            "and cc.descrip = :#{#cmsCategory.descrip}\n" +
            "and cc.keyword = :#{#cmsCategory.keyword}\n" +
            "and cc.link = :#{#cmsCategory.link}\n" +
            "and cc.parent_id = :#{#cmsCategory.parentId}\n" +
            "and cc.model_id = :#{#cmsCategory.modelId}\n" +
            "and cc.sort = :#{#cmsCategory.sort}\n" +
            "and cc.is_link = :#{#cmsCategory.isLink}", nativeQuery = true)
    List<CmsCategory> findCmsCategorgFullList(@Param("cmsCategory")CmsCategory cmsCategory);

}
