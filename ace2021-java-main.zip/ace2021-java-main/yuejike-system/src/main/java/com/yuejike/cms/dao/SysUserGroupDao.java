package com.yuejike.cms.dao;

import com.yuejike.cms.domain.SysUserGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * 标签分组Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Repository
public interface SysUserGroupDao extends JpaRepository<SysUserGroup, Long>, JpaSpecificationExecutor<SysUserGroup> {


    List<SysUserGroup> findByGroupIdIn(List<Long> groupIds);


    SysUserGroup findByName(String name);




}
