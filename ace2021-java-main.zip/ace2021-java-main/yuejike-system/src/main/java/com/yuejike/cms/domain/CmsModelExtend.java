package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 模型扩展信息对象 cms_model_extend
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_model_extend")
@Data
public class CmsModelExtend extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long id;

    /** 模型id */
    @Excel(name = "模型id")
    @Column(name="model_id")
    @ApiModelProperty(value = "模型id")
    private Long modelId;

    /** 中文字段名 */
    @Excel(name = "中文字段名")
    @Column(name="cn_field")
    @ApiModelProperty(value = "中文字段名")
    private String cnField;

    /** 英文字段名 */
    @Excel(name = "英文字段名")
    @Column(name="en_field")
    @ApiModelProperty(value = "英文字段名")
    private String enField;

    /** 字段类型 */
    @Excel(name = "字段类型")
    @Column(name="field_type")
    @ApiModelProperty(value = "字段类型")
    private String fieldType;

    /** 备注说明 */
    @Excel(name = "备注说明")
    @Column(name="remark")
    @ApiModelProperty(value = "备注说明")
    private String remark;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "备注说明")
    private Date createTime;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "备注说明")
    private Date updateTime;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "备注说明")
    private String createBy;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "备注说明")
    private String updateBy;

    /** 删除标识 */
    @Column(name="del_flag")
    @ApiModelProperty(value = "备注说明")
    private String delFlag;

    /** 对应字典 */
    @Column(name="dict_type")
    @ApiModelProperty(value = "对应字典")
    private String dictType;


    // 模型
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "model_id",referencedColumnName = "model_id",insertable = false,updatable = false,foreignKey = @ForeignKey(name = "none",value = ConstraintMode.NO_CONSTRAINT))
    private CmsModel model;



}
