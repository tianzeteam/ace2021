package com.yuejike.cms.service;

import java.util.List;
import java.util.Map;

/**
 * @author JinZJ
 * @version 1.0
 * @Description:
 * @date 2021/11/25 15:57
 */
public interface ISysAccessRecService {

    void addVisit(String path);

    Map getBaseStatistics();

    Long getProductUv(Long productId);

    List<Map<String, Long>> getProductUv(Long[] productIds);

    Map getWholeSituation();

    Map getOverallViewing();

    void addGateCounter();

    Map getRegistration();

    List<Map> getExhibitorSource();

    List<Map> getAudienceSource();

    List<Map> getPopularExhibitors();

    List<Map> getPopularProduct();

    List<Map> getExhibitionHallCount();

    List<Map> getIntendedTransaction();

    Map<String, Long> pendingApprovalData();
}
