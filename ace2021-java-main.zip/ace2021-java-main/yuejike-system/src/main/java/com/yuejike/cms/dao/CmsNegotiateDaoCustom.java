package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsNegotiate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

@Repository
public interface CmsNegotiateDaoCustom {
    Page<CmsNegotiate> findNegotiatePage(CmsNegotiate negotiate, Pageable pageable);
}
