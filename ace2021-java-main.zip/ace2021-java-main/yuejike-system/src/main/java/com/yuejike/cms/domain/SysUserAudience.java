package com.yuejike.cms.domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import com.yuejike.common.core.domain.entity.SysUser;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 专业观众信息对象 sys_user_audience
 *
 * @author tangdw
 * @since 1.0 2021-08-26
 */
@Entity
@Table(name = "sys_user_audience")
@Data
// @JsonIgnoreProperties(value = {"hibernateLazyInitializer"})
public class SysUserAudience extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** 用户id */
    @Id
    @Column(name="user_id")
    @ApiModelProperty(value = "专业观众ID")
    private Long userId;

    /** 删除标识 */
    @Column(name="del_flag")
    @ApiModelProperty(value = "删除标识")
    private String delFlag;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "创建人")
    private String createBy;

    /** 创建时间 */
    @Excel(name = "提交时间")
    @Column(name="create_time")
    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "修改人")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "修改时间")
    private Date updateTime;

    @Excel(name = "用户名称")
    @Transient
    private String userName;

    @Excel(name = "手机号")
    @Transient
    private String phoneNumber;

    @Excel(name = "邮箱")
    @Transient
    private String email;

    /** 公司名称 */
    @Excel(name = "公司名称")
    @Column(name="company_name")
    @ApiModelProperty(value = "公司名称")
    private String companyName;

    /** 统一信用代码 */
    @Excel(name = "统一信用代码")
    @Column(name="intent")
    @ApiModelProperty(value = "统一信用代码")
    private String intent;

    /** 城市id */
//    @Excel(name = "城市id")
    @Column(name="city_id")
    @ApiModelProperty(value = "城市id")
    private Long cityId;


    @Excel(name = "国家")
    @Transient
    private String countryName;

    @Excel(name = "省份")
    @Transient
    private String provinceName;

    @Excel(name = "城市")
    @Transient
    private String cityName;


    /** 国家id */
//    @Excel(name = "国家id")
    @Column(name="country_id")
    @ApiModelProperty(value = "国家id")
    private Long countryId;

    /** 省份id */
//    @Excel(name = "省份id")
    @Column(name="province_id")
    @ApiModelProperty(value = "省份id")
    private Long provinceId;



    @OneToOne
    @JoinColumn(name = "user_id",insertable = false,updatable = false)
    private SysUser user;

    @Excel(name = "审核状态")
    @Transient
    private String reviewStatus;

    // 国家
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "country_id",referencedColumnName = "country_id",insertable = false,updatable = false,foreignKey = @ForeignKey(name = "none",value = ConstraintMode.NO_CONSTRAINT))
    private CmsCountry country;
    // 省份
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "province_id",referencedColumnName = "province_id",insertable = false,updatable = false,foreignKey = @ForeignKey(name = "none",value = ConstraintMode.NO_CONSTRAINT))
    private CmsProvince province;
    // 城市
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "city_id",referencedColumnName = "city_id",insertable = false,updatable = false,foreignKey = @ForeignKey(name = "none",value = ConstraintMode.NO_CONSTRAINT))
    private CmsCity city;
}
