package com.yuejike.cms.dto;

import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


/**
 * @author song
 * @date 2021年09月16日 18:23
 */
@Data
public class MessageDTO extends BaseEntity {

    @Excel(name = "手机号码",type = Excel.Type.IMPORT)
    private String phone;
}
