package com.yuejike.cms.service;


import com.yuejike.cms.domain.CmsLiveAppointment;


import java.util.Date;
import java.util.List;

/**
 * 直播预约Service接口
 *
 * @author cian
 * @since 1.0 2021-11-11
 */
public interface ICmsLiveAppointmentService {

    /**
     * 查询预约列表
     *
     * @param req 直播
     * @return 直播集合
     */
    List<CmsLiveAppointment> findCmsLiveList(CmsLiveAppointment req, Date example_start_date, Date example_end_date);

    /**
     * 新增直播预约
     *
     * @param cmsLiveAppointment 直播
     * @return 结果
     */
    CmsLiveAppointment save(CmsLiveAppointment cmsLiveAppointment);

    /**
     * 预约通知任务
     */
    void scheduler_live_notice();
}
