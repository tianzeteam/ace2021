package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsConference;

/**
 * 线下会议Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsConferenceService  {
    /**
     * 查询线下会议
     *
     * @param conferenceId 线下会议ID
     * @return 线下会议
     */
    CmsConference findById(Long conferenceId);

    /**
     * 分页查询线下会议列表
     *
     * @param req 线下会议
     * @return 线下会议集合
     */
    Page<CmsConference> findCmsConferencePage(CmsConference req);

    /**
     * 查询线下会议列表
     *
     * @param req 线下会议
     * @return 线下会议集合
     */
    List<CmsConference> findCmsConferenceList(CmsConference req);

    /**
     * 新增线下会议
     *
     * @param cmsConference 线下会议
     * @return 结果
     */
    void save(CmsConference cmsConference);

    /**
     * 批量删除线下会议
     *
     * @param conferenceIds 需要删除的线下会议ID
     * @return 结果
     */
    void deleteByIds(List<Long> conferenceIds);

    /**
     * 删除线下会议信息
     *
     * @param conferenceId 线下会议ID
     * @return 结果
     */
    void deleteCmsConferenceById(Long conferenceId);

    void batchAudit(Long[] conferenceIds, CmsConference cmsConference);
}
