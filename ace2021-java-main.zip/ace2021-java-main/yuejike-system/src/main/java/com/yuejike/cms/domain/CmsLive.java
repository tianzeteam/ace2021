package com.yuejike.cms.domain;

import java.util.Date;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 直播对象 cms_live
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_live")
@Data
public class CmsLive extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="live_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long liveId;

    /** 直播名称 */
    @Excel(name = "直播名称")
    @Column(name="name")
    @ApiModelProperty(value = "直播名称")
    private String name;

    /** 直播开始时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @Excel(name = "直播开始时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    @Column(name="start_time")
    @ApiModelProperty(value = "直播开始时间")
    private Date startTime;

    /** 直播结束时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @Excel(name = "直播结束时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    @Column(name="end_time")
    @ApiModelProperty(value = "直播结束时间")
    private Date endTime;

    /** 直播类型（0：论坛直播 1：活动直播） */
    @Excel(name = "直播类型", readConverterExp = "0=：论坛直播,1=：活动直播")
    @Column(name="type")
    @ApiModelProperty(value = "直播类型")
    private String type;

    /** 直播介绍 */
    @Excel(name = "直播介绍")
    @Column(name="introduce")
    @ApiModelProperty(value = "直播介绍")
    private String introduce;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "直播介绍")
    private Date createTime;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "直播介绍")
    private Date updateTime;

    /** 创建者 */
    @Column(name="create_by")
    @ApiModelProperty(value = "直播介绍")
    private String createBy;

    /** 创建者类型（0：主办方1：参展商） */
    @Excel(name = "创建者类型", readConverterExp = "0=：主办方1：参展商")
    @Column(name="create_type")
    @ApiModelProperty(value = "创建者类型")
    private String createType;

    /** 创建直播人id */
    @Excel(name = "创建直播人id")
    @Column(name="create_id")
    @ApiModelProperty(value = "创建直播人id")
    private Long createId;

    /** 展商部门id */
    @Excel(name = "展商部门id")
    @Column(name="dept_id")
    @ApiModelProperty(value = "展商部门id")
    private Long deptId;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "创建直播人id")
    private String updateBy;

    /** 删除标识 */
    @Column(name="del_flag")
    @ApiModelProperty(value = "创建直播人id")
    private String delFlag;

    /** 审核人id */
    @Excel(name = "审核人id")
    @Column(name="reviewer_id")
    @ApiModelProperty(value = "审核人id")
    private Long reviewerId;

    /** 审核状态(0:待审核 1：已通过 2：已拒绝) */
    @Excel(name = "审核状态(0:待审核 1：已通过 2：已拒绝)")
    @Column(name="status")
    @ApiModelProperty(value = "审核状态(0:待审核 1：已通过 2：已拒绝)")
    private String status;

    /** 授权类型（0：全部可见02参展商03会议代表04媒体05专业观众06观众） */
    @Excel(name = "授权类型", readConverterExp = "02参展商03会议代表04媒体05专业观众06观众")
    @Column(name="empower")
    @ApiModelProperty(value = "授权类型")
    private String empower;

    /** 点播视频id或者直播回放id */
    @Excel(name = "点播视频id或者直播回放id")
    @Column(name="video_id")
    @ApiModelProperty(value = "点播视频id或者直播回放id")
    private String videoId;

    /** 百家云直播房间id */
    @Excel(name = "百家云直播房间id")
    @Column(name="room_id")
    @ApiModelProperty(value = "百家云直播房间id")
    private String roomId;

    /** 文件名 */
    @Excel(name = "文件名")
    @Column(name="upfile_name")
    @ApiModelProperty(value = "文件名")
    private String upfileName;

    /** 主题 */
    @Excel(name = "主题")
    @Column(name="theme")
    @ApiModelProperty(value = "主题")
    private String theme;

    /** 直播进程状态（0：未开始 1：进行中 2：已结束） */
    @Excel(name = "直播进程状态", readConverterExp = "0=：未开始,1=：进行中,2=：已结束")
    @Column(name="process")
    @ApiModelProperty(value = "直播进程状态")
    private String process;

    /** 直播封面图 */
    @Excel(name = "直播封面图")
    @Column(name="cover_picture")
    @ApiModelProperty(value = "直播封面图")
    private String coverPicture;

    /** 排序 */
    @Excel(name = "排序")
    @Column(name="sort")
    @ApiModelProperty(value = "排序")
    private Integer sort;

    /** 直播外部链接 */
    @Excel(name = "直播外部链接")
    @Column(name="live_url")
    @ApiModelProperty(value = "直播外部链接")
    private String liveUrl;

    /** 直播形式（0：在线直播1：外部链接直播 2：图文直播） */
    @Excel(name = "直播形式", readConverterExp = "0=：在线直播1：外部链接直播,2=：图文直播")
    @Column(name="live_form")
    @ApiModelProperty(value = "直播形式")
    private String liveForm;

    @Excel(name = "博览会id")
    @Column(name="exposition_id")
    @ApiModelProperty(value = "博览会id")
    private Long expositionId;

    @Excel(name = "限制人数")
    @Column(name="limit_number_people")
    @ApiModelProperty(value = "限制人数")
    private Integer limitNumberPeople;


    @Excel(name = "显示状态(0:上架1:下架)")
    @Column(name="visible")
    @ApiModelProperty(value = "显示状态")
    private String visible;

    @Excel(name = "可见的分组id")
    @Column(name="group_id")
    @ApiModelProperty(value = "可见的分组id")
    private String groupId;

    @Excel(name = "审核时间")
    @Column(name="review_time")
    @ApiModelProperty(value = "审核时间")
    private Date reviewTime;


    @Excel(name = "审核拒绝原因")
    @Column(name="review_reject_reason")
    @ApiModelProperty(value = "审核拒绝原因")
    private String reviewRejectReason;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "create_id",referencedColumnName = "user_id",insertable = false,updatable = false)
    private SysUserExhibitor userExhibitor;

    @Excel(name = "管理员码")
    @Column(name="admin_code")
    @ApiModelProperty(value = "管理员码")
    private String adminCode;

    @Excel(name = "学生码")
    @Column(name="student_code")
    @ApiModelProperty(value = "学生码")
    private String studentCode;

    @Excel(name = "教师码")
    @Column(name="teacher_code")
    @ApiModelProperty(value = "教师码")
    private String teacherCode;

    @Transient
    private Integer enrollNumber;

    /**
     * 是否是审核操作（0：不是1：是）
     */
    @Transient
    private String isReview;

    //是否是ui请求列表(0:否1：是)
    @Transient
    private String isUiList;
}
