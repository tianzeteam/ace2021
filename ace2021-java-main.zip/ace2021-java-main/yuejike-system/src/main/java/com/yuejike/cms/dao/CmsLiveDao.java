package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsLive;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


/**
 * 直播Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Repository
public interface CmsLiveDao extends JpaRepository<CmsLive, Long>, JpaSpecificationExecutor<CmsLive> {

    @Query(value = "select * from cms_live where room_id=?1",nativeQuery = true)
    CmsLive findByRoomId(String roomId);
}
