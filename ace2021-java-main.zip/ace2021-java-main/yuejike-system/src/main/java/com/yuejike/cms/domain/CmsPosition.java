package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 位置信息管理对象 cms_position
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_position")
@Data
public class CmsPosition extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="position_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long positionId;

    /** 位置名称 */
    @Excel(name = "位置名称")
    @Column(name="position_title")
    @ApiModelProperty(value = "位置名称")
    private String positionTitle;

    /** 状态(0:正常:1:弃用) */
    @Excel(name = "状态(0:正常:1:弃用)")
    @Column(name="status")
    @ApiModelProperty(value = "状态(0:正常:1:弃用)")
    private String status;

    /** 删除标识 */
    @Column(name="del_flag")
    @ApiModelProperty(value = "状态(0:正常:1:弃用)")
    private String delFlag;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "状态(0:正常:1:弃用)")
    private String createBy;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "状态(0:正常:1:弃用)")
    private Date createTime;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "状态(0:正常:1:弃用)")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "状态(0:正常:1:弃用)")
    private Date updateTime;

    /** 备注 */
    @Excel(name = "备注")
    @Column(name="remark")
    @ApiModelProperty(value = "备注")
    private String remark;

    @Excel(name = "图片建议尺寸")
    @Column(name="banner_size")
    @ApiModelProperty(value = "图片建议尺寸")
    private String bannerSize;

    @Excel(name = "博览会id")
    @Column(name="exposition_id")
    @ApiModelProperty(value = "博览会id")
    private Long expositionId;
}
