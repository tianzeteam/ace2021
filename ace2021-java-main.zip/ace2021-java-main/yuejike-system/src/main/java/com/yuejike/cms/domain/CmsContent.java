package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 文章对象 cms_content
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_content")
@Data
public class CmsContent extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="content_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long contentId;

    /** 标题 */
    @Excel(name = "标题")
    @Column(name="title")
    @ApiModelProperty(value = "标题")
    private String title;

    /** 栏目id */
    @Excel(name = "栏目id")
    @Column(name="category_id")
    @ApiModelProperty(value = "栏目id")
    private Long categoryId;

    @OneToOne
    @JoinColumn(name = "category_id",insertable = false,updatable = false)
    private CmsCategory cmsCategory;

    /** 跳转链接 */
    @Excel(name = "跳转链接")
    @Column(name="link")
    @ApiModelProperty(value = "跳转链接")
    private String link;

    /** 文章内容 */
    @Excel(name = "文章内容")
    @Column(name="details")
    @ApiModelProperty(value = "文章内容")
    private String details;

    /** 关键字 */
    @Excel(name = "关键字")
    @Column(name="keyword")
    @ApiModelProperty(value = "关键字")
    private String keyword;

    /** 文章缩略图 */
    @Excel(name = "文章缩略图")
    @Column(name="img_url")
    @ApiModelProperty(value = "文章缩略图")
    private String imgUrl;

    /** 排序 */
    @Excel(name = "排序")
    @Column(name="sort")
    @ApiModelProperty(value = "排序")
    private Integer sort;

    /** 发布时间 */
    @JsonFormat(pattern = "yyyy-MM-dd",timezone = "GMT+8")
    @Excel(name = "发布时间", width = 30, dateFormat = "yyyy-MM-dd")
    @Column(name="push_time")
    @ApiModelProperty(value = "发布时间")
    private Date pushTime;

    /** 来源 */
    @Excel(name = "来源")
    @Column(name="source")
    @ApiModelProperty(value = "来源")
    private String source;

    /** 作者 */
    @Excel(name = "作者")
    @Column(name="author")
    @ApiModelProperty(value = "作者")
    private String author;

    /** 显示/隐藏(0:显示1：隐藏) */
    @Excel(name = "显示/隐藏(0:显示1：隐藏)")
    @Column(name="visible")
    @ApiModelProperty(value = "显示/隐藏(0:显示1：隐藏)")
    private String visible;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "显示/隐藏(0:显示1：隐藏)")
    private Date createTime;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "显示/隐藏(0:显示1：隐藏)")
    private Date updateTime;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "显示/隐藏(0:显示1：隐藏)")
    private String createBy;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "显示/隐藏(0:显示1：隐藏)")
    private String updateBy;

    /** 删除标识(0:正常1:删除) */
    @Column(name="del_flag")
    @ApiModelProperty(value = "显示/隐藏(0:显示1：隐藏)")
    private String delFlag;

    /** 模型扩展字段json数据 */
    @Column(name="model_extend_data")
    @ApiModelProperty(value = "模型扩展字段json数据")
    private String modelExtendData;

//    @Column(name="cid.category_name")
//    @ApiModelProperty(value = "栏目名称")
//    private String categoryName;
    @Transient
    private String systematics;

    @Column(name="review_id")
    @ApiModelProperty(value = "审核人id")
    private Long reviewId;

    @Column(name="review_time")
    @ApiModelProperty(value = "审核时间")
    private Date reviewTime;

    @Column(name="review_reject_reason")
    @ApiModelProperty(value = "审核建议")
    private String reviewRejectReason;

    @Column(name="review_status")
    @ApiModelProperty(value = "审核状态")
    private String reviewStatus;

    @Column(name="create_id")
    @ApiModelProperty(value = "创建人id")
    private Long createId;

    // 是否是投稿（0：否1：是）
    @Column(name="is_contribution")
    @ApiModelProperty(value = "是否是投稿")
    private String isContribution;


}
