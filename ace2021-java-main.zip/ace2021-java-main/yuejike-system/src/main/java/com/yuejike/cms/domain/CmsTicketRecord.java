package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 门票预约记录对象 cms_ticket_record
 *
 * @author tangdw
 * @since 1.0 2021-10-18
 */
@Entity
@Table(name = "cms_ticket_record")
@Data
public class CmsTicketRecord extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long id;

    /** 用户id */
    @Column(name="user_id")
    @ApiModelProperty(value = "${comment}")
    private Long userId;

    /** 用户姓名 */
    @Excel(name = "用户姓名")
    @Column(name="user_name")
    @ApiModelProperty(value = "用户姓名")
    private String userName;

    /** 身份证号码 */
    @Excel(name = "身份证号码")
    @Column(name="id_card")
    @ApiModelProperty(value = "身份证号码")
    private String idCard;

    /** 证件类型 */
    @Excel(name = "证件类型")
    @Column(name="card_type")
    @ApiModelProperty(value = "证件类型")
    private String cardType;

    /** 开始时间 */
    @JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss",timezone = "GMT+8")
    @Excel(name = "开始时间", width = 30, dateFormat = "yyyy-MM-dd hh:mm:ss")
    @Column(name="start_time")
    @ApiModelProperty(value = "开始时间")
    private Date startTime;

    /** 结束时间 */
    @JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss",timezone = "GMT+8")
    @Excel(name = "结束时间", width = 30, dateFormat = "yyyy-MM-dd hh:mm:ss")
    @Column(name="end_time")
    @ApiModelProperty(value = "结束时间")
    private Date endTime;

    /** 是否是vip（0：否1：是） */
    @Excel(name = "是否是vip", readConverterExp = "0=：否1：是")
    @Column(name="is_vip")
    @ApiModelProperty(value = "是否是vip")
    private String isVip;

    /** 二维码地址 */
    @Excel(name = "二维码地址")
    @Column(name="code_address")
    @ApiModelProperty(value = "二维码地址")
    private String codeAddress;

    /** 门票号码 */
    @Excel(name = "门票号码")
    @Column(name="ticket_number")
    @ApiModelProperty(value = "门票号码")
    private String ticketNumber;

    /** 是否使用过（0：否1：是） */
    @Excel(name = "是否使用过", readConverterExp = "0=：否1：是")
    @Column(name="is_used")
    @ApiModelProperty(value = "是否使用过")
    private String isUsed;

    /** 排序 */
    @Excel(name = "排序")
    @Column(name="sort")
    @ApiModelProperty(value = "排序")
    private Long sort;

    /** 参会时间段 */
    @Excel(name = "参会时间段")
    @Column(name="time")
    @ApiModelProperty(value = "参会时间段")
    private String time;

    /** 删除标识（0：正常1：删除） */
    @Column(name="del_flag")
    @ApiModelProperty(value = "参会时间段")
    private String delFlag;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "参会时间段")
    private String createBy;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "参会时间段")
    private Date createTime;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "参会时间段")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "参会时间段")
    private Date updateTime;


}
