package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsBanner;

/**
 * 轮播图Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsBannerService  {
    /**
     * 查询轮播图
     *
     * @param bannerId 轮播图ID
     * @return 轮播图
     */
    CmsBanner findById(Long bannerId);

    /**
     * 分页查询轮播图列表
     *
     * @param req 轮播图
     * @return 轮播图集合
     */
    Page<CmsBanner> findCmsBannerPage(CmsBanner req);

    /**
     * 查询轮播图列表
     *
     * @param req 轮播图
     * @return 轮播图集合
     */
    List<CmsBanner> findCmsBannerList(CmsBanner req);

    /**
     * 新增轮播图
     *
     * @param cmsBanner 轮播图
     * @return 结果
     */
    void save(CmsBanner cmsBanner);

    /**
     * 批量删除轮播图
     *
     * @param bannerIds 需要删除的轮播图ID
     * @return 结果
     */
    void deleteByIds(List<Long> bannerIds);

    /**
     * 删除轮播图信息
     *
     * @param bannerId 轮播图ID
     * @return 结果
     */
    void deleteCmsBannerById(Long bannerId);
}
