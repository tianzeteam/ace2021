package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import com.yuejike.system.domain.SysNotice;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 站内信对象 sys_inbox
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "sys_inbox")
@Data
public class SysInbox extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="inbox_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long inboxId;

    /** 发起人id */
    @Excel(name = "发起人id")
    @Column(name="send_id")
    @ApiModelProperty(value = "发起人id")
    private Long sendId;

    /** 接收人id */
    @Excel(name = "接收人id")
    @Column(name="accept_id")
    @ApiModelProperty(value = "接收人id")
    private Long acceptId;



    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "内容")
    private String createBy;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "内容")
    private Date createTime;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "内容")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "内容")
    private Date updateTime;

    /** 删除标识（0：正常1：删除） */
    @Column(name="del_flag")
    @ApiModelProperty(value = "内容")
    private String delFlag;

    /** 状态（0：未读1：已读） */
    @Excel(name = "状态", readConverterExp = "0=：未读1：已读")
    @Column(name="status")
    @ApiModelProperty(value = "状态")
    private String status;


    /** 通知id */
    @Excel(name = "通知id")
    @Column(name="notice_id")
    @ApiModelProperty(value = "状态")
    private Long noticeId;

    @OneToOne
    @JoinColumn(name = "notice_id",insertable = false,updatable = false)
    private SysNotice notice;
}
