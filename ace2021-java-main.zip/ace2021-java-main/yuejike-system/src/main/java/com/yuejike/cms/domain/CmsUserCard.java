package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 名片对象 cms_user_card
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_user_card")
@Data
public class CmsUserCard extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="card_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long cardId;

    /** 名字 */
    @Excel(name = "名字")
    @Column(name="name")
    @ApiModelProperty(value = "名字")
    private String name;

    /** 电话 */
    @Excel(name = "电话")
    @Column(name="phone")
    @ApiModelProperty(value = "电话")
    private String phone;

    /** 用户id */
    @Excel(name = "用户id")
    @Column(name="user_id")
    @ApiModelProperty(value = "用户id")
    private Long userId;

    /** 删除标识（0：正常 1：删除） */
    @Column(name="del_flag")
    @ApiModelProperty(value = "用户id")
    private String delFlag;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "用户id")
    private Date createTime;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "用户id")
    private Date updateTime;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "用户id")
    private String createBy;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "用户id")
    private String updateBy;

    /** 邮箱 */
    @Excel(name = "邮箱")
    @Column(name="email")
    @ApiModelProperty(value = "邮箱")
    private String email;

    /** 地址 */
    @Excel(name = "地址")
    @Column(name="address")
    @ApiModelProperty(value = "地址")
    private String address;

    /** 职位 */
    @Excel(name = "职位")
    @Column(name="position")
    @ApiModelProperty(value = "职位")
    private String position;

    /** 公司名称 */
    @Excel(name = "公司名称")
    @Column(name="company_name")
    @ApiModelProperty(value = "公司名称")
    private String companyName;


}
