package com.yuejike.cms.domain;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 场馆信息对象 cms_hall
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_hall")
@Data
public class CmsHall extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="hall_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long hallId;

    @Transient
    private List<Long> hallIds;

    /** 场馆名称 */
    @Excel(name = "场馆名称")
    @Column(name="name")
    @ApiModelProperty(value = "场馆名称")
    private String name;

    /** 场馆地址 */
    @Excel(name = "场馆地址")
    @Column(name="address")
    @ApiModelProperty(value = "场馆地址")
    private String address;

    /** 场馆面积 */
    @Excel(name = "场馆面积")
    @Column(name="area")
    @ApiModelProperty(value = "场馆面积")
    private String area;

    /** 场馆所在城市 */
    @Excel(name = "场馆所在城市")
    @Column(name="city")
    @ApiModelProperty(value = "场馆所在城市")
    private String city;

    /** 场馆简介 */
    @Excel(name = "场馆简介")
    @Column(name="introduce")
    @ApiModelProperty(value = "场馆简介")
    private String introduce;

    /** 展厅号 */
    @Excel(name = "展厅号")
    @Column(name="hall_no")
    @ApiModelProperty(value = "展厅号")
    private String hallNo;

    /** 展位号 */
    @Excel(name = "展位号")
    @Column(name="booth_no")
    @ApiModelProperty(value = "展位号")
    private String boothNo;

    /** 删除标识 */
    @Column(name="del_flag")
    @ApiModelProperty(value = "展位号")
    private String delFlag;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "展位号")
    private Date createTime;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "展位号")
    private Date updateTime;

    /** 创建人id */
    @Column(name="create_by")
    @ApiModelProperty(value = "展位号")
    private String createBy;

    /** 更新人id */
    @Column(name="update_by")
    @ApiModelProperty(value = "展位号")
    private String updateBy;

    /** 状态(0：上架:1：下架) */
    @Excel(name = "状态(0：上架:1：下架)")
    @Column(name="status")
    @ApiModelProperty(value = "状态(0：上架:1：下架)")
    private String status;

    /** 场馆图 */
    @Excel(name = "场馆图")
    @Column(name="img_url")
    @ApiModelProperty(value = "场馆图")
    private String imgUrl;


    /** 套餐配置 */
    @Excel(name = "套餐配置")
    @Column(name="package_configuration")
    @ApiModelProperty(value = "套餐配置")
    private String packageConfiguration;


    /** 套餐配置附件 */
    @Excel(name = "套餐配置附件")
    @Column(name="package_configuration_url")
    @ApiModelProperty(value = "套餐配置附件")
    private String packageConfigurationUrl;


    /** 填报信息附件 */
    @Excel(name = "填报信息附件")
    @Column(name="introduce_url")
    @ApiModelProperty(value = "填报信息附件")
    private String introduceUrl;


}
