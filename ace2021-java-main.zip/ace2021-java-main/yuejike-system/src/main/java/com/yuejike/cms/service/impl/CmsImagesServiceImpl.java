package com.yuejike.cms.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.yuejike.common.utils.DateUtils;

import java.util.Date;
import org.apache.commons.lang3.StringUtils;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yuejike.cms.dao.CmsImagesDao;
import com.yuejike.cms.domain.CmsImages;
import com.yuejike.cms.service.ICmsImagesService;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/**
 * 图片关联Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsImagesServiceImpl implements ICmsImagesService {

    @Autowired
    private CmsImagesDao cmsImagesDao;

    /**
     * 查询图片关联
     *
     * @param imageId 图片关联ID
     * @return 图片关联
     */
    @Override
    public CmsImages findById(Long imageId) {
        return cmsImagesDao.findById(imageId).get();
    }

    /**
     * 分页查询图片关联列表
     *
     * @param req 图片关联
     * @return 图片关联
     */
    @Override
    public Page<CmsImages> findCmsImagesPage(CmsImages req) {
        Specification<CmsImages> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsImages> page = cmsImagesDao.findAll(example, pageable);
        return page;
    }

    /**
     * 分页查询图片关联列表
     *
     * @param req 图片关联
     * @return 图片关联
     */
    @Override
    public List<CmsImages> findCmsImagesList(CmsImages req) {
        Specification<CmsImages> example = formatQueryParams(req);
        List<CmsImages> list = cmsImagesDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    private Specification<CmsImages> formatQueryParams(CmsImages req){
        Specification<CmsImages> example = new Specification<CmsImages>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<CmsImages> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getImageId()){
                    Predicate pre = cb.equal(root.get("imageId").as(Long.class), req.getImageId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getName())){
                    Predicate pre = cb.like(root.get("name").as(String.class), "%" + req.getName()+ "%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getType())){
                    Predicate pre = cb.equal(root.get("type").as(String.class), req.getType());
                    list.add(pre);
                }
                if (null != req.getBusinessId()){
                    Predicate pre = cb.equal(root.get("businessId").as(Long.class), req.getBusinessId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getImgUrl())){
                    Predicate pre = cb.equal(root.get("imgUrl").as(String.class), req.getImgUrl());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getRemark())){
                    Predicate pre = cb.equal(root.get("remark").as(String.class), req.getRemark());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())){
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }
                if (null != req.getCreateTime()){
                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
                if (null != req.getUpdateTime()){
                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
                    list.add(pre);
                }
                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）图片关联
     *
     * @param cmsImages 图片关联
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void save(CmsImages cmsImages) {
        cmsImages.setCreateTime(DateUtils.getNowDate());
        cmsImagesDao.save(cmsImages);
    }


    /**
     * 批量删除图片关联
     *
     * @param imageIds 需要删除的图片关联ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> imageIds) {
        List<CmsImages> existBeans = cmsImagesDao.findAllById(imageIds);
        if(!existBeans.isEmpty()){
            cmsImagesDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除图片关联信息
     *
     * @param imageId 图片关联ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsImagesById(Long imageId) {
         cmsImagesDao.deleteById(imageId);
    }
}
