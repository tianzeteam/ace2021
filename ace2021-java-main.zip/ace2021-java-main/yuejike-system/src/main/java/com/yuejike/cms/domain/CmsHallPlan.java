package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 展区规划对象 cms_hall_plan
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_hall_plan")
@Data
public class CmsHallPlan extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="plan_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long planId;

    /** 展会id */
    @Excel(name = "展会id")
    @Column(name="exposition_id")
    @ApiModelProperty(value = "展会id")
    private Long expositionId;

    /** 展区分类id */
    @Excel(name = "展区分类id")
    @Column(name="classification_id")
    @ApiModelProperty(value = "展区分类id")
    private Long classificationId;

    /** 展区图url */
    @Excel(name = "展区图url")
    @Column(name="img_url")
    @ApiModelProperty(value = "展区图url")
    private String imgUrl;

    /** 排序 */
    @Excel(name = "排序")
    @Column(name="sort")
    @ApiModelProperty(value = "排序")
    private Integer sort;

    /** 是否显示（0：显示1：隐藏） */
    @Excel(name = "是否显示", readConverterExp = "0=：显示1：隐藏")
    @Column(name="visible")
    @ApiModelProperty(value = "是否显示")
    private String visible;

    /** 删除标识（0：正常1：删除） */
    @Column(name="del_flag")
    @ApiModelProperty(value = "是否显示")
    private String delFlag;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "是否显示")
    private String createBy;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "是否显示")
    private Date createTime;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "是否显示")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "是否显示")
    private Date updateTime;


}
