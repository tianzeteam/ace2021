package com.yuejike.cms.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import com.yuejike.cms.dao.CmsConferenceDao;
import com.yuejike.cms.domain.CmsConference;
import com.yuejike.cms.domain.CmsLive;
import com.yuejike.cms.service.ICmsConferenceService;
import com.yuejike.cms.service.ICmsLiveService;
import com.yuejike.common.utils.DateUtils;

import org.apache.commons.lang3.StringUtils;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yuejike.cms.dao.CmsEnrollDao;
import com.yuejike.cms.domain.CmsEnroll;
import com.yuejike.cms.service.ICmsEnrollService;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/**
 * 会议报名Service业务层处理
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Transactional(readOnly = true)
@Service
public class CmsEnrollServiceImpl implements ICmsEnrollService {

    @Autowired
    private CmsEnrollDao cmsEnrollDao;
    @Autowired
    private ICmsConferenceService cmsConferenceService;
    @Autowired
    private ICmsLiveService cmsLiveService;

    /**
     * 查询会议报名
     *
     * @param enrollId 会议报名ID
     * @return 会议报名
     */
    @Override
    public CmsEnroll findById(Long enrollId) {
        return cmsEnrollDao.findById(enrollId).get();
    }

    /**
     * 分页查询会议报名列表
     *
     * @param req 会议报名
     * @return 会议报名
     */
    @Override
    public Page<CmsEnroll> findCmsEnrollPage(CmsEnroll req) {
        Specification<CmsEnroll> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        Page<CmsEnroll> page = cmsEnrollDao.findAll(example, pageable);
        for (CmsEnroll cmsEnroll : page) {
            if(cmsEnroll.getConferenceId() != null){
                CmsConference conference = cmsConferenceService.findById(cmsEnroll.getConferenceId());
                cmsEnroll.setConference(conference);
            }
            if(cmsEnroll.getLiveId() != null){
                CmsLive live = cmsLiveService.findById(cmsEnroll.getLiveId());

                cmsEnroll.setLive(live);
            }

        }
        return page;
    }

    /**
     * 分页查询会议报名列表
     *
     * @param req 会议报名
     * @return 会议报名
     */
    @Override
    public List<CmsEnroll> findCmsEnrollList(CmsEnroll req) {
        Specification<CmsEnroll> example = formatQueryParams(req);
        List<CmsEnroll> list = cmsEnrollDao.findAll(example, Sort.by(Sort.Direction.DESC,"createTime"));
        return list;
    }

    private Specification<CmsEnroll> formatQueryParams(CmsEnroll req){
        Specification<CmsEnroll> example = new Specification<CmsEnroll>() {
            private static final long serialVersionUID = 1L;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat sdfmat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            @Override
            public Predicate toPredicate(Root<CmsEnroll> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (null != req.getEnrollId()){
                    Predicate pre = cb.equal(root.get("enrollId").as(Long.class), req.getEnrollId());
                    list.add(pre);
                }
                if (null != req.getUserId()){
                    Predicate pre = cb.equal(root.get("userId").as(Long.class), req.getUserId());
                    list.add(pre);
                }
                if (null != req.getExhibitorId()){
                    Predicate pre = cb.equal(root.get("exhibitorId").as(Long.class), req.getExhibitorId());
                    list.add(pre);
                }
                if (null != req.getConferenceId()){
                    Predicate pre = cb.equal(root.get("conferenceId").as(Long.class), req.getConferenceId());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getStatus())){
                    Predicate pre = cb.like(root.get("status").as(String.class),"%"+ req.getStatus()+"%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getDelFlag())){
                    Predicate pre = cb.equal(root.get("delFlag").as(String.class), req.getDelFlag());
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getCreateBy())){
                    Predicate pre = cb.equal(root.get("createBy").as(String.class), req.getCreateBy());
                    list.add(pre);
                }

                if (StringUtils.isNotBlank(req.getUpdateBy())){
                    Predicate pre = cb.equal(root.get("updateBy").as(String.class), req.getUpdateBy());
                    list.add(pre);
                }
//                if (null != req.getUpdateTime()){
//                    Predicate pre = cb.equal(root.get("updateTime").as(Date.class), req.getUpdateTime());
//                    list.add(pre);
//                }
                if (StringUtils.isNotBlank(req.getRejectReason())){
                    Predicate pre = cb.equal(root.get("rejectReason").as(String.class), req.getRejectReason());
                    list.add(pre);
                }
                if (null != req.getReviewerId()){
                    Predicate pre = cb.equal(root.get("reviewerId").as(Long.class), req.getReviewerId());
                    list.add(pre);
                }
                if (null != req.getLiveId()){
                    Predicate pre = cb.equal(root.get("liveId").as(Long.class), req.getLiveId());
                    list.add(pre);
                }
//                模糊查询
                if (StringUtils.isNotBlank(req.getStatus())){
                    Predicate pre = cb.like(root.get("status").as(String.class),"%"+ req.getStatus()+"%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getType())){
                    Predicate pre = cb.like(root.get("type").as(String.class),"%"+ req.getType()+"%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getExhibitorName())){
                    Predicate pre = cb.like(root.get("exhibitorName").as(String.class),"%"+ req.getExhibitorName()+"%");
                    list.add(pre);
                }
                if (StringUtils.isNotBlank(req.getConferenceName())){
                    Predicate pre = cb.like(root.get("conferenceName").as(String.class),"%"+ req.getConferenceName()+"%");
                    list.add(pre);
                }
                if (null != req.getStartTime() && null !=req.getEndTime()){
//                    Predicate pre = cb.equal(root.get("createTime").as(Date.class), req.getCreateTime());
                    Predicate pre = null;
                    try {
                        Calendar endTime = Calendar.getInstance();
                        endTime.setTime(req.getEndTime());
                        endTime.add(Calendar.HOUR,23);
                        endTime.add(Calendar.MINUTE,59);
                        endTime.add(Calendar.SECOND,59);
                        pre = cb.between(root.get("createTime"),
                                sdfmat.parse(sdfmat.format(req.getStartTime())),
                                sdfmat.parse(sdfmat.format(endTime.getTime())));
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    list.add(pre);
                }

                if (list.isEmpty()) {
                    return null;
                }
                return cb.and(list.toArray(new Predicate[0]));
            }
        };
        return example;
    }

    /**
     * 保存（新增/修改）会议报名
     *
     * @param cmsEnroll 会议报名
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void save(CmsEnroll cmsEnroll) {
        // cmsEnroll.setCreateTime(DateUtils.getNowDate());
        cmsEnrollDao.save(cmsEnroll);
    }


    /**
     * 批量删除会议报名
     *
     * @param enrollIds 需要删除的会议报名ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(List<Long> enrollIds) {
        List<CmsEnroll> existBeans = cmsEnrollDao.findAllById(enrollIds);
        if(!existBeans.isEmpty()){
            cmsEnrollDao.deleteAll(existBeans);
        }
    }

    /**
     * 删除会议报名信息
     *
     * @param enrollId 会议报名ID
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteCmsEnrollById(Long enrollId) {
         cmsEnrollDao.deleteById(enrollId);
    }

    @Override
    public List<CmsEnroll> findByLiveId(Long liveId) {
        return cmsEnrollDao.findByLiveId(liveId);
    }

    @Override
    public CmsEnroll findByLiveIdAndUserId(Long liveId, Long userId) {
        return cmsEnrollDao.findByLiveIdAndUserId(liveId, userId);
    }

    @Transactional(readOnly = false)
    @Override
    public int updateByLiveId(Long liveId) {
        return cmsEnrollDao.updateByLiveId(liveId);
    }

    @Transactional(readOnly = false)
    @Override
    public int updateByConferenceId(Long conferenceId) {
        return cmsEnrollDao.updateByConferenceId(conferenceId);
    }
}
