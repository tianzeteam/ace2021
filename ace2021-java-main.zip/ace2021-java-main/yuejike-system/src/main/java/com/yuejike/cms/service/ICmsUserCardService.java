package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsUserCard;

/**
 * 名片Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsUserCardService  {
    /**
     * 查询名片
     *
     * @param cardId 名片ID
     * @return 名片
     */
    CmsUserCard findById(Long cardId);

    /**
     * 分页查询名片列表
     *
     * @param req 名片
     * @return 名片集合
     */
    Page<CmsUserCard> findCmsUserCardPage(CmsUserCard req);

    /**
     * 查询名片列表
     *
     * @param req 名片
     * @return 名片集合
     */
    List<CmsUserCard> findCmsUserCardList(CmsUserCard req);

    /**
     * 新增名片
     *
     * @param cmsUserCard 名片
     * @return 结果
     */
    void save(CmsUserCard cmsUserCard);

    /**
     * 批量删除名片
     *
     * @param cardIds 需要删除的名片ID
     * @return 结果
     */
    void deleteByIds(List<Long> cardIds);

    /**
     * 删除名片信息
     *
     * @param cardId 名片ID
     * @return 结果
     */
    void deleteCmsUserCardById(Long cardId);

    CmsUserCard findByUserId(Long id);
}
