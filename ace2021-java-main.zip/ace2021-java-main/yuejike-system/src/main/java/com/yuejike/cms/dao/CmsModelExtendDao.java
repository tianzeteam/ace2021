package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsModelExtend;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


/**
 * 模型扩展信息Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Repository
public interface CmsModelExtendDao extends JpaRepository<CmsModelExtend, Long>, JpaSpecificationExecutor<CmsModelExtend> {

    @Query(value = "SELECT cme.* from cms_model_extend cme " +
            "  left join cms_model m on m.model_id = cme.model_id" +
            "  left join cms_category cc on cc.model_id = m.model_id" +
            "  where  cc.category_id=?1  order by cme.update_time",nativeQuery = true)
    List<CmsModelExtend> getModelExtendList(Long categoryId);

    @Transactional
    @Modifying
    @Query(value = "delete from cms_model_extend where model_id =?1",nativeQuery = true)
    int deleteByModelId(Long modelId);
}
