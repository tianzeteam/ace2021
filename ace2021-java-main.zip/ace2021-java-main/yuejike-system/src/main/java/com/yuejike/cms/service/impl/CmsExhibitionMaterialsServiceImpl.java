package com.yuejike.cms.service.impl;

import com.yuejike.cms.dao.ExhibitionMaterialsDao;
import com.yuejike.cms.domain.ExhibitionMaterials;
import com.yuejike.cms.domain.SysUserExhibitor;
import com.yuejike.cms.service.ICmsExhibitionMaterialsService;
import com.yuejike.common.core.page.PageDomain;
import com.yuejike.common.core.page.TableSupport;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 * @author JinZJ
 * @version 1.0
 * @Description:
 * @date 2021/11/17 11:08
 */
@Transactional(readOnly = true)
@Service
public class CmsExhibitionMaterialsServiceImpl implements ICmsExhibitionMaterialsService {

    @Autowired
    private ExhibitionMaterialsDao exhibitionMaterialsDao;

    @Override
    public Page<ExhibitionMaterials> selectMaterialsList(ExhibitionMaterials req) {
        Specification<ExhibitionMaterials> example = formatQueryParams(req);
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Pageable pageable = PageRequest.of(pageDomain.getPageNo(),
                Optional.ofNullable(pageDomain.getPageSize()).orElse(PageDomain.DEFAULT_PAGE_SIZE),
                Sort.Direction.DESC,
                Optional.ofNullable(pageDomain.getOrderByColumn()).orElse("createTime"));
        return exhibitionMaterialsDao.findAll(example, pageable);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public ExhibitionMaterials insertMaterials(ExhibitionMaterials exhibitionMaterials) {
        return exhibitionMaterialsDao.save(exhibitionMaterials);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteMaterialsByIds(Long[] ids) {
        List<ExhibitionMaterials> existBeans = exhibitionMaterialsDao.findAllById(Arrays.asList(ids.clone()));
        if(!existBeans.isEmpty()){
            exhibitionMaterialsDao.deleteAll(existBeans);
        }
    }

    private Specification<ExhibitionMaterials> formatQueryParams(ExhibitionMaterials req){
        Specification<ExhibitionMaterials> example = new Specification<ExhibitionMaterials>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<ExhibitionMaterials> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (StringUtils.isNotEmpty(req.getContacts())) {
                    Predicate pre = cb.like(root.get("contacts").as(String.class), "%"+req.getContacts()+"%");
                    list.add(pre);
                }
                if (StringUtils.isNotEmpty(req.getContactNumber())) {
                    Predicate pre = cb.like(root.get("contactNumber").as(String.class), "%"+req.getContactNumber()+"%");
                    list.add(pre);
                }
                if (req.getUserId() != null) {
                    Predicate pre = cb.equal(root.get("userId").as(Long.class), req.getUserId());
                    list.add(pre);
                }
                if(req.getParams().get("exhibitorName") != null && req.getParams().get("exhibitorName").toString().equals("")){
                    Join<ExhibitionMaterials, SysUserExhibitor> userJoin = root.join("sysUserExhibitor", JoinType.LEFT);
                    Predicate userPre = cb.like(userJoin.get("name"), "%"+req.getParams().get("exhibitorName").toString()+"%");
                    list.add(userPre);
                }
                return cb.and(list.toArray(new Predicate[0]));
            }

        };
        return example;
    }

}
