package com.yuejike.cms.service;

import com.yuejike.cms.domain.ExhibitionMaterials;
import org.springframework.data.domain.Page;

/**
 * @author JinZJ
 * @version 1.0
 * @Description:
 * @date 2021/11/17 11:08
 */
public interface ICmsExhibitionMaterialsService {

    Page<ExhibitionMaterials> selectMaterialsList(ExhibitionMaterials exhibitionMaterials);

    ExhibitionMaterials insertMaterials(ExhibitionMaterials exhibitionMaterials);

    void deleteMaterialsByIds(Long[] ids);
}
