package com.yuejike.cms.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

/**
 * 直播预约 cms_live_appointment
 *
 * @author cian
 * @since 1.0 2021-11-11
 */
@Entity
@Table(name = " cms_live_appointment")
@Data
public class CmsLiveAppointment extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /** id */
    @Id
    @Column(name="appointment_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long appointmentId;

    /** 预约者id*/
    @Column(name="user_id")
    @ApiModelProperty(value = "预约者id")
    private Long userId;

    /**直播 id */
    @Column(name="live_id")
    @ApiModelProperty(value = "直播id}")
    private Long liveId;

    /** 直播名称 */
    @Column(name="name")
    @ApiModelProperty(value = "直播名称")
    private String name;

    /** 直播开始时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @Column(name="start_time")
    @ApiModelProperty(value = "直播开始时间")
    private Date startTime;


    /** 直播类型（0：论坛直播 1：活动直播） */
    @Column(name="type")
    @ApiModelProperty(value = "直播类型")
    private String type;

    /** 直播介绍 */
    @Column(name="introduce")
    @ApiModelProperty(value = "直播介绍")
    private String introduce;

    /** 预约通知手机号码*/
    @Column(name="mobile")
    @ApiModelProperty(value = "预约通知手机号码")
    private String mobile;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "预约创建时间")
    private Date createTime;


    /** 创建者 */
    @Column(name="create_by")
    @ApiModelProperty(value = "预约创建者")
    private String createBy;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "预约更新人")
    private String updateBy;


    /** 预约状态(0正常 1关闭) */
    @Column(name="status")
    @ApiModelProperty(value = "预约状态（0正常 1关闭")
    private String status;






}
