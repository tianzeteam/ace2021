package com.yuejike.cms.domain;

import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

/**
 * @author JinZJ
 * @version 1.0
 * @Description:
 * @date 2021/11/23 15:21
 */
@Entity
@Table(name = "cms_product_category")
@Data
public class CmsProductCategory extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="category_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long categoryId;

    /** 栏目中文名 */
    @Excel(name = "栏目中文名")
    @Column(name="cn_name")
    @ApiModelProperty(value = "栏目中文名")
    private String cnName;

    /** 栏目英文名 */
    @Excel(name = "栏目英文名")
    @Column(name="en_name")
    @ApiModelProperty(value = "栏目英文名")
    private String enName;

    @Excel(name = "栏目日文名称")
    @Column(name="ja_name")
    @ApiModelProperty(value = "栏目日文名称")
    private String jaName;

    @Excel(name = "栏目韩文名称")
    @Column(name="ko_name")
    @ApiModelProperty(value = "栏目韩文名称")
    private String koName;

    /** 父id */
    @Excel(name = "父id")
    @Column(name="parent_id")
    @ApiModelProperty(value = "父id")
    private Long parentId;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "父id")
    private Date createTime;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "父id")
    private Date updateTime;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "父id")
    private String createBy;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "父id")
    private String updateBy;

    @Excel(name = "排序")
    @Column(name="sort")
    @ApiModelProperty(value = "排序")
    private Integer sort;

    @Transient
    @ApiModelProperty(value = "子集")
    private List<CmsProductCategory> children;

    @Transient
    @ApiModelProperty(value = "父级栏目名称")
    private String parentName;

}
