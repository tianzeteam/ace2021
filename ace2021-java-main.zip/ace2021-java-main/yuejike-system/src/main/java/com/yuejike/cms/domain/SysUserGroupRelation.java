package com.yuejike.cms.domain;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import com.yuejike.common.core.domain.entity.SysUser;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 人员分组关联对象 sys_user_group_relation
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "sys_user_group_relation")
@Data
public class SysUserGroupRelation extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long id;

    /** 分组id */
    @Excel(name = "分组id")
    @Column(name="group_id")
    @ApiModelProperty(value = "分组id")
    private Long groupId;

    /** 用户id */
    @Excel(name = "用户id")
    @Column(name="user_id")
    @ApiModelProperty(value = "用户id")
    private Long userId;
    @Transient
    private List<Long> userIds;
    @Transient
    private List<Long> groupIds;
    /** 删除标识（0：正常 1：删除） */
    @Column(name="del_flag")
    @ApiModelProperty(value = "用户id")
    private String delFlag;

    /** 创建人id */
    @Column(name="create_by")
    @ApiModelProperty(value = "用户id")
    private String createBy;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "用户id")
    private Date createTime;

    /** 更新人id */
    @Column(name="update_by")
    @ApiModelProperty(value = "用户id")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "用户id")
    private Date updateTime;

    // @ManyToMany
    // @JoinColumn(name = "user_id",insertable = false,updatable = false)
    // private SysUser user;
    //
    // @ManyToMany
    // @JoinColumn(name = "group_id",insertable = false,updatable = false)
    // private SysUserGroup group;

}
