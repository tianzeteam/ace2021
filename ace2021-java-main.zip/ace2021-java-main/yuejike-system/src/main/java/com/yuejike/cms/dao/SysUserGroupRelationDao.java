package com.yuejike.cms.dao;

import com.yuejike.cms.domain.SysUserGroupRelation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


/**
 * 人员分组关联Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Repository
public interface SysUserGroupRelationDao extends JpaRepository<SysUserGroupRelation, Long>, JpaSpecificationExecutor<SysUserGroupRelation> {
    @Query(value = "select * from sys_user_group_relation where  user_id=?1",nativeQuery = true)
    SysUserGroupRelation findByUserIdAndGroupId(Long userId);

    @Query(value = "select * from sys_user_group_relation where group_id=?1",nativeQuery = true)
    List<SysUserGroupRelation> findByGroupId(Long groupId);

    @Transactional
    @Modifying
    @Query(value = "delete from sys_user_group_relation where group_id=?1",nativeQuery = true)
    int deleteByGroupId(Long groupId);

}
