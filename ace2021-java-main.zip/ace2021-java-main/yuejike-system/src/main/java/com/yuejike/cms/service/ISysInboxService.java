package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.SysInbox;

/**
 * 站内信Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ISysInboxService  {
    /**
     * 查询站内信
     *
     * @param inboxId 站内信ID
     * @return 站内信
     */
    SysInbox findById(Long inboxId);

    /**
     * 分页查询站内信列表
     *
     * @param req 站内信
     * @return 站内信集合
     */
    Page<SysInbox> findSysInboxPage(SysInbox req);

    Page<SysInbox> findSysInboxByUserId(SysInbox req);
    /**
     * 查询站内信列表
     *
     * @param req 站内信
     * @return 站内信集合
     */
    List<SysInbox> findSysInboxList(SysInbox req);

    /**
     * 新增站内信
     *
     * @param sysInbox 站内信
     * @return 结果
     */
    void save(SysInbox sysInbox);

    /**
     * 批量删除站内信
     *
     * @param inboxIds 需要删除的站内信ID
     * @return 结果
     */
    void deleteByIds(List<Long> inboxIds);

    /**
     * 删除站内信信息
     *
     * @param inboxId 站内信ID
     * @return 结果
     */
    void deleteSysInboxById(Long inboxId);
}
