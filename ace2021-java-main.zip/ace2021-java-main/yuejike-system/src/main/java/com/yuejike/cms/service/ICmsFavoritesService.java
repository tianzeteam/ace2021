package com.yuejike.cms.service;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsFavorites;

/**
 * 收藏Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsFavoritesService  {
    /**
     * 查询收藏
     *
     * @param favoritesId 收藏ID
     * @return 收藏
     */
    CmsFavorites findById(Long favoritesId);

    /**
     * 分页查询收藏列表
     *
     * @param req 收藏
     * @return 收藏集合
     */
    Page<CmsFavorites> findCmsFavoritesPage(CmsFavorites req);

    /**
     * 查询收藏列表
     *
     * @param req 收藏
     * @return 收藏集合
     */
    List<CmsFavorites> findCmsFavoritesList(CmsFavorites req);

    /**
     * 新增收藏
     *
     * @param cmsFavorites 收藏
     * @return 结果
     */
    CmsFavorites save(CmsFavorites cmsFavorites);

    /**
     * 批量删除收藏
     *
     * @param favoritesIds 需要删除的收藏ID
     * @return 结果
     */
    void deleteByIds(List<Long> favoritesIds);

    /**
     * 删除收藏信息
     *
     * @param favoritesId 收藏ID
     * @return 结果
     */
    void deleteCmsFavoritesById(Long favoritesId);

    CmsFavorites findByUserIdAndBusinessTypeAndBusinessId(Long userId,String businessType,Long businessId);

    Long getFavoritesCountByProductId(Long productId);

    List<Map<String, Long>> getFavoritesCountByProductId(Long[] productIds);

}
