package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsNegotiate;
import com.yuejike.cms.dto.CmsNegotiateDTO;
import com.yuejike.common.core.domain.model.LoginUser;
import com.yuejike.common.enums.UserType;
import com.yuejike.common.utils.SecurityUtils;
import com.yuejike.common.utils.bean.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.query.internal.NativeQueryImpl;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Predicate;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Transactional(readOnly = true)
@Service
public class CmsNegotiateDaoCustomImpl implements CmsNegotiateDaoCustom {
    @PersistenceContext
    private EntityManager entityManager;
    @Autowired
    private SysUserExhibitorDao sysUserExhibitorDao;

    @Override
    public Page<CmsNegotiate> findNegotiatePage(CmsNegotiate negotiate, Pageable pageable) {
        ArrayList<Object> params = new ArrayList<>();
        StringBuilder sql = new StringBuilder();
        sql.append("FROM cms_negotiate n ");
        sql.append("LEFT JOIN sys_user u ON (n.send_id = u.user_id)");
        sql.append("LEFT JOIN cms_product p on (n.product_id=p.product_id) ");
        sql.append("LEFT JOIN sys_user ue on (ue.dept_id=n.accept_id and ue.user_type='02') ");
        sql.append("LEFT JOIN sys_user_exhibitor e ON (ue.user_id = e.user_id)");

        buildWhere(sql,negotiate,params);
        Query totalQuery = entityManager.createNativeQuery("select count(*) " + sql.toString());
        for (int i = 0; i < params.size(); i++) {
            totalQuery.setParameter(i + 1, params.get(i));
        }
        List<?> resultList = totalQuery.getResultList();
        if (resultList.isEmpty()) {
            return Page.empty();
        }
       BigInteger total = (BigInteger) resultList.get(0);

        Query contentQuery = entityManager.createNativeQuery("SELECT n.reply,n.start_time as startTime,n.end_time endTime,n.reservation_time reservationTime,n.negotiate_id as negotiateId,n.product_id as productId,n.contacts as contacts,n.phone as phone,n.remark as remark,n.send_id as sendId,n.accept_id as acceptId,n.create_by as createBy,n.create_time as createTime,n.update_by as updateBy,n.update_time as updateTime,n.status as status,n.del_flag as delFlag,u.nick_name as userName,p.name productName,e.name exhibitorName " + sql.toString());
        for (int i = 0; i < params.size(); i++) {
            contentQuery.setParameter(i + 1, params.get(i));
        }
        contentQuery.unwrap(NativeQueryImpl.class).setResultTransformer(Transformers.aliasToBean(CmsNegotiateDTO.class));
        contentQuery.setFirstResult(pageable.getPageNumber() * pageable.getPageSize());
        contentQuery.setMaxResults(pageable.getPageSize());
        List<CmsNegotiateDTO> result = contentQuery.getResultList();
        List<CmsNegotiate> collect = result.stream().map(s -> {
            CmsNegotiate cmsNegotiate = new CmsNegotiate();
            BeanUtils.copyProperties(s, cmsNegotiate);
            cmsNegotiate.setNegotiateId(s.getNegotiateId().longValue());
            cmsNegotiate.setProductId(s.getProductId().longValue());
            cmsNegotiate.setContacts(s.getContacts());
            cmsNegotiate.setPhone(s.getPhone());
            cmsNegotiate.setRemark(s.getRemark());
            cmsNegotiate.setSendId(s.getSendId().longValue());
            cmsNegotiate.setAcceptId(s.getAcceptId().longValue());
            cmsNegotiate.setCreateBy(s.getCreateBy());
            cmsNegotiate.setCreateTime(s.getCreateTime());
            cmsNegotiate.setUpdateTime(s.getUpdateTime());
            cmsNegotiate.setUpdateBy(s.getUpdateBy());
            cmsNegotiate.setDelFlag(s.getDelFlag().toString());

            cmsNegotiate.setStatus(s.getStatus().toString());

            if (s.getEndTime() != null) {
                cmsNegotiate.setEndTime(s.getEndTime().longValue());
            }
            if (s.getStartTime() != null) {
                cmsNegotiate.setStartTime(s.getStartTime().longValue());
            }
            cmsNegotiate.setReply(s.getReply());
            cmsNegotiate.setReservationTime(s.getReservationTime());
            return cmsNegotiate;
        }).collect(Collectors.toList());
        return new PageImpl<>(collect, pageable, total.intValue());
    }

    private void buildWhere(StringBuilder sql, CmsNegotiate negotiate, List<Object> params) {
        sql.append("  where n.del_flag = '0'  ");
         if (StringUtils.isNotBlank(negotiate.getUserName())) {
            sql.append("   AND u.nick_name like ? ");
            params.add("%" + negotiate.getUserName() + "%");
        }
        if (StringUtils.isNotBlank(negotiate.getProductName())) {
            sql.append("   AND p.name like ? ");
            params.add("%" + negotiate.getProductName() + "%");
        }
        if (StringUtils.isNotBlank(negotiate.getExhibitorName())) {
            sql.append("   AND e.name like ? ");
            params.add("%" + negotiate.getExhibitorName() + "%");
        }
        if (null != negotiate.getSendId()){
            sql.append(" and n.send_id = ? ");
            params.add( negotiate.getSendId());
        }
        if (null != negotiate.getAcceptId()){
            sql.append(" and n.accept_id = ? ");
            params.add( negotiate.getAcceptId());
        }
        if (null != negotiate.getDelFlag()){
            sql.append(" and n.del_flag = ? ");
            params.add( "'"+negotiate.getDelFlag()+ "'");
        }
        if (null != negotiate.getStatus()){
            sql.append(" and n.status = ? ");
            params.add( "'"+negotiate.getStatus()+ "'");
        }
//        if (StringUtils.isNotBlank(req.getStatus())) {
//            sql.append("   AND i.status = ? ");
//            params.add(req.getStatus());
//        }
//        if (null != req.getNoticeId()) {
//            sql.append("   AND i.notice_id = ? ");
//            params.add(req.getNoticeId());
//        }
        // if (StringUtils.isNotBlank(req.getContent())) {
        //     sql.append("   AND i.content like ? ");
        //     params.add("%" + req.getContent() + "%");
        // }
        //判断渠道数据权限
        LoginUser loginUser = SecurityUtils.getLoginUserNoThrow();
        boolean isChannel = (loginUser != null && loginUser.getUser() != null
                && loginUser.getUser().getRoles() != null && loginUser.getUser().getRoles()
                .stream().filter(item -> item.getRoleKey().startsWith("channel")).count()>0);
        if(isChannel){
            sql.append(" and (u.channel_id = ? or ue.channel_id = ?) ");
            params.add(loginUser.getUser().getUserId());
            params.add(loginUser.getUser().getUserId());
        }
        //主办方按展区过滤数据权限
        if(loginUser != null && loginUser.getUser() != null && loginUser.getUser().getUserType().equals(UserType.ZBF_JS.getCode())){
            List<Long> planIds = new ArrayList<>();
            if(loginUser.getUser().getRoles() != null){
                loginUser.getUser().getRoles().forEach(role -> {
                    if(com.yuejike.common.utils.StringUtils.isNotEmpty(role.getPlanIds())) {
                        Arrays.stream(role.getPlanIds().split(",")).forEach(it -> {
                            if(!planIds.contains(Long.valueOf(it))){
                                planIds.add(Long.valueOf(it));
                            }
                        });
                    }
                });
            }
            List<Long> tmpUsers = null;
            if(planIds.size()>0){
                tmpUsers = sysUserExhibitorDao.getExhibitorUserIdByPlanIds(planIds);
            }
            String strUserIds = "0";
            if(tmpUsers != null && tmpUsers.size()>0){
                for(Long userId:tmpUsers){
                    strUserIds = strUserIds + "," + userId;
                }
            }
            sql.append(" and (u.user_id in ("+strUserIds+") or ue.user_id in ("+strUserIds+")) ");
        }

        sql.append(negotiate.getParams().getOrDefault("dataScope", ""));
    }
}
