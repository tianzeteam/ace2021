package com.yuejike.cms.dao;

import com.yuejike.cms.domain.CmsClassification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * 分类Dao接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Repository
public interface CmsClassificationDao extends JpaRepository<CmsClassification, Long>, JpaSpecificationExecutor<CmsClassification> {

    @Query(value = "SELECT count(*) FROM `cms_classification` WHERE parent_id =?;   ", nativeQuery = true)
    Integer hasChildByMenuId(Long menuId);

    @Query(value = "select * from cms_classification where parent_id in (?1)",nativeQuery = true)
    List<CmsClassification> findByParentId(List<Long> classificationId);

    @Query(value = "SELECT classification_id FROM cms_hall_plan WHERE plan_id IN (?1)", nativeQuery = true)
    List<Long> getClassificationIdByPlanIds(List<Long> planIds);

}
