package com.yuejike.cms.service;

import java.util.List;

import com.yuejike.model.TreeSelectModel;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsClassification;

/**
 * 分类Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsClassificationService  {
    /**
     * 查询部门管理数据
     *
     * @param classification 部门信息
     * @return 部门信息集合
     */
    List< CmsClassification> selectClassList(CmsClassification classification);
    /**
     * 查询分类
     *
     * @param classificationId 分类ID
     * @return 分类
     */
    CmsClassification findById(Long classificationId);

    /**
     * 分页查询分类列表
     *
     * @param req 分类
     * @return 分类集合
     */
    Page<CmsClassification> findCmsClassificationPage(CmsClassification req);

    /**
     * 查询分类列表
     *
     * @param req 分类
     * @return 分类集合
     */
    List<CmsClassification> findCmsClassificationList(CmsClassification req);

    /**
     * 新增分类
     *
     * @param cmsClassification 分类
     * @return 结果
     */
    void save(CmsClassification cmsClassification);

    /**
     * 批量删除分类
     *
     * @param classificationIds 需要删除的分类ID
     * @return 结果
     */
    void deleteByIds(List<Long> classificationIds);
    /**
     * 是否存在菜单子节点
     *
     * @param classificationId 菜单ID
     * @return 结果 true 存在 false 不存在
     */
    boolean hasChildByMenuId(Long classificationId);

    /**
     * 删除分类信息
     *
     * @param classificationId 分类ID
     * @return 结果
     */
    void deleteCmsClassificationById(Long classificationId);

    /**
     * 生成树形结构
     * @param classifications
     * @return
     */
    List<CmsClassification> buildTree(List<CmsClassification> classifications);

    /**
     * 构建前端所需要下拉树结构
     *
     * @param classifications 分类列表
     * @return 下拉树结构列表
     */
    List<TreeSelectModel> buildTreeSelect(List<CmsClassification> classifications);

    List<CmsClassification> findByParentId(List<Long> classificationId);

}
