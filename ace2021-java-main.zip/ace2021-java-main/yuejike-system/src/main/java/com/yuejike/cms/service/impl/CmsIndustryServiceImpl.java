package com.yuejike.cms.service.impl;

import com.yuejike.cms.dao.CmsIndustryDao;
import com.yuejike.cms.domain.CmsIndustry;
import com.yuejike.cms.service.ICmsIndustryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional(readOnly = true)
@Service
public class CmsIndustryServiceImpl implements ICmsIndustryService {

    @Autowired
    CmsIndustryDao cmsIndustryDao;


    /**
     * 查询全部
     * @return cmsIndustries
     */
    @Override
    public List<CmsIndustry> findAll() {
        return cmsIndustryDao.findAll();
    }

    @Override
    public CmsIndustry findByIndustryId(String industryId) {
        return cmsIndustryDao.findByIndustryId(industryId);
    }
}
