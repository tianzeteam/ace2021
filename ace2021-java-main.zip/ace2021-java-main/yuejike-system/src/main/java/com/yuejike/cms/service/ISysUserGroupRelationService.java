package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.SysUserGroupRelation;

/**
 * 人员分组关联Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ISysUserGroupRelationService  {
    /**
     * 查询人员分组关联
     *
     * @param id 人员分组关联ID
     * @return 人员分组关联
     */
    SysUserGroupRelation findById(Long id);

    /**
     * 分页查询人员分组关联列表
     *
     * @param req 人员分组关联
     * @return 人员分组关联集合
     */
    Page<SysUserGroupRelation> findSysUserGroupRelationPage(SysUserGroupRelation req);

    /**
     * 查询人员分组关联列表
     *
     * @param req 人员分组关联
     * @return 人员分组关联集合
     */
    List<SysUserGroupRelation> findSysUserGroupRelationList(SysUserGroupRelation req);

    /**
     * 新增人员分组关联
     *
     * @param sysUserGroupRelation 人员分组关联
     * @return 结果
     */
    void save(SysUserGroupRelation sysUserGroupRelation);

    /**
     * 批量删除人员分组关联
     *
     * @param ids 需要删除的人员分组关联ID
     * @return 结果
     */
    void deleteByIds(List<Long> ids);

    /**
     * 删除人员分组关联信息
     *
     * @param id 人员分组关联ID
     * @return 结果
     */
    void deleteSysUserGroupRelationById(Long id);

    SysUserGroupRelation findByUserIdAndGroupId(Long userId);

    List<SysUserGroupRelation> findByGroupId(Long groupId);
    int deleteByGroupId(Long groupId);

}
