package com.yuejike.cms.dao;


import com.yuejike.cms.domain.CmsLiveAppointment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


/**
 * 直播预约Dao接口
 *
 * @author cian
 * @since 1.0 2021-11-11
 */
@Repository
public interface CmsLiveAppointmentDao extends JpaRepository<CmsLiveAppointment, Long>, JpaSpecificationExecutor<CmsLiveAppointment> {

}
