package com.yuejike.cms.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;
import java.math.BigInteger;
import java.util.Date;

/**
 * 站内信对象 sys_inbox
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Data
public class SysInboxDTO extends BaseEntity {

//    private static final long serialVersionUID = 1L;

    /** id */
//    @Id
//    @Column(name="inbox_id")
    @ApiModelProperty(value = "${comment}")
    private BigInteger inboxId;

//    /** 发起人id */
//    @Excel(name = "发起人id")
//    @Column(name="send_id")
    @ApiModelProperty(value = "发起人id")
    private BigInteger sendId;

//    /** 接收人id */
//    @Excel(name = "接收人id")
//    @Column(name="accept_id")
    @ApiModelProperty(value = "接收人id")
    private BigInteger acceptId;

    /** 标题 */
//    @Excel(name = "标题")
//    @Column(name="title")
    @ApiModelProperty(value = "标题")
    private String title;

    /** 内容 */
//    @Excel(name = "内容")
//    @Column(name="content")
    @ApiModelProperty(value = "内容")
    private String content;

    /** 创建人 */
//    @Column(name="create_by")
    @ApiModelProperty(value = "内容")
    private String createBy;

    /** 创建时间 */
//    @Column(name="create_time")
    @ApiModelProperty(value = "内容")
    private Date createTime;

    /** 更新人 */
//    @Column(name="update_by")
    @ApiModelProperty(value = "内容")
    private String updateBy;

    /** 更新时间 */
//    @Column(name="update_time")
    @ApiModelProperty(value = "内容")
    private Date updateTime;

    /** 删除标识（0：正常1：删除） */
//    @Column(name="del_flag")
    @ApiModelProperty(value = "内容")
    private Character delFlag;

    /** 状态（0：未读1：已读） */
//    @Excel(name = "状态", readConverterExp = "0=：未读1：已读")
//    @Column(name="status")
    @ApiModelProperty(value = "状态")
    private Character status;

    /** 消息类型（0：站内信1：预约洽谈 2：即时沟通3：直播通知） */
//    @Excel(name = "消息类型", readConverterExp = "0=：站内信1：预约洽谈,2=：即时沟通3：直播通知")
//    @Column(name="type")
    @ApiModelProperty(value = "消息类型")
    private Character type;

    /** 是否立即发布（0：发布 1：暂不发布） */
//    @Excel(name = "是否立即发布", readConverterExp = "0=：发布,1=：暂不发布")
//    @Column(name="is_push")
    @ApiModelProperty(value = "是否立即发布")
    private Character isPush;

    /** 发布时间 */
    @JsonFormat(pattern = "yyyy-MM-dd",timezone = "GMT+8")
//    @Excel(name = "发布时间", width = 30, dateFormat = "yyyy-MM-dd")
//    @Column(name="push_time")
    @ApiModelProperty(value = "发布时间")
    private Date pushTime;

    @ApiModelProperty(value = "发送人")
    @Transient
    private String sendName;

    private BigInteger noticeId;
}
