package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 图片关联对象 cms_images
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
@Entity
@Table(name = "cms_images")
@Data
public class CmsImages extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** id */
    @Id
    @Column(name="image_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "${comment}")
    private Long imageId;

    /** 图片名称 */
    @Excel(name = "图片名称")
    @Column(name="name")
    @ApiModelProperty(value = "图片名称")
    private String name;

    /** 类型(0：展商图片1：展品图片) */
    @Excel(name = "类型(0：展商图片1：展品图片)")
    @Column(name="type")
    @ApiModelProperty(value = "类型(0：展商图片1：展品图片)")
    private String type;

    /** 业务id */
    @Excel(name = "业务id")
    @Column(name="business_id")
    @ApiModelProperty(value = "业务id")
    private Long businessId;

    /** 图片url地址 */
    @Excel(name = "图片url地址")
    @Column(name="img_url")
    @ApiModelProperty(value = "图片url地址")
    private String imgUrl;

    /** 备注 */
    @Excel(name = "备注")
    @Column(name="remark")
    @ApiModelProperty(value = "备注")
    private String remark;

    /** 删除标识 */
    @Column(name="del_flag")
    @ApiModelProperty(value = "备注")
    private String delFlag;

    /** 创建人 */
    @Column(name="create_by")
    @ApiModelProperty(value = "备注")
    private String createBy;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "备注")
    private Date createTime;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "备注")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "备注")
    private Date updateTime;


}
