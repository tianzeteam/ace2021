package com.yuejike.cms.domain;

import com.yuejike.common.core.domain.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.sql.Timestamp;

/**
 * @author JinZJ
 * @version 1.0
 * @Description: 展厅素材
 * @date 2021/11/17 10:57
 */
@Entity
@Table(name = "v3d_exhibition_materials")
@Setter
@Getter
public class ExhibitionMaterials extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "id")
    private Long id;

    @ApiModelProperty(value = "用户id",required=true)
    @Column(name="user_id")
    private Long userId;

    @CreationTimestamp
    @Column(name = "create_time", updatable = false)
    @ApiModelProperty(value = "创建时间", hidden = true)
    private Timestamp createTime;

    @NotNull(message = "压缩包路径不能为空")
    @ApiModelProperty(value = "压缩包路径")
    @Column(name = "zip_path")
    private String zipPath;

    @NotNull(message = "联系人不能为空")
    @ApiModelProperty(value = "联系人")
    @Column(name = "contacts")
    private String contacts;

    @NotNull(message = "联系电话不能为空")
    @ApiModelProperty(value = "联系电话")
    @Column(name = "contact_number")
    private String contactNumber;

    @OneToOne
    @JoinColumn(name = "user_id", insertable = false, updatable = false)
    private SysUserExhibitor sysUserExhibitor;

}
