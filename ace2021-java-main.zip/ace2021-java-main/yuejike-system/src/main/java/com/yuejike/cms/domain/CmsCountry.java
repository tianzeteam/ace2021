package com.yuejike.cms.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.yuejike.common.annotation.Excel;
import com.yuejike.common.core.domain.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import io.swagger.annotations.ApiModelProperty;

/**
 * 国家字典对象 cms_country
 *
 * @author tangdw
 * @since 1.0 2021-08-26
 */
@Entity
@Table(name = "cms_country")
@Data
@JsonIgnoreProperties(value = {"hibernateLazyInitializer"})
public class CmsCountry extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** 国家id */
    @Id
    @Column(name="country_id")
    @ApiModelProperty(value = "${comment}")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long countryId;

    /** 国家名 */
    @Excel(name = "国家名")
    @Column(name="country_name")
    @ApiModelProperty(value = "国家名")
    private String countryName;

    /** 创建者 */
    @Column(name="create_by")
    @ApiModelProperty(value = "国家名")
    private String createBy;

    /** 创建时间 */
    @Column(name="create_time")
    @ApiModelProperty(value = "国家名")
    private Date createTime;

    /** 更新人 */
    @Column(name="update_by")
    @ApiModelProperty(value = "国家名")
    private String updateBy;

    /** 更新时间 */
    @Column(name="update_time")
    @ApiModelProperty(value = "国家名")
    private Date updateTime;

    /** 删除标识(0:正常1:删除) */
    @Column(name="del_flag")
    @ApiModelProperty(value = "国家名")
    private String delFlag;


}
