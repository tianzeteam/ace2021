package com.yuejike.cms.service;

import java.util.List;
import org.springframework.data.domain.Page;
import com.yuejike.cms.domain.CmsHall;

/**
 * 场馆信息Service接口
 *
 * @author tangdw
 * @since 1.0 2021-08-22
 */
public interface ICmsHallService  {
    /**
     * 查询场馆信息
     *
     * @param hallId 场馆信息ID
     * @return 场馆信息
     */
    CmsHall findById(Long hallId);

    /**
     * 分页查询场馆信息列表
     *
     * @param req 场馆信息
     * @return 场馆信息集合
     */
    Page<CmsHall> findCmsHallPage(CmsHall req);

    /**
     * 查询场馆信息列表
     *
     * @param req 场馆信息
     * @return 场馆信息集合
     */
    List<CmsHall> findCmsHallList(CmsHall req);

    /**
     * 新增场馆信息
     *
     * @param cmsHall 场馆信息
     * @return 结果
     */
    CmsHall save(CmsHall cmsHall);

    /**
     * 批量删除场馆信息
     *
     * @param hallIds 需要删除的场馆信息ID
     * @return 结果
     */
    void deleteByIds(List<Long> hallIds);

    /**
     * 删除场馆信息信息
     *
     * @param hallId 场馆信息ID
     * @return 结果
     */
    void deleteCmsHallById(Long hallId);

    /**
     * 修改场馆状态
     * @param cmsHall
     * @return
     */
    int updateHallStatus(CmsHall cmsHall);
}
